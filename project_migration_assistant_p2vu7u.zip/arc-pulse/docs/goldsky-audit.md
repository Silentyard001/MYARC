# MYARC Goldsky Subgraph — Deployment Readiness Audit

**Date:** 2026-09-22  
**Question answered:** Is the existing MYARC subgraph ready to be built and deployed to
Goldsky to replace the RPC-based historical event path currently causing the
Rising/Momentum `eth_getLogs` 429 problem?

---

## Executive Verdict

**NOT READY — two blocking gaps, both in the subgraph itself.**

The subgraph manifest targets the correct contract address and the correct network.
The schema, mapping logic, and GraphQL client are structurally sound. However the
ABI file bundled with the subgraph (`subgraph/abis/MYARC.json`) was generated
from a pre-v5 contract and is missing the `ReviewUpvoted` and `ReviewTipped` events
that were added in v5. Additionally neither event is present in `subgraph.yaml` as
an event handler, nor in `schema.graphql` as an entity, nor in `mapping.ts` as a
handler function.

`ReviewUpvoted` is a **required** event for the Momentum Index (boost velocity
component), and `usePlatformMomentum` already attempts to fetch it via
`getPaginatedLogs` — which is the exact call causing the 429s. Once the subgraph
is updated and deployed, the existing subgraph-first paths in `useProjectMomentum`
and `useOnchainActivity` will immediately pick up the GraphQL path and bypass
`getPaginatedLogs` for all covered events.

There is also no `package.json` inside `subgraph/` — the Graph CLI build toolchain
is not set up in that directory. This must be resolved before `graph build` can run.

---

## Current Data Architecture

```
MYARC contract (0x101d8fb447acafac5a1269a46c6c62af796beb5e on arc-testnet)
  │
  │ events
  ▼
┌─────────────────────────────────────────────────────────┐
│  Goldsky Subgraph (NOT YET DEPLOYED)                    │
│  subgraph/subgraph.yaml                                 │
│  Covers: Voted, VoteRetracted, ReviewPosted,            │
│          ProjectVerified, PollVoteCast, PollRewardClaimed│
│  Missing: ReviewUpvoted, ReviewTipped                   │
└──────────────────────┬──────────────────────────────────┘
                       │ GraphQL (when VITE_SUBGRAPH_URL set)
                       ▼
             src/lib/graphql.ts → querySubgraph()
                       │
              (already consumed by)
                       │
        useOnchainActivity  ←── subgraph-first, RPC fallback
        useProjectMomentum  ←── subgraph-first, RPC fallback
        useVerifiedOwners   ←── subgraph-first, RPC fallback
        useProjectAnalytics ←── subgraph-first, RPC fallback

── RPC fallback (currently the only active path) ─────────────────────────────
src/utils/getLogs.ts → getPaginatedLogs()
  │
  ├─ usePlatformAnalytics  (always RPC — no subgraph path, comment says intentional)
  ├─ usePlatformMomentum   (always RPC — no subgraph path in this hook)
  ├─ useProjectMomentum    (RPC fallback when VITE_SUBGRAPH_URL absent)
  ├─ useOnchainActivity    (RPC fallback when VITE_SUBGRAPH_URL absent)
  ├─ useProjectAnalytics   (RPC fallback when VITE_SUBGRAPH_URL absent)
  └─ useVerifiedOwners     (RPC fallback when VITE_SUBGRAPH_URL absent)
```

**Why 429s are happening:**  
`VITE_SUBGRAPH_URL` is empty → every hook falls through to `getPaginatedLogs` →
each Rising page load triggers ~4–6 `eth_getLogs` scans of the entire chain
history → ThirdWeb rate-limits the session.

---

## Event Coverage Matrix

| Event | In subgraph.yaml | In mapping.ts | In schema.graphql | Frontend consumer | Required for Momentum/Rising |
|---|---|---|---|---|---|
| `Voted` | ✅ | ✅ handleVoted | ✅ Vote entity | useOnchainActivity, useProjectAnalytics, useProjectMomentum, usePlatformMomentum, usePlatformAnalytics | ✅ vote velocity, sentiment |
| `VoteRetracted` | ✅ | ✅ handleVoteRetracted | ✅ VoteRetraction entity | useOnchainActivity, useProjectAnalytics, useProjectMomentum, usePlatformMomentum | ✅ vote velocity (net), sentiment |
| `ReviewPosted` | ✅ | ✅ handleReviewPosted | ✅ Review entity | useOnchainActivity, useProjectAnalytics, useProjectMomentum, usePlatformMomentum | ✅ review velocity |
| `ProjectVerified` | ✅ | ✅ handleProjectVerified | ✅ VerifiedProject entity | useVerifiedOwners | informational (verified badge) |
| `PollVoteCast` | ✅ | ✅ handlePollVoteCast | ✅ PollVote entity | usePlatformAnalytics (poll participation rate) | informational |
| `PollRewardClaimed` | ✅ | ✅ handlePollRewardClaimed | ✅ PollRewardClaim entity | not directly consumed | informational |
| **`ReviewUpvoted`** | ❌ | ❌ | ❌ | **usePlatformMomentum (boost velocity)** | **✅ CRITICAL — boost velocity component** |
| `ReviewTipped` | ❌ | ❌ | ❌ | ReviewTipped toast in ProjectDetailSheet | informational for Momentum (no boost signal) |
| `ReviewFlagged` | ❌ | ❌ | ❌ | useReviewFlags (Supabase-backed, not subgraph) | not required |
| `BatchVoted` | ❌ | ❌ | ❌ | no direct frontend consumer | not required (Voted events cover individual votes) |
| `VerificationFeeCharged` | ❌ | ❌ | ❌ | not consumed | not required |
| `WhitelistAdded` | ❌ | ❌ | ❌ | not consumed | not required |
| `WhitelistRemoved` | ❌ | ❌ | ❌ | not consumed | not required |

---

## Momentum/Rising Data Requirements

| Required datum | Used by | Current source | Goldsky can replace? |
|---|---|---|---|
| All `Voted` events with timestamps | Momentum vote velocity, sentiment | `getPaginatedLogs` (RPC, 429-prone) | ✅ Yes — covered by existing schema |
| All `VoteRetracted` events with timestamps | Momentum net vote count, sentiment | `getPaginatedLogs` (RPC) | ✅ Yes — covered |
| All `ReviewPosted` events with timestamps | Momentum review velocity | `getPaginatedLogs` (RPC) | ✅ Yes — covered |
| All `ReviewUpvoted` events with timestamps + `authorAmount` | Momentum boost velocity (`boostVolume7d`) | `getPaginatedLogs` (RPC) | ⚠️ Only after adding event to subgraph |
| Block timestamps for all above events | Converting block numbers to wall-clock ms | `publicClient.getBlock()` per block | ✅ Yes — `timestamp` field already in all entities |
| `ProjectVerified` owner per project | Verified badge, embed generator | `getPaginatedLogs` (RPC) or subgraph | ✅ Yes — covered |

**Critical data flow for Momentum (Rising → eth_getLogs → 429):**

```
usePlatformMomentum.run()
  └─ getPaginatedLogs(Voted)          ← 429 source, chunked across entire chain
  └─ getPaginatedLogs(VoteRetracted)  ← 429 source
  └─ getPaginatedLogs(ReviewPosted)   ← 429 source
  └─ getPaginatedLogs(ReviewUpvoted)  ← 429 source (no subgraph path even when URL set)
  └─ per-block getBlock() calls       ← eliminated by subgraph timestamps
```

Once subgraph is deployed and `VITE_SUBGRAPH_URL` is set:

- `useProjectMomentum` already has the subgraph-first path — it immediately uses GraphQL for Voted/VoteRetracted/ReviewPosted (eliminating 3 of the 4 `getPaginatedLogs` calls).
- `usePlatformMomentum` has **no subgraph path** — it always calls `getPaginatedLogs`. This hook will continue causing 429s for the Rising page even after deployment unless a subgraph query is added to it.
- `usePlatformAnalytics` also has **no subgraph path** (intentionally, per its comment), but this is only used in the admin panel, which is lower frequency.

---

## Subgraph Gaps

### Gap 1 — ABI file is stale (blocking)
`subgraph/abis/MYARC.json` was generated from the pre-v5 contract. It lacks:
- `ReviewUpvoted` event ABI entry
- `ReviewTipped` event ABI entry
- `MIN_UPVOTE_AMOUNT` constant
- `upvoteProtocolFeeBps` getter
- `getReviewUpvoteStats` function
- `setUpvoteProtocolFeeBps` function
- `upvoteReview` function

The subgraph will fail to compile if `mapping.ts` references `ReviewUpvoted` from
the generated types, because the generated types are derived from this ABI file.

**Fix:** Regenerate `subgraph/abis/MYARC.json` from the current compiled artifact
at `contracts/out/MYARC.sol/MYARC.json` (already up-to-date from `forge build`).

### Gap 2 — ReviewUpvoted not indexed (blocking for Momentum)
`subgraph.yaml`, `schema.graphql`, and `mapping.ts` have no coverage of
`ReviewUpvoted`. The boost velocity component of the Momentum Index requires this
event. Without it, `usePlatformMomentum` will continue using the RPC fallback for
boost data regardless of subgraph availability.

**Fix (3 files):**
1. `schema.graphql`: add `ReviewUpvote` entity with `projectId`, `reviewIndex`,
   `upvoter`, `author`, `authorAmount` (= `totalAmount - protocolFee`), `totalAmount`,
   `protocolFee`, `blockNumber`, `timestamp`.
2. `subgraph.yaml`: add `ReviewUpvote` to entities list and add event handler entry for
   `ReviewUpvoted(indexed bytes32,indexed uint256,indexed address,address,uint256,uint256)`.
3. `mapping.ts`: add `handleReviewUpvoted` handler.

### Gap 3 — No package.json in subgraph/ (blocking for build)
There is no `subgraph/package.json`. The Graph Protocol build toolchain
(`@graphprotocol/graph-cli`, `@graphprotocol/graph-ts`) must be installed as
devDependencies there before `graph codegen` and `graph build` can run.

**Fix:** Create `subgraph/package.json` with the Graph CLI dependencies and scripts.

### Gap 4 — usePlatformMomentum has no subgraph path (causes continued 429s post-deploy)
Even after deployment, `usePlatformMomentum` (which drives the Rising page) has no
GraphQL query path — it always falls back to `getPaginatedLogs`. The subgraph would
only partially solve the 429 problem.

**Fix (recommended):** Add a platform-wide GraphQL query to `src/lib/graphql.ts`
(e.g. `ALL_EVENTS_QUERY` fetching all votes, retractions, reviews, and review upvotes
with pagination) and add a subgraph-first path to `usePlatformMomentum` mirroring the
pattern already established in `useProjectMomentum` and `useOnchainActivity`.

### Gap 5 — ReviewTipped not indexed (minor, not blocking)
`ReviewTipped` is not in the subgraph. It is not currently required for Momentum.
The Activity tab toast for tips works via direct contract read, not subgraph. 
**Not a blocker for deployment.**

---

## Goldsky Readiness

**NOT READY** to deploy as-is. Two blocking issues:

1. No `subgraph/package.json` — cannot run `graph codegen` or `graph build`.
2. ABI file is stale — missing v5 events (`ReviewUpvoted`, `ReviewTipped`).
3. `ReviewUpvoted` not in manifest, schema, or mapping — Momentum boost signal blind.

After the three required changes above, the subgraph will be deployable and will
eliminate `eth_getLogs` 429s for `useProjectMomentum`, `useOnchainActivity`,
`useVerifiedOwners`, and `useProjectAnalytics`. The Rising page
(`usePlatformMomentum`) will need its own subgraph-first path added to fully resolve
the 429 issue.

---

## Required Changes Before Deployment

### File 1: `subgraph/package.json` (create)
```json
{
  "name": "myarc-subgraph",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "codegen": "graph codegen",
    "build":   "graph build",
    "deploy:goldsky": "goldsky subgraph deploy myarc/1.0.0 --path ."
  },
  "devDependencies": {
    "@graphprotocol/graph-cli": "^0.71.0",
    "@graphprotocol/graph-ts":  "^0.31.0"
  }
}
```

### File 2: `subgraph/abis/MYARC.json` (regenerate)
Copy from `contracts/out/MYARC.sol/MYARC.json` (the Foundry build artifact,
already current from the last `forge build`). Do not hand-edit.

### File 3: `subgraph/schema.graphql` (add entity)
```graphql
type ReviewUpvote @entity {
  " tx hash + log index "
  id: ID!
  projectId: String!
  reviewIndex: BigInt!
  upvoter: String!
  author: String!
  authorAmount: BigInt!
  totalAmount: BigInt!
  protocolFee: BigInt!
  blockNumber: BigInt!
  timestamp: BigInt!
}
```

### File 4: `subgraph/subgraph.yaml` (add entity + handler)
Add `ReviewUpvote` to the entities list and add:
```yaml
- event: ReviewUpvoted(indexed bytes32,indexed uint256,indexed address,address,uint256,uint256)
  handler: handleReviewUpvoted
```

### File 5: `subgraph/src/mapping.ts` (add handler + import)
```typescript
import { ReviewUpvoted } from '../generated/MYARC/MYARC'
import { ReviewUpvote } from '../generated/schema'

export function handleReviewUpvoted(event: ReviewUpvoted): void {
  const id = eventId(event.transaction.hash, event.logIndex)
  const entity = new ReviewUpvote(id)
  entity.projectId = event.params.projectId.toHex()
  entity.reviewIndex = event.params.reviewIndex
  entity.upvoter = event.params.upvoter.toHex()
  entity.author = event.params.author.toHex()
  entity.totalAmount = event.params.totalAmount
  entity.protocolFee = event.params.protocolFee
  entity.authorAmount = event.params.totalAmount.minus(event.params.protocolFee)
  entity.blockNumber = event.block.number
  entity.timestamp = event.block.timestamp
  entity.save()
}
```

### File 6: `src/lib/graphql.ts` (add query + type)
Add `GqlReviewUpvote` interface and `ALL_EVENTS_QUERY` for `usePlatformMomentum`.

### File 7: `src/hooks/usePlatformMomentum.ts` (add subgraph-first path)
Mirror the subgraph-first / RPC-fallback pattern from `useProjectMomentum` using
`ALL_EVENTS_QUERY`. This is the change that eliminates the Rising page 429s.

---

## Deployment Plan (post-changes)

### Step 1 — Update ABI
```bash
cp contracts/out/MYARC.sol/MYARC.json subgraph/abis/MYARC.json
```

### Step 2 — Install Graph CLI inside subgraph/
```bash
cd subgraph && npm install   # or bun install once package.json exists
```

### Step 3 — Code generation
```bash
cd subgraph && graph codegen
```
This generates `subgraph/generated/MYARC/MYARC.ts` from the updated ABI.
Verify the generated file contains `ReviewUpvoted` before continuing.

### Step 4 — Build
```bash
cd subgraph && graph build
```
Produces `subgraph/build/`. Fix any AssemblyScript type errors before continuing.

### Step 5 — Goldsky deploy
```bash
goldsky subgraph deploy myarc/1.0.0 --path subgraph/
```
Or using the script in `goldsky.json`:
```bash
goldsky subgraph deploy myarc/1.0.0 --path subgraph/
```
The `goldsky.json` at the project root specifies `name: "myarc"`,
`version: "1.0.0"`, `path: "subgraph/"`.

### Step 6 — Obtain GraphQL endpoint
After deployment the Goldsky dashboard provides the GraphQL URL. It will be of the
form: `https://api.goldsky.com/api/public/<project-id>/subgraphs/myarc/1.0.0/gn`

### Step 7 — Set environment variable
```
VITE_SUBGRAPH_URL=https://api.goldsky.com/api/public/<project-id>/subgraphs/myarc/1.0.0/gn
```
This is the single existing env var already wired throughout the application
(`src/lib/graphql.ts` reads it as `VITE_SUBGRAPH_URL`). No new variable needed.

### Step 8 — Restart Vite dev server
`.env` changes require a dev server restart to take effect (Vite reads env files only
at startup — HMR does not pick up `.env` changes).

### Step 9 — Verify subgraph is indexing
Use the Goldsky dashboard or query:
```graphql
{ _meta { block { number } } }
```
Wait for the indexed block to approach the chain's current head before testing.

### Which RPC fallback to keep during migration
Keep **all existing RPC fallback paths** during migration. They are the safety net
while the subgraph catches up to chain head. Remove only after verifying subgraph
coverage in production.

---

## Post-Deployment Verification Checklist

Test each feature and confirm the data source used (check browser network tab for
GraphQL vs. RPC calls):

| # | Feature | What to verify | Subgraph path? |
|---|---|---|---|
| 1 | Discover | Projects render with vote counts and sentiment | No — Discover reads contract state directly via readContract |
| 2 | Project Detail | Reviews, vote tally, verified badge load | ✅ useProjectAnalytics, useVerifiedOwners use subgraph path |
| 3 | Reviews | Review list renders with sentiments | ✅ Reviews come from contract readContract (getReview), not subgraph |
| 4 | Review Upvotes | Boost stats display on reviews | Partial — useReviewUpvotes uses readContract (getReviewUpvoteStats), not getLogs |
| 5 | Activity tab | Connected wallet's votes and reviews appear | ✅ useOnchainActivity uses subgraph path |
| 6 | Rising page | All 5 sections render with momentum scores | ⚠️ usePlatformMomentum — requires Gap 4 fix for full subgraph path |
| 7 | Community Momentum | Momentum Index and explainers show on Rising cards | ✅ once usePlatformMomentum subgraph path added |
| 8 | Momentum Index | Scores are non-zero for active projects | ✅ verify `momentumIndex > 0` for ArcSwap |
| 9 | Leaderboard | Projects sorted by votes | No — Leaderboard reads contract tallies via readContract |
| 10 | Community Milestones | Achieved milestones show in ProjectDetailSheet | ✅ derived from momentum signals |
| 11 | **Rising / Momentum no 429** | No `eth_getLogs` 429 errors in console | ✅ only after Gap 4 (usePlatformMomentum subgraph path) is implemented |

**Critical post-deploy check for the 429 fix:**  
Open the Rising tab. In the browser DevTools Network panel, confirm requests go to
the Goldsky URL (`api.goldsky.com`) rather than `rpc.testnet.arc.io` for
`eth_getLogs`. If `eth_getLogs` calls still appear, the subgraph-first path in
`usePlatformMomentum` is not yet active.
