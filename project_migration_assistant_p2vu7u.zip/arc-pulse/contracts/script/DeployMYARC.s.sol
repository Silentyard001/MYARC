// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import {Script, console2} from "forge-std/Script.sol";
import {MYARC} from "../MYARC.sol";

/**
 * @title  DeployMYARC
 * @notice Simple deployment script for MYARC on Arc Testnet.
 *
 *         Usage
 *         ─────
 *         # Set required env vars:
 *         export PRIVATE_KEY=0x...          # deployer private key
 *         export EPOCH_DURATION=604800      # 7 days in seconds (optional, 0 = default)
 *
 *         # Dry-run (no broadcast):
 *         forge script contracts/script/DeployMYARC.s.sol \
 *           --rpc-url https://rpc.testnet.arc.io \
 *           --sig "run()"
 *
 *         # Broadcast (actual deployment):
 *         forge script contracts/script/DeployMYARC.s.sol \
 *           --rpc-url https://rpc.testnet.arc.io \
 *           --broadcast \
 *           --sig "run()"
 *
 *         The deployed address is printed to stdout as:
 *           MYARC deployed at: 0x...
 *
 *         Copy that address into:
 *           - AGENTS.md  under  ## Deployed Contracts
 *           - .env       as     VITE_MYARC_ADDRESS=0x...
 */
contract DeployMYARC is Script {
    function run() external returns (address deployed) {
        uint256 deployerKey   = vm.envUint("PRIVATE_KEY");
        uint256 epochDuration = vm.envOr("EPOCH_DURATION", uint256(0));
        // If INITIAL_OWNER is set, transfer ownership to that address at deploy
        // time instead of leaving it with the deployer wallet.
        address initialOwner  = vm.envOr("INITIAL_OWNER", address(0));

        address deployer = vm.addr(deployerKey);
        console2.log("Deployer       :", deployer);
        console2.log("Initial owner  :", initialOwner == address(0) ? deployer : initialOwner);
        console2.log("Chain ID       :", block.chainid);
        console2.log("Epoch duration :", epochDuration == 0 ? 604800 : epochDuration, "s");

        vm.startBroadcast(deployerKey);
        MYARC pulse = new MYARC(epochDuration, initialOwner);
        vm.stopBroadcast();

        deployed = address(pulse);
        console2.log("MYARC deployed at:", deployed);
        console2.log("Domain separator    :", vm.toString(pulse.domainSeparator()));
        console2.log("VOTE_TYPEHASH       :", vm.toString(pulse.VOTE_TYPEHASH()));
    }
}
