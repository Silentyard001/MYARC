// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import {EIP712} from "@openzeppelin/contracts/utils/cryptography/EIP712.sol";
import {ECDSA} from "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";

/**
 * @title  MYARC
 * @notice Social sentiment registry for the Arc ecosystem.
 *
 *         Core capabilities
 *         ─────────────────
 *         • vote / retractVote   — per-address, per-project sentiment tracking
 *         • batchVote            — vote on multiple projects in one transaction
 *         • voteBySig            — EIP-712 gasless meta-transactions
 *         • postReview           — append-only text reviews (max 400 bytes)
 *         • flagReview           — community spam-reporting with event emission
 *         • Epoch voting         — configurable time-windows for sentiment snapshots
 *         • verifyProject        — first-claim project ownership verification
 *         • createPoll           — owner-only staked community polls
 *         • voteOnPoll           — vote with native-token stake
 *         • claimPollReward      — proportional reward distribution to winning voters
 *
 *         PROJECT ID ENCODING
 *         ───────────────────
 *         Project IDs are right-padded UTF-8 slugs cast to bytes32, identical
 *         to the Solidity literal `bytes32("arcswap")`. The frontend mirrors
 *         this with viem's `padHex(stringToHex(slug), { size: 32, dir: 'right' })`.
 *         Slugs must be ≤ 32 ASCII characters. Do NOT use keccak256 — the
 *         frontend and test suite both rely on this deterministic encoding.
 */
contract MYARC is EIP712, Ownable {
    using ECDSA for bytes32;

    // ─── Types ────────────────────────────────────────────────────────────────

    enum Sentiment {
        Bullish,
        Neutral,
        Bearish
    }

    struct VoteTally {
        uint128 bullish;
        uint128 neutral;
        uint128 bearish;
    }

    struct Review {
        address author;
        Sentiment sentiment;
        uint40 timestamp;
        string body;
    }

    // ─── Poll types ───────────────────────────────────────────────────────────

    struct Poll {
        string question;
        string[] options;
        uint40 endsAt;
        bool exists;
    }

    struct PollVoteRecord {
        uint8 optionIndex;
        uint256 stake;
        bool claimed;
    }

    // ─── EIP-712 type hash ────────────────────────────────────────────────────

    /// keccak256("Vote(bytes32 projectId,uint8 sentiment,uint256 nonce,uint256 deadline)")
    bytes32 public constant VOTE_TYPEHASH =
        keccak256("Vote(bytes32 projectId,uint8 sentiment,uint256 nonce,uint256 deadline)");

    // ─── Constants ────────────────────────────────────────────────────────────

    uint256 public constant MAX_REVIEW_LENGTH = 400;

    /// @notice Maximum number of projects per batchVote call (gas-cap).
    uint256 public constant MAX_BATCH_SIZE = 50;

    /// @notice Minimum stake to vote on a poll (0.001 USDC in Arc's 18-decimal native denomination).
    uint256 public constant MIN_POLL_STAKE = 1e15;

    /// @notice Minimum value to upvote a review (same denomination and minimum as MIN_POLL_STAKE).
    uint256 public constant MIN_UPVOTE_AMOUNT = 1e15;

    // ─── Storage ──────────────────────────────────────────────────────────────

    /// @notice Aggregate (all-time) vote counts per project.
    mapping(bytes32 projectId => VoteTally) public tallies;

    /// @notice Aggregate vote counts per project per epoch.
    mapping(uint256 epochId => mapping(bytes32 projectId => VoteTally)) public epochTallies;

    /// @notice Duration of a single epoch in seconds (configurable at deploy; immutable after).
    uint256 public immutable epochDuration;

    /// @notice Block timestamp when the epoch clock started.
    uint256 public immutable epochStart;

    /// @notice Current packed vote for each (voter, project) pair.
    ///         0 = no vote, 1 = Bullish, 2 = Neutral, 3 = Bearish.
    mapping(address voter => mapping(bytes32 projectId => uint8)) private _votes;

    /// @notice Per-(voter, project, epoch) vote — tracks whether a voter already
    ///         cast a vote in a given epoch (packed same as _votes).
    mapping(address voter => mapping(bytes32 projectId => mapping(uint256 epochId => uint8)))
        private _epochVotes;

    /// @notice All reviews per project, in submission order.
    mapping(bytes32 projectId => Review[]) private _reviews;

    /// @notice Total number of reviews per project (cheaper to cache).
    mapping(bytes32 projectId => uint256) public reviewCount;

    /// @notice Flag count per (projectId, reviewIndex).
    mapping(bytes32 projectId => mapping(uint256 reviewIndex => uint256)) public flagCount;

    /// @notice Per-signer nonce for meta-transaction replay protection.
    mapping(address signer => uint256) public nonces;

    // ─── Project verification storage ────────────────────────────────────────

    /// @notice Verified owner for each project (first-claim-wins).
    mapping(bytes32 projectId => address) private _verifiedOwner;

    /// @notice Fee required to verify a project (in Arc's 18-decimal native denomination).
    ///         Defaults to 5 USDC (5e18). Updatable by the contract owner.
    uint256 public verificationFee = 5e18;

    // ─── Flexible verification fee storage ───────────────────────────────────

    /// @notice Addresses that pay zero verification fee (whitelist).
    mapping(address wallet => bool) public verificationWhitelist;

    /// @notice Per-wallet custom verification fee override.
    mapping(address wallet => uint256) public customVerificationFee;

    /// @notice Whether a custom fee has been explicitly set for a wallet.
    ///         Needed because 0 (free) is a valid custom fee.
    mapping(address wallet => bool) public hasCustomFee;

    /// @notice When true, all new verifications are paused.
    bool public verificationPaused;

    // ─── Tipping storage ──────────────────────────────────────────────────────

    /// @notice Protocol fee in basis points taken from each tip (default 10% = 1000 bps).
    ///         Max 5000 (50%). Remainder goes to the reviewer.
    uint256 public tipProtocolFeeBps = 1000;

    // ─── Review upvote storage ────────────────────────────────────────────────

    /// @notice Protocol fee in basis points taken from each review upvote (default 5% = 500 bps).
    ///         Max 3000 (30%). Remainder goes to the review author.
    uint256 public upvoteProtocolFeeBps = 500;

    /// @notice Total author-received amount per (projectId, reviewIndex) — economic weight signal.
    mapping(bytes32 => mapping(uint256 => uint256)) public reviewUpvoteWeight;

    /// @notice Upvote count per (projectId, reviewIndex).
    mapping(bytes32 => mapping(uint256 => uint256)) public reviewUpvoteCount;

    // ─── Poll storage ─────────────────────────────────────────────────────────

    /// @notice Poll data by pollId.
    mapping(bytes32 pollId => Poll) private _polls;

    /// @notice Vote counts per option per poll.
    mapping(bytes32 pollId => uint256[]) private _pollOptionVotes;

    /// @notice Total stake pool per poll.
    mapping(bytes32 pollId => uint256) public pollTotalStake;

    /// @notice Vote record per (poll, voter).
    mapping(bytes32 pollId => mapping(address voter => PollVoteRecord)) private _pollVotes;

    /// @notice Whether a winner index has been resolved for a poll.
    mapping(bytes32 pollId => bool) public pollWinnerResolved;

    /// @notice Cached winning option index once resolved.
    mapping(bytes32 pollId => uint8) public pollWinnerIndex;

    // ─── Events ───────────────────────────────────────────────────────────────

    event Voted(
        bytes32 indexed projectId,
        address indexed voter,
        Sentiment sentiment,
        bool isChange
    );

    event VoteRetracted(bytes32 indexed projectId, address indexed voter);

    event ReviewPosted(
        bytes32 indexed projectId,
        address indexed author,
        Sentiment sentiment,
        uint256 reviewIndex
    );

    /// @notice Emitted when a community member flags a review for spam/abuse.
    event ReviewFlagged(
        bytes32 indexed projectId,
        uint256 indexed reviewIndex,
        address indexed flagger,
        uint256 totalFlags
    );

    /// @notice Emitted when a batch vote completes.
    event BatchVoted(address indexed voter, uint256 count);

    /// @notice Emitted when a project ownership claim succeeds.
    event ProjectVerified(bytes32 indexed projectId, address indexed owner);

    /// @notice Emitted when a verification fee is charged.
    event VerificationFeeCharged(bytes32 indexed projectId, address indexed verifier, uint256 fee);

    /// @notice Emitted when a wallet is added to the verification whitelist.
    event WhitelistAdded(address indexed wallet);

    /// @notice Emitted when a wallet is removed from the verification whitelist.
    event WhitelistRemoved(address indexed wallet);

    /// @notice Emitted when a staked poll vote is cast.
    event PollVoteCast(
        bytes32 indexed pollId,
        address indexed voter,
        uint8 optionIndex,
        uint256 stake
    );

    /// @notice Emitted when a poll reward is claimed.
    event PollRewardClaimed(
        bytes32 indexed pollId,
        address indexed claimant,
        uint256 amount
    );

    /// @notice Emitted when a reviewer receives a tip.
    event ReviewTipped(
        bytes32 indexed projectId,
        uint256 indexed reviewIndex,
        address indexed tipper,
        address reviewer,
        uint256 amount,
        uint256 protocolFee
    );

    /// @notice Emitted when a review is upvoted with an economic signal.
    event ReviewUpvoted(
        bytes32 indexed projectId,
        uint256 indexed reviewIndex,
        address indexed upvoter,
        address author,
        uint256 totalAmount,
        uint256 protocolFee
    );

    // ─── Errors ───────────────────────────────────────────────────────────────

    error EmptyProjectId();
    error EmptyReviewBody();
    error ReviewTooLong();
    error NoActiveVote();
    error ReviewIndexOutOfBounds(uint256 index, uint256 length);
    error SignatureExpired();
    error InvalidSignature();
    error EmptyBatch();
    error BatchLengthMismatch();
    error BatchTooLarge();
    error AlreadyFlagged();
    error AlreadyVerified();
    error InsufficientVerificationFee();
    error VerificationPaused();
    error PollNotFound();
    error PollAlreadyExists();
    error PollStillActive();
    error PollEnded();
    error PollOptionOutOfBounds();
    error PollAlreadyVoted();
    error InsufficientStake();
    error NoPollVote();
    error NotPollWinner();
    error AlreadyClaimed();
    error TransferFailed();
    error ReviewNotFound();
    error ZeroTipValue();
    error TipFeeBpsTooHigh();
    error CannotUpvoteOwnReview();
    error InsufficientUpvoteAmount();
    error UpvoteFeeBpsTooHigh();
    error FeeTransferFailed();
    error AuthorTransferFailed();

    // ─── Constructor ──────────────────────────────────────────────────────────

    /**
     * @param _epochDuration Length of each voting epoch in seconds.
     *                       Pass 0 to use the default of 7 days (604800s).
     * @param _initialOwner  Address that will own the contract (receives fees,
     *                       can create polls, set verification fee).
     *                       Pass address(0) to default to msg.sender.
     */
    constructor(uint256 _epochDuration, address _initialOwner)
        EIP712("MYARC", "1")
        Ownable(_initialOwner == address(0) ? msg.sender : _initialOwner)
    {
        epochDuration = _epochDuration == 0 ? 7 days : _epochDuration;
        epochStart    = block.timestamp;
    }

    // ─── Epoch helpers ────────────────────────────────────────────────────────

    /**
     * @notice Returns the current epoch ID (0-indexed, advances every epochDuration).
     */
    function currentEpoch() public view returns (uint256) {
        return (block.timestamp - epochStart) / epochDuration;
    }

    /**
     * @notice Returns the Unix timestamp when the next epoch begins.
     */
    function nextEpochStart() external view returns (uint256) {
        uint256 epoch = currentEpoch();
        return epochStart + (epoch + 1) * epochDuration;
    }

    // ─── Vote functions ───────────────────────────────────────────────────────

    /**
     * @notice Cast or update a vote for `projectId` directly.
     */
    function vote(bytes32 projectId, Sentiment sentiment) external {
        if (projectId == bytes32(0)) revert EmptyProjectId();
        _applyVote(msg.sender, projectId, sentiment);
    }

    /**
     * @notice Cast or update votes for multiple projects in a single transaction.
     */
    function batchVote(
        bytes32[] calldata projectIds,
        uint8[]   calldata sentiments
    ) external {
        uint256 n = projectIds.length;
        if (n == 0)                       revert EmptyBatch();
        if (n != sentiments.length)       revert BatchLengthMismatch();
        if (n > MAX_BATCH_SIZE)           revert BatchTooLarge();

        for (uint256 i = 0; i < n; i++) {
            bytes32 pid = projectIds[i];
            if (pid == bytes32(0)) revert EmptyProjectId();
            _applyVote(msg.sender, pid, Sentiment(sentiments[i] % 3));
        }

        emit BatchVoted(msg.sender, n);
    }

    /**
     * @notice Cast or update a vote via an EIP-712 signature (gasless UX).
     */
    function voteBySig(
        bytes32 projectId,
        Sentiment sentiment,
        uint256 nonce,
        uint256 deadline,
        bytes calldata signature
    ) external {
        if (projectId == bytes32(0)) revert EmptyProjectId();
        if (block.timestamp > deadline) revert SignatureExpired();

        bytes32 structHash = keccak256(
            abi.encode(VOTE_TYPEHASH, projectId, uint8(sentiment), nonce, deadline)
        );

        address signer = ECDSA.recover(_hashTypedDataV4(structHash), signature);

        if (nonces[signer] != nonce) revert InvalidSignature();
        nonces[signer]++;

        _applyVote(signer, projectId, sentiment);
    }

    /**
     * @notice Retract the caller's vote for `projectId`.
     */
    function retractVote(bytes32 projectId) external {
        if (projectId == bytes32(0)) revert EmptyProjectId();

        uint8 prev = _votes[msg.sender][projectId];
        if (prev == 0) revert NoActiveVote();

        _votes[msg.sender][projectId] = 0;
        _decrement(projectId, prev);

        uint256 epoch = currentEpoch();
        uint8 epochPrev = _epochVotes[msg.sender][projectId][epoch];
        if (epochPrev != 0) {
            _epochVotes[msg.sender][projectId][epoch] = 0;
            _epochDecrement(epoch, projectId, epochPrev);
        }

        emit VoteRetracted(projectId, msg.sender);
    }

    // ─── Review functions ─────────────────────────────────────────────────────

    /**
     * @notice Post a review for `projectId`.
     */
    function postReview(bytes32 projectId, Sentiment sentiment, string calldata body) external {
        if (projectId == bytes32(0)) revert EmptyProjectId();
        uint256 len = bytes(body).length;
        if (len == 0)                   revert EmptyReviewBody();
        if (len > MAX_REVIEW_LENGTH)    revert ReviewTooLong();

        uint256 idx = _reviews[projectId].length;
        _reviews[projectId].push(
            Review({
                author:    msg.sender,
                sentiment: sentiment,
                timestamp: uint40(block.timestamp),
                body:      body
            })
        );
        reviewCount[projectId] = idx + 1;

        emit ReviewPosted(projectId, msg.sender, sentiment, idx);
    }

    /**
     * @notice Flag a review for spam or abuse.
     */
    function flagReview(bytes32 projectId, uint256 reviewIndex) external {
        uint256 len = _reviews[projectId].length;
        if (reviewIndex >= len) revert ReviewIndexOutOfBounds(reviewIndex, len);

        if (_hasFlagged[msg.sender][projectId][reviewIndex]) revert AlreadyFlagged();
        _hasFlagged[msg.sender][projectId][reviewIndex] = true;

        uint256 total = flagCount[projectId][reviewIndex] + 1;
        flagCount[projectId][reviewIndex] = total;

        emit ReviewFlagged(projectId, reviewIndex, msg.sender, total);
    }

    // ─── Project verification ─────────────────────────────────────────────────

    /**
     * @notice Claim ownership of a project listing. First claim wins.
     *         Fee is computed dynamically: whitelist → 0, custom fee → custom,
     *         otherwise global verificationFee. Excess msg.value is refunded.
     * @param  projectId  The project's bytes32 slug key.
     */
    function verifyProject(bytes32 projectId) external payable {
        if (verificationPaused) revert VerificationPaused();
        if (projectId == bytes32(0)) revert EmptyProjectId();
        if (_verifiedOwner[projectId] != address(0)) revert AlreadyVerified();

        uint256 effectiveFee = getEffectiveFee(msg.sender);
        if (msg.value < effectiveFee) revert InsufficientVerificationFee();

        _verifiedOwner[projectId] = msg.sender;

        // Forward effective fee to contract owner via low-level call
        if (effectiveFee > 0) {
            (bool ok,) = payable(owner()).call{value: effectiveFee}("");
            if (!ok) revert TransferFailed();
        }

        // Refund any excess
        uint256 excess = msg.value - effectiveFee;
        if (excess > 0) {
            (bool refundOk,) = payable(msg.sender).call{value: excess}("");
            if (!refundOk) revert TransferFailed();
        }

        emit ProjectVerified(projectId, msg.sender);
        emit VerificationFeeCharged(projectId, msg.sender, effectiveFee);
    }

    /**
     * @notice Return the verified owner for a project (address(0) if unclaimed).
     */
    function getVerifiedOwner(bytes32 projectId) external view returns (address) {
        return _verifiedOwner[projectId];
    }

    /**
     * @notice Return the global verification fee.
     */
    function getVerificationFee() external view returns (uint256) {
        return verificationFee;
    }

    /**
     * @notice Return the effective fee that `wallet` would pay right now.
     *         Whitelisted → 0. Custom fee set → customVerificationFee[wallet].
     *         Otherwise → global verificationFee.
     */
    function getEffectiveFee(address wallet) public view returns (uint256) {
        if (verificationWhitelist[wallet]) return 0;
        if (hasCustomFee[wallet]) return customVerificationFee[wallet];
        return verificationFee;
    }

    /**
     * @notice Update the global verification fee. Only callable by the contract owner.
     */
    function setVerificationFee(uint256 fee) external onlyOwner {
        verificationFee = fee;
    }

    /**
     * @notice Pause or unpause all new verifications. Only callable by the contract owner.
     */
    function setVerificationPaused(bool paused) external onlyOwner {
        verificationPaused = paused;
    }

    /**
     * @notice Add a wallet to the verification whitelist (zero fee). Owner only.
     */
    function addToWhitelist(address wallet) external onlyOwner {
        verificationWhitelist[wallet] = true;
        emit WhitelistAdded(wallet);
    }

    /**
     * @notice Remove a wallet from the verification whitelist. Owner only.
     */
    function removeFromWhitelist(address wallet) external onlyOwner {
        verificationWhitelist[wallet] = false;
        emit WhitelistRemoved(wallet);
    }

    /**
     * @notice Set a custom verification fee for a specific wallet. Owner only.
     *         Pass fee = 0 for a free custom override.
     */
    function setCustomFee(address wallet, uint256 fee) external onlyOwner {
        customVerificationFee[wallet] = fee;
        hasCustomFee[wallet] = true;
    }

    /**
     * @notice Remove the custom fee override for a wallet (reverts to global fee). Owner only.
     */
    function removeCustomFee(address wallet) external onlyOwner {
        hasCustomFee[wallet] = false;
    }

    // ─── Tipping ──────────────────────────────────────────────────────────────

    /**
     * @notice Return the current tip protocol fee in basis points.
     */
    function getTipProtocolFeeBps() external view returns (uint256) {
        return tipProtocolFeeBps;
    }

    /**
     * @notice Update the tip protocol fee. Owner only. Max 5000 bps (50%).
     */
    function setTipProtocolFeeBps(uint256 bps) external onlyOwner {
        if (bps > 5000) revert TipFeeBpsTooHigh();
        tipProtocolFeeBps = bps;
    }

    /**
     * @notice Tip the author of a review. A protocol fee is deducted and forwarded
     *         to the contract owner; the remainder goes to the reviewer.
     * @param  projectId    The project the review belongs to.
     * @param  reviewIndex  0-based index of the review to tip.
     */
    function tipReviewer(bytes32 projectId, uint256 reviewIndex) external payable {
        if (msg.value == 0) revert ZeroTipValue();
        uint256 len = _reviews[projectId].length;
        if (reviewIndex >= len) revert ReviewNotFound();

        address reviewer = _reviews[projectId][reviewIndex].author;
        uint256 protocolFee = (msg.value * tipProtocolFeeBps) / 10_000;
        uint256 reviewerAmount = msg.value - protocolFee;

        // Forward protocol fee to contract owner
        if (protocolFee > 0) {
            (bool feeOk,) = payable(owner()).call{value: protocolFee}("");
            if (!feeOk) revert TransferFailed();
        }

        // Forward remainder to reviewer
        (bool tipOk,) = payable(reviewer).call{value: reviewerAmount}("");
        if (!tipOk) revert TransferFailed();

        emit ReviewTipped(projectId, reviewIndex, msg.sender, reviewer, reviewerAmount, protocolFee);
    }

    // ─── Review upvotes ───────────────────────────────────────────────────────

    /**
     * @notice Update the review upvote protocol fee. Owner only. Max 3000 bps (30%).
     */
    function setUpvoteProtocolFeeBps(uint256 bps) external onlyOwner {
        if (bps > 3000) revert UpvoteFeeBpsTooHigh();
        upvoteProtocolFeeBps = bps;
    }

    /**
     * @notice Return the upvote stats for a specific review, read directly from storage.
     * @param  projectId    The project bytes32 slug key.
     * @param  reviewIndex  0-based index of the review.
     * @return count        Number of upvotes received.
     * @return totalWeight  Total author-received amount (economic weight signal).
     */
    function getReviewUpvoteStats(bytes32 projectId, uint256 reviewIndex)
        external
        view
        returns (uint256 count, uint256 totalWeight)
    {
        count       = reviewUpvoteCount[projectId][reviewIndex];
        totalWeight = reviewUpvoteWeight[projectId][reviewIndex];
    }

    /**
     * @notice Upvote a review with an economic signal. A protocol fee is deducted
     *         and forwarded to the contract owner; the remainder goes to the review author.
     *         Weight accumulates in storage for ranking purposes.
     * @param  projectId    The project the review belongs to.
     * @param  reviewIndex  0-based index of the review to upvote.
     */
    function upvoteReview(bytes32 projectId, uint256 reviewIndex) external payable {
        // 1. Fetch the review — reverts if index out of bounds
        uint256 len = _reviews[projectId].length;
        if (reviewIndex >= len) revert ReviewNotFound();
        Review storage review = _reviews[projectId][reviewIndex];

        // 2. Minimum amount check
        if (msg.value < MIN_UPVOTE_AMOUNT) revert InsufficientUpvoteAmount();

        // 3. Cannot upvote your own review
        if (msg.sender == review.author) revert CannotUpvoteOwnReview();

        // 4. Compute fee split
        uint256 protocolFee  = (msg.value * upvoteProtocolFeeBps) / 10_000;
        uint256 authorAmount = msg.value - protocolFee;

        // 5. Transfer protocol fee to owner
        if (protocolFee > 0) {
            (bool feeOk,) = payable(owner()).call{value: protocolFee}("");
            if (!feeOk) revert FeeTransferFailed();
        }

        // 6. Transfer author amount to review author
        (bool authorOk,) = payable(review.author).call{value: authorAmount}("");
        if (!authorOk) revert AuthorTransferFailed();

        // 7. Update storage weight and count
        reviewUpvoteWeight[projectId][reviewIndex] += authorAmount;
        reviewUpvoteCount[projectId][reviewIndex]  += 1;

        // 8. Emit event
        emit ReviewUpvoted(projectId, reviewIndex, msg.sender, review.author, msg.value, protocolFee);
    }

    // ─── Polls ────────────────────────────────────────────────────────────────

    /**
     * @notice Create a new staked poll. Only callable by the contract owner.
     * @param  pollId    Unique identifier for this poll.
     * @param  question  Poll question text.
     * @param  options   Answer options (at least 2).
     * @param  endsAt    Unix timestamp when voting closes.
     */
    function createPoll(
        bytes32 pollId,
        string calldata question,
        string[] calldata options,
        uint40 endsAt
    ) external onlyOwner {
        if (_polls[pollId].exists) revert PollAlreadyExists();
        require(options.length >= 2, "MYARC: need at least 2 options");
        require(endsAt > block.timestamp, "MYARC: endsAt must be in the future");

        _polls[pollId] = Poll({
            question: question,
            options: options,
            endsAt: endsAt,
            exists: true
        });
        // Initialize vote count array
        _pollOptionVotes[pollId] = new uint256[](options.length);
    }

    /**
     * @notice Vote on a poll with a native-token stake.
     * @param  pollId       The poll to vote on.
     * @param  optionIndex  0-based index of the chosen option.
     */
    function voteOnPoll(bytes32 pollId, uint8 optionIndex) external payable {
        Poll storage poll = _polls[pollId];
        if (!poll.exists) revert PollNotFound();
        if (block.timestamp >= poll.endsAt) revert PollEnded();
        if (optionIndex >= poll.options.length) revert PollOptionOutOfBounds();
        if (msg.value < MIN_POLL_STAKE) revert InsufficientStake();

        PollVoteRecord storage record = _pollVotes[pollId][msg.sender];
        if (record.stake > 0) revert PollAlreadyVoted();

        _pollVotes[pollId][msg.sender] = PollVoteRecord({
            optionIndex: optionIndex,
            stake: msg.value,
            claimed: false
        });
        _pollOptionVotes[pollId][optionIndex] += 1;
        _pollOptionStake[pollId][optionIndex] += msg.value;
        pollTotalStake[pollId] += msg.value;

        emit PollVoteCast(pollId, msg.sender, optionIndex, msg.value);
    }

    /**
     * @notice Claim a proportional share of the poll's stake pool.
     *         Callable only after the poll has ended. Distributes the total pool
     *         proportionally among voters who picked the winning option.
     * @param  pollId  The poll to claim from.
     */
    function claimPollReward(bytes32 pollId) external {
        Poll storage poll = _polls[pollId];
        if (!poll.exists) revert PollNotFound();
        if (block.timestamp < poll.endsAt) revert PollStillActive();

        PollVoteRecord storage record = _pollVotes[pollId][msg.sender];
        if (record.stake == 0) revert NoPollVote();
        if (record.claimed) revert AlreadyClaimed();

        // Resolve winner lazily (first claimant pays the resolution gas)
        if (!pollWinnerResolved[pollId]) {
            _resolvePollWinner(pollId);
        }

        uint8 winner = pollWinnerIndex[pollId];
        if (record.optionIndex != winner) revert NotPollWinner();

        record.claimed = true;

        uint256 winnerVotes = _pollOptionVotes[pollId][winner];
        uint256 totalPool   = pollTotalStake[pollId];

        // Proportional share: sender's stake / total winner-side stake
        // (all winner voters staked the same entry fee in our model,
        //  so we distribute proportionally by their stake amount)
        uint256 winnerStakeTotal = _winnerStakeTotal[pollId];
        // Guard against div-by-zero (should be impossible if winners exist)
        if (winnerStakeTotal == 0) revert NoPollVote();

        uint256 reward = (record.stake * totalPool) / winnerStakeTotal;

        (bool ok,) = msg.sender.call{value: reward}("");
        if (!ok) revert TransferFailed();

        emit PollRewardClaimed(pollId, msg.sender, reward);
    }

    // ─── Poll view functions ──────────────────────────────────────────────────

    /**
     * @notice Return the current vote counts for each option in a poll.
     * @return optionVotes  Array of vote counts in option order.
     * @return totalStake   Total staked amount in the pool.
     */
    function getPollResult(bytes32 pollId)
        external
        view
        returns (uint256[] memory optionVotes, uint256 totalStake)
    {
        if (!_polls[pollId].exists) revert PollNotFound();
        optionVotes = _pollOptionVotes[pollId];
        totalStake  = pollTotalStake[pollId];
    }

    /**
     * @notice Return the cached total stake contributed by winning-side voters.
     *         Returns 0 before the winner has been resolved (i.e. before the first
     *         claimPollReward call after the poll ends).
     */
    function getWinnerStakeTotal(bytes32 pollId) external view returns (uint256) {
        return _winnerStakeTotal[pollId];
    }

    /**
     * @notice Return a voter's stake in a specific poll.
     */
    function getPollStake(bytes32 pollId, address voter)
        external
        view
        returns (uint256 stake, uint8 optionIndex, bool claimed)
    {
        PollVoteRecord storage r = _pollVotes[pollId][voter];
        stake       = r.stake;
        optionIndex = r.optionIndex;
        claimed     = r.claimed;
    }

    /**
     * @notice Return the poll metadata (question, options, endsAt).
     */
    function getPoll(bytes32 pollId)
        external
        view
        returns (string memory question, string[] memory options, uint40 endsAt)
    {
        Poll storage poll = _polls[pollId];
        if (!poll.exists) revert PollNotFound();
        question = poll.question;
        options  = poll.options;
        endsAt   = poll.endsAt;
    }

    // ─── View functions ───────────────────────────────────────────────────────

    function getVote(address voter, bytes32 projectId) external view returns (uint8) {
        return _votes[voter][projectId];
    }

    function getEpochVote(address voter, bytes32 projectId, uint256 epochId)
        external view returns (uint8)
    {
        return _epochVotes[voter][projectId][epochId];
    }

    function getReview(bytes32 projectId, uint256 index)
        external
        view
        returns (Review memory)
    {
        uint256 len = _reviews[projectId].length;
        if (index >= len) revert ReviewIndexOutOfBounds(index, len);
        return _reviews[projectId][index];
    }

    function getReviews(bytes32 projectId, uint256 offset, uint256 limit)
        external
        view
        returns (Review[] memory out)
    {
        uint256 total = _reviews[projectId].length;
        if (offset >= total || limit == 0) return out;

        uint256 end = offset + limit;
        if (end > total) end = total;

        out = new Review[](end - offset);
        for (uint256 i = offset; i < end; i++) {
            out[i - offset] = _reviews[projectId][i];
        }
    }

    function domainSeparator() external view returns (bytes32) {
        return _domainSeparatorV4();
    }

    // ─── Additional private storage ───────────────────────────────────────────

    /// @dev Tracks whether a given address has already flagged a (project, review).
    mapping(address flagger => mapping(bytes32 projectId => mapping(uint256 reviewIndex => bool)))
        private _hasFlagged;

    /// @dev Total stake contributed by winning-side voters (cached when winner is resolved).
    mapping(bytes32 pollId => uint256) private _winnerStakeTotal;

    // ─── Internal helpers ─────────────────────────────────────────────────────

    function _applyVote(address voter, bytes32 projectId, Sentiment sentiment) private {
        uint8 packed = uint8(sentiment) + 1;
        uint8 prev   = _votes[voter][projectId];

        bool isChange = prev != 0;
        if (isChange) {
            _decrement(projectId, prev);
        }

        _votes[voter][projectId] = packed;
        _increment(projectId, packed);

        uint256 epoch = currentEpoch();
        uint8 epochPrev = _epochVotes[voter][projectId][epoch];
        if (epochPrev != 0) {
            _epochDecrement(epoch, projectId, epochPrev);
        }
        _epochVotes[voter][projectId][epoch] = packed;
        _epochIncrement(epoch, projectId, packed);

        emit Voted(projectId, voter, sentiment, isChange);
    }

    function _increment(bytes32 projectId, uint8 packed) private {
        VoteTally storage t = tallies[projectId];
        if (packed == 1) t.bullish += 1;
        else if (packed == 2) t.neutral += 1;
        else t.bearish += 1;
    }

    function _decrement(bytes32 projectId, uint8 packed) private {
        VoteTally storage t = tallies[projectId];
        if (packed == 1) t.bullish -= 1;
        else if (packed == 2) t.neutral -= 1;
        else t.bearish -= 1;
    }

    function _epochIncrement(uint256 epochId, bytes32 projectId, uint8 packed) private {
        VoteTally storage t = epochTallies[epochId][projectId];
        if (packed == 1) t.bullish += 1;
        else if (packed == 2) t.neutral += 1;
        else t.bearish += 1;
    }

    function _epochDecrement(uint256 epochId, bytes32 projectId, uint8 packed) private {
        VoteTally storage t = epochTallies[epochId][projectId];
        if (packed == 1) t.bullish -= 1;
        else if (packed == 2) t.neutral -= 1;
        else t.bearish -= 1;
    }

    /**
     * @dev Resolve and cache the winning option (most votes; ties go to lower index).
     *      Also caches the total stake on the winner side for reward distribution.
     */
    function _resolvePollWinner(bytes32 pollId) private {
        uint256[] storage votes = _pollOptionVotes[pollId];
        uint256 len = votes.length;
        uint8 winner = 0;
        uint256 maxVotes = votes[0];
        for (uint256 i = 1; i < len; i++) {
            if (votes[i] > maxVotes) {
                maxVotes = votes[i];
                winner   = uint8(i);
            }
        }
        pollWinnerIndex[pollId]    = winner;
        pollWinnerResolved[pollId] = true;

        // Pre-compute total stake on the winner side by iterating every voter
        // would require tracking voters — instead we cache it lazily per-voter.
        // We need the sum: store it as a running total incremented on each claim.
        // But we need it BEFORE any claim to distribute correctly.
        // Solution: store total-stake-by-option at vote time.
        _winnerStakeTotal[pollId] = _pollOptionStake[pollId][winner];
    }

    /// @dev Total stake per option (used for proportional reward calculation).
    mapping(bytes32 pollId => mapping(uint256 optionIndex => uint256)) private _pollOptionStake;
}
