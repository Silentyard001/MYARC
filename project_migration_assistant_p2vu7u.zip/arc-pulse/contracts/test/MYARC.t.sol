// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import {Test, console2} from "forge-std/Test.sol";
import {MYARC} from "../MYARC.sol";

/**
 * @title  MYARCTest
 * @notice Comprehensive unit tests covering:
 *           - vote() happy path, revert paths, tally correctness, events
 *           - retractVote() behaviour (including epoch counter cleanup)
 *           - batchVote() happy path, revert paths, mixed sentiments
 *           - postReview() validation and pagination
 *           - flagReview() happy path, duplicate prevention, OOB revert
 *           - EIP-712 voteBySig(): happy path, nonce consumption, replay, deadline
 *           - Epoch voting: currentEpoch, epochTallies, cross-epoch isolation
 *           - verifyProject(): first claim, duplicate rejection, event
 *           - createPoll / voteOnPoll / claimPollReward: full lifecycle
 *           - Fuzz: any voter/project/sentiment, tally consistency,
 *             change-vote total invariant, nonce monotonicity, batch tally
 */
contract MYARCTest is Test {
    /// @dev Allows the test contract (as contract owner) to receive ETH fee forwards.
    receive() external payable {}
    MYARC internal pulse;

    bytes32 internal constant PROJECT_A = keccak256("arc.defi.arcswap");
    bytes32 internal constant PROJECT_B = keccak256("arc.nft.arcpunks");
    bytes32 internal constant PROJECT_C = keccak256("arc.bridge.bridgearc");

    address internal alice = makeAddr("alice");
    address internal bob   = makeAddr("bob");
    address internal carol = makeAddr("carol");

    uint256 internal signerKey;
    address internal signer;

    // Default epoch duration used in all tests
    uint256 internal constant EPOCH_DURATION = 7 days;

    // Poll helpers
    bytes32 internal constant POLL_A = keccak256("poll.q4.growth");
    bytes32 internal constant POLL_B = keccak256("poll.ux.features");

    string[] internal twoOptions;
    string[] internal threeOptions;

    function setUp() public {
        pulse = new MYARC(EPOCH_DURATION, address(0));

        signerKey = uint256(keccak256("arc.pulse.test.signer"));
        signer    = vm.addr(signerKey);

        twoOptions   = new string[](2);
        twoOptions[0] = "Option A";
        twoOptions[1] = "Option B";

        threeOptions  = new string[](3);
        threeOptions[0] = "DeFi";
        threeOptions[1] = "Gaming";
        threeOptions[2] = "NFTs";

        // Give test accounts some ETH for poll staking and verification fees
        vm.deal(alice, 100 ether);
        vm.deal(bob,   100 ether);
        vm.deal(carol, 100 ether);
        // The test contract is the owner — give it ETH so it can receive fee transfers
        vm.deal(address(this), 100 ether);
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    function _signVote(
        uint256 privateKey,
        bytes32 projectId,
        MYARC.Sentiment sentiment,
        uint256 nonce,
        uint256 deadline
    ) internal view returns (bytes memory sig) {
        bytes32 VOTE_TYPEHASH =
            keccak256("Vote(bytes32 projectId,uint8 sentiment,uint256 nonce,uint256 deadline)");

        bytes32 structHash = keccak256(
            abi.encode(VOTE_TYPEHASH, projectId, uint8(sentiment), nonce, deadline)
        );

        bytes32 digest = keccak256(
            abi.encodePacked("\x19\x01", pulse.domainSeparator(), structHash)
        );

        (uint8 v, bytes32 r, bytes32 s) = vm.sign(privateKey, digest);
        sig = abi.encodePacked(r, s, v);
    }

    function _createPollA() internal {
        uint40 endsAt = uint40(block.timestamp + 7 days);
        pulse.createPoll(POLL_A, "Which sector grows most?", threeOptions, endsAt);
    }

    // ─── vote() ───────────────────────────────────────────────────────────────

    function test_vote_bullish_incrementsTally() public {
        vm.prank(alice);
        pulse.vote(PROJECT_A, MYARC.Sentiment.Bullish);

        (uint128 bull, uint128 neut, uint128 bear) = pulse.tallies(PROJECT_A);
        assertEq(bull, 1);
        assertEq(neut, 0);
        assertEq(bear, 0);
    }

    function test_vote_neutral_incrementsTally() public {
        vm.prank(alice);
        pulse.vote(PROJECT_A, MYARC.Sentiment.Neutral);

        (uint128 bull, uint128 neut, uint128 bear) = pulse.tallies(PROJECT_A);
        assertEq(bull, 0);
        assertEq(neut, 1);
        assertEq(bear, 0);
    }

    function test_vote_bearish_incrementsTally() public {
        vm.prank(alice);
        pulse.vote(PROJECT_A, MYARC.Sentiment.Bearish);

        (uint128 bull, uint128 neut, uint128 bear) = pulse.tallies(PROJECT_A);
        assertEq(bull, 0);
        assertEq(neut, 0);
        assertEq(bear, 1);
    }

    function test_vote_setsGetVote() public {
        vm.prank(alice);
        pulse.vote(PROJECT_A, MYARC.Sentiment.Bullish);
        assertEq(pulse.getVote(alice, PROJECT_A), 1);
    }

    function test_vote_emitsVotedEvent() public {
        vm.expectEmit(true, true, false, true, address(pulse));
        emit MYARC.Voted(PROJECT_A, alice, MYARC.Sentiment.Bullish, false);
        vm.prank(alice);
        pulse.vote(PROJECT_A, MYARC.Sentiment.Bullish);
    }

    function test_vote_changeVote_movesCounters() public {
        vm.startPrank(alice);
        pulse.vote(PROJECT_A, MYARC.Sentiment.Bullish);
        pulse.vote(PROJECT_A, MYARC.Sentiment.Bearish);
        vm.stopPrank();

        (uint128 bull, uint128 neut, uint128 bear) = pulse.tallies(PROJECT_A);
        assertEq(bull, 0);
        assertEq(neut, 0);
        assertEq(bear, 1);
    }

    function test_vote_emitsVotedEvent_isChange_onUpdate() public {
        vm.prank(alice);
        pulse.vote(PROJECT_A, MYARC.Sentiment.Bullish);

        vm.expectEmit(true, true, false, true, address(pulse));
        emit MYARC.Voted(PROJECT_A, alice, MYARC.Sentiment.Neutral, true);
        vm.prank(alice);
        pulse.vote(PROJECT_A, MYARC.Sentiment.Neutral);
    }

    function test_vote_multipleVoters_accumulateTally() public {
        vm.prank(alice); pulse.vote(PROJECT_A, MYARC.Sentiment.Bullish);
        vm.prank(bob);   pulse.vote(PROJECT_A, MYARC.Sentiment.Bullish);
        vm.prank(carol); pulse.vote(PROJECT_A, MYARC.Sentiment.Bearish);

        (uint128 bull, uint128 neut, uint128 bear) = pulse.tallies(PROJECT_A);
        assertEq(bull, 2);
        assertEq(neut, 0);
        assertEq(bear, 1);
    }

    function test_vote_differentProjects_isolated() public {
        vm.prank(alice); pulse.vote(PROJECT_A, MYARC.Sentiment.Bullish);
        vm.prank(alice); pulse.vote(PROJECT_B, MYARC.Sentiment.Bearish);

        (uint128 bullA,,) = pulse.tallies(PROJECT_A);
        (,, uint128 bearB) = pulse.tallies(PROJECT_B);
        assertEq(bullA, 1);
        assertEq(bearB, 1);
    }

    function test_vote_revertsOnZeroProjectId() public {
        vm.prank(alice);
        vm.expectRevert(MYARC.EmptyProjectId.selector);
        pulse.vote(bytes32(0), MYARC.Sentiment.Bullish);
    }

    // ─── retractVote() ────────────────────────────────────────────────────────

    function test_retractVote_decrementsCounter() public {
        vm.startPrank(alice);
        pulse.vote(PROJECT_A, MYARC.Sentiment.Bullish);
        pulse.retractVote(PROJECT_A);
        vm.stopPrank();

        (uint128 bull,,) = pulse.tallies(PROJECT_A);
        assertEq(bull, 0);
        assertEq(pulse.getVote(alice, PROJECT_A), 0);
    }

    function test_retractVote_emitsEvent() public {
        vm.prank(alice);
        pulse.vote(PROJECT_A, MYARC.Sentiment.Bullish);

        vm.expectEmit(true, true, false, false, address(pulse));
        emit MYARC.VoteRetracted(PROJECT_A, alice);
        vm.prank(alice);
        pulse.retractVote(PROJECT_A);
    }

    function test_retractVote_revertsWithNoActiveVote() public {
        vm.prank(alice);
        vm.expectRevert(MYARC.NoActiveVote.selector);
        pulse.retractVote(PROJECT_A);
    }

    function test_retractVote_revertsOnZeroProjectId() public {
        vm.prank(alice);
        vm.expectRevert(MYARC.EmptyProjectId.selector);
        pulse.retractVote(bytes32(0));
    }

    function test_retractVote_onlyAffectsCallerVote() public {
        vm.prank(alice); pulse.vote(PROJECT_A, MYARC.Sentiment.Bullish);
        vm.prank(bob);   pulse.vote(PROJECT_A, MYARC.Sentiment.Bullish);

        vm.prank(alice);
        pulse.retractVote(PROJECT_A);

        (uint128 bull,,) = pulse.tallies(PROJECT_A);
        assertEq(bull, 1);
    }

    function test_retractVote_allowsRevoteAfterRetract() public {
        vm.startPrank(alice);
        pulse.vote(PROJECT_A, MYARC.Sentiment.Bullish);
        pulse.retractVote(PROJECT_A);
        pulse.vote(PROJECT_A, MYARC.Sentiment.Bearish);
        vm.stopPrank();

        (uint128 bull,, uint128 bear) = pulse.tallies(PROJECT_A);
        assertEq(bull, 0);
        assertEq(bear, 1);
    }

    function test_retractVote_clearsEpochCounter() public {
        vm.prank(alice);
        pulse.vote(PROJECT_A, MYARC.Sentiment.Bullish);

        uint256 epoch = pulse.currentEpoch();
        (uint128 bull,,) = pulse.epochTallies(epoch, PROJECT_A);
        assertEq(bull, 1);

        vm.prank(alice);
        pulse.retractVote(PROJECT_A);

        (uint128 bullAfter,,) = pulse.epochTallies(epoch, PROJECT_A);
        assertEq(bullAfter, 0);
    }

    // ─── batchVote() ─────────────────────────────────────────────────────────

    function test_batchVote_happyPath() public {
        bytes32[] memory ids = new bytes32[](3);
        ids[0] = PROJECT_A;
        ids[1] = PROJECT_B;
        ids[2] = PROJECT_C;

        uint8[] memory sentiments = new uint8[](3);
        sentiments[0] = uint8(MYARC.Sentiment.Bullish);
        sentiments[1] = uint8(MYARC.Sentiment.Neutral);
        sentiments[2] = uint8(MYARC.Sentiment.Bearish);

        vm.prank(alice);
        pulse.batchVote(ids, sentiments);

        (uint128 bull,,) = pulse.tallies(PROJECT_A);
        (, uint128 neut,) = pulse.tallies(PROJECT_B);
        (,, uint128 bear) = pulse.tallies(PROJECT_C);
        assertEq(bull, 1);
        assertEq(neut, 1);
        assertEq(bear, 1);
    }

    function test_batchVote_emitsBatchVotedEvent() public {
        bytes32[] memory ids = new bytes32[](2);
        ids[0] = PROJECT_A;
        ids[1] = PROJECT_B;

        uint8[] memory sentiments = new uint8[](2);
        sentiments[0] = 0;
        sentiments[1] = 0;

        vm.expectEmit(true, false, false, true, address(pulse));
        emit MYARC.BatchVoted(alice, 2);

        vm.prank(alice);
        pulse.batchVote(ids, sentiments);
    }

    function test_batchVote_emitsVotedEventPerProject() public {
        bytes32[] memory ids = new bytes32[](1);
        ids[0] = PROJECT_A;
        uint8[] memory sentiments = new uint8[](1);
        sentiments[0] = 0; // Bullish

        vm.expectEmit(true, true, false, true, address(pulse));
        emit MYARC.Voted(PROJECT_A, alice, MYARC.Sentiment.Bullish, false);

        vm.prank(alice);
        pulse.batchVote(ids, sentiments);
    }

    function test_batchVote_singleProject() public {
        bytes32[] memory ids = new bytes32[](1);
        ids[0] = PROJECT_A;
        uint8[] memory sentiments = new uint8[](1);
        sentiments[0] = 0;

        vm.prank(alice);
        pulse.batchVote(ids, sentiments);

        (uint128 bull,,) = pulse.tallies(PROJECT_A);
        assertEq(bull, 1);
    }

    function test_batchVote_sameProjectUpdatesVote() public {
        bytes32[] memory ids = new bytes32[](1);
        ids[0] = PROJECT_A;
        uint8[] memory s1 = new uint8[](1);
        s1[0] = 0; // Bullish

        vm.prank(alice);
        pulse.batchVote(ids, s1);

        uint8[] memory s2 = new uint8[](1);
        s2[0] = 2; // Bearish

        vm.prank(alice);
        pulse.batchVote(ids, s2);

        (uint128 bull,, uint128 bear) = pulse.tallies(PROJECT_A);
        assertEq(bull, 0);
        assertEq(bear, 1);
    }

    function test_batchVote_revertsOnEmptyBatch() public {
        bytes32[] memory ids = new bytes32[](0);
        uint8[] memory sentiments = new uint8[](0);

        vm.prank(alice);
        vm.expectRevert(MYARC.EmptyBatch.selector);
        pulse.batchVote(ids, sentiments);
    }

    function test_batchVote_revertsOnLengthMismatch() public {
        bytes32[] memory ids = new bytes32[](2);
        ids[0] = PROJECT_A;
        ids[1] = PROJECT_B;
        uint8[] memory sentiments = new uint8[](1);
        sentiments[0] = 0;

        vm.prank(alice);
        vm.expectRevert(MYARC.BatchLengthMismatch.selector);
        pulse.batchVote(ids, sentiments);
    }

    function test_batchVote_revertsOnZeroProjectId() public {
        bytes32[] memory ids = new bytes32[](2);
        ids[0] = PROJECT_A;
        ids[1] = bytes32(0);
        uint8[] memory sentiments = new uint8[](2);

        vm.prank(alice);
        vm.expectRevert(MYARC.EmptyProjectId.selector);
        pulse.batchVote(ids, sentiments);
    }

    function test_batchVote_revertsOnExceedingMaxBatchSize() public {
        uint256 n = pulse.MAX_BATCH_SIZE() + 1;
        bytes32[] memory ids = new bytes32[](n);
        uint8[] memory sentiments = new uint8[](n);
        for (uint256 i = 0; i < n; i++) {
            ids[i] = keccak256(abi.encodePacked("p", i));
        }

        vm.prank(alice);
        vm.expectRevert(MYARC.BatchTooLarge.selector);
        pulse.batchVote(ids, sentiments);
    }

    function test_batchVote_multipleVoters() public {
        bytes32[] memory ids = new bytes32[](2);
        ids[0] = PROJECT_A;
        ids[1] = PROJECT_B;
        uint8[] memory s = new uint8[](2);
        s[0] = 0;
        s[1] = 0;

        vm.prank(alice); pulse.batchVote(ids, s);
        vm.prank(bob);   pulse.batchVote(ids, s);

        (uint128 bullA,,) = pulse.tallies(PROJECT_A);
        (uint128 bullB,,) = pulse.tallies(PROJECT_B);
        assertEq(bullA, 2);
        assertEq(bullB, 2);
    }

    // ─── flagReview() ─────────────────────────────────────────────────────────

    function test_flagReview_happyPath() public {
        vm.prank(alice);
        pulse.postReview(PROJECT_A, MYARC.Sentiment.Bullish, "Great project.");

        vm.prank(bob);
        pulse.flagReview(PROJECT_A, 0);

        assertEq(pulse.flagCount(PROJECT_A, 0), 1);
    }

    function test_flagReview_emitsEvent() public {
        vm.prank(alice);
        pulse.postReview(PROJECT_A, MYARC.Sentiment.Bullish, "Good.");

        vm.expectEmit(true, true, true, true, address(pulse));
        emit MYARC.ReviewFlagged(PROJECT_A, 0, bob, 1);

        vm.prank(bob);
        pulse.flagReview(PROJECT_A, 0);
    }

    function test_flagReview_multipleFlaggers_accumulateCount() public {
        vm.prank(alice);
        pulse.postReview(PROJECT_A, MYARC.Sentiment.Bullish, "Good.");

        vm.prank(bob);   pulse.flagReview(PROJECT_A, 0);
        vm.prank(carol); pulse.flagReview(PROJECT_A, 0);

        assertEq(pulse.flagCount(PROJECT_A, 0), 2);
    }

    function test_flagReview_revertsOnDuplicateFlag() public {
        vm.prank(alice);
        pulse.postReview(PROJECT_A, MYARC.Sentiment.Bullish, "Good.");

        vm.prank(bob);
        pulse.flagReview(PROJECT_A, 0);

        vm.prank(bob);
        vm.expectRevert(MYARC.AlreadyFlagged.selector);
        pulse.flagReview(PROJECT_A, 0);
    }

    function test_flagReview_revertsOnOOBIndex() public {
        vm.prank(bob);
        vm.expectRevert(
            abi.encodeWithSelector(MYARC.ReviewIndexOutOfBounds.selector, 0, 0)
        );
        pulse.flagReview(PROJECT_A, 0);
    }

    function test_flagReview_reviewsFlaggingIsolatedPerProject() public {
        vm.prank(alice);
        pulse.postReview(PROJECT_A, MYARC.Sentiment.Bullish, "For A.");
        vm.prank(alice);
        pulse.postReview(PROJECT_B, MYARC.Sentiment.Bearish, "For B.");

        vm.prank(bob); pulse.flagReview(PROJECT_A, 0);

        assertEq(pulse.flagCount(PROJECT_A, 0), 1);
        assertEq(pulse.flagCount(PROJECT_B, 0), 0);
    }

    // ─── Epoch voting ─────────────────────────────────────────────────────────

    function test_epoch_initiallyZero() public view {
        assertEq(pulse.currentEpoch(), 0);
    }

    function test_epoch_advancesAfterDuration() public {
        vm.warp(block.timestamp + EPOCH_DURATION);
        assertEq(pulse.currentEpoch(), 1);
    }

    function test_epoch_advancesMultipleTimes() public {
        vm.warp(block.timestamp + EPOCH_DURATION * 5);
        assertEq(pulse.currentEpoch(), 5);
    }

    function test_epoch_nextEpochStart_isCorrect() public view {
        uint256 expected = pulse.epochStart() + EPOCH_DURATION;
        assertEq(pulse.nextEpochStart(), expected);
    }

    function test_epoch_voteRecordedInCurrentEpoch() public {
        vm.prank(alice);
        pulse.vote(PROJECT_A, MYARC.Sentiment.Bullish);

        uint256 epoch = pulse.currentEpoch();
        (uint128 bull,,) = pulse.epochTallies(epoch, PROJECT_A);
        assertEq(bull, 1);
    }

    function test_epoch_tally_isolatedBetweenEpochs() public {
        vm.prank(alice);
        pulse.vote(PROJECT_A, MYARC.Sentiment.Bullish);

        (uint128 e0bull,,) = pulse.epochTallies(0, PROJECT_A);
        assertEq(e0bull, 1);

        vm.warp(block.timestamp + EPOCH_DURATION);
        assertEq(pulse.currentEpoch(), 1);

        vm.prank(alice);
        pulse.vote(PROJECT_A, MYARC.Sentiment.Neutral);

        (uint128 e0bullAfter,,) = pulse.epochTallies(0, PROJECT_A);
        assertEq(e0bullAfter, 1);

        (, uint128 e1neut,) = pulse.epochTallies(1, PROJECT_A);
        assertEq(e1neut, 1);
    }

    function test_epoch_globalTallySpansAllEpochs() public {
        vm.prank(alice);
        pulse.vote(PROJECT_A, MYARC.Sentiment.Bullish);

        vm.warp(block.timestamp + EPOCH_DURATION);

        vm.prank(bob);
        pulse.vote(PROJECT_A, MYARC.Sentiment.Bullish);

        (uint128 bull,,) = pulse.tallies(PROJECT_A);
        assertEq(bull, 2);
    }

    function test_epoch_sameVoterSameEpochCountedOnce() public {
        vm.startPrank(alice);
        pulse.vote(PROJECT_A, MYARC.Sentiment.Bullish);
        pulse.vote(PROJECT_A, MYARC.Sentiment.Neutral);
        vm.stopPrank();

        uint256 epoch = pulse.currentEpoch();
        (uint128 bull, uint128 neut, uint128 bear) = pulse.epochTallies(epoch, PROJECT_A);
        assertEq(bull + neut + bear, 1, "Only one epoch slot per voter per epoch");
    }

    function test_epoch_batchVoteUpdatesEpochTallies() public {
        bytes32[] memory ids = new bytes32[](2);
        ids[0] = PROJECT_A;
        ids[1] = PROJECT_B;
        uint8[] memory s = new uint8[](2);
        s[0] = 0;
        s[1] = 1;

        vm.prank(alice);
        pulse.batchVote(ids, s);

        uint256 epoch = pulse.currentEpoch();
        (uint128 bullA,,) = pulse.epochTallies(epoch, PROJECT_A);
        (, uint128 neutB,) = pulse.epochTallies(epoch, PROJECT_B);
        assertEq(bullA, 1);
        assertEq(neutB, 1);
    }

    function test_epochDuration_customValue() public {
        MYARC custom = new MYARC(1 days, address(0));
        assertEq(custom.epochDuration(), 1 days);
    }

    function test_epochDuration_defaultsTo7Days() public {
        MYARC defaultPulse = new MYARC(0, address(0));
        assertEq(defaultPulse.epochDuration(), 7 days);
    }

    function test_getEpochVote_returnsCorrectPackedValue() public {
        vm.prank(alice);
        pulse.vote(PROJECT_A, MYARC.Sentiment.Neutral);

        uint256 epoch = pulse.currentEpoch();
        assertEq(pulse.getEpochVote(alice, PROJECT_A, epoch), 2); // 2 = Neutral
    }

    // ─── postReview() ─────────────────────────────────────────────────────────

    function test_postReview_happyPath() public {
        vm.prank(alice);
        pulse.postReview(PROJECT_A, MYARC.Sentiment.Bullish, "Solid liquidity depth.");

        assertEq(pulse.reviewCount(PROJECT_A), 1);
        MYARC.Review memory r = pulse.getReview(PROJECT_A, 0);
        assertEq(r.author, alice);
        assertEq(uint8(r.sentiment), uint8(MYARC.Sentiment.Bullish));
        assertEq(r.body, "Solid liquidity depth.");
        assertGt(r.timestamp, 0);
    }

    function test_postReview_emitsEvent() public {
        vm.expectEmit(true, true, false, true, address(pulse));
        emit MYARC.ReviewPosted(PROJECT_A, alice, MYARC.Sentiment.Bullish, 0);
        vm.prank(alice);
        pulse.postReview(PROJECT_A, MYARC.Sentiment.Bullish, "Good.");
    }

    function test_postReview_revertsOnEmptyBody() public {
        vm.prank(alice);
        vm.expectRevert(MYARC.EmptyReviewBody.selector);
        pulse.postReview(PROJECT_A, MYARC.Sentiment.Bullish, "");
    }

    function test_postReview_revertsOnBodyTooLong() public {
        string memory tooLong = new string(401);
        vm.prank(alice);
        vm.expectRevert(MYARC.ReviewTooLong.selector);
        pulse.postReview(PROJECT_A, MYARC.Sentiment.Bullish, tooLong);
    }

    function test_postReview_acceptsExactMaxLength() public {
        string memory exact = new string(400);
        vm.prank(alice);
        pulse.postReview(PROJECT_A, MYARC.Sentiment.Bullish, exact);
        assertEq(pulse.reviewCount(PROJECT_A), 1);
    }

    function test_postReview_revertsOnZeroProjectId() public {
        vm.prank(alice);
        vm.expectRevert(MYARC.EmptyProjectId.selector);
        pulse.postReview(bytes32(0), MYARC.Sentiment.Bullish, "ok");
    }

    function test_postReview_multipleReviews_indexedCorrectly() public {
        vm.prank(alice); pulse.postReview(PROJECT_A, MYARC.Sentiment.Bullish, "First.");
        vm.prank(bob);   pulse.postReview(PROJECT_A, MYARC.Sentiment.Neutral, "Second.");

        assertEq(pulse.reviewCount(PROJECT_A), 2);
        assertEq(pulse.getReview(PROJECT_A, 0).body, "First.");
        assertEq(pulse.getReview(PROJECT_A, 1).body, "Second.");
    }

    function test_postReview_reviewsIsolatedPerProject() public {
        vm.prank(alice); pulse.postReview(PROJECT_A, MYARC.Sentiment.Bullish, "For A.");
        vm.prank(bob);   pulse.postReview(PROJECT_B, MYARC.Sentiment.Bearish, "For B.");

        assertEq(pulse.reviewCount(PROJECT_A), 1);
        assertEq(pulse.reviewCount(PROJECT_B), 1);
    }

    function test_maxReviewLength_is400() public view {
        assertEq(pulse.MAX_REVIEW_LENGTH(), 400);
    }

    // ─── getReviews() pagination ──────────────────────────────────────────────

    function _seedReviews(uint256 n) internal {
        for (uint256 i = 0; i < n; i++) {
            vm.prank(address(uint160(i + 1)));
            pulse.postReview(PROJECT_A, MYARC.Sentiment.Bullish, "x");
        }
    }

    function test_getReviews_emptySliceOnNoReviews() public view {
        MYARC.Review[] memory out = pulse.getReviews(PROJECT_A, 0, 10);
        assertEq(out.length, 0);
    }

    function test_getReviews_fullPage() public {
        _seedReviews(5);
        MYARC.Review[] memory out = pulse.getReviews(PROJECT_A, 0, 5);
        assertEq(out.length, 5);
    }

    function test_getReviews_offsetPage() public {
        _seedReviews(5);
        MYARC.Review[] memory out = pulse.getReviews(PROJECT_A, 2, 3);
        assertEq(out.length, 3);
        assertEq(out[0].author, address(3));
    }

    function test_getReviews_clipsToEnd() public {
        _seedReviews(3);
        MYARC.Review[] memory out = pulse.getReviews(PROJECT_A, 2, 10);
        assertEq(out.length, 1);
    }

    function test_getReviews_limitZero_returnsEmpty() public {
        _seedReviews(3);
        MYARC.Review[] memory out = pulse.getReviews(PROJECT_A, 0, 0);
        assertEq(out.length, 0);
    }

    function test_getReviews_offsetBeyondEnd_returnsEmpty() public {
        _seedReviews(3);
        MYARC.Review[] memory out = pulse.getReviews(PROJECT_A, 10, 5);
        assertEq(out.length, 0);
    }

    function test_getReview_revertsOutOfBounds() public {
        vm.expectRevert(abi.encodeWithSelector(MYARC.ReviewIndexOutOfBounds.selector, 0, 0));
        pulse.getReview(PROJECT_A, 0);
    }

    function test_getReview_revertsOutOfBoundsWithReviews() public {
        _seedReviews(2);
        vm.expectRevert(
            abi.encodeWithSelector(MYARC.ReviewIndexOutOfBounds.selector, 5, 2)
        );
        pulse.getReview(PROJECT_A, 5);
    }

    // ─── voteBySig() ──────────────────────────────────────────────────────────

    function test_voteBySig_happyPath() public {
        uint256 deadline = block.timestamp + 1800;
        uint256 nonce = pulse.nonces(signer);
        bytes memory sig = _signVote(signerKey, PROJECT_A, MYARC.Sentiment.Bullish, nonce, deadline);

        vm.prank(bob);
        pulse.voteBySig(PROJECT_A, MYARC.Sentiment.Bullish, nonce, deadline, sig);

        (uint128 bull,,) = pulse.tallies(PROJECT_A);
        assertEq(bull, 1);
        assertEq(pulse.getVote(signer, PROJECT_A), 1);
    }

    function test_voteBySig_emitsVotedEvent() public {
        uint256 deadline = block.timestamp + 1800;
        uint256 nonce = pulse.nonces(signer);
        bytes memory sig = _signVote(signerKey, PROJECT_A, MYARC.Sentiment.Neutral, nonce, deadline);

        vm.expectEmit(true, true, false, true, address(pulse));
        emit MYARC.Voted(PROJECT_A, signer, MYARC.Sentiment.Neutral, false);
        pulse.voteBySig(PROJECT_A, MYARC.Sentiment.Neutral, nonce, deadline, sig);
    }

    function test_voteBySig_consumesNonce() public {
        uint256 deadline = block.timestamp + 1800;
        uint256 nonce0 = pulse.nonces(signer);
        bytes memory sig = _signVote(signerKey, PROJECT_A, MYARC.Sentiment.Bullish, nonce0, deadline);
        pulse.voteBySig(PROJECT_A, MYARC.Sentiment.Bullish, nonce0, deadline, sig);
        assertEq(pulse.nonces(signer), nonce0 + 1);
    }

    function test_voteBySig_replays_revert() public {
        uint256 deadline = block.timestamp + 1800;
        uint256 nonce0 = pulse.nonces(signer);
        bytes memory sig = _signVote(signerKey, PROJECT_A, MYARC.Sentiment.Bullish, nonce0, deadline);
        pulse.voteBySig(PROJECT_A, MYARC.Sentiment.Bullish, nonce0, deadline, sig);

        vm.expectRevert(MYARC.InvalidSignature.selector);
        pulse.voteBySig(PROJECT_A, MYARC.Sentiment.Bullish, nonce0, deadline, sig);
    }

    function test_voteBySig_revertsAfterDeadline() public {
        uint256 deadline = block.timestamp + 100;
        uint256 nonce = pulse.nonces(signer);
        bytes memory sig = _signVote(signerKey, PROJECT_A, MYARC.Sentiment.Bullish, nonce, deadline);

        vm.warp(deadline + 1);

        vm.expectRevert(MYARC.SignatureExpired.selector);
        pulse.voteBySig(PROJECT_A, MYARC.Sentiment.Bullish, nonce, deadline, sig);
    }

    function test_voteBySig_revertsOnGarbledSig() public {
        uint256 deadline = block.timestamp + 1800;
        bytes memory sig = new bytes(65);

        vm.expectRevert();
        pulse.voteBySig(PROJECT_A, MYARC.Sentiment.Bullish, 0, deadline, sig);
    }

    function test_voteBySig_revertsOnZeroProjectId() public {
        uint256 deadline = block.timestamp + 1800;
        uint256 nonce = pulse.nonces(signer);
        bytes memory sig = _signVote(signerKey, bytes32(0), MYARC.Sentiment.Bullish, nonce, deadline);
        vm.expectRevert(MYARC.EmptyProjectId.selector);
        pulse.voteBySig(bytes32(0), MYARC.Sentiment.Bullish, nonce, deadline, sig);
    }

    function test_voteBySig_changeVote_via_sig() public {
        vm.prank(signer);
        pulse.vote(PROJECT_A, MYARC.Sentiment.Bullish);

        uint256 deadline = block.timestamp + 1800;
        uint256 nonce = pulse.nonces(signer);
        bytes memory sig = _signVote(signerKey, PROJECT_A, MYARC.Sentiment.Bearish, nonce, deadline);
        pulse.voteBySig(PROJECT_A, MYARC.Sentiment.Bearish, nonce, deadline, sig);

        (uint128 bull,, uint128 bear) = pulse.tallies(PROJECT_A);
        assertEq(bull, 0);
        assertEq(bear, 1);
    }

    function test_nonces_initiallyZero() public view {
        assertEq(pulse.nonces(alice), 0);
        assertEq(pulse.nonces(bob), 0);
    }

    // ─── Invariants ───────────────────────────────────────────────────────────

    function test_invariant_voteRetract_leavesZeroTally() public {
        vm.startPrank(alice);
        pulse.vote(PROJECT_A, MYARC.Sentiment.Bullish);
        pulse.retractVote(PROJECT_A);
        vm.stopPrank();

        (uint128 bull, uint128 neut, uint128 bear) = pulse.tallies(PROJECT_A);
        assertEq(bull + neut + bear, 0);
    }

    function test_invariant_epochTally_neverExceedsUniqueVoters() public {
        vm.prank(alice); pulse.vote(PROJECT_A, MYARC.Sentiment.Bullish);
        vm.prank(bob);   pulse.vote(PROJECT_A, MYARC.Sentiment.Neutral);
        vm.prank(carol); pulse.vote(PROJECT_A, MYARC.Sentiment.Bearish);

        uint256 epoch = pulse.currentEpoch();
        (uint128 bull, uint128 neut, uint128 bear) = pulse.epochTallies(epoch, PROJECT_A);
        assertEq(bull + neut + bear, 3);
    }

    // ─── verifyProject() ──────────────────────────────────────────────────────

    function test_verifyProject_happyPath() public {
        uint256 fee = pulse.verificationFee();
        vm.prank(alice);
        pulse.verifyProject{value: fee}(PROJECT_A);

        assertEq(pulse.getVerifiedOwner(PROJECT_A), alice);
    }

    function test_verifyProject_emitsEvent() public {
        uint256 fee = pulse.verificationFee();
        vm.expectEmit(true, true, false, false, address(pulse));
        emit MYARC.ProjectVerified(PROJECT_A, alice);

        vm.prank(alice);
        pulse.verifyProject{value: fee}(PROJECT_A);
    }

    function test_verifyProject_firstClaimWins_rejectsSecondClaim() public {
        uint256 fee = pulse.verificationFee();
        vm.prank(alice);
        pulse.verifyProject{value: fee}(PROJECT_A);

        vm.prank(bob);
        vm.expectRevert(MYARC.AlreadyVerified.selector);
        pulse.verifyProject{value: fee}(PROJECT_A);

        // Alice is still the verified owner
        assertEq(pulse.getVerifiedOwner(PROJECT_A), alice);
    }

    function test_verifyProject_differentProjects_differentOwners() public {
        uint256 fee = pulse.verificationFee();
        vm.prank(alice);
        pulse.verifyProject{value: fee}(PROJECT_A);

        vm.prank(bob);
        pulse.verifyProject{value: fee}(PROJECT_B);

        assertEq(pulse.getVerifiedOwner(PROJECT_A), alice);
        assertEq(pulse.getVerifiedOwner(PROJECT_B), bob);
    }

    function test_verifyProject_revertsOnZeroProjectId() public {
        uint256 fee = pulse.verificationFee();
        vm.prank(alice);
        vm.expectRevert(MYARC.EmptyProjectId.selector);
        pulse.verifyProject{value: fee}(bytes32(0));
    }

    function test_getVerifiedOwner_returnsZeroForUnclaimedProject() public view {
        assertEq(pulse.getVerifiedOwner(PROJECT_A), address(0));
    }

    // ─── verifyProject() — fee tests ──────────────────────────────────────────

    /// @notice Reverts when msg.value is less than verificationFee.
    function test_verifyProject_revertsOnInsufficientFee() public {
        uint256 fee = pulse.verificationFee();
        vm.prank(alice);
        vm.expectRevert(MYARC.InsufficientVerificationFee.selector);
        pulse.verifyProject{value: fee - 1}(PROJECT_A);
    }

    /// @notice Succeeds when msg.value equals the exact fee.
    function test_verifyProject_succeedsWithExactFee() public {
        uint256 fee = pulse.verificationFee();
        vm.prank(alice);
        pulse.verifyProject{value: fee}(PROJECT_A);
        assertEq(pulse.getVerifiedOwner(PROJECT_A), alice);
    }

    /// @notice Succeeds when msg.value exceeds the fee; excess is refunded to sender.
    function test_verifyProject_succeedsWithExcessFee() public {
        uint256 fee = pulse.verificationFee();
        uint256 excess = 1 ether;
        uint256 aliceBefore = alice.balance;

        vm.prank(alice);
        pulse.verifyProject{value: fee + excess}(PROJECT_A);

        assertEq(pulse.getVerifiedOwner(PROJECT_A), alice);
        // Alice should be refunded the excess (only fee deducted)
        assertApproxEqAbs(alice.balance, aliceBefore - fee, 1000, "Only fee deducted, excess refunded");
    }

    /// @notice Only the effective fee is forwarded to the contract owner.
    function test_verifyProject_feeForwardedToOwner() public {
        uint256 fee = pulse.verificationFee();
        address contractOwner = pulse.owner();

        uint256 ownerBefore = contractOwner.balance;
        vm.prank(alice);
        pulse.verifyProject{value: fee}(PROJECT_A);
        uint256 ownerAfter = contractOwner.balance;

        assertEq(ownerAfter - ownerBefore, fee, "Owner should receive exact fee");
    }

    /// @notice setVerificationFee is restricted to the owner.
    function test_setVerificationFee_onlyOwner() public {
        // Non-owner should revert
        vm.prank(alice);
        vm.expectRevert();
        pulse.setVerificationFee(1e18);

        // Owner should succeed
        pulse.setVerificationFee(1e18);
        assertEq(pulse.verificationFee(), 1e18);
        assertEq(pulse.getVerificationFee(), 1e18);
    }

    // ─── Flexible verification fee system ────────────────────────────────────

    /// @notice Whitelisted wallet pays zero fee.
    function test_verifyProject_whitelistedWalletPaysFree() public {
        pulse.addToWhitelist(alice);

        uint256 aliceBefore = alice.balance;
        vm.prank(alice);
        pulse.verifyProject{value: 0}(PROJECT_A);

        assertEq(pulse.getVerifiedOwner(PROJECT_A), alice);
        // Alice paid nothing (balance unchanged, minus tiny gas which is 0 in tests)
        assertEq(alice.balance, aliceBefore);
    }

    /// @notice Whitelisted wallet gets effective fee of 0 from getEffectiveFee.
    function test_getEffectiveFee_whitelisted() public {
        pulse.addToWhitelist(alice);
        assertEq(pulse.getEffectiveFee(alice), 0);
    }

    /// @notice Custom fee wallet pays its custom amount.
    function test_verifyProject_customFeeWalletPaysCustomAmount() public {
        uint256 customFee = 2e18; // 2 USDC
        pulse.setCustomFee(alice, customFee);

        address contractOwner = pulse.owner();
        uint256 ownerBefore = contractOwner.balance;

        vm.prank(alice);
        pulse.verifyProject{value: customFee}(PROJECT_A);

        assertEq(pulse.getVerifiedOwner(PROJECT_A), alice);
        assertEq(contractOwner.balance - ownerBefore, customFee);
    }

    /// @notice Custom fee of 0 (free override, not whitelist) works.
    function test_verifyProject_customFeeZero() public {
        pulse.setCustomFee(alice, 0);
        assertTrue(pulse.hasCustomFee(alice));
        assertEq(pulse.getEffectiveFee(alice), 0);

        vm.prank(alice);
        pulse.verifyProject{value: 0}(PROJECT_A);
        assertEq(pulse.getVerifiedOwner(PROJECT_A), alice);
    }

    /// @notice Wallet with no special treatment pays global fee.
    function test_getEffectiveFee_noOverridePaysGlobalFee() public view {
        assertEq(pulse.getEffectiveFee(alice), pulse.verificationFee());
    }

    /// @notice getEffectiveFee returns custom fee for wallet with custom fee set.
    function test_getEffectiveFee_customFee() public {
        uint256 custom = 3e18;
        pulse.setCustomFee(bob, custom);
        assertEq(pulse.getEffectiveFee(bob), custom);
    }

    /// @notice Excess msg.value above effective fee is refunded to sender.
    function test_verifyProject_excessRefundedToSender() public {
        uint256 fee = pulse.verificationFee();
        uint256 excess = 2 ether;
        uint256 aliceBefore = alice.balance;

        vm.prank(alice);
        pulse.verifyProject{value: fee + excess}(PROJECT_A);

        // Alice should have paid only `fee`, getting `excess` back
        assertApproxEqAbs(alice.balance, aliceBefore - fee, 1000);
    }

    /// @notice Paused state causes verifyProject to revert with VerificationPaused.
    function test_verifyProject_revertsWhenPaused() public {
        pulse.setVerificationPaused(true);

        vm.prank(alice);
        vm.expectRevert(MYARC.VerificationPaused.selector);
        pulse.verifyProject{value: 5e18}(PROJECT_A);
    }

    /// @notice Unpausing re-enables verification.
    function test_verifyProject_unpauseReenablesVerification() public {
        pulse.setVerificationPaused(true);
        pulse.setVerificationPaused(false);

        uint256 fee = pulse.verificationFee();
        vm.prank(alice);
        pulse.verifyProject{value: fee}(PROJECT_A);
        assertEq(pulse.getVerifiedOwner(PROJECT_A), alice);
    }

    /// @notice Only owner can call setVerificationPaused.
    function test_setVerificationPaused_onlyOwner() public {
        vm.prank(alice);
        vm.expectRevert();
        pulse.setVerificationPaused(true);

        pulse.setVerificationPaused(true);
        assertTrue(pulse.verificationPaused());
    }

    /// @notice Only owner can call addToWhitelist.
    function test_addToWhitelist_onlyOwner() public {
        vm.prank(alice);
        vm.expectRevert();
        pulse.addToWhitelist(bob);

        pulse.addToWhitelist(bob);
        assertTrue(pulse.verificationWhitelist(bob));
    }

    /// @notice Only owner can call removeFromWhitelist.
    function test_removeFromWhitelist_onlyOwner() public {
        pulse.addToWhitelist(alice);

        vm.prank(bob);
        vm.expectRevert();
        pulse.removeFromWhitelist(alice);

        pulse.removeFromWhitelist(alice);
        assertFalse(pulse.verificationWhitelist(alice));
    }

    /// @notice Only owner can call setCustomFee.
    function test_setCustomFee_onlyOwner() public {
        vm.prank(alice);
        vm.expectRevert();
        pulse.setCustomFee(bob, 1e18);

        pulse.setCustomFee(bob, 1e18);
        assertTrue(pulse.hasCustomFee(bob));
        assertEq(pulse.customVerificationFee(bob), 1e18);
    }

    /// @notice Only owner can call removeCustomFee.
    function test_removeCustomFee_onlyOwner() public {
        pulse.setCustomFee(alice, 1e18);

        vm.prank(bob);
        vm.expectRevert();
        pulse.removeCustomFee(alice);

        pulse.removeCustomFee(alice);
        assertFalse(pulse.hasCustomFee(alice));
        // After removal, effective fee reverts to global
        assertEq(pulse.getEffectiveFee(alice), pulse.verificationFee());
    }

    /// @notice WhitelistAdded and WhitelistRemoved events are emitted correctly.
    function test_whitelist_emitsEvents() public {
        vm.expectEmit(true, false, false, false, address(pulse));
        emit MYARC.WhitelistAdded(alice);
        pulse.addToWhitelist(alice);

        vm.expectEmit(true, false, false, false, address(pulse));
        emit MYARC.WhitelistRemoved(alice);
        pulse.removeFromWhitelist(alice);
    }

    /// @notice VerificationFeeCharged event emitted with correct fee.
    function test_verifyProject_emitsVerificationFeeChargedEvent() public {
        uint256 fee = pulse.verificationFee();

        vm.expectEmit(true, true, false, true, address(pulse));
        emit MYARC.VerificationFeeCharged(PROJECT_A, alice, fee);

        vm.prank(alice);
        pulse.verifyProject{value: fee}(PROJECT_A);
    }

    /// @notice Whitelist member emits VerificationFeeCharged with fee = 0.
    function test_verifyProject_whitelisted_emitsZeroFeeEvent() public {
        pulse.addToWhitelist(alice);

        vm.expectEmit(true, true, false, true, address(pulse));
        emit MYARC.VerificationFeeCharged(PROJECT_A, alice, 0);

        vm.prank(alice);
        pulse.verifyProject{value: 0}(PROJECT_A);
    }

    // ─── createPoll() ─────────────────────────────────────────────────────────

    function test_createPoll_happyPath() public {
        _createPollA();

        (string memory question, string[] memory opts, uint40 endsAt) = pulse.getPoll(POLL_A);
        assertEq(question, "Which sector grows most?");
        assertEq(opts.length, 3);
        assertEq(opts[0], "DeFi");
        assertGt(endsAt, block.timestamp);
    }

    function test_createPoll_revertsOnDuplicatePollId() public {
        _createPollA();

        vm.expectRevert(MYARC.PollAlreadyExists.selector);
        pulse.createPoll(POLL_A, "Duplicate?", twoOptions, uint40(block.timestamp + 1 days));
    }

    function test_createPoll_revertsForNonOwner() public {
        vm.prank(alice);
        vm.expectRevert();
        pulse.createPoll(POLL_A, "Q?", twoOptions, uint40(block.timestamp + 1 days));
    }

    function test_createPoll_revertsForPastEndsAt() public {
        vm.expectRevert("MYARC: endsAt must be in the future");
        pulse.createPoll(POLL_B, "Q?", twoOptions, uint40(block.timestamp - 1));
    }

    // ─── voteOnPoll() ─────────────────────────────────────────────────────────

    function test_voteOnPoll_happyPath() public {
        _createPollA();

        vm.prank(alice);
        pulse.voteOnPoll{value: 1e15}(POLL_A, 0);

        (uint256[] memory optVotes, uint256 totalStake) = pulse.getPollResult(POLL_A);
        assertEq(optVotes[0], 1);
        assertEq(totalStake, 1e15);
    }

    function test_voteOnPoll_emitsEvent() public {
        _createPollA();

        vm.expectEmit(true, true, false, true, address(pulse));
        emit MYARC.PollVoteCast(POLL_A, alice, 0, 1e15);

        vm.prank(alice);
        pulse.voteOnPoll{value: 1e15}(POLL_A, 0);
    }

    function test_voteOnPoll_revertsOnDuplicateVote() public {
        _createPollA();

        vm.startPrank(alice);
        pulse.voteOnPoll{value: 1e15}(POLL_A, 0);

        vm.expectRevert(MYARC.PollAlreadyVoted.selector);
        pulse.voteOnPoll{value: 1e15}(POLL_A, 1);
        vm.stopPrank();
    }

    function test_voteOnPoll_revertsOnInsufficientStake() public {
        _createPollA();

        vm.prank(alice);
        vm.expectRevert(MYARC.InsufficientStake.selector);
        pulse.voteOnPoll{value: 1e14}(POLL_A, 0); // below 1e15 minimum
    }

    function test_voteOnPoll_revertsOnOutOfBoundsOption() public {
        _createPollA();

        vm.prank(alice);
        vm.expectRevert(MYARC.PollOptionOutOfBounds.selector);
        pulse.voteOnPoll{value: 1e15}(POLL_A, 5); // only 3 options
    }

    function test_voteOnPoll_revertsAfterPollEnds() public {
        _createPollA();
        vm.warp(block.timestamp + 8 days); // past endsAt

        vm.prank(alice);
        vm.expectRevert(MYARC.PollEnded.selector);
        pulse.voteOnPoll{value: 1e15}(POLL_A, 0);
    }

    function test_voteOnPoll_revertsOnNonexistentPoll() public {
        vm.prank(alice);
        vm.expectRevert(MYARC.PollNotFound.selector);
        pulse.voteOnPoll{value: 1e15}(keccak256("nonexistent"), 0);
    }

    // ─── claimPollReward() ────────────────────────────────────────────────────

    function test_claimPollReward_winnersReceiveProportionalShare() public {
        _createPollA();
        uint256 stakeEach = 2e15;

        // Alice and Bob both vote option 0 (DeFi) — winners
        vm.prank(alice);
        pulse.voteOnPoll{value: stakeEach}(POLL_A, 0);
        vm.prank(bob);
        pulse.voteOnPoll{value: stakeEach}(POLL_A, 0);
        // Carol votes option 1 — loser
        vm.prank(carol);
        pulse.voteOnPoll{value: stakeEach}(POLL_A, 1);

        // Total pool = 3 * stakeEach, winner option stake = 2 * stakeEach
        uint256 totalPool = 3 * stakeEach;
        // Alice's share: (stakeEach / 2 * stakeEach) * totalPool = totalPool / 2
        uint256 expectedAlice = (stakeEach * totalPool) / (2 * stakeEach);

        vm.warp(block.timestamp + 8 days); // end poll

        uint256 balanceBefore = alice.balance;
        vm.prank(alice);
        pulse.claimPollReward(POLL_A);
        uint256 received = alice.balance - balanceBefore;

        assertEq(received, expectedAlice);
    }

    function test_claimPollReward_emitsEvent() public {
        _createPollA();

        vm.prank(alice);
        pulse.voteOnPoll{value: 1e15}(POLL_A, 0);
        vm.prank(bob);
        pulse.voteOnPoll{value: 1e15}(POLL_A, 1);

        vm.warp(block.timestamp + 8 days);

        vm.expectEmit(true, true, false, false, address(pulse));
        emit MYARC.PollRewardClaimed(POLL_A, alice, 0); // amount checked separately

        vm.prank(alice);
        pulse.claimPollReward(POLL_A);
    }

    function test_claimPollReward_revertsForNonWinner() public {
        _createPollA();

        // Alice votes option 0, Bob votes option 1
        // Alice gets more votes on option 0 than option 1, so option 0 wins
        vm.prank(alice);
        pulse.voteOnPoll{value: 1e15}(POLL_A, 0);
        vm.prank(carol);
        pulse.voteOnPoll{value: 1e15}(POLL_A, 0);
        vm.prank(bob);
        pulse.voteOnPoll{value: 1e15}(POLL_A, 1);

        vm.warp(block.timestamp + 8 days);

        // Bob is a loser (voted option 1, option 0 won)
        vm.prank(bob);
        vm.expectRevert(MYARC.NotPollWinner.selector);
        pulse.claimPollReward(POLL_A);
    }

    function test_claimPollReward_revertsOnDoubleClaim() public {
        _createPollA();

        vm.prank(alice);
        pulse.voteOnPoll{value: 1e15}(POLL_A, 0);
        vm.prank(bob);
        pulse.voteOnPoll{value: 1e15}(POLL_A, 1);

        vm.warp(block.timestamp + 8 days);

        vm.prank(alice);
        pulse.claimPollReward(POLL_A);

        vm.prank(alice);
        vm.expectRevert(MYARC.AlreadyClaimed.selector);
        pulse.claimPollReward(POLL_A);
    }

    function test_claimPollReward_revertsBeforePollEnds() public {
        _createPollA();

        vm.prank(alice);
        pulse.voteOnPoll{value: 1e15}(POLL_A, 0);

        // Poll not ended yet
        vm.prank(alice);
        vm.expectRevert(MYARC.PollStillActive.selector);
        pulse.claimPollReward(POLL_A);
    }

    function test_claimPollReward_revertsForNonVoter() public {
        _createPollA();

        vm.prank(alice);
        pulse.voteOnPoll{value: 1e15}(POLL_A, 0);

        vm.warp(block.timestamp + 8 days);

        // Bob never voted
        vm.prank(bob);
        vm.expectRevert(MYARC.NoPollVote.selector);
        pulse.claimPollReward(POLL_A);
    }

    // ─── claimPollReward() — extended proportional distribution tests ─────────

    /// @notice Three winners with different stakes each receive a share proportional
    ///         to their individual stake relative to the total winning-side stake.
    ///         Losing-side stake flows to winners; gas tolerance is ±1000 wei.
    function test_claimPollReward_proportionalDistribution() public {
        _createPollA(); // 3 options: DeFi(0), Gaming(1), NFTs(2)

        uint256 stakeAlice = 1e15;
        uint256 stakeBob   = 2e15;
        uint256 stakeCarol = 3e15;

        // All three vote for the winning option (0 = DeFi)
        vm.prank(alice); pulse.voteOnPoll{value: stakeAlice}(POLL_A, 0);
        vm.prank(bob);   pulse.voteOnPoll{value: stakeBob}(POLL_A, 0);
        vm.prank(carol); pulse.voteOnPoll{value: stakeCarol}(POLL_A, 0);

        // Add a loser voter with a fresh address so the pool is larger than winner-side
        address dave = makeAddr("dave");
        vm.deal(dave, 10 ether);
        uint256 stakeDave = 4e15;
        vm.prank(dave); pulse.voteOnPoll{value: stakeDave}(POLL_A, 1); // loser

        vm.warp(block.timestamp + 8 days); // end poll

        uint256 totalPool        = stakeAlice + stakeBob + stakeCarol + stakeDave;
        uint256 winnerStakeTotal = stakeAlice + stakeBob + stakeCarol;

        // Expected: claimant.stake * totalPool / winnerStakeTotal
        uint256 expectedAlice = (stakeAlice * totalPool) / winnerStakeTotal;
        uint256 expectedBob   = (stakeBob   * totalPool) / winnerStakeTotal;
        uint256 expectedCarol = (stakeCarol * totalPool) / winnerStakeTotal;

        uint256 balAlice0 = alice.balance;
        vm.prank(alice); pulse.claimPollReward(POLL_A);
        assertApproxEqAbs(alice.balance - balAlice0, expectedAlice, 1000);

        uint256 balBob0 = bob.balance;
        vm.prank(bob); pulse.claimPollReward(POLL_A);
        assertApproxEqAbs(bob.balance - balBob0, expectedBob, 1000);

        uint256 balCarol0 = carol.balance;
        vm.prank(carol); pulse.claimPollReward(POLL_A);
        assertApproxEqAbs(carol.balance - balCarol0, expectedCarol, 1000);
    }

    /// @notice A voter on the losing option cannot claim a reward.
    function test_claimPollReward_loserCannotClaim() public {
        _createPollA();

        // Alice wins (option 0 x2 votes), Bob loses (option 1 x1 vote)
        vm.prank(alice); pulse.voteOnPoll{value: 1e15}(POLL_A, 0);
        vm.prank(carol); pulse.voteOnPoll{value: 1e15}(POLL_A, 0);
        vm.prank(bob);   pulse.voteOnPoll{value: 1e15}(POLL_A, 1);

        vm.warp(block.timestamp + 8 days);

        vm.prank(bob);
        vm.expectRevert(MYARC.NotPollWinner.selector);
        pulse.claimPollReward(POLL_A);
    }

    /// @notice A winner who claims a second time receives AlreadyClaimed.
    function test_claimPollReward_cannotClaimTwice() public {
        _createPollA();

        vm.prank(alice); pulse.voteOnPoll{value: 2e15}(POLL_A, 0); // winner
        vm.prank(bob);   pulse.voteOnPoll{value: 1e15}(POLL_A, 1); // loser

        vm.warp(block.timestamp + 8 days);

        vm.prank(alice);
        pulse.claimPollReward(POLL_A); // first claim — succeeds

        vm.prank(alice);
        vm.expectRevert(MYARC.AlreadyClaimed.selector);
        pulse.claimPollReward(POLL_A); // second claim — must revert
    }

    /// @notice getWinnerStakeTotal returns the sum of stakes from winning-side
    ///         voters only (not the full pool), matching the expected value.
    function test_claimPollReward_winnerStakeTotalIsCorrect() public {
        _createPollA();

        uint256 stakeAlice = 3e15; // winner side
        uint256 stakeBob   = 2e15; // winner side
        uint256 stakeCarol = 5e15; // loser side

        vm.prank(alice); pulse.voteOnPoll{value: stakeAlice}(POLL_A, 0);
        vm.prank(bob);   pulse.voteOnPoll{value: stakeBob}(POLL_A, 0);
        vm.prank(carol); pulse.voteOnPoll{value: stakeCarol}(POLL_A, 1);

        vm.warp(block.timestamp + 8 days);

        // Trigger winner resolution by claiming (lazy resolution)
        vm.prank(alice);
        pulse.claimPollReward(POLL_A);

        // Now winner is resolved — winnerStakeTotal must equal winner-side stake only
        uint256 winnerStakeTotal = pulse.getWinnerStakeTotal(POLL_A);
        assertEq(winnerStakeTotal, stakeAlice + stakeBob,
            "winnerStakeTotal must equal sum of winning-side stakes only");

        // Cross-check: total pool includes loser stake
        (, uint256 totalPool) = pulse.getPollResult(POLL_A);
        assertEq(totalPool, stakeAlice + stakeBob + stakeCarol);
        assertTrue(winnerStakeTotal < totalPool,
            "winnerStakeTotal must be strictly less than total pool when losers voted");
    }

    // ─── tipReviewer() ────────────────────────────────────────────────────────

    /// @dev Helper: alice posts a review and returns PROJECT_A + reviewIndex 0.
    function _seedReviewForTip() internal returns (bytes32 projectId, uint256 reviewIndex) {
        projectId = PROJECT_A;
        reviewIndex = 0;
        vm.prank(alice);
        pulse.postReview(projectId, MYARC.Sentiment.Bullish, "Great project for tipping test.");
    }

    /// @notice Tip splits correctly: 10% to protocol (owner), 90% to reviewer (alice).
    function test_tipReviewer_splitCorrectly() public {
        (bytes32 pid, uint256 idx) = _seedReviewForTip();

        uint256 tip = 1e18; // 1 USDC
        uint256 protocolFee = (tip * pulse.tipProtocolFeeBps()) / 10_000;
        uint256 reviewerShare = tip - protocolFee;

        address contractOwner = pulse.owner();
        uint256 ownerBefore   = contractOwner.balance;
        uint256 aliceBefore   = alice.balance;

        vm.prank(bob);
        pulse.tipReviewer{value: tip}(pid, idx);

        assertEq(contractOwner.balance - ownerBefore, protocolFee, "Owner receives protocol fee");
        assertEq(alice.balance - aliceBefore, reviewerShare, "Alice receives reviewer share");
    }

    /// @notice Entire tip flows correctly when protocol fee is 0%.
    function test_tipReviewer_zeroFeeGoesEntirelyToReviewer() public {
        pulse.setTipProtocolFeeBps(0);
        (bytes32 pid, uint256 idx) = _seedReviewForTip();

        uint256 tip = 5e17;
        uint256 aliceBefore = alice.balance;

        vm.prank(bob);
        pulse.tipReviewer{value: tip}(pid, idx);

        assertEq(alice.balance - aliceBefore, tip, "Entire tip goes to reviewer when fee is 0");
    }

    /// @notice Protocol fee is forwarded to the owner address.
    function test_tipReviewer_protocolFeeForwardedToOwner() public {
        (bytes32 pid, uint256 idx) = _seedReviewForTip();

        uint256 tip = 2e18;
        uint256 expectedFee = (tip * 1000) / 10_000; // 10%

        address contractOwner = pulse.owner();
        uint256 ownerBefore = contractOwner.balance;

        vm.prank(bob);
        pulse.tipReviewer{value: tip}(pid, idx);

        assertEq(contractOwner.balance - ownerBefore, expectedFee);
    }

    /// @notice Zero msg.value reverts with ZeroTipValue.
    function test_tipReviewer_revertsOnZeroValue() public {
        (bytes32 pid, uint256 idx) = _seedReviewForTip();

        vm.prank(bob);
        vm.expectRevert(MYARC.ZeroTipValue.selector);
        pulse.tipReviewer{value: 0}(pid, idx);
    }

    /// @notice Invalid review index reverts with ReviewNotFound.
    function test_tipReviewer_revertsOnInvalidIndex() public {
        (bytes32 pid,) = _seedReviewForTip(); // index 0 exists

        vm.prank(bob);
        vm.expectRevert(MYARC.ReviewNotFound.selector);
        pulse.tipReviewer{value: 1e18}(pid, 99); // out of bounds
    }

    /// @notice setTipProtocolFeeBps updates the stored bps.
    function test_setTipProtocolFeeBps_updatesValue() public {
        pulse.setTipProtocolFeeBps(500); // 5%
        assertEq(pulse.tipProtocolFeeBps(), 500);
        assertEq(pulse.getTipProtocolFeeBps(), 500);
    }

    /// @notice setTipProtocolFeeBps reverts when bps > 5000.
    function test_setTipProtocolFeeBps_revertsOnExcessive() public {
        vm.expectRevert(MYARC.TipFeeBpsTooHigh.selector);
        pulse.setTipProtocolFeeBps(5001);

        // Exactly 5000 is allowed
        pulse.setTipProtocolFeeBps(5000);
        assertEq(pulse.tipProtocolFeeBps(), 5000);
    }

    /// @notice Only owner can call setTipProtocolFeeBps.
    function test_setTipProtocolFeeBps_onlyOwner() public {
        vm.prank(alice);
        vm.expectRevert();
        pulse.setTipProtocolFeeBps(200);

        // Owner succeeds
        pulse.setTipProtocolFeeBps(200);
        assertEq(pulse.tipProtocolFeeBps(), 200);
    }

    /// @notice ReviewTipped event is emitted with correct values.
    function test_tipReviewer_emitsEvent() public {
        (bytes32 pid, uint256 idx) = _seedReviewForTip();

        uint256 tip = 1e18;
        uint256 protocolFee = (tip * pulse.tipProtocolFeeBps()) / 10_000;
        uint256 reviewerAmount = tip - protocolFee;

        vm.expectEmit(true, true, true, true, address(pulse));
        emit MYARC.ReviewTipped(pid, idx, bob, alice, reviewerAmount, protocolFee);

        vm.prank(bob);
        pulse.tipReviewer{value: tip}(pid, idx);
    }

    /// @notice Excess goes to reviewer, not protocol (protocol fee is a fixed % of msg.value).
    function test_tipReviewer_largerTipMoreToReviewer() public {
        (bytes32 pid, uint256 idx) = _seedReviewForTip();

        // 10% bps — reviewer always gets 90% regardless of tip size
        uint256 smallTip = 1e15;
        uint256 largeTip = 5e18;

        uint256 aliceBefore = alice.balance;
        vm.prank(bob);
        pulse.tipReviewer{value: smallTip}(pid, idx);
        uint256 smallReceived = alice.balance - aliceBefore;

        aliceBefore = alice.balance;
        vm.prank(carol);
        pulse.tipReviewer{value: largeTip}(pid, idx);
        uint256 largeReceived = alice.balance - aliceBefore;

        assertEq(smallReceived, (smallTip * 9000) / 10_000);
        assertEq(largeReceived, (largeTip * 9000) / 10_000);
        assertGt(largeReceived, smallReceived, "Larger tip = more to reviewer");
    }

    // ─── Fuzz ─────────────────────────────────────────────────────────────────

    function testFuzz_vote_anyProjectAnyVoter(
        address voter,
        bytes32 projectId,
        uint8 rawSentiment
    ) public {
        vm.assume(projectId != bytes32(0));
        vm.assume(voter != address(0));
        MYARC.Sentiment s = MYARC.Sentiment(rawSentiment % 3);

        vm.prank(voter);
        pulse.vote(projectId, s);

        (uint128 bull, uint128 neut, uint128 bear) = pulse.tallies(projectId);
        assertEq(bull + neut + bear, 1);
    }

    function testFuzz_vote_tallyConsistency(address[4] memory voters) public {
        bytes32 pid = keccak256("fuzz.project");
        uint256 expected;

        for (uint256 i = 0; i < voters.length; i++) {
            address v = voters[i];
            vm.assume(v != address(0));
            bool isNew = true;
            for (uint256 j = 0; j < i; j++) {
                if (voters[j] == v) { isNew = false; break; }
            }
            if (isNew) expected++;

            vm.prank(v);
            pulse.vote(pid, MYARC.Sentiment.Bullish);
        }

        (uint128 bull,,) = pulse.tallies(pid);
        assertEq(uint256(bull), expected);
    }

    function testFuzz_changeVote_totalUnchanged(uint8 s1, uint8 s2) public {
        MYARC.Sentiment sent1 = MYARC.Sentiment(s1 % 3);
        MYARC.Sentiment sent2 = MYARC.Sentiment(s2 % 3);

        vm.startPrank(alice);
        pulse.vote(PROJECT_A, sent1);
        pulse.vote(PROJECT_A, sent2);
        vm.stopPrank();

        (uint128 bull, uint128 neut, uint128 bear) = pulse.tallies(PROJECT_A);
        assertEq(bull + neut + bear, 1);
    }

    function testFuzz_voteBySig_nonceMonotonic(uint8 count) public {
        uint256 n = (uint256(count) % 8) + 1;
        uint256 deadline = block.timestamp + 3600;

        for (uint256 i = 0; i < n; i++) {
            uint256 nonce = pulse.nonces(signer);
            assertEq(nonce, i);

            bytes32 pid = keccak256(abi.encodePacked("project", i));
            bytes memory sig = _signVote(signerKey, pid, MYARC.Sentiment.Bullish, nonce, deadline);
            pulse.voteBySig(pid, MYARC.Sentiment.Bullish, nonce, deadline, sig);
        }

        assertEq(pulse.nonces(signer), n);
    }

    function testFuzz_batchVote_tallyMatchesSingleVotes(uint8 len) public {
        uint256 n = (uint256(len) % 10) + 1; // 1–10 projects

        bytes32[] memory ids = new bytes32[](n);
        uint8[] memory sentiments = new uint8[](n);
        for (uint256 i = 0; i < n; i++) {
            ids[i] = keccak256(abi.encodePacked("batch.project", i));
            sentiments[i] = uint8(i % 3);
        }

        vm.prank(alice);
        pulse.batchVote(ids, sentiments);

        for (uint256 i = 0; i < n; i++) {
            (uint128 bull, uint128 neut, uint128 bear) = pulse.tallies(ids[i]);
            assertEq(bull + neut + bear, 1, "Each batch project should have exactly 1 vote");
        }
    }

    // ─── upvoteReview() ───────────────────────────────────────────────────────

    /// @dev Helper: alice posts a review and returns the projectId and reviewIndex.
    function _seedReviewForUpvote()
        internal
        returns (bytes32 projectId, uint256 reviewIndex)
    {
        projectId   = PROJECT_A;
        reviewIndex = 0;
        vm.prank(alice);
        pulse.postReview(projectId, MYARC.Sentiment.Bullish, "Great project upvote test.");
    }

    /// @notice Default fee split: 5% protocol (owner), 95% author (alice).
    function test_upvoteReview_defaultFeeSplit() public {
        (bytes32 pid, uint256 idx) = _seedReviewForUpvote();

        uint256 amount       = 1e16; // 0.01 USDC
        uint256 protocolFee  = (amount * pulse.upvoteProtocolFeeBps()) / 10_000; // 5%
        uint256 authorAmount = amount - protocolFee;

        assertEq(pulse.upvoteProtocolFeeBps(), 500); // default 5%

        address owner_ = pulse.owner();
        uint256 ownerBefore = owner_.balance;
        uint256 aliceBefore = alice.balance;

        vm.prank(bob);
        pulse.upvoteReview{value: amount}(pid, idx);

        assertEq(owner_.balance - ownerBefore, protocolFee,  "Owner receives 5% protocol fee");
        assertEq(alice.balance  - aliceBefore, authorAmount, "Alice receives 95% author amount");
    }

    /// @notice Atomic failure: if author transfer fails, whole tx reverts and storage is unchanged.
    function test_upvoteReview_atomicFailure_authorTransferFails() public {
        // Deploy a contract that cannot receive ETH (no receive/fallback)
        RejectEth rejecter = new RejectEth();
        bytes32 pid = PROJECT_B;
        // rejecter posts a review
        vm.prank(address(rejecter));
        pulse.postReview(pid, MYARC.Sentiment.Bullish, "From non-payable author.");

        uint256 amount = 1e15;

        vm.prank(bob);
        vm.expectRevert(MYARC.AuthorTransferFailed.selector);
        pulse.upvoteReview{value: amount}(pid, 0);

        // Storage must be unchanged
        (uint256 count, uint256 weight) = pulse.getReviewUpvoteStats(pid, 0);
        assertEq(count,  0, "Count must not increment on failure");
        assertEq(weight, 0, "Weight must not increment on failure");
    }

    /// @notice Exact MIN_UPVOTE_AMOUNT succeeds.
    function test_upvoteReview_exactMinAmountSucceeds() public {
        (bytes32 pid, uint256 idx) = _seedReviewForUpvote();
        uint256 min = pulse.MIN_UPVOTE_AMOUNT();

        vm.prank(bob);
        pulse.upvoteReview{value: min}(pid, idx);

        (uint256 count,) = pulse.getReviewUpvoteStats(pid, idx);
        assertEq(count, 1);
    }

    /// @notice One below MIN_UPVOTE_AMOUNT reverts with InsufficientUpvoteAmount.
    function test_upvoteReview_belowMinAmountReverts() public {
        (bytes32 pid, uint256 idx) = _seedReviewForUpvote();
        uint256 min = pulse.MIN_UPVOTE_AMOUNT();

        vm.prank(bob);
        vm.expectRevert(MYARC.InsufficientUpvoteAmount.selector);
        pulse.upvoteReview{value: min - 1}(pid, idx);
    }

    /// @notice Cannot upvote your own review.
    function test_upvoteReview_ownReviewReverts() public {
        (bytes32 pid, uint256 idx) = _seedReviewForUpvote();

        vm.prank(alice); // alice is the author
        vm.expectRevert(MYARC.CannotUpvoteOwnReview.selector);
        pulse.upvoteReview{value: 1e15}(pid, idx);
    }

    /// @notice Out-of-bounds index reverts with ReviewNotFound.
    function test_upvoteReview_invalidIndexReverts() public {
        (bytes32 pid,) = _seedReviewForUpvote();

        vm.prank(bob);
        vm.expectRevert(MYARC.ReviewNotFound.selector);
        pulse.upvoteReview{value: 1e15}(pid, 99);
    }

    /// @notice Weight accumulates correctly across multiple upvotes from different wallets.
    function test_upvoteReview_weightAccumulates() public {
        (bytes32 pid, uint256 idx) = _seedReviewForUpvote();

        uint256 bps = pulse.upvoteProtocolFeeBps();
        uint256 amount1 = 2e15;
        uint256 amount2 = 3e15;

        uint256 authorAmount1 = amount1 - (amount1 * bps) / 10_000;
        uint256 authorAmount2 = amount2 - (amount2 * bps) / 10_000;

        vm.prank(bob);
        pulse.upvoteReview{value: amount1}(pid, idx);

        vm.prank(carol);
        pulse.upvoteReview{value: amount2}(pid, idx);

        (uint256 count, uint256 weight) = pulse.getReviewUpvoteStats(pid, idx);
        assertEq(count,  2,                           "Count should be 2");
        assertEq(weight, authorAmount1 + authorAmount2, "Weight should accumulate correctly");
    }

    /// @notice Count increments correctly per upvote.
    function test_upvoteReview_countIncrements() public {
        (bytes32 pid, uint256 idx) = _seedReviewForUpvote();
        uint256 min = pulse.MIN_UPVOTE_AMOUNT();

        vm.prank(bob);   pulse.upvoteReview{value: min}(pid, idx);
        vm.prank(carol); pulse.upvoteReview{value: min}(pid, idx);

        (uint256 count,) = pulse.getReviewUpvoteStats(pid, idx);
        assertEq(count, 2, "Count should be 2 after two upvotes");
    }

    /// @notice getReviewUpvoteStats returns correct values directly from storage.
    function test_upvoteReview_getReviewUpvoteStats_correctAfterMultiple() public {
        (bytes32 pid, uint256 idx) = _seedReviewForUpvote();

        uint256 bps = pulse.upvoteProtocolFeeBps();
        uint256 upvote1 = 5e15;
        uint256 upvote2 = 7e15;
        uint256 upvote3 = 3e15;

        address dave = makeAddr("dave2");
        vm.deal(dave, 10 ether);

        vm.prank(bob);   pulse.upvoteReview{value: upvote1}(pid, idx);
        vm.prank(carol); pulse.upvoteReview{value: upvote2}(pid, idx);
        vm.prank(dave);  pulse.upvoteReview{value: upvote3}(pid, idx);

        uint256 expectedWeight =
            (upvote1 - (upvote1 * bps) / 10_000) +
            (upvote2 - (upvote2 * bps) / 10_000) +
            (upvote3 - (upvote3 * bps) / 10_000);

        (uint256 count, uint256 weight) = pulse.getReviewUpvoteStats(pid, idx);
        assertEq(count,  3,             "Count should equal number of upvotes");
        assertEq(weight, expectedWeight, "Weight should equal sum of author amounts");
    }

    /// @notice Only owner can call setUpvoteProtocolFeeBps.
    function test_setUpvoteProtocolFeeBps_onlyOwner() public {
        vm.prank(alice);
        vm.expectRevert();
        pulse.setUpvoteProtocolFeeBps(200);

        // Owner succeeds
        pulse.setUpvoteProtocolFeeBps(200);
        assertEq(pulse.upvoteProtocolFeeBps(), 200);
    }

    /// @notice bps above 3000 reverts with UpvoteFeeBpsTooHigh.
    function test_setUpvoteProtocolFeeBps_revertsAbove3000() public {
        vm.expectRevert(MYARC.UpvoteFeeBpsTooHigh.selector);
        pulse.setUpvoteProtocolFeeBps(3001);
    }

    /// @notice bps of exactly 3000 succeeds.
    function test_setUpvoteProtocolFeeBps_exactly3000Succeeds() public {
        pulse.setUpvoteProtocolFeeBps(3000);
        assertEq(pulse.upvoteProtocolFeeBps(), 3000);
    }

    /// @notice ReviewUpvoted event is emitted with correct values.
    function test_upvoteReview_emitsEvent() public {
        (bytes32 pid, uint256 idx) = _seedReviewForUpvote();

        uint256 amount      = 1e16;
        uint256 bps         = pulse.upvoteProtocolFeeBps();
        uint256 protocolFee = (amount * bps) / 10_000;

        vm.expectEmit(true, true, true, true, address(pulse));
        emit MYARC.ReviewUpvoted(pid, idx, bob, alice, amount, protocolFee);

        vm.prank(bob);
        pulse.upvoteReview{value: amount}(pid, idx);
    }

    /// @notice Storage mappings are isolated per project and per review index.
    function test_upvoteReview_isolatedPerProjectAndIndex() public {
        // Post one review on PROJECT_A and one on PROJECT_B
        vm.prank(alice);
        pulse.postReview(PROJECT_A, MYARC.Sentiment.Bullish, "Review on A.");
        vm.prank(alice);
        pulse.postReview(PROJECT_B, MYARC.Sentiment.Bullish, "Review on B.");

        vm.prank(bob); pulse.upvoteReview{value: 1e15}(PROJECT_A, 0);

        (uint256 countA,) = pulse.getReviewUpvoteStats(PROJECT_A, 0);
        (uint256 countB,) = pulse.getReviewUpvoteStats(PROJECT_B, 0);
        assertEq(countA, 1, "PROJECT_A review 0 should have 1 upvote");
        assertEq(countB, 0, "PROJECT_B review 0 should be unaffected");
    }
}

/// @dev Helper contract that cannot receive ETH — used to test atomic failure.
contract RejectEth {
    // No receive() or fallback() — all ETH transfers to this address revert.
}
