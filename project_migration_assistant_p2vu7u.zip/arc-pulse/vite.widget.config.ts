/**
 * Vite build config for the embeddable Pulse Badge widget.
 *
 * Produces two outputs:
 *   dist/widget/pulse-badge.iife.js  — IIFE for <script> tag usage
 *   dist/widget/pulse-badge.es.js    — ES module for bundler/npm
 *
 * The main application build is unaffected — this config is only invoked
 * by `bun run build:widget`.
 */
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'
import { nodePolyfills } from 'vite-plugin-node-polyfills'

export default defineConfig({
  plugins: [react(), nodePolyfills()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
    dedupe: ['react', 'react-dom'],
  },
  build: {
    outDir: 'dist/widget',
    emptyOutDir: true,
    lib: {
      entry: path.resolve(__dirname, 'src/widget/index.ts'),
      name: 'PulseBadge',
      formats: ['iife', 'es'],
      fileName: (format) =>
        format === 'iife' ? 'pulse-badge.iife.js' : 'pulse-badge.es.js',
    },
    rollupOptions: {
      // React and ReactDOM are bundled in the IIFE so the embed works without
      // any host-side dependencies. They are externalised in the ES build so
      // bundler consumers can tree-shake against their own React copy.
      external: (id, _importer, isResolved) => {
        if (isResolved) return false
        // Only externalise for the ES build — handled via output.globals below.
        // Vite processes formats separately; we mark nothing external here and
        // let the IIFE bundle everything, keeping ES output self-contained too
        // for simplicity (avoids peer-dep issues for embed consumers).
        return false
      },
    },
    // Minify for smaller embed payload
    minify: 'esbuild',
    sourcemap: false,
  },
})
