/* oxlint-disable */
/**
 * MYARC — Phase 3 Authentication Tests
 *
 * Tests the server-side authorization boundary: the Supabase RLS policy and
 * the Edge Function logic, tested via deterministic logic-level unit tests.
 *
 * These tests do NOT require a live Supabase instance. They test:
 *   1. The challenge generation logic (nonce entropy, expiry, message format).
 *   2. The signature verification logic (correct sig, wrong address, wrong sig,
 *      expired challenge, missing challenge, replayed challenge).
 *   3. The session storage logic (load/save/clear, expiry, wallet-change).
 *   4. The updateProfile authorization gate (session required, session mismatch).
 *
 * Run with: bun test src/test/auth.test.ts
 *
 * For integration tests against a live Supabase instance, see
 * src/test/auth.integration.test.ts (requires VITE_SUPABASE_URL etc. in .env).
 */

import { describe, it, expect, beforeEach } from 'bun:test'

// ── Helpers replicated from Edge Function logic ────────────────────────────────
// These are pure functions extracted from the Edge Function for unit testing.
// They must stay logically equivalent to the deployed functions.

function buildChallengeMessage(opts: {
  domain: string
  walletAddress: string
  chainId: string
  nonce: string
  issuedAt: string
  expiresAt: string
}): string {
  return [
    `${opts.domain} wants you to sign in with your Ethereum account:`,
    opts.walletAddress,
    '',
    'Sign in to MYARC. This request will not trigger a blockchain transaction or cost any gas.',
    '',
    `URI: https://${opts.domain}`,
    'Version: 1',
    `Chain ID: ${opts.chainId}`,
    `Nonce: ${opts.nonce}`,
    `Issued At: ${opts.issuedAt}`,
    `Expiration Time: ${opts.expiresAt}`,
  ].join('\n')
}

function isChallengeExpired(expiresAt: string): boolean {
  return new Date(expiresAt) < new Date()
}

function isValidNonce(nonce: string): boolean {
  return /^[0-9a-f]{64}$/.test(nonce)
}

function isValidAddress(addr: string): boolean {
  return /^0x[0-9a-fA-F]{40}$/.test(addr)
}

// Simplified session key (matches useAuth implementation)
function sessionKey(walletAddress: string): string {
  return `myarc:auth:${walletAddress.toLowerCase()}`
}

// ── Mock session storage (Map-based) ──────────────────────────────────────────

class MockSessionStorage {
  private store = new Map<string, string>()
  getItem(key: string): string | null { return this.store.get(key) ?? null }
  setItem(key: string, value: string): void { this.store.set(key, value) }
  removeItem(key: string): void { this.store.delete(key) }
  clear(): void { this.store.clear() }
}

interface StoredSession {
  walletAddress: string
  userId: string
  accessToken: string
  refreshToken: string
  expiresAt: string
}

function loadSession(storage: MockSessionStorage, walletAddress: string): StoredSession | null {
  const raw = storage.getItem(sessionKey(walletAddress))
  if (!raw) return null
  const s = JSON.parse(raw) as StoredSession
  if (new Date(s.expiresAt) < new Date()) {
    storage.removeItem(sessionKey(walletAddress))
    return null
  }
  return s
}

function saveSession(storage: MockSessionStorage, session: StoredSession): void {
  storage.setItem(sessionKey(session.walletAddress), JSON.stringify(session))
}

function clearSession(storage: MockSessionStorage, walletAddress: string): void {
  storage.removeItem(sessionKey(walletAddress))
}

// ── Tests ─────────────────────────────────────────────────────────────────────

const WALLET_A = '0xaabbccddee112233445566778899aabbccddeeff'
const WALLET_B = '0x1122334455aabbccddeeff001122334455aabbcc'
const NONCE    = 'a'.repeat(64) // 64 hex chars
const DOMAIN   = 'myarc.app'
const CHAIN_ID = '2040'

describe('challenge generation', () => {
  it('produces a deterministic message for given inputs', () => {
    const now     = new Date().toISOString()
    const expires = new Date(Date.now() + 5 * 60_000).toISOString()
    const msg = buildChallengeMessage({
      domain: DOMAIN, walletAddress: WALLET_A, chainId: CHAIN_ID,
      nonce: NONCE, issuedAt: now, expiresAt: expires,
    })
    expect(msg).toContain(`${DOMAIN} wants you to sign in`)
    expect(msg).toContain(WALLET_A)
    expect(msg).toContain(`Nonce: ${NONCE}`)
    expect(msg).toContain(`Chain ID: ${CHAIN_ID}`)
    expect(msg).toContain('URI: https://')
    expect(msg).toContain('Version: 1')
  })

  it('validates nonce format: 64 lowercase hex chars', () => {
    expect(isValidNonce(NONCE)).toBe(true)
    expect(isValidNonce('A'.repeat(64))).toBe(false)   // uppercase not valid
    expect(isValidNonce('a'.repeat(63))).toBe(false)   // too short
    expect(isValidNonce('a'.repeat(65))).toBe(false)   // too long
    expect(isValidNonce('')).toBe(false)
    expect(isValidNonce('z'.repeat(64))).toBe(false)   // non-hex
  })

  it('validates wallet address format', () => {
    expect(isValidAddress(WALLET_A)).toBe(true)
    expect(isValidAddress('0x' + WALLET_A.slice(2).toUpperCase())).toBe(true) // mixed-case hex digits OK
    expect(isValidAddress('0x' + 'a'.repeat(39))).toBe(false)  // too short
    expect(isValidAddress('0x' + 'a'.repeat(41))).toBe(false)  // too long
    expect(isValidAddress('not-an-address')).toBe(false)
    expect(isValidAddress('')).toBe(false)
  })
})

describe('challenge expiry', () => {
  it('accepts a fresh challenge (expires in 5 minutes)', () => {
    const expiresAt = new Date(Date.now() + 5 * 60_000).toISOString()
    expect(isChallengeExpired(expiresAt)).toBe(false)
  })

  it('rejects an expired challenge (expired 1ms ago)', () => {
    const expiresAt = new Date(Date.now() - 1).toISOString()
    expect(isChallengeExpired(expiresAt)).toBe(true)
  })

  it('rejects a challenge that expired 10 minutes ago', () => {
    const expiresAt = new Date(Date.now() - 10 * 60_000).toISOString()
    expect(isChallengeExpired(expiresAt)).toBe(true)
  })

  it('accepts a challenge expiring exactly 1ms from now', () => {
    const expiresAt = new Date(Date.now() + 1).toISOString()
    expect(isChallengeExpired(expiresAt)).toBe(false)
  })
})

describe('session storage', () => {
  let storage: MockSessionStorage

  beforeEach(() => {
    storage = new MockSessionStorage()
  })

  it('returns null for a wallet with no stored session', () => {
    expect(loadSession(storage, WALLET_A)).toBeNull()
  })

  it('saves and restores a valid session', () => {
    const session: StoredSession = {
      walletAddress: WALLET_A,
      userId: 'user-uuid-123',
      accessToken: 'tok.abc',
      refreshToken: 'ref.abc',
      expiresAt: new Date(Date.now() + 3600_000).toISOString(),
    }
    saveSession(storage, session)
    const loaded = loadSession(storage, WALLET_A)
    expect(loaded).not.toBeNull()
    expect(loaded!.userId).toBe('user-uuid-123')
    expect(loaded!.accessToken).toBe('tok.abc')
  })

  it('rejects an expired stored session and removes it', () => {
    const session: StoredSession = {
      walletAddress: WALLET_A,
      userId: 'user-uuid-123',
      accessToken: 'tok.abc',
      refreshToken: 'ref.abc',
      expiresAt: new Date(Date.now() - 1000).toISOString(), // expired
    }
    saveSession(storage, session)
    const loaded = loadSession(storage, WALLET_A)
    expect(loaded).toBeNull()
    // Storage should have been cleaned up
    expect(storage.getItem(sessionKey(WALLET_A))).toBeNull()
  })

  it('clearSession removes the session for a wallet', () => {
    const session: StoredSession = {
      walletAddress: WALLET_A,
      userId: 'user-uuid-123',
      accessToken: 'tok.abc',
      refreshToken: 'ref.abc',
      expiresAt: new Date(Date.now() + 3600_000).toISOString(),
    }
    saveSession(storage, session)
    clearSession(storage, WALLET_A)
    expect(loadSession(storage, WALLET_A)).toBeNull()
  })

  it('sessions for different wallets are independent', () => {
    const sessionA: StoredSession = {
      walletAddress: WALLET_A,
      userId: 'user-a',
      accessToken: 'tok.a',
      refreshToken: 'ref.a',
      expiresAt: new Date(Date.now() + 3600_000).toISOString(),
    }
    const sessionB: StoredSession = {
      walletAddress: WALLET_B,
      userId: 'user-b',
      accessToken: 'tok.b',
      refreshToken: 'ref.b',
      expiresAt: new Date(Date.now() + 3600_000).toISOString(),
    }
    saveSession(storage, sessionA)
    saveSession(storage, sessionB)
    clearSession(storage, WALLET_A)
    // Wallet A session gone, Wallet B session intact
    expect(loadSession(storage, WALLET_A)).toBeNull()
    expect(loadSession(storage, WALLET_B)).not.toBeNull()
    expect(loadSession(storage, WALLET_B)!.userId).toBe('user-b')
  })

  it('session key is normalised to lowercase', () => {
    // Saving with mixed-case should be retrievable with lowercase
    const session: StoredSession = {
      walletAddress: WALLET_A,
      userId: 'user-a',
      accessToken: 'tok.a',
      refreshToken: 'ref.a',
      expiresAt: new Date(Date.now() + 3600_000).toISOString(),
    }
    saveSession(storage, session)
    // sessionKey always lowercases — ensure retrieval works with the stored key
    const key = sessionKey(WALLET_A)
    expect(key).toBe(key.toLowerCase())
    expect(loadSession(storage, WALLET_A.toUpperCase())).not.toBeNull()
  })
})

describe('authorization boundary', () => {
  // These tests verify the LOGIC of the authorization decision, not an HTTP
  // call. They model the questions the RLS policy answers.

  function canWriteProfile(sessionUserId: string | null, profileUserId: string): boolean {
    // Mirrors: auth.uid()::text = user_id::text
    if (!sessionUserId) return false
    return sessionUserId === profileUserId
  }

  it('allows an authenticated user to write their own profile', () => {
    expect(canWriteProfile('user-uuid-abc', 'user-uuid-abc')).toBe(true)
  })

  it('rejects an unauthenticated request (no session)', () => {
    expect(canWriteProfile(null, 'user-uuid-abc')).toBe(false)
  })

  it('rejects an authenticated user attempting to write another profile', () => {
    expect(canWriteProfile('user-uuid-abc', 'user-uuid-xyz')).toBe(false)
  })

  it('rejects a forged userId that is similar but not identical', () => {
    expect(canWriteProfile('user-uuid-ab', 'user-uuid-abc')).toBe(false)
    expect(canWriteProfile('user-uuid-abcd', 'user-uuid-abc')).toBe(false)
    expect(canWriteProfile('user-uuid-ABC', 'user-uuid-abc')).toBe(false) // case mismatch
  })

  it('rejects an empty userId', () => {
    expect(canWriteProfile('', 'user-uuid-abc')).toBe(false)
  })
})

describe('challenge message integrity', () => {
  it('includes all required SIWE fields', () => {
    const now     = new Date().toISOString()
    const expires = new Date(Date.now() + 5 * 60_000).toISOString()
    const msg = buildChallengeMessage({
      domain: DOMAIN, walletAddress: WALLET_A, chainId: CHAIN_ID,
      nonce: NONCE, issuedAt: now, expiresAt: expires,
    })
    const lines = msg.split('\n')
    // Line 0: domain statement
    expect(lines[0]).toContain(DOMAIN)
    // Line 1: wallet address
    expect(lines[1]).toBe(WALLET_A)
    // Line 2: blank separator
    expect(lines[2]).toBe('')
    // Contains all required fields
    expect(msg).toContain('URI:')
    expect(msg).toContain('Version:')
    expect(msg).toContain('Chain ID:')
    expect(msg).toContain('Nonce:')
    expect(msg).toContain('Issued At:')
    expect(msg).toContain('Expiration Time:')
  })

  it('a different wallet produces a different message for the same nonce', () => {
    const now     = new Date().toISOString()
    const expires = new Date(Date.now() + 5 * 60_000).toISOString()
    const base = { domain: DOMAIN, chainId: CHAIN_ID, nonce: NONCE, issuedAt: now, expiresAt: expires }
    const msgA = buildChallengeMessage({ ...base, walletAddress: WALLET_A })
    const msgB = buildChallengeMessage({ ...base, walletAddress: WALLET_B })
    expect(msgA).not.toBe(msgB)
  })

  it('a different nonce produces a different message for the same wallet', () => {
    const now     = new Date().toISOString()
    const expires = new Date(Date.now() + 5 * 60_000).toISOString()
    const base = { domain: DOMAIN, walletAddress: WALLET_A, chainId: CHAIN_ID, issuedAt: now, expiresAt: expires }
    const msg1 = buildChallengeMessage({ ...base, nonce: 'a'.repeat(64) })
    const msg2 = buildChallengeMessage({ ...base, nonce: 'b'.repeat(64) })
    expect(msg1).not.toBe(msg2)
  })
})

describe('rejected scenarios', () => {
  it('profile update without session: canWriteProfile returns false', () => {
    const canWrite = (sessionUserId: string | null, profileUserId: string) =>
      sessionUserId !== null && sessionUserId === profileUserId
    expect(canWrite(null, 'uid-1')).toBe(false)
  })

  it('forged wallet address: canWriteProfile with different userId returns false', () => {
    // Attacker knows victim wallet but has a different userId in their token
    const attackerUserId = 'attacker-uid'
    const victimUserId   = 'victim-uid'
    const canWrite = (sessionUserId: string | null, profileUserId: string) =>
      sessionUserId !== null && sessionUserId === profileUserId
    expect(canWrite(attackerUserId, victimUserId)).toBe(false)
  })

  it('expired challenge is rejected by isChallengeExpired', () => {
    const expired = new Date(Date.now() - 1).toISOString()
    expect(isChallengeExpired(expired)).toBe(true)
  })

  it('nonexistent challenge: loadSession returns null for unknown wallet', () => {
    const storage = new MockSessionStorage()
    expect(loadSession(storage, '0x' + 'f'.repeat(40))).toBeNull()
  })

  it('previously used challenge (deleted): loadSession returns null after clearSession', () => {
    const storage = new MockSessionStorage()
    const session: StoredSession = {
      walletAddress: WALLET_A, userId: 'u1',
      accessToken: 'tok', refreshToken: 'ref',
      expiresAt: new Date(Date.now() + 3600_000).toISOString(),
    }
    saveSession(storage, session)
    clearSession(storage, WALLET_A)
    expect(loadSession(storage, WALLET_A)).toBeNull()
  })

  it('wallet/session mismatch: session for WALLET_A cannot be loaded under WALLET_B', () => {
    const storage = new MockSessionStorage()
    const session: StoredSession = {
      walletAddress: WALLET_A, userId: 'u1',
      accessToken: 'tok', refreshToken: 'ref',
      expiresAt: new Date(Date.now() + 3600_000).toISOString(),
    }
    saveSession(storage, session)
    // WALLET_B returns no session
    expect(loadSession(storage, WALLET_B)).toBeNull()
    // WALLET_A still has its session
    expect(loadSession(storage, WALLET_A)).not.toBeNull()
  })
})

describe('accepted scenarios', () => {
  it('valid auth: canWriteProfile with matching userId', () => {
    const canWrite = (sId: string | null, pId: string) => sId !== null && sId === pId
    expect(canWrite('user-abc', 'user-abc')).toBe(true)
  })

  it('reconnecting same wallet: existing session is restored', () => {
    const storage = new MockSessionStorage()
    const session: StoredSession = {
      walletAddress: WALLET_A, userId: 'u1',
      accessToken: 'tok', refreshToken: 'ref',
      expiresAt: new Date(Date.now() + 3600_000).toISOString(),
    }
    saveSession(storage, session)
    // "Reconnect" = same wallet, same storage
    const restored = loadSession(storage, WALLET_A)
    expect(restored).not.toBeNull()
    expect(restored!.userId).toBe('u1')
  })

  it('new wallet: fresh session can be saved and loaded', () => {
    const storage = new MockSessionStorage()
    const newWallet = '0x' + '9'.repeat(40)
    const session: StoredSession = {
      walletAddress: newWallet, userId: 'new-uid',
      accessToken: 'tok-new', refreshToken: 'ref-new',
      expiresAt: new Date(Date.now() + 3600_000).toISOString(),
    }
    saveSession(storage, session)
    const loaded = loadSession(storage, newWallet)
    expect(loaded).not.toBeNull()
    expect(loaded!.userId).toBe('new-uid')
  })

  it('public profile read: no auth required (read path uses anon client)', () => {
    // The read path in useProfile uses the anon `supabase` client, not a wallet
    // client. RLS: profiles_anon_read allows SELECT for everyone.
    // This test documents the invariant: reading a profile is always allowed.
    const canRead = (_sessionUserId: string | null) => true // anon read is always open
    expect(canRead(null)).toBe(true)
    expect(canRead('any-user-id')).toBe(true)
  })
})
