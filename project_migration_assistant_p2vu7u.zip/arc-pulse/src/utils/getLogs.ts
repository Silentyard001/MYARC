/**
 * getPaginatedLogs
 *
 * Drop-in replacement for publicClient.getLogs({ fromBlock: 0n, toBlock: 'latest' })
 * that works within the Arc Testnet RPC's 100,000-block-per-request limit.
 *
 * Strategy:
 *   1. Fetch the current block number.
 *   2. Split [0, currentBlock] into chunks of CHUNK_SIZE blocks.
 *   3. For each chunk, try publicClient.getLogs first (uses wagmi transport,
 *      which prefers rpc.testnet.arc.io after the rank:true fix).
 *   4. If the client call fails (CORS / rate-limit from ThirdWeb leaking
 *      through), retry the chunk via a raw JSON-RPC fetch directly against
 *      rpc.testnet.arc.io — this bypasses any wagmi transport routing.
 *   5. Execute chunks sequentially with a 150 ms inter-chunk delay.
 *   6. Merge all results into a single flat array.
 *
 * This is a temporary workaround until the Goldsky subgraph is deployed and
 * VITE_SUBGRAPH_URL is set — at that point the subgraph path in each hook
 * takes over automatically and this function is never called.
 */

import type { Log } from 'viem'
import type { PublicClient } from 'viem'
import { decodeEventLog } from 'viem'

/** Max blocks per getLogs request (RPC limit is 100 000; use 99 000 for safety). */
const CHUNK_SIZE = 99_000n

/** Delay between sequential chunk requests (ms). */
const CHUNK_DELAY_MS = 150

/** Direct RPC endpoint — used as raw-fetch fallback when the wagmi client fails. */
const ARC_RPC_DIRECT = 'https://rpc.testnet.arc.io'

// We use `any` for the filter fields that involve viem's complex
// discriminated-union overloads, and cast internally. This avoids fighting
// TypeScript's overload resolution while keeping the public API ergonomic.
export type PaginatedFilter = {
  address?: `0x${string}` | `0x${string}`[]
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  event?: any
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  args?: any
  strict?: boolean
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

function toHex(n: bigint): string {
  return '0x' + n.toString(16)
}

/**
 * Raw JSON-RPC fallback for a single chunk.
 * Called when publicClient.getLogs throws (CORS / rate-limit).
 * Sends eth_getLogs directly to rpc.testnet.arc.io and decodes
 * event args when an ABI event is provided in the filter.
 */
async function fetchChunkDirect(
  filter: PaginatedFilter,
  fromBlock: bigint,
  toBlock: bigint,
): Promise<Log[]> {
  const rpcFilter: Record<string, unknown> = {
    fromBlock: toHex(fromBlock),
    toBlock: toHex(toBlock),
  }
  if (filter.address) rpcFilter.address = filter.address

  // Build topics from the event ABI if provided
  if (filter.event) {
    try {
      // Use viem's encodeEventTopics to derive the topic0 signature hash
      const { encodeEventTopics } = await import('viem')
      // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
      const topics = encodeEventTopics({ abi: [filter.event], args: filter.args as never })
      if (topics.length > 0) rpcFilter.topics = topics
    } catch {
      // If topic encoding fails, proceed without topic filter (over-fetches)
    }
  }

  const res = await fetch(ARC_RPC_DIRECT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      jsonrpc: '2.0',
      id: 1,
      method: 'eth_getLogs',
      params: [rpcFilter],
    }),
  })

  if (!res.ok) throw new Error(`eth_getLogs direct fetch failed: ${res.status}`)

  const json = await res.json() as { result?: unknown[]; error?: { message: string } }
  if (json.error) throw new Error(`eth_getLogs RPC error: ${json.error.message}`)

  type RawLog = {
    address: `0x${string}`
    topics: [`0x${string}`, ...`0x${string}`[]]
    data: `0x${string}`
    blockNumber: `0x${string}`
    transactionHash: `0x${string}`
    transactionIndex: `0x${string}`
    blockHash: `0x${string}`
    logIndex: `0x${string}`
    removed: boolean
  }
  const rawLogs = (json.result ?? []) as RawLog[]

  return rawLogs.map((raw) => {
    const base: Log = {
      address: raw.address,
      topics: raw.topics,
      data: raw.data,
      blockNumber: BigInt(raw.blockNumber),
      transactionHash: raw.transactionHash,
      transactionIndex: Number(BigInt(raw.transactionIndex)),
      blockHash: raw.blockHash,
      logIndex: Number(BigInt(raw.logIndex)),
      removed: raw.removed,
    }

    // Decode args when ABI event is available
    if (filter.event) {
      try {
        // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
        const decoded = decodeEventLog({ abi: [filter.event], data: raw.data, topics: raw.topics })
        const { args, eventName } = decoded as { args: Record<string, unknown>; eventName: string }
        return { ...base, args, eventName } as Log
      } catch {
        // Return undecoded log — callers handle missing args defensively
      }
    }

    return base
  })
}

export async function getPaginatedLogs(
  publicClient: PublicClient,
  filter: PaginatedFilter,
): Promise<Log[]> {
  const currentBlock = await publicClient.getBlockNumber()

  const allLogs: Log[] = []
  let from = 0n

  while (from <= currentBlock) {
    const to = from + CHUNK_SIZE - 1n <= currentBlock
      ? from + CHUNK_SIZE - 1n
      : currentBlock

    if (from > 0n) await sleep(CHUNK_DELAY_MS)

    try {
      // Cast through any to bypass viem's discriminated-union overloads.
      // The fields we pass are valid at runtime; only the static types conflict.
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const logs = await (publicClient.getLogs as (p: any) => Promise<Log[]>)({
        ...filter,
        fromBlock: from,
        toBlock: to,
      })
      allLogs.push(...logs)
    } catch {
      // Client call failed (likely ThirdWeb CORS or rate-limit).
      // Retry this chunk directly against rpc.testnet.arc.io.
      const logs = await fetchChunkDirect(filter, from, to)
      allLogs.push(...logs)
    }

    from = to + 1n
  }

  return allLogs
}
