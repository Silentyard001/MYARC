/**
 * projectId utilities
 *
 * ENCODING CONTRACT
 * ─────────────────
 * MYARC.sol identifies projects by bytes32 keys. We use right-padded UTF-8:
 *
 *   bytes32(slug)  ≡  padHex(stringToHex(slug), { size: 32, dir: 'right' })
 *
 * This is identical to Solidity's `bytes32("arcswap")` literal — the string
 * bytes are placed in the HIGH (left) bytes and the remainder is zero-padded
 * on the right. Slugs must be ≤ 32 ASCII characters to avoid truncation.
 *
 * The Forge test suite encodes slugs the same way via `bytes32("arcswap")`,
 * so frontend and contract are always in sync. Do NOT switch to keccak256
 * encoding without updating both the tests and the seed data.
 */
import { stringToHex, padHex } from 'viem'

/**
 * Convert a project slug to the bytes32 key used on-chain.
 * Right-pads the UTF-8 bytes to 32 bytes — matches Solidity `bytes32("slug")`.
 */
export function slugToBytes32(slug: string): `0x${string}` {
  const hex = stringToHex(slug)
  return padHex(hex, { size: 32, dir: 'right' })
}

/**
 * Reverse of slugToBytes32: trim trailing zero bytes from a right-padded bytes32
 * and decode the remaining UTF-8. Returns the original slug if the encoding was
 * produced by slugToBytes32 and the slug was ≤ 32 ASCII characters.
 */
export function bytes32ToSlug(bytes32: `0x${string}`): string {
  // Strip 0x prefix and trailing zero pairs
  const hex = bytes32.slice(2).replace(/00+$/, '')
  // Decode hex → UTF-8 bytes → string
  const bytes = new Uint8Array(hex.match(/.{1,2}/g)?.map((b) => parseInt(b, 16)) ?? [])
  return new TextDecoder().decode(bytes)
}

/** Sentiment string → uint8 as used by the contract (0=Bullish,1=Neutral,2=Bearish) */
export function sentimentToUint8(s: 'bullish' | 'neutral' | 'bearish'): 0 | 1 | 2 {
  if (s === 'bullish') return 0
  if (s === 'neutral') return 1
  return 2
}

/** uint8 → sentiment string */
export function uint8ToSentiment(n: number): 'bullish' | 'neutral' | 'bearish' {
  if (n === 1) return 'bullish'   // packed vote: 1=Bullish
  if (n === 2) return 'neutral'   // packed vote: 2=Neutral
  return 'bearish'                // packed vote: 3=Bearish
}
