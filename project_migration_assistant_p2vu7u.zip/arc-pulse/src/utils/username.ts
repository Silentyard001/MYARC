/**
 * username.ts
 *
 * Central username validation and reserved-name handling for MYARC.
 *
 * Rules:
 *   - 3–20 characters
 *   - Lowercase letters, digits, underscores only (a-z 0-9 _)
 *   - Must not be in the reserved list
 *   - Stored and compared case-insensitively (normalise to lowercase before save/compare)
 *
 * The RESERVED list lives here — never scatter it across frontend components.
 * To add a reserved name, extend the array below.
 */

// ── Reserved usernames ─────────────────────────────────────────────────────────
export const RESERVED_USERNAMES: readonly string[] = [
  'admin',
  'administrator',
  'support',
  'arc',
  'myarc',
  'official',
  'moderator',
]

// ── Normalisation ──────────────────────────────────────────────────────────────

/** Normalise a username to its canonical form for storage and comparison. */
export function normaliseUsername(raw: string): string {
  return raw.trim().toLowerCase()
}

// ── Validation ────────────────────────────────────────────────────────────────

export type UsernameValidationResult =
  | { valid: true }
  | { valid: false; reason: string }

const USERNAME_RE = /^[a-z0-9_]{3,20}$/

/**
 * Validate a username.
 *
 * Accepts the raw user input; normalises internally before testing.
 * Returns { valid: true } or { valid: false, reason: string }.
 */
export function validateUsername(raw: string): UsernameValidationResult {
  if (!raw || raw.trim().length === 0) {
    return { valid: false, reason: 'Username is required.' }
  }

  const normalised = normaliseUsername(raw)

  if (normalised.length < 3) {
    return { valid: false, reason: 'Username must be at least 3 characters.' }
  }

  if (normalised.length > 20) {
    return { valid: false, reason: 'Username must be 20 characters or fewer.' }
  }

  if (!USERNAME_RE.test(normalised)) {
    return {
      valid: false,
      reason: 'Username may only contain letters, numbers, and underscores.',
    }
  }

  if (RESERVED_USERNAMES.includes(normalised)) {
    return { valid: false, reason: 'That username is reserved.' }
  }

  return { valid: true }
}

/**
 * Format a username for display (prepends @).
 * Returns null when username is null/empty.
 */
export function formatUsername(username: string | null | undefined): string | null {
  if (!username) return null
  return `@${username}`
}

/**
 * Return the short display label for a wallet address.
 * e.g. 0x83F2...A91C
 */
export function shortAddress(address: string): string {
  if (address.length < 10) return address
  return `${address.slice(0, 6)}...${address.slice(-4)}`
}
