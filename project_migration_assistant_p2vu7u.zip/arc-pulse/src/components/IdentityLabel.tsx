/**
 * IdentityLabel
 *
 * The single source of truth for rendering a wallet address as a MYARC
 * identity. All UI that displays a user must go through this component or
 * the useProfileCache hook — never format wallet addresses inline.
 *
 * Identity resolution order:
 *   1. @username         (if set)
 *   2. displayName       (if set)
 *   3. "Anonymous User"  (fallback — never a raw wallet address)
 *
 * Wallet address shown only when walletVisibility === 'public', using the
 * existing shortened format (0x83F2…A91C). Never exposed when hidden.
 *
 * The component self-fetches via useProfileCache — no pre-loading needed.
 */

import { useEffect } from 'react'
import { useProfileCache } from '../hooks/useProfileCache'

interface IdentityLabelProps {
  /** Raw wallet address used as the lookup key (never displayed unless public). */
  address: string
  /**
   * When true, append the (visibility-gated) shortened wallet address after
   * the identity label. Silently omitted when walletVisibility is hidden.
   */
  showAddress?: boolean
  /** Rendered while the profile is still loading. Default: empty. */
  fallback?: string
  /** Tailwind / custom class applied to the root element. */
  className?: string
  style?: React.CSSProperties
  /** When provided, the label is rendered as a button that fires onClick(address). */
  onClick?: (address: string) => void
}

export function IdentityLabel({
  address,
  showAddress = false,
  fallback = '',
  className,
  style,
  onClick,
}: IdentityLabelProps) {
  const { resolve, getLabel, getPublicAddress } = useProfileCache()

  useEffect(() => {
    if (address) resolve([address])
  }, [address, resolve])

  const label     = getLabel(address) ?? fallback
  const publicAddr = showAddress ? getPublicAddress(address) : null

  const content = (
    <>
      {label && <span>{label}</span>}
      {showAddress && publicAddr && (
        <span
          className="mono"
          style={{ fontSize: '0.75em', opacity: 0.65, marginLeft: '0.4em' }}
        >
          {publicAddr}
        </span>
      )}
    </>
  )

  if (onClick) {
    return (
      <button
        type="button"
        onClick={() => onClick(address)}
        className={className}
        style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', ...style }}
      >
        {content}
      </button>
    )
  }

  return (
    <span className={className} style={style}>
      {content}
    </span>
  )
}
