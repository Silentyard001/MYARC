/**
 * TvlSparkline
 *
 * A lightweight pure-SVG sparkline for historical TVL data.
 * No chart library dependency — just React + SVG.
 *
 * Renders a smooth polyline with an optional gradient fill.
 * Coloured green when the last value >= first, red otherwise.
 */

import type { TvlSnapshot } from '../data/projects'

interface TvlSparklineProps {
  data: TvlSnapshot[]
  width?: number
  height?: number
  /** Show the gradient fill below the line. Default true. */
  fill?: boolean
}

export function TvlSparkline({ data, width = 80, height = 28, fill = true }: TvlSparklineProps) {
  if (!data || data.length < 2) return null

  const values = data.map((d) => d.tvlM)
  const min = Math.min(...values)
  const max = Math.max(...values)
  const range = max - min || 1 // avoid divide-by-zero

  // Map value → SVG y coordinate (inverted: higher = lower y)
  const pad = 2
  const toX = (i: number) => pad + (i / (values.length - 1)) * (width - pad * 2)
  const toY = (v: number) => pad + ((max - v) / range) * (height - pad * 2)

  const points = values.map((v, i) => `${toX(i)},${toY(v)}`).join(' ')
  const isUp = values[values.length - 1] >= values[0]

  const strokeColor = isUp ? 'var(--bullish)' : 'var(--bearish)'
  // Stable deterministic ID from the data itself to avoid Math.random in render
  const fillId = `sparkfill-${values.length}-${values[0]}-${values[values.length - 1]}`

  // Close the fill path: go to bottom-right, bottom-left, then back up
  const lastX = toX(values.length - 1)
  const firstX = toX(0)
  const bottom = height - pad + 2

  const fillPath = `M ${firstX},${toY(values[0])} L ${points.replace(/^[^ ]+ /, '')} L ${lastX},${bottom} L ${firstX},${bottom} Z`

  return (
    <svg
      width={width}
      height={height}
      viewBox={`0 0 ${width} ${height}`}
      fill="none"
      aria-hidden="true"
      style={{ display: 'block', overflow: 'visible' }}
    >
      {fill && (
        <defs>
          <linearGradient id={fillId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={strokeColor} stopOpacity={0.25} />
            <stop offset="100%" stopColor={strokeColor} stopOpacity={0} />
          </linearGradient>
        </defs>
      )}
      {fill && (
        <path
          d={fillPath}
          fill={`url(#${fillId})`}
        />
      )}
      <polyline
        points={points}
        stroke={strokeColor}
        strokeWidth={1.5}
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
      {/* End dot */}
      <circle
        cx={toX(values.length - 1)}
        cy={toY(values[values.length - 1])}
        r={2}
        fill={strokeColor}
      />
    </svg>
  )
}
