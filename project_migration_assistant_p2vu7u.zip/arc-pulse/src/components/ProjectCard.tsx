import { motion, useReducedMotion, useAnimation } from 'framer-motion'
import { useRef, useEffect } from 'react'
import { MessageSquare, TrendingUp, TrendingDown, Minus, Globe, BadgeCheck, Bookmark, BookmarkCheck, AlertTriangle } from 'lucide-react'
import type { Project, Sentiment, VoteCounts } from '../data/projects'
import { VoteBar } from './VoteBar'
import { TvlSparkline } from './TvlSparkline'
import { ProjectLogo } from './ProjectLogo'
import { AnimatedNumber } from './AnimatedNumber'
import { useTaxonomy } from '../hooks/useTaxonomy'

interface ProjectCardProps {
  project: Project
  userVote: Sentiment | null
  onVote: (projectId: string, sentiment: Sentiment) => void
  onSelect: (project: Project) => void
  isConnected?: boolean
  isVerified?: boolean
  isWatched?: boolean
  onToggleWatchlist?: (projectId: string) => void
}

// Minimum ms between accepted clicks — prevents animation glitches on rapid taps.
const CLICK_DEBOUNCE_MS = 150

function VoteButton({
  sentiment,
  active,
  count,
  onClick,
}: {
  sentiment: Sentiment
  active: boolean
  count: number
  onClick: () => void
}) {
  // Active state backgrounds use CSS-variable-relative tints so they work in
  // both light (#1a8047 green) and dark (#8dd89f soft green) modes.
  const cfg = {
    bullish: { icon: TrendingUp,   label: 'Bullish', activeBg: 'color-mix(in srgb, var(--bullish) 12%, transparent)', activeBorder: 'color-mix(in srgb, var(--bullish) 30%, transparent)' },
    neutral: { icon: Minus,        label: 'Neutral', activeBg: 'color-mix(in srgb, var(--neutral) 12%, transparent)', activeBorder: 'color-mix(in srgb, var(--neutral) 30%, transparent)' },
    bearish: { icon: TrendingDown, label: 'Bearish', activeBg: 'color-mix(in srgb, var(--bearish) 12%, transparent)', activeBorder: 'color-mix(in srgb, var(--bearish) 30%, transparent)' },
  }
  const { icon: Icon, label, activeBg, activeBorder } = cfg[sentiment]

  const prefersReduced = useReducedMotion()
  const controls = useAnimation()
  const lastClickRef = useRef<number>(0)
  const prevActiveRef = useRef(active)

  // Fire the settle animation when this button transitions to active.
  // Skipped entirely under prefers-reduced-motion.
  useEffect(() => {
    if (!prefersReduced && active && !prevActiveRef.current) {
      void controls.start({
        scale: [1, 0.96, 0.99, 1],
        transition: { duration: 0.18, ease: 'easeOut', times: [0, 0.4, 0.75, 1] },
      })
    }
    prevActiveRef.current = active
  }, [active, controls, prefersReduced])

  function handleClick() {
    const now = Date.now()
    if (now - lastClickRef.current < CLICK_DEBOUNCE_MS) return
    lastClickRef.current = now
    onClick()
  }

  return (
    <motion.button
      animate={controls}
      whileTap={prefersReduced ? undefined : { scale: 0.95 }}
      onClick={handleClick}
      className="flex-1 flex items-center justify-center gap-2 py-2 rounded-xl border transition-all duration-150 select-none min-h-[44px]"
      style={
        active
          ? { background: activeBg, color: `var(--${sentiment})`, borderColor: activeBorder, borderWidth: '1px' }
          : {
              background: 'transparent',
              color: 'var(--subtle)',
              borderColor: 'var(--border)',
              borderWidth: '1px',
            }
      }
    >
      <Icon size={14} strokeWidth={active ? 2.5 : 1.75} />
      <AnimatedNumber
        value={count}
        duration={prefersReduced ? 0 : 0.35}
        className="text-xs font-semibold tabular-nums"
        style={{ color: 'inherit' }}
        aria-hidden="true"
      />
      <span className="text-[10px] font-medium hidden sm:inline" style={{ opacity: active ? 0.9 : 0.6 }}>
        {label}
      </span>
    </motion.button>
  )
}

function getDominantSentiment(votes: VoteCounts): Sentiment {
  if (votes.bullish >= votes.neutral && votes.bullish >= votes.bearish) return 'bullish'
  if (votes.bearish > votes.bullish && votes.bearish > votes.neutral) return 'bearish'
  return 'neutral'
}

export function ProjectCard({
  project,
  userVote,
  onVote,
  onSelect,
  isConnected = false,
  isVerified = false,
  isWatched = false,
  onToggleWatchlist,
}: ProjectCardProps) {
  const dominant = getDominantSentiment(project.votes)
  const BookmarkIcon = isWatched ? BookmarkCheck : Bookmark
  const prefersReduced = useReducedMotion()
  const taxonomy = useTaxonomy()
  const categoryLabel = project.primaryCategory
    ? (taxonomy.getCategory(project.primaryCategory)?.label ?? project.primaryCategory)
    : null

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={prefersReduced ? undefined : { y: -2, transition: { duration: 0.15, ease: 'easeOut' } }}
      className="rounded-2xl border p-5 space-y-3 transition-shadow duration-200"
      style={{
        background: 'var(--surface)',
        borderColor: 'var(--border)',
        boxShadow: 'var(--card-shadow)',
      }}
    >
      {/* Header */}
      <div className="flex items-start gap-3">
        <ProjectLogo project={project} size="md" />

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="display font-semibold text-base leading-tight" style={{ color: 'var(--ink)' }}>
              {project.name}
            </h3>
            {/* Verified badge */}
            {isVerified && !project.verifiedBadgeHidden && (
              <BadgeCheck size={15} style={{ color: 'var(--accent)', flexShrink: 0 }} strokeWidth={2.5} />
            )}
            <span
              className="w-1.5 h-1.5 rounded-full flex-shrink-0"
              style={{ background: dominant === 'bullish' ? 'var(--bullish)' : dominant === 'bearish' ? 'var(--bearish)' : 'var(--neutral)' }}
            />
          </div>
          <p className="text-sm mt-0.5 leading-snug" style={{ color: 'var(--muted)' }}>
            {project.tagline}
          </p>
        </div>

        {/* Bookmark toggle */}
        <button
          onClick={(e) => { e.stopPropagation(); onToggleWatchlist?.(project.id) }}
          className="flex-shrink-0 p-2 rounded-xl transition-all hover:opacity-70 min-h-[44px] min-w-[44px] flex items-center justify-center"
          style={{
            background: isWatched ? 'rgba(26,92,255,0.08)' : 'var(--surface-muted)',
            color: isWatched ? 'var(--accent)' : 'var(--muted)',
          }}
          title={isWatched ? 'Remove from watchlist' : 'Add to watchlist'}
        >
          <BookmarkIcon size={15} strokeWidth={isWatched ? 2.5 : 2} />
        </button>
      </div>

      {/* Classification chips + meta */}
      <div className="flex items-center gap-1.5 flex-wrap">
        {/* Primary category — accent tint */}
        {categoryLabel && (
          <span
            className="text-[11px] px-2 py-0.5 rounded-full font-medium"
            style={{ background: 'color-mix(in srgb, var(--accent) 10%, transparent)', color: 'var(--accent)' }}
          >
            {categoryLabel}
          </span>
        )}
        {/* Canonical tags — subtle */}
        {project.canonicalTags?.map((tag) => (
          <span
            key={tag}
            className="text-[11px] px-2 py-0.5 rounded-full"
            style={{ background: 'var(--surface-muted)', color: 'var(--subtle)' }}
          >
            {tag}
          </span>
        ))}
        {project.tvl && (
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] px-2 py-0.5 rounded-full font-medium tabular-nums"
              style={{ background: 'rgba(26,128,71,0.08)', color: 'var(--bullish)' }}>
              TVL {project.tvl}
            </span>
            {project.tvlHistory && (
              <TvlSparkline data={project.tvlHistory} width={48} height={18} />
            )}
          </div>
        )}
        <span className="text-[11px] ml-auto" style={{ color: 'var(--subtle)', opacity: 0.7 }}>
          {project.launchDate}
        </span>
      </div>

      {/* Vote bar */}
      <VoteBar votes={project.votes} />

      {/* Vote buttons */}
      <div className="flex gap-2">
        {(['bullish', 'neutral', 'bearish'] as Sentiment[]).map((s) => (
          <VoteButton
            key={s}
            sentiment={s}
            active={userVote === s}
            count={project.votes[s]}
            onClick={() => onVote(project.id, s)}
          />
        ))}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between gap-2 pt-0.5">
        <button
          onClick={() => onSelect(project)}
          className="flex items-center gap-1.5 text-sm font-medium transition-opacity hover:opacity-75"
          style={{ color: 'var(--accent)' }}
        >
          <MessageSquare size={13} />
          {project.reviews.length} review{project.reviews.length !== 1 ? 's' : ''}
        </button>
        <div className="flex items-center gap-3">
          {project.website && (
            <a
              href={project.website}
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => e.stopPropagation()}
              className="flex items-center gap-1 text-xs transition-opacity hover:opacity-70"
              style={{ color: 'var(--subtle)' }}
            >
              <Globe size={11} />
              Website
            </a>
          )}
          <button
            onClick={() => onSelect(project)}
            className="text-xs transition-opacity hover:opacity-70"
            style={{ color: 'var(--subtle)' }}
          >
            Details
          </button>
        </div>
      </div>

      {/* Wallet nudge — shown only when not connected */}
      {!isConnected && (
        <p className="text-xs text-center pt-1" style={{ color: 'var(--subtle)' }}>
          Connect wallet to vote
        </p>
      )}

      {/* Status banner */}
      {(project.status === 'under_review' || project.status === 'inactive') && (
        <div
          className="flex items-center gap-2 px-3 py-2 rounded-xl -mx-0"
          style={{
            background: project.status === 'under_review' ? 'rgba(245,158,11,0.10)' : 'rgba(100,116,139,0.10)',
            border: `1px solid ${project.status === 'under_review' ? 'rgba(245,158,11,0.28)' : 'rgba(100,116,139,0.22)'}`,
          }}
        >
          <AlertTriangle size={12} style={{ color: project.status === 'under_review' ? '#f59e0b' : 'var(--muted)', flexShrink: 0 }} />
          <span className="text-xs font-semibold" style={{ color: project.status === 'under_review' ? '#f59e0b' : 'var(--muted)' }}>
            {project.status === 'under_review' ? 'Under Review' : 'Inactive'}
          </span>
        </div>
      )}
    </motion.div>
  )
}
