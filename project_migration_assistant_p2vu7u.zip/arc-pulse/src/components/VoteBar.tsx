/**
 * VoteBar — MYARC sentiment instrument.
 *
 * Renders community sentiment as a single continuous track rather than
 * three isolated bars. The bullish zone anchors the left, bearish anchors
 * the right, and neutral fills the centre naturally.
 *
 * All percentages are derived from the passed VoteCounts — nothing is
 * invented here.
 *
 * Size variants:
 *   'md' — full instrument with a text readout below (ProjectCard, detail sheet)
 *   'sm' — track only, no labels (FeaturedBanner, LeaderboardRow)
 */

import { motion, useReducedMotion } from 'framer-motion'
import type { VoteCounts } from '../data/projects'
import { AnimatedNumber } from './AnimatedNumber'

interface VoteBarProps {
  votes: VoteCounts
  size?: 'sm' | 'md'
}

export function VoteBar({ votes, size = 'md' }: VoteBarProps) {
  const total = votes.bullish + votes.neutral + votes.bearish
  const prefersReduced = useReducedMotion()

  if (total === 0) return null

  const bullPct = Math.round((votes.bullish / total) * 100)
  const neutPct = Math.round((votes.neutral / total) * 100)
  const bearPct = 100 - bullPct - neutPct

  // Dominant sentiment for the text readout
  const dominant: 'bullish' | 'neutral' | 'bearish' =
    votes.bullish >= votes.neutral && votes.bullish >= votes.bearish
      ? 'bullish'
      : votes.bearish > votes.bullish && votes.bearish > votes.neutral
      ? 'bearish'
      : 'neutral'

  const dominantPct = dominant === 'bullish' ? bullPct : dominant === 'bearish' ? bearPct : neutPct

  // Sentiment colour tokens
  const COLORS = {
    bullish: { fill: 'var(--bullish)', label: 'Bullish',  ariaLabel: 'bullish' },
    neutral: { fill: 'var(--neutral)', label: 'Neutral',  ariaLabel: 'neutral' },
    bearish: { fill: 'var(--bearish)', label: 'Bearish',  ariaLabel: 'bearish' },
  }

  const trackH = size === 'sm' ? '4px' : '6px'
  const dur    = prefersReduced ? 0 : 0.55

  return (
    <div className="space-y-1.5">
      {/* Track */}
      <div
        className="relative w-full overflow-hidden rounded-full"
        style={{
          height: trackH,
          background: 'var(--surface-muted)',
        }}
        role="img"
        aria-label={
          `Community sentiment: ${bullPct}% bullish, ${neutPct}% neutral, ${bearPct}% bearish — ${total.toLocaleString()} votes total`
        }
      >
        {/* Bullish zone — left anchor */}
        {bullPct > 0 && (
          <motion.div
            className="absolute left-0 top-0 h-full"
            initial={{ width: 0 }}
            animate={{ width: `${bullPct}%` }}
            transition={{ duration: dur, ease: [0.25, 0.1, 0.25, 1] }}
            style={{
              background: 'var(--bullish)',
              // Subtle tonal fade — the right edge is very slightly lighter,
              // giving the zone a sense of depth rather than flat paint.
              // Uses a white overlay gradient (neutral blending, no color shift).
              backgroundImage: 'linear-gradient(to right, transparent 60%, rgba(255,255,255,0.09) 100%)',
            }}
          />
        )}

        {/* Neutral zone — middle */}
        {neutPct > 0 && (
          <motion.div
            className="absolute top-0 h-full"
            initial={{ width: 0, left: `${bullPct}%` }}
            animate={{ width: `${neutPct}%`, left: `${bullPct}%` }}
            transition={{ duration: dur, ease: [0.25, 0.1, 0.25, 1], delay: prefersReduced ? 0 : 0.08 }}
            style={{ background: 'var(--neutral)', opacity: 0.55 }}
          />
        )}

        {/* Bearish zone — right anchor */}
        {bearPct > 0 && (
          <motion.div
            className="absolute right-0 top-0 h-full"
            initial={{ width: 0 }}
            animate={{ width: `${bearPct}%` }}
            transition={{ duration: dur, ease: [0.25, 0.1, 0.25, 1], delay: prefersReduced ? 0 : 0.14 }}
            style={{
              background: 'var(--bearish)',
              backgroundImage: 'linear-gradient(to left, transparent 60%, rgba(255,255,255,0.09) 100%)',
            }}
          />
        )}
      </div>

      {/* Text readout — md size only */}
      {size === 'md' && (
        <div className="flex items-baseline justify-between gap-2">
          {/* Dominant sentiment — primary read */}
          <span
            className="text-[11px] font-semibold tabular-nums"
            style={{
              color: COLORS[dominant].fill,
              transition: prefersReduced ? undefined : 'color 0.3s ease',
            }}
            aria-hidden="true"
          >
            <AnimatedNumber
              value={dominantPct}
              suffix="%"
              duration={prefersReduced ? 0 : 0.4}
              style={{ color: 'inherit' }}
            />
            {' '}
            <span className="font-medium" style={{ opacity: 0.85 }}>
              {COLORS[dominant].label.toLowerCase()}
            </span>
          </span>

          {/* Vote count — secondary context */}
          <AnimatedNumber
            value={total}
            suffix=" votes"
            duration={prefersReduced ? 0 : 0.4}
            className="text-[11px] tabular-nums"
            style={{ color: 'var(--subtle)' }}
            aria-hidden="true"
          />
        </div>
      )}
    </div>
  )
}
