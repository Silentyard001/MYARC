/**
 * ProfileSettingsModal
 *
 * Bottom-sheet modal for editing the connected wallet's MYARC profile.
 * Uses the existing MYARC design tokens and component patterns.
 *
 * Fields:
 *   - Username (optional, unique, @handle)
 *   - Display Name
 *   - Avatar URL
 *   - Bio
 *   - Wallet Visibility (hidden / public toggle)
 */

import { useState, useEffect, useRef } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { X, User, AtSign, Eye, EyeOff, Image, FileText, Check, Loader2, ShieldCheck, AlertCircle } from 'lucide-react'
import { toast } from 'sonner'
import type { UserProfile, ProfileUpdatePayload, WalletVisibility } from '../hooks/useProfile'
import type { AuthStatus } from '../hooks/useAuth'
import { validateUsername, formatUsername, shortAddress } from '../utils/username'

interface ProfileSettingsModalProps {
  isOpen: boolean
  onClose: () => void
  profile: UserProfile | null
  onSave: (payload: ProfileUpdatePayload) => Promise<{ ok: boolean; error?: string }>
  /**
   * Phase 3: current authentication status. When not 'authenticated', the modal
   * shows a sign-in prompt instead of the edit form. The user must complete SIWE
   * authentication before profile changes are accepted by the server.
   */
  authStatus?: AuthStatus
  /** Called when the user clicks "Sign in to edit". Triggers the SIWE flow. */
  onSignIn?: () => Promise<unknown>
}

export function ProfileSettingsModal({ isOpen, onClose, profile, onSave, authStatus, onSignIn }: ProfileSettingsModalProps) {
  // Derive initial values from profile — reinitialise when the modal opens
  // by tracking the last profile snapshot we seeded from.
  const seededForRef = useRef<string | null>(null)
  const profileKey = profile?.userId ?? null

  const [username, setUsername]       = useState(() => profile?.username ?? '')
  const [displayName, setDisplayName] = useState(() => profile?.displayName ?? '')
  const [avatarUrl, setAvatarUrl]     = useState(() => profile?.avatarUrl ?? '')
  const [bio, setBio]                 = useState(() => profile?.bio ?? '')
  const [walletVisibility, setWalletVisibility] = useState<WalletVisibility>(
    () => profile?.walletVisibility ?? 'hidden'
  )
  const [usernameError, setUsernameError] = useState<string | null>(null)
  const [isSaving, setIsSaving]           = useState(false)
  const [isSigningIn, setIsSigningIn]     = useState(false)

  // Derived: whether the user needs to authenticate before saving.
  // When authStatus is undefined (Supabase not configured), we let the save
  // proceed — it will either succeed (if the server is somehow configured)
  // or fail gracefully (the old x-wallet-address path has been removed, so
  // the Supabase write will be rejected by RLS, but localStorage still works).
  const needsAuth = authStatus !== undefined && authStatus !== 'authenticated'

  // Re-seed form fields when the modal opens with a different profile
  useEffect(() => {
    if (isOpen && profile && seededForRef.current !== profileKey) {
      seededForRef.current = profileKey
      setUsername(profile.username ?? '')
      setDisplayName(profile.displayName ?? '')
      setAvatarUrl(profile.avatarUrl ?? '')
      setBio(profile.bio ?? '')
      setWalletVisibility(profile.walletVisibility)
      setUsernameError(null)
    }
    if (!isOpen) {
      // Reset seed marker so next open re-seeds
      seededForRef.current = null
    }
  // profileKey captures the identity; this effect is intentionally not exhaustive
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, profileKey])

  function handleUsernameChange(value: string) {
    setUsername(value)
    if (value.trim() === '') {
      setUsernameError(null)
      return
    }
    const result = validateUsername(value)
    setUsernameError(result.valid ? null : result.reason)
  }

  async function handleSignIn() {
    if (!onSignIn) return
    setIsSigningIn(true)
    try {
      await onSignIn()
    } finally {
      setIsSigningIn(false)
    }
  }

  async function handleSave() {
    // Validate username before save
    if (username.trim() !== '') {
      const result = validateUsername(username)
      if (!result.valid) {
        setUsernameError(result.reason)
        return
      }
    }

    setIsSaving(true)
    const payload: ProfileUpdatePayload = {
      username: username.trim() === '' ? null : username.trim(),
      displayName: displayName.trim(),
      avatarUrl: avatarUrl.trim() === '' ? null : avatarUrl.trim(),
      bio: bio.trim() === '' ? null : bio.trim(),
      walletVisibility,
    }

    const result = await onSave(payload)
    setIsSaving(false)

    if (result.ok) {
      toast.success('Profile saved.')
      onClose()
    } else {
      if (result.error?.toLowerCase().includes('username')) {
        setUsernameError(result.error ?? 'Username error.')
      } else {
        toast.error(result.error ?? 'Could not save profile.')
      }
    }
  }

  const walletLabel = profile
    ? profile.walletVisibility === 'public'
      ? shortAddress(profile.walletAddress)
      : 'Wallet hidden'
    : null

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            key="backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-40"
            style={{ background: 'rgba(0,0,0,0.45)', backdropFilter: 'blur(4px)' }}
            onClick={onClose}
          />

          {/* Sheet */}
          <motion.div
            key="sheet"
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', stiffness: 380, damping: 38 }}
            className="fixed bottom-0 left-0 right-0 z-50 max-w-2xl mx-auto rounded-t-3xl overflow-hidden"
            style={{
              background: 'var(--sheet-bg)',
              border: '1px solid var(--border)',
              maxHeight: '92dvh',
              display: 'flex',
              flexDirection: 'column',
            }}
          >
            {/* Drag handle */}
            <div className="flex justify-center pt-3 pb-1 flex-shrink-0">
              <div className="w-10 h-1 rounded-full" style={{ background: 'var(--border-strong)' }} />
            </div>

            {/* Header */}
            <div className="flex items-center justify-between px-5 py-3 flex-shrink-0"
              style={{ borderBottom: '1px solid var(--border)' }}>
              <div>
                <h2 className="display font-semibold text-base" style={{ color: 'var(--ink)' }}>
                  Profile Settings
                </h2>
                {profile && (
                  <p className="text-xs mt-0.5 mono" style={{ color: 'var(--subtle)' }}>
                    {walletLabel}
                  </p>
                )}
              </div>
              <button
                onClick={onClose}
                className="p-2 rounded-xl min-h-[44px] min-w-[44px] flex items-center justify-center transition-opacity hover:opacity-70"
                style={{ background: 'var(--surface-muted)', color: 'var(--muted)' }}
              >
                <X size={18} />
              </button>
            </div>

            {/* Scrollable body */}
            <div className="overflow-y-auto flex-1 px-5 py-5 space-y-5">

              {/* Username */}
              <div className="space-y-1.5">
                <label className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-widest"
                  style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                  <AtSign size={12} />
                  Username
                  <span style={{ color: 'var(--muted)', fontWeight: 400, textTransform: 'none', letterSpacing: 0 }}>
                    — optional
                  </span>
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-sm font-medium pointer-events-none"
                    style={{ color: 'var(--muted)' }}>
                    @
                  </span>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => handleUsernameChange(e.target.value)}
                    placeholder="yourhandle"
                    maxLength={20}
                    spellCheck={false}
                    autoComplete="off"
                    className="w-full pl-7 pr-4 py-3 rounded-xl text-sm outline-none transition-all"
                    style={{
                      background: 'var(--surface-muted)',
                      border: `1px solid ${usernameError ? 'var(--bearish)' : 'var(--border)'}`,
                      color: 'var(--ink)',
                      fontFamily: "'DM Sans', sans-serif",
                    }}
                  />
                </div>
                {usernameError ? (
                  <p className="text-xs" style={{ color: 'var(--bearish)' }}>{usernameError}</p>
                ) : username.trim() !== '' ? (
                  <p className="text-xs" style={{ color: 'var(--subtle)' }}>
                    Will be shown as {formatUsername(username)}
                  </p>
                ) : (
                  <p className="text-xs" style={{ color: 'var(--subtle)' }}>
                    Leave blank to display as Anonymous User
                  </p>
                )}
              </div>

              {/* Display Name */}
              <div className="space-y-1.5">
                <label className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-widest"
                  style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                  <User size={12} />
                  Display Name
                </label>
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="Your name"
                  maxLength={50}
                  className="w-full px-3.5 py-3 rounded-xl text-sm outline-none transition-all"
                  style={{
                    background: 'var(--surface-muted)',
                    border: '1px solid var(--border)',
                    color: 'var(--ink)',
                    fontFamily: "'DM Sans', sans-serif",
                  }}
                />
              </div>

              {/* Avatar URL */}
              <div className="space-y-1.5">
                <label className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-widest"
                  style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                  <Image size={12} />
                  Avatar URL
                  <span style={{ color: 'var(--muted)', fontWeight: 400, textTransform: 'none', letterSpacing: 0 }}>
                    — optional
                  </span>
                </label>
                <div className="flex items-center gap-3">
                  {avatarUrl && (
                    <img
                      src={avatarUrl}
                      alt="Avatar preview"
                      className="w-10 h-10 rounded-full object-cover flex-shrink-0"
                      style={{ border: '1px solid var(--border)' }}
                      onError={(e) => { (e.target as HTMLImageElement).style.display = 'none' }}
                    />
                  )}
                  {!avatarUrl && (
                    <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                      style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
                      <User size={18} style={{ color: 'var(--muted)' }} />
                    </div>
                  )}
                  <input
                    type="url"
                    value={avatarUrl}
                    onChange={(e) => setAvatarUrl(e.target.value)}
                    placeholder="https://..."
                    className="flex-1 px-3.5 py-3 rounded-xl text-sm outline-none transition-all"
                    style={{
                      background: 'var(--surface-muted)',
                      border: '1px solid var(--border)',
                      color: 'var(--ink)',
                      fontFamily: "'DM Sans', sans-serif",
                    }}
                  />
                </div>
              </div>

              {/* Bio */}
              <div className="space-y-1.5">
                <label className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-widest"
                  style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                  <FileText size={12} />
                  Bio
                  <span style={{ color: 'var(--muted)', fontWeight: 400, textTransform: 'none', letterSpacing: 0 }}>
                    — optional
                  </span>
                </label>
                <textarea
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  placeholder="A short bio..."
                  rows={3}
                  maxLength={200}
                  className="w-full px-3.5 py-3 rounded-xl text-sm outline-none resize-none transition-all"
                  style={{
                    background: 'var(--surface-muted)',
                    border: '1px solid var(--border)',
                    color: 'var(--ink)',
                    fontFamily: "'DM Sans', sans-serif",
                  }}
                />
                <p className="text-xs text-right tabular-nums" style={{ color: 'var(--subtle)' }}>
                  {bio.length}/200
                </p>
              </div>

              {/* Wallet Visibility */}
              <div className="space-y-2">
                <label className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-widest"
                  style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                  <Eye size={12} />
                  Wallet Visibility
                </label>

                <div className="space-y-2">
                  {/* Hidden */}
                  <button
                    type="button"
                    onClick={() => setWalletVisibility('hidden')}
                    className="w-full flex items-start gap-3 px-4 py-3.5 rounded-xl text-left transition-all"
                    style={{
                      background: walletVisibility === 'hidden' ? 'rgba(18,45,69,0.06)' : 'var(--surface-muted)',
                      border: `1.5px solid ${walletVisibility === 'hidden' ? 'var(--accent)' : 'var(--border)'}`,
                    }}
                  >
                    <EyeOff size={16} style={{ color: walletVisibility === 'hidden' ? 'var(--accent)' : 'var(--muted)', marginTop: 2, flexShrink: 0 }} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>Hidden</span>
                        {walletVisibility === 'hidden' && (
                          <span className="flex items-center justify-center w-4 h-4 rounded-full flex-shrink-0"
                            style={{ background: 'var(--accent)' }}>
                            <Check size={10} color="var(--bg)" strokeWidth={3} />
                          </span>
                        )}
                      </div>
                      <p className="text-xs mt-0.5 leading-relaxed" style={{ color: 'var(--muted)' }}>
                        Wallet address not shown on your MYARC profile
                      </p>
                    </div>
                  </button>

                  {/* Public */}
                  <button
                    type="button"
                    onClick={() => setWalletVisibility('public')}
                    className="w-full flex items-start gap-3 px-4 py-3.5 rounded-xl text-left transition-all"
                    style={{
                      background: walletVisibility === 'public' ? 'rgba(18,45,69,0.06)' : 'var(--surface-muted)',
                      border: `1.5px solid ${walletVisibility === 'public' ? 'var(--accent)' : 'var(--border)'}`,
                    }}
                  >
                    <Eye size={16} style={{ color: walletVisibility === 'public' ? 'var(--accent)' : 'var(--muted)', marginTop: 2, flexShrink: 0 }} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>Public</span>
                        {walletVisibility === 'public' && (
                          <span className="flex items-center justify-center w-4 h-4 rounded-full flex-shrink-0"
                            style={{ background: 'var(--accent)' }}>
                            <Check size={10} color="var(--bg)" strokeWidth={3} />
                          </span>
                        )}
                      </div>
                      <p className="text-xs mt-0.5 leading-relaxed" style={{ color: 'var(--muted)' }}>
                        Show shortened address (e.g.{' '}
                        <span className="mono">
                          {profile ? shortAddress(profile.walletAddress) : '0x83F2...A91C'}
                        </span>
                        ) on your profile
                      </p>
                    </div>
                  </button>
                </div>

                {/* Help text */}
                <p className="text-xs leading-relaxed px-1" style={{ color: 'var(--subtle)' }}>
                  Your wallet remains connected to your MYARC account, but hidden wallets aren't
                  displayed publicly on MYARC. Blockchain transactions remain publicly visible onchain.
                </p>
              </div>

              {/* Bottom padding for safe area */}
              <div className="h-4" />
            </div>

            {/* Footer */}
            <div className="flex-shrink-0 px-5 pb-6 pt-3 space-y-2"
              style={{ borderTop: '1px solid var(--border)' }}>

              {/* Phase 3: auth gate — show sign-in prompt when unauthenticated */}
              {needsAuth ? (
                <>
                  <div className="flex items-start gap-3 px-4 py-3 rounded-xl mb-1"
                    style={{ background: 'rgba(249,115,22,0.08)', border: '1px solid rgba(249,115,22,0.20)' }}>
                    <AlertCircle size={15} style={{ color: '#f97316', flexShrink: 0, marginTop: 1 }} />
                    <p className="text-xs leading-relaxed" style={{ color: 'var(--ink-2)' }}>
                      You need to verify wallet ownership before editing your profile. This is a one-time signature — no transaction or gas required.
                    </p>
                  </div>
                  <button
                    onClick={() => { void handleSignIn() }}
                    disabled={isSigningIn || !onSignIn}
                    className="w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl text-sm font-semibold min-h-[52px] transition-all"
                    style={{
                      background: 'var(--accent)',
                      color: 'var(--bg)',
                      opacity: (isSigningIn || !onSignIn) ? 0.6 : 1,
                    }}
                  >
                    {isSigningIn ? (
                      <><Loader2 size={16} className="animate-spin" /> Signing in…</>
                    ) : (
                      <><ShieldCheck size={16} /> Sign in to edit</>
                    )}
                  </button>
                </>
              ) : (
                <button
                  onClick={() => { void handleSave() }}
                  disabled={isSaving || Boolean(usernameError)}
                  className="w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl text-sm font-semibold min-h-[52px] transition-all"
                  style={{
                    background: 'var(--accent)',
                    color: 'var(--bg)',
                    opacity: (isSaving || Boolean(usernameError)) ? 0.6 : 1,
                  }}
                >
                  {isSaving ? (
                    <><Loader2 size={16} className="animate-spin" /> Saving…</>
                  ) : (
                    'Save Profile'
                  )}
                </button>
              )}

              <button
                onClick={onClose}
                className="w-full py-3 rounded-2xl text-sm font-medium transition-opacity hover:opacity-70"
                style={{ color: 'var(--muted)' }}
              >
                Cancel
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}
