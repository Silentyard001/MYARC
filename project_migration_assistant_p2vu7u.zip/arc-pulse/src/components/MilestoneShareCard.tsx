/**
 * MilestoneShareCard — a shareable, visually self-contained milestone card.
 *
 * Renders a single achieved Milestone with project identity, suitable for
 * sharing or embedding in the project detail sheet.
 *
 * All metric values come from the Milestone object produced by the canonical
 * momentum library — this component performs no independent calculation.
 *
 * Design: follows MYARC visual conventions (CSS variables, no emojis,
 * lucide-react icons only, Framer Motion animations, Space Grotesk display).
 */
import { motion } from 'framer-motion'
import { ThumbsUp, MessageSquare, Wallet, Flame, TrendingUp, Share2, Check } from 'lucide-react'
import { useState } from 'react'
import type { Milestone } from '../lib/momentum'
import type { Project } from '../data/projects'
import { ProjectLogo } from './ProjectLogo'

const ICON_MAP = {
  vote:      ThumbsUp,
  review:    MessageSquare,
  wallet:    Wallet,
  sentiment: TrendingUp,
  flame:     Flame,
} as const

const CATEGORY_COLOR: Record<Milestone['category'], string> = {
  votes:     'var(--accent)',
  reviews:   'var(--bullish)',
  wallets:   '#a78bfa',
  sentiment: 'var(--bullish)',
  momentum:  'var(--accent)',
}

interface MilestoneShareCardProps {
  milestone: Milestone
  project: Project
  /** If true, shows a compact inline variant instead of the full card. */
  compact?: boolean
  /** Framer Motion delay for staggered list rendering. */
  animationDelay?: number
}

function formatValue(m: Milestone): string {
  if (m.category === 'votes' || m.category === 'reviews' || m.category === 'wallets') {
    return m.value.toLocaleString()
  }
  if (m.category === 'sentiment') return `${m.value}%`
  return String(m.value)
}

function progressPct(m: Milestone): number {
  if (m.threshold === 0) return 100
  return Math.min(100, Math.round((m.value / m.threshold) * 100))
}

export function MilestoneShareCard({
  milestone,
  project,
  compact = false,
  animationDelay = 0,
}: MilestoneShareCardProps) {
  const [copied, setCopied] = useState(false)
  const Icon = ICON_MAP[milestone.iconKey]
  const color = CATEGORY_COLOR[milestone.category]
  const pct = progressPct(milestone)

  const handleShare = () => {
    const text = `${project.name} just hit a milestone on MYARC: "${milestone.label}"! ${window.location.origin}/?project=${project.id}`
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }).catch(() => {/* ignore */})
  }

  if (compact) {
    return (
      <motion.div
        initial={{ opacity: 0, x: -8 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.2, delay: animationDelay }}
        className="flex items-center gap-3 px-3 py-2.5 rounded-xl"
        style={{
          background: milestone.achieved
            ? `color-mix(in srgb, ${color} 8%, transparent)`
            : 'var(--surface)',
          border: `1px solid ${milestone.achieved ? `color-mix(in srgb, ${color} 20%, transparent)` : 'var(--border)'}`,
          opacity: milestone.achieved ? 1 : 0.55,
        }}
      >
        <div className="flex-shrink-0 w-7 h-7 rounded-lg flex items-center justify-center"
          style={{ background: `color-mix(in srgb, ${color} 15%, transparent)` }}>
          <Icon size={14} style={{ color }} />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs font-semibold leading-tight truncate"
            style={{ color: milestone.achieved ? 'var(--ink)' : 'var(--muted)' }}>
            {milestone.label}
          </p>
          {!milestone.achieved && (
            <div className="mt-1 h-1 rounded-full overflow-hidden"
              style={{ background: 'var(--border)' }}>
              <div className="h-full rounded-full transition-all duration-500"
                style={{ width: `${pct}%`, background: color }} />
            </div>
          )}
        </div>
        {milestone.achieved && (
          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full flex-shrink-0"
            style={{ background: `color-mix(in srgb, ${color} 15%, transparent)`, color }}>
            {formatValue(milestone)}
          </span>
        )}
      </motion.div>
    )
  }

  // Full card
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, delay: animationDelay }}
      className="rounded-2xl overflow-hidden"
      style={{
        background: 'var(--glass)',
        border: `1px solid color-mix(in srgb, ${color} 25%, var(--border))`,
        backdropFilter: 'blur(12px)',
      }}
    >
      {/* Accent band */}
      <div className="h-1 w-full" style={{ background: color }} />

      <div className="px-5 py-4 space-y-3">
        {/* Header row */}
        <div className="flex items-start gap-3">
          <div className="flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ background: `color-mix(in srgb, ${color} 15%, transparent)` }}>
            <Icon size={20} style={{ color }} />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-[11px] uppercase tracking-widest font-semibold"
              style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
              Community milestone
            </p>
            <p className="font-semibold text-sm leading-snug mt-0.5"
              style={{ color: 'var(--ink)' }}>
              {milestone.label}
            </p>
          </div>
        </div>

        {/* Project identity */}
        <div className="flex items-center gap-2.5">
          <ProjectLogo project={project} size="sm" />
          <p className="text-sm font-medium" style={{ color: 'var(--ink-2)' }}>{project.name}</p>
        </div>

        {/* Description */}
        <p className="text-xs leading-relaxed" style={{ color: 'var(--muted)' }}>
          {milestone.description}
        </p>

        {/* Progress bar (always shown — full when achieved, partial when pending) */}
        <div>
          <div className="flex justify-between items-center mb-1">
            <span className="text-[11px]" style={{ color: 'var(--subtle)' }}>
              {milestone.achieved ? 'Achieved' : `${formatValue(milestone)} / ${milestone.threshold.toLocaleString()}`}
            </span>
            <span className="text-[11px] font-semibold tabular-nums" style={{ color }}>
              {pct}%
            </span>
          </div>
          <div className="h-1.5 rounded-full overflow-hidden" style={{ background: 'var(--border)' }}>
            <motion.div
              className="h-full rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${pct}%` }}
              transition={{ duration: 0.6, delay: animationDelay + 0.15, ease: 'easeOut' }}
              style={{ background: color }}
            />
          </div>
        </div>

        {/* Share button (achieved only) */}
        {milestone.achieved && (
          <button
            onClick={handleShare}
            className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg transition-opacity hover:opacity-70"
            style={{
              background: `color-mix(in srgb, ${color} 10%, transparent)`,
              color,
            }}
          >
            {copied ? <Check size={12} /> : <Share2 size={12} />}
            {copied ? 'Copied!' : 'Share milestone'}
          </button>
        )}
      </div>
    </motion.div>
  )
}
