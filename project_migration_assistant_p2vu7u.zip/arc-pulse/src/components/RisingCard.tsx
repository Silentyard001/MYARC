/**
 * RisingCard — compact card for the Rising tab.
 *
 * Renders a MomentumResult alongside its corresponding Project (for name/logo/tags).
 * Answers two questions for every visitor:
 *   1. How much community momentum does this project have?
 *   2. Why is it here?
 *
 * All metric values come directly from MomentumResult.signals — zero recalculation
 * of any kind is performed here. This component is purely presentational.
 */

import { motion, useReducedMotion } from 'framer-motion'
import { BadgeCheck, TrendingUp, TrendingDown, Minus, Flame, Users, Star } from 'lucide-react'
import type { Project } from '../data/projects'
import type { MomentumResult } from '../lib/momentum'
import { ProjectLogo } from './ProjectLogo'

interface RisingCardProps {
  result: MomentumResult
  project: Project | undefined
  rank?: number
  isVerified?: boolean
  onSelect: (project: Project) => void
  /** Why is this card showing in this particular section? e.g. 'Rising Now', 'New & Rising' */
  sectionLabel?: string
  animationDelay?: number
}

// Module-level constant — captured once at import time, stable across renders.
// Used to compute freshness labels without calling Date.now() in render.
const MODULE_NOW_MS = new Date().getTime()

/** Derive a freshness label purely from the computedAt ISO string. */
function freshLabel(computedAt: string): string {
  const ageMs = MODULE_NOW_MS - new Date(computedAt).getTime()
  if (ageMs < 60_000) return 'Just now'
  if (ageMs < 3_600_000) return `${Math.floor(ageMs / 60_000)}m ago`
  return `${Math.floor(ageMs / 3_600_000)}h ago`
}

// Momentum Index badge color thresholds
function momentumColor(index: number): string {
  if (index >= 60) return 'var(--bullish)'
  if (index >= 30) return 'var(--accent)'
  return 'var(--muted)'
}

function momentumBg(index: number): string {
  // Use color-mix to derive theme-aware tints from design tokens rather than
  // hardcoded light-mode rgba values. color-mix is supported in all modern browsers.
  if (index >= 60) return 'color-mix(in srgb, var(--bullish) 12%, transparent)'
  if (index >= 30) return 'color-mix(in srgb, var(--accent) 10%, transparent)'
  return 'color-mix(in srgb, var(--neutral) 8%, transparent)'
}

function sentimentColor(pct: number | null): string {
  if (pct === null) return 'var(--muted)'
  if (pct >= 60) return 'var(--bullish)'
  if (pct >= 40) return 'var(--neutral)'
  return 'var(--bearish)'
}

function SentimentIcon({ pct }: { pct: number | null }) {
  if (pct === null) return <Minus size={12} />
  if (pct >= 60) return <TrendingUp size={12} />
  if (pct >= 40) return <Minus size={12} />
  return <TrendingDown size={12} />
}

export function RisingCard({
  result,
  project,
  rank,
  isVerified = false,
  onSelect,
  sectionLabel,
  animationDelay = 0,
}: RisingCardProps) {
  const shouldReduceMotion = useReducedMotion()
  const { momentumIndex, signals, explainers, computedAt } = result
  const { sentiment, votes, reviews, boosts, newParticipants7d, insufficientHistory } = signals

  const age = freshLabel(computedAt)

  // Only show explainers that are meaningful (skip "No recent community activity")
  const meaningfulExplainers = explainers.filter((e) => !e.startsWith('No recent'))

  // Directional entry: alternate x-offset by rank so cards fill from alternating sides.
  // Reduced-motion: suppress all translation.
  const rankNum = rank ?? 0
  const entryX = shouldReduceMotion ? 0 : rankNum % 2 === 0 ? 8 : -8
  const entryVariants = {
    hidden: { opacity: 0, y: shouldReduceMotion ? 0 : 10, x: entryX },
    visible: { opacity: 1, y: 0, x: 0 },
  }

  // Momentum badge pulse: fires once after entry animation completes.
  // Skipped entirely when reduced-motion is preferred.
  const badgePulseDelay = animationDelay + 0.38
  const badgePulse = shouldReduceMotion
    ? {}
    : {
        animate: { scale: [1, 1.07, 1] },
        transition: { delay: badgePulseDelay, duration: 0.32, ease: 'easeInOut', times: [0, 0.5, 1] },
      }

  if (!project) {
    // Project not found in seed/submitted list — render a minimal fallback
    return (
      <motion.div
        variants={entryVariants}
        initial="hidden"
        animate="visible"
        transition={{ delay: animationDelay, duration: 0.22, ease: [0.2, 0, 0.28, 1] }}
        className="px-4 py-3 rounded-2xl border"
        style={{ background: 'var(--surface)', borderColor: 'var(--border)' }}
      >
        <div className="flex items-center gap-3">
          <span className="display font-bold text-sm w-5 flex-shrink-0" style={{ color: 'var(--subtle)' }}>
            {rank}
          </span>
          <div className="w-9 h-9 rounded-xl flex-shrink-0" style={{ background: 'var(--surface-muted)' }} />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold truncate" style={{ color: 'var(--ink)' }}>
              {result.projectSlug}
            </p>
            <p className="text-xs" style={{ color: 'var(--subtle)' }}>Not in project registry</p>
          </div>
          <div className="flex-shrink-0 px-2.5 py-1 rounded-full text-xs font-bold tabular-nums"
            style={{ background: momentumBg(momentumIndex), color: momentumColor(momentumIndex) }}>
            {momentumIndex}
          </div>
        </div>
      </motion.div>
    )
  }

  return (
    <motion.div
      variants={entryVariants}
      initial="hidden"
      animate="visible"
      transition={{ delay: animationDelay, duration: 0.22, ease: [0.2, 0, 0.28, 1] }}
    >
      <button
        onClick={() => onSelect(project)}
        className="w-full text-left rounded-2xl border transition-all hover:opacity-90 active:scale-[0.99] block"
        style={{ background: 'var(--surface)', borderColor: 'var(--border)' }}
      >
        {/* Header row */}
        <div className="px-4 pt-4 pb-3 flex items-start gap-3">
          {/* Rank */}
          <span className="display font-bold text-sm w-5 mt-0.5 flex-shrink-0 text-center" style={{ color: 'var(--subtle)' }}>
            {rank}
          </span>

          {/* Logo */}
          <div className="flex-shrink-0 mt-0.5">
            <ProjectLogo project={project} size="md" />
          </div>

          {/* Name + meta */}
          <div className="flex-1 min-w-0 space-y-0.5">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="display font-semibold text-sm leading-tight truncate" style={{ color: 'var(--ink)' }}>
                {project.name}
              </span>
              {isVerified && (
                <BadgeCheck size={13} style={{ color: 'var(--accent)', flexShrink: 0 }} />
              )}
              {insufficientHistory && (
                <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full flex-shrink-0"
                  style={{ background: 'rgba(26,92,255,0.08)', color: 'var(--accent)', border: '1px solid rgba(26,92,255,0.15)' }}>
                  New
                </span>
              )}
              {sectionLabel && !insufficientHistory && (
                <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full flex-shrink-0"
                  style={{ background: 'var(--surface-muted)', color: 'var(--muted)', border: '1px solid var(--border)' }}>
                  {sectionLabel}
                </span>
              )}
            </div>
            <p className="text-xs leading-tight line-clamp-1" style={{ color: 'var(--subtle)' }}>
              {project.tagline}
            </p>
          </div>

          {/* Momentum badge — single scale pulse after entry settles */}
          <div className="flex-shrink-0 flex flex-col items-end gap-0.5">
            <motion.div
              className="flex items-center gap-1 px-2.5 py-1 rounded-full"
              style={{ background: momentumBg(momentumIndex), border: `1px solid ${momentumColor(momentumIndex)}30` }}
              {...badgePulse}
            >
              <Flame size={11} style={{ color: momentumColor(momentumIndex) }} />
              <span className="text-xs font-bold tabular-nums" style={{ color: momentumColor(momentumIndex) }}>
                {momentumIndex}
              </span>
            </motion.div>
            <span className="text-[10px]" style={{ color: 'var(--subtle)' }}>{age}</span>
          </div>
        </div>

        {/* Signal pills row */}
        <div className="px-4 pb-3 flex items-center gap-2 flex-wrap">
          {/* Sentiment */}
          {sentiment.bullishPct !== null && (
            <div className="flex items-center gap-1 px-2 py-0.5 rounded-full"
              style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
              <SentimentIcon pct={sentiment.bullishPct} />
              <span className="text-[11px] font-semibold tabular-nums" style={{ color: sentimentColor(sentiment.bullishPct) }}>
                {sentiment.bullishPct}% bullish
              </span>
            </div>
          )}

          {/* Votes 7d */}
          {votes.d7 > 0 && (
            <div className="flex items-center gap-1 px-2 py-0.5 rounded-full"
              style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
              <TrendingUp size={11} style={{ color: 'var(--accent)' }} />
              <span className="text-[11px] font-medium" style={{ color: 'var(--ink-2)' }}>
                {votes.d7} vote{votes.d7 !== 1 ? 's' : ''} this week
              </span>
            </div>
          )}

          {/* Reviews 7d */}
          {reviews.d7 > 0 && (
            <div className="flex items-center gap-1 px-2 py-0.5 rounded-full"
              style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
              <Star size={11} style={{ color: 'var(--accent)' }} />
              <span className="text-[11px] font-medium" style={{ color: 'var(--ink-2)' }}>
                {reviews.d7} review{reviews.d7 !== 1 ? 's' : ''} this week
              </span>
            </div>
          )}

          {/* New wallets */}
          {newParticipants7d > 0 && (
            <div className="flex items-center gap-1 px-2 py-0.5 rounded-full"
              style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
              <Users size={11} style={{ color: 'var(--accent)' }} />
              <span className="text-[11px] font-medium" style={{ color: 'var(--ink-2)' }}>
                {newParticipants7d} new wallet{newParticipants7d !== 1 ? 's' : ''}
              </span>
            </div>
          )}

          {/* Boosts */}
          {boosts.d7 > 0 && (
            <div className="flex items-center gap-1 px-2 py-0.5 rounded-full"
              style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
              <Flame size={11} style={{ color: 'var(--accent)' }} />
              <span className="text-[11px] font-medium" style={{ color: 'var(--ink-2)' }}>
                {boosts.d7} boost{boosts.d7 !== 1 ? 's' : ''}
              </span>
            </div>
          )}
        </div>

        {/* Explainers */}
        {meaningfulExplainers.length > 0 && (
          <div className="px-4 pb-3.5 pt-0">
            <div className="flex flex-wrap gap-x-2 gap-y-0.5">
              {meaningfulExplainers.map((e) => (
                <span key={e} className="text-[11px]" style={{ color: 'var(--muted)' }}>
                  {e}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Insufficient history disclaimer */}
        {insufficientHistory && (
          <div className="px-4 pb-3.5 pt-0">
            <p className="text-[11px] italic" style={{ color: 'var(--subtle)' }}>
              Too new for reliable percentage comparisons — showing raw activity only.
            </p>
          </div>
        )}
      </button>
    </motion.div>
  )
}
