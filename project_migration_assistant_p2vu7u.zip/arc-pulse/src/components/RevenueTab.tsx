/**
 * RevenueTab
 *
 * Revenue tracking dashboard shown inside AdminPanel for the contract owner.
 * Sections:
 *   1. Verification fees      — sum tx.value for each ProjectVerified log
 *   2. Poll stake volume      — getPollResult() total stakes (facilitated volume)
 *   3. Featured placements    — manual off-chain entries stored in Supabase
 *   4. Summary row            — total on-chain + off-chain + combined
 *   5. Export CSV button
 */
import { useState, useEffect, useCallback, useMemo } from 'react'
import { usePublicClient } from 'wagmi'
import { parseAbiItem, parseAbi } from 'viem'
import { Download, PlusCircle, X } from 'lucide-react'
import { toast } from 'sonner'
import { ARC_TESTNET_CHAIN_ID } from '../config'
import { supabase } from '../lib/supabase'
import { POLLS } from '../data/projects'
import { slugToBytes32 } from '../utils/projectId'
import { bytes32ToSlug } from '../utils/projectId'

// ── ABIs ─────────────────────────────────────────────────────────────────────

const PROJECT_VERIFIED_EVENT = parseAbiItem(
  'event ProjectVerified(bytes32 indexed projectId, address indexed owner)'
)

const GET_POLL_RESULT_ABI = parseAbi([
  'function getPollResult(bytes32 pollId) view returns (uint256[] optionVotes, uint256 totalStake)',
])

// ── Types ─────────────────────────────────────────────────────────────────────

interface VerificationEntry {
  projectId: string   // slug
  verifier: string    // address
  feePaid: number     // USDC (formatted)
  date: string        // ISO
  txHash: string
}

interface PollStakeEntry {
  pollId: string
  question: string
  totalStake: number  // USDC
}

interface FeaturedEntry {
  id: string
  label: string
  amount_usdc: number
  date: string
  notes: string
  created_at: string
}

// ── Helpers ───────────────────────────────────────────────────────────────────

/** Convert Arc native wei (18 decimals) to USDC display (2 dp) */
function weiToUsdc(wei: bigint): number {
  // Arc native 18 dec → USDC 6 dec → display
  const usdc6 = wei / 1_000_000_000_000n
  return Number(usdc6) / 1_000_000
}

function fmtUsdc(n: number): string {
  return n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
}

// ── Component ─────────────────────────────────────────────────────────────────

interface RevenueTabProps {
  contractAddress: `0x${string}` | undefined
}

export function RevenueTab({ contractAddress }: RevenueTabProps) {
  const publicClient = usePublicClient({ chainId: ARC_TESTNET_CHAIN_ID })

  const [verificationEntries, setVerificationEntries] = useState<VerificationEntry[]>([])
  const [pollStakes, setPollStakes] = useState<PollStakeEntry[]>([])
  const [featuredEntries, setFeaturedEntries] = useState<FeaturedEntry[]>([])
  const [isLoading, setIsLoading] = useState(Boolean(contractAddress && publicClient))

  // New featured entry form state
  const [addingEntry, setAddingEntry] = useState(false)
  const [newLabel, setNewLabel] = useState('')
  const [newAmount, setNewAmount] = useState('')
  const [newDate, setNewDate] = useState(() => new Date().toISOString().slice(0, 10))
  const [newNotes, setNewNotes] = useState('')
  const [isSaving, setIsSaving] = useState(false)

  // ── Fetch on-chain data ─────────────────────────────────────────────────────
  useEffect(() => {
    if (!contractAddress || !publicClient) return

    let cancelled = false

    async function fetchData() {
      if (!publicClient || !contractAddress) return

      try {
        // 1. Verification fee logs
        const verifiedLogs = await publicClient.getLogs({
          address: contractAddress,
          event: PROJECT_VERIFIED_EVENT,
          fromBlock: 0n,
          toBlock: 'latest',
        })

        const entries: VerificationEntry[] = []
        for (const log of verifiedLogs) {
          try {
            const args = log.args as { projectId: `0x${string}`; owner: string }
            const tx = await publicClient.getTransaction({ hash: log.transactionHash })
            const block = await publicClient.getBlock({ blockNumber: log.blockNumber })
            const slug = bytes32ToSlug(args.projectId)
            entries.push({
              projectId: slug,
              verifier: args.owner,
              feePaid: weiToUsdc(tx.value),
              date: new Date(Number(block.timestamp) * 1000).toISOString(),
              txHash: log.transactionHash ?? '',
            })
          } catch { /* skip malformed */ }
        }
        if (!cancelled) setVerificationEntries(entries)

        // 2. Poll stakes
        const stakeEntries: PollStakeEntry[] = []
        for (const poll of POLLS) {
          try {
            const pollId32 = slugToBytes32(poll.id)
            const [, totalStake] = await publicClient.readContract({
              address: contractAddress,
              abi: GET_POLL_RESULT_ABI,
              functionName: 'getPollResult',
              args: [pollId32],
            }) as [bigint[], bigint]
            stakeEntries.push({
              pollId: poll.id,
              question: poll.question,
              totalStake: weiToUsdc(totalStake),
            })
          } catch { /* poll not on-chain yet */ }
        }
        if (!cancelled) setPollStakes(stakeEntries)
      } catch { /* ignore rpc errors */ } finally {
        if (!cancelled) setIsLoading(false)
      }
    }

    void fetchData()
    return () => { cancelled = true }
  }, [contractAddress, publicClient])

  // ── Fetch featured placement entries from Supabase ─────────────────────────
  const loadFeaturedEntries = useCallback(async () => {
    if (!supabase) return
    const { data } = await supabase
      .from('revenue_entries')
      .select('*')
      .order('date', { ascending: false })
    if (data) setFeaturedEntries(data as FeaturedEntry[])
  }, [])

  useEffect(() => {
    void (async () => {
      if (!supabase) return
      const { data } = await supabase
        .from('revenue_entries')
        .select('*')
        .order('date', { ascending: false })
      if (data) setFeaturedEntries(data as FeaturedEntry[])
    })()
  }, [])

  // ── Totals ──────────────────────────────────────────────────────────────────
  const totalOnchain = useMemo(
    () => verificationEntries.reduce((s, e) => s + e.feePaid, 0),
    [verificationEntries]
  )
  const totalOffchain = useMemo(
    () => featuredEntries.reduce((s, e) => s + Number(e.amount_usdc), 0),
    [featuredEntries]
  )
  const totalFacilitated = useMemo(
    () => pollStakes.reduce((s, e) => s + e.totalStake, 0),
    [pollStakes]
  )

  // ── Save new featured entry ─────────────────────────────────────────────────
  const handleSaveEntry = useCallback(async () => {
    if (!newLabel.trim() || !newAmount.trim()) {
      toast.error('Label and amount are required.')
      return
    }
    const amount = parseFloat(newAmount)
    if (isNaN(amount) || amount < 0) { toast.error('Invalid amount.'); return }

    setIsSaving(true)
    try {
      if (supabase) {
        const { error } = await supabase.from('revenue_entries').insert({
          type: 'featured',
          label: newLabel.trim(),
          amount_usdc: amount,
          date: newDate,
          notes: newNotes.trim(),
        })
        if (error) throw error
        await loadFeaturedEntries()
      } else {
        // Local-only fallback
        const localEntry: FeaturedEntry = {
          id: `local-${Date.now()}`,
          label: newLabel.trim(),
          amount_usdc: amount,
          date: newDate,
          notes: newNotes.trim(),
          created_at: new Date().toISOString(),
        }
        setFeaturedEntries((prev) => [localEntry, ...prev])
      }
      setNewLabel(''); setNewAmount(''); setNewNotes('')
      setNewDate(new Date().toISOString().slice(0, 10))
      setAddingEntry(false)
      toast.success('Revenue entry saved.')
    } catch {
      toast.error('Failed to save entry.')
    } finally {
      setIsSaving(false)
    }
  }, [newLabel, newAmount, newDate, newNotes, loadFeaturedEntries])

  // ── Delete featured entry ───────────────────────────────────────────────────
  const handleDeleteEntry = useCallback(async (id: string) => {
    setFeaturedEntries((prev) => prev.filter((e) => e.id !== id))
    if (supabase) {
      await supabase.from('revenue_entries').delete().eq('id', id)
    }
    toast('Entry removed.', { duration: 1500 })
  }, [])

  // ── Export CSV ──────────────────────────────────────────────────────────────
  const handleExport = useCallback(() => {
    const rows: string[][] = [
      ['Type', 'Label / Project', 'Amount (USDC)', 'Date', 'Notes / Verifier', 'Tx Hash'],
    ]
    for (const e of verificationEntries) {
      rows.push(['Verification Fee', e.projectId, fmtUsdc(e.feePaid), e.date.slice(0, 10), e.verifier, e.txHash])
    }
    for (const e of pollStakes) {
      rows.push(['Poll Volume', e.question, fmtUsdc(e.totalStake), '', '', ''])
    }
    for (const e of featuredEntries) {
      rows.push(['Featured Placement', e.label, fmtUsdc(Number(e.amount_usdc)), e.date, e.notes, ''])
    }
    rows.push(['', '', '', '', '', ''])
    rows.push(['Total On-chain Revenue', '', fmtUsdc(totalOnchain), '', '', ''])
    rows.push(['Total Off-chain Revenue', '', fmtUsdc(totalOffchain), '', '', ''])
    rows.push(['Total Poll Volume Facilitated', '', fmtUsdc(totalFacilitated), '', '', ''])
    rows.push(['Combined Revenue', '', fmtUsdc(totalOnchain + totalOffchain), '', '', ''])

    const csv = rows.map((r) => r.map((c) => `"${c.replace(/"/g, '""')}"`).join(',')).join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `myarc-revenue-${new Date().toISOString().slice(0, 10)}.csv`
    a.click()
    URL.revokeObjectURL(url)
    toast.success('CSV downloaded.')
  }, [verificationEntries, pollStakes, featuredEntries, totalOnchain, totalOffchain, totalFacilitated])

  if (isLoading) {
    return (
      <div className="space-y-3 pb-6">
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className="h-16 rounded-2xl animate-pulse" style={{ background: 'var(--surface-muted)' }} />
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-6 pb-8">

      {/* ── Summary row ───────────────────────────────────────────────────────── */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'On-chain Revenue', value: `$${fmtUsdc(totalOnchain)}`, sub: 'Verification fees' },
          { label: 'Off-chain Revenue', value: `$${fmtUsdc(totalOffchain)}`, sub: 'Featured placements' },
          { label: 'Combined Total', value: `$${fmtUsdc(totalOnchain + totalOffchain)}`, sub: 'All revenue' },
        ].map(({ label, value, sub }) => (
          <div key={label} className="rounded-2xl p-3 text-center space-y-0.5"
            style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
            <p className="display font-bold text-lg tabular-nums leading-tight" style={{ color: 'var(--ink)' }}>{value}</p>
            <p className="text-xs font-medium" style={{ color: 'var(--ink-2)' }}>{label}</p>
            <p className="text-xs" style={{ color: 'var(--subtle)' }}>{sub}</p>
          </div>
        ))}
      </div>

      {/* ── Export button ─────────────────────────────────────────────────────── */}
      <button
        onClick={handleExport}
        className="w-full flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-semibold min-h-[44px] transition-all hover:opacity-85"
        style={{ background: 'var(--surface)', border: '1px solid var(--border)', color: 'var(--ink-2)' }}>
        <Download size={15} />
        Export CSV
      </button>

      {/* ── Section: Verification Fees ────────────────────────────────────────── */}
      <section className="space-y-2">
        <div className="flex items-center justify-between">
          <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
            Verification Fees
          </p>
          <span className="text-xs tabular-nums font-semibold" style={{ color: 'var(--bullish)' }}>
            ${fmtUsdc(totalOnchain)}
          </span>
        </div>
        {verificationEntries.length === 0 ? (
          <p className="text-sm py-2" style={{ color: 'var(--subtle)' }}>No verifications yet.</p>
        ) : (
          <div className="rounded-2xl overflow-hidden" style={{ border: '1px solid var(--border)' }}>
            {verificationEntries.map((e, i) => (
              <div key={e.txHash || i}
                className="flex items-center gap-3 px-4 py-3"
                style={{ borderBottom: i < verificationEntries.length - 1 ? '1px solid var(--border)' : 'none', background: 'var(--surface)' }}>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate" style={{ color: 'var(--ink)' }}>{e.projectId}</p>
                  <p className="text-xs font-mono truncate" style={{ color: 'var(--subtle)' }}>
                    {e.verifier.slice(0, 8)}...{e.verifier.slice(-4)}
                  </p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-sm font-semibold tabular-nums" style={{ color: 'var(--bullish)' }}>${fmtUsdc(e.feePaid)}</p>
                  <p className="text-xs" style={{ color: 'var(--subtle)' }}>{e.date.slice(0, 10)}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* ── Section: Poll Volume ──────────────────────────────────────────────── */}
      <section className="space-y-2">
        <div className="flex items-center justify-between">
          <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
            Poll Stakes (Volume Facilitated)
          </p>
          <span className="text-xs tabular-nums font-semibold" style={{ color: 'var(--neutral)' }}>
            ${fmtUsdc(totalFacilitated)}
          </span>
        </div>
        {pollStakes.length === 0 ? (
          <p className="text-sm py-2" style={{ color: 'var(--subtle)' }}>No on-chain polls yet.</p>
        ) : (
          <div className="rounded-2xl overflow-hidden" style={{ border: '1px solid var(--border)' }}>
            {pollStakes.map((e, i) => (
              <div key={e.pollId}
                className="flex items-center justify-between gap-3 px-4 py-3"
                style={{ borderBottom: i < pollStakes.length - 1 ? '1px solid var(--border)' : 'none', background: 'var(--surface)' }}>
                <p className="text-sm flex-1 min-w-0 truncate" style={{ color: 'var(--ink-2)' }}>{e.question}</p>
                <p className="text-sm font-semibold tabular-nums flex-shrink-0" style={{ color: 'var(--neutral)' }}>${fmtUsdc(e.totalStake)}</p>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* ── Section: Featured Placements ──────────────────────────────────────── */}
      <section className="space-y-2">
        <div className="flex items-center justify-between">
          <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
            Featured Placements
          </p>
          <div className="flex items-center gap-3">
            <span className="text-xs tabular-nums font-semibold" style={{ color: 'var(--bullish)' }}>
              ${fmtUsdc(totalOffchain)}
            </span>
            <button
              onClick={() => setAddingEntry(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold min-h-[32px] transition-all hover:opacity-85"
              style={{ background: 'var(--accent)', color: 'var(--bg)' }}>
              <PlusCircle size={11} />
              Add
            </button>
          </div>
        </div>

        {/* Add entry form */}
        {addingEntry && (
          <div className="rounded-2xl p-4 space-y-3" style={{ background: 'var(--surface)', border: '1px solid var(--accent)' }}>
            <div className="grid grid-cols-2 gap-2">
              <div className="col-span-2">
                <label className="text-xs font-medium mb-1 block" style={{ color: 'var(--muted)' }}>Project / Label</label>
                <input type="text" value={newLabel} onChange={(e) => setNewLabel(e.target.value)}
                  placeholder="e.g. ArcSwap Q4 featured" className="w-full px-3 py-2 rounded-xl text-sm border bg-transparent outline-none"
                  style={{ borderColor: 'var(--border)', color: 'var(--ink)', fontFamily: "'DM Sans', sans-serif" }} />
              </div>
              <div>
                <label className="text-xs font-medium mb-1 block" style={{ color: 'var(--muted)' }}>Amount (USDC)</label>
                <input type="number" min="0" step="0.01" value={newAmount} onChange={(e) => setNewAmount(e.target.value)}
                  placeholder="0.00" className="w-full px-3 py-2 rounded-xl text-sm border bg-transparent outline-none"
                  style={{ borderColor: 'var(--border)', color: 'var(--ink)', fontFamily: "'DM Sans', sans-serif" }} />
              </div>
              <div>
                <label className="text-xs font-medium mb-1 block" style={{ color: 'var(--muted)' }}>Date</label>
                <input type="date" value={newDate} onChange={(e) => setNewDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl text-sm border bg-transparent outline-none"
                  style={{ borderColor: 'var(--border)', color: 'var(--ink)', fontFamily: "'DM Sans', sans-serif" }} />
              </div>
              <div className="col-span-2">
                <label className="text-xs font-medium mb-1 block" style={{ color: 'var(--muted)' }}>Notes (optional)</label>
                <input type="text" value={newNotes} onChange={(e) => setNewNotes(e.target.value)}
                  placeholder="e.g. 30-day placement, paid via USDC" className="w-full px-3 py-2 rounded-xl text-sm border bg-transparent outline-none"
                  style={{ borderColor: 'var(--border)', color: 'var(--ink)', fontFamily: "'DM Sans', sans-serif" }} />
              </div>
            </div>
            <div className="flex gap-2">
              <button onClick={() => void handleSaveEntry()} disabled={isSaving}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold min-h-[44px] transition-all hover:opacity-85 disabled:opacity-50"
                style={{ background: 'var(--accent)', color: 'var(--bg)' }}>
                {isSaving ? 'Saving…' : 'Save Entry'}
              </button>
              <button onClick={() => setAddingEntry(false)}
                className="px-4 py-2.5 rounded-xl text-sm font-medium min-h-[44px] transition-all hover:opacity-70"
                style={{ background: 'var(--surface-muted)', color: 'var(--muted)' }}>
                Cancel
              </button>
            </div>
          </div>
        )}

        {featuredEntries.length === 0 && !addingEntry ? (
          <p className="text-sm py-2" style={{ color: 'var(--subtle)' }}>No manual entries yet. Add one above.</p>
        ) : (
          <div className="rounded-2xl overflow-hidden" style={{ border: '1px solid var(--border)' }}>
            {featuredEntries.map((e, i) => (
              <div key={e.id}
                className="flex items-center gap-3 px-4 py-3"
                style={{ borderBottom: i < featuredEntries.length - 1 ? '1px solid var(--border)' : 'none', background: 'var(--surface)' }}>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate" style={{ color: 'var(--ink)' }}>{e.label}</p>
                  {e.notes && <p className="text-xs truncate" style={{ color: 'var(--subtle)' }}>{e.notes}</p>}
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-sm font-semibold tabular-nums" style={{ color: 'var(--bullish)' }}>${fmtUsdc(Number(e.amount_usdc))}</p>
                  <p className="text-xs" style={{ color: 'var(--subtle)' }}>{e.date}</p>
                </div>
                <button onClick={() => void handleDeleteEntry(e.id)}
                  className="w-7 h-7 flex items-center justify-center rounded-full flex-shrink-0 hover:opacity-70 transition-opacity"
                  style={{ background: 'var(--surface-muted)' }}>
                  <X size={12} style={{ color: 'var(--muted)' }} />
                </button>
              </div>
            ))}
          </div>
        )}
      </section>

    </div>
  )
}
