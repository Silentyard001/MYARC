import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Clock, CheckCircle2, Trophy, Megaphone } from 'lucide-react'
import { toast } from 'sonner'
import type { Poll } from '../data/projects'
import { AnimatedNumber } from './AnimatedNumber'

interface PollWidgetProps {
  poll: Poll
  votedOption: string | null
  onVote: (pollId: string, optionId: string) => void
  isConnected?: boolean
  /** Total stake pool for this poll (in arc native wei). Shown when > 0 */
  totalStake?: bigint
  /** Stake per option index (parallel to poll.options by position) */
  optionStakes?: bigint[]
  /** Whether the connected wallet is eligible to claim a reward */
  canClaim?: boolean
  onClaim?: (pollId: string) => void
}

/** Format ms-until-end as a live countdown string */
function formatCountdown(ms: number): string {
  if (ms <= 0) return 'Ended'
  const totalSec = Math.floor(ms / 1000)
  const days  = Math.floor(totalSec / 86400)
  const hours = Math.floor((totalSec % 86400) / 3600)
  const mins  = Math.floor((totalSec % 3600) / 60)
  const secs  = totalSec % 60

  if (days > 0)  return `${days}d ${hours}h ${mins}m`
  if (hours > 0) return `${hours}h ${mins}m ${secs}s`
  if (mins > 0)  return `${mins}m ${secs}s`
  return `${secs}s`
}

/** Hook that ticks every second and returns ms remaining until `endsAt` */
function useCountdown(endsAt: number): number {
  const [remaining, setRemaining] = useState(() => Math.max(0, endsAt - Date.now()))

  useEffect(() => {
    if (remaining <= 0) return
    const id = setInterval(() => {
      const left = Math.max(0, endsAt - Date.now())
      setRemaining(left)
      if (left === 0) clearInterval(id)
    }, 1000)
    return () => clearInterval(id)
  }, [endsAt, remaining])

  return remaining
}

/** Format a bigint native wei amount as "X.XXX USDC" (6 decimal USDC = native on Arc) */
function formatNativeAmount(wei: bigint): string {
  if (wei === 0n) return '0 USDC'
  // Arc native uses 18 decimals for gas, but USDC ERC-20 uses 6.
  // In preview mode there is no real stake, so just show a human-readable placeholder.
  const usdcWei = wei / 1_000_000_000_000n // 18→6
  const major = usdcWei / 1_000_000n
  const minor = usdcWei % 1_000_000n
  const minorStr = minor.toString().padStart(6, '0').replace(/0+$/, '')
  return minorStr.length > 0 ? `${major}.${minorStr} USDC` : `${major} USDC`
}

export function PollWidget({
  poll,
  votedOption,
  onVote,
  isConnected = false,
  totalStake = 0n,
  optionStakes,
  canClaim = false,
  onClaim,
}: PollWidgetProps) {
  const hasVoted = votedOption !== null
  const remaining = useCountdown(poll.endsAt)
  const ended = remaining === 0
  const hasStake = totalStake > 0n

  const total = poll.options.reduce((sum, o) => {
    return sum + o.votes
  }, 0) || poll.totalVotes

  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl border p-5 space-y-4"
      style={{ background: 'var(--surface)', borderColor: 'var(--border)', backdropFilter: 'blur(12px)', WebkitBackdropFilter: 'blur(12px)' }}>

      {/* Sponsored label */}
      {poll.sponsored && poll.sponsorName && (
        <div className="flex items-center gap-1.5">
          <Megaphone size={11} style={{ color: 'var(--subtle)' }} />
          <span className="text-xs" style={{ color: 'var(--subtle)' }}>
            Sponsored by {poll.sponsorName}
          </span>
        </div>
      )}

      {/* Header */}
      <div className="space-y-1">
        <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
          {poll.category}
        </span>
        <h3 className="display font-semibold text-base leading-snug text-balance" style={{ color: 'var(--ink)' }}>
          {poll.question}
        </h3>
      </div>

      {/* Timer row */}
      <div className="flex items-center gap-2 text-xs flex-wrap" style={{ color: ended ? 'var(--bearish)' : 'var(--muted)' }}>
        <Clock size={12} />
        <span className="tabular-nums font-medium">{formatCountdown(remaining)}</span>
        <span style={{ color: 'var(--border-strong)' }}>·</span>
        <AnimatedNumber value={total} suffix=" votes" duration={0.35} className="tabular-nums" aria-hidden="true" />
        {hasStake && (
          <>
            <span style={{ color: 'var(--border-strong)' }}>·</span>
            <span className="tabular-nums font-medium" style={{ color: 'var(--bullish)' }}>
              {formatNativeAmount(totalStake)} pool
            </span>
          </>
        )}
        {ended && (
          <span className="ml-auto text-xs font-semibold px-2 py-0.5 rounded-full"
            style={{ background: 'rgba(186,43,76,0.10)', color: 'var(--bearish)' }}>
            Closed
          </span>
        )}
      </div>

      {/* Options */}
      <div className="space-y-2.5">
        {poll.options.map((option, idx) => {
          const pct = total > 0 ? Math.round((option.votes / total) * 100) : 0
          const isSelected = votedOption === option.id
          const canVote = !hasVoted && !ended && isConnected

          // Stake share for this option
          const optionStake = optionStakes?.[idx] ?? 0n
          const stakePct = hasStake
            ? Number((optionStake * 100n) / totalStake)
            : 0

          return (
            <div key={option.id} className="space-y-1">
              <button
                onClick={() => canVote && onVote(poll.id, option.id)}
                className="w-full text-left px-3.5 py-3 rounded-xl border transition-all relative overflow-hidden min-h-[44px]"
                style={isSelected
                  ? { background: 'var(--surface-muted)', borderColor: 'var(--accent)', borderWidth: '1.5px', cursor: 'default' }
                  : hasVoted || ended
                  ? { background: 'var(--surface-muted)', borderColor: 'var(--border)', cursor: 'default', opacity: 0.85 }
                  : canVote
                  ? { background: 'var(--surface-muted)', borderColor: 'var(--border)', cursor: 'pointer' }
                  : { background: 'var(--surface-muted)', borderColor: 'var(--border)', cursor: 'not-allowed', opacity: 0.7 }}>

                {/* Vote-count bar fill */}
                {(hasVoted || ended) && (
                  <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }}
                    transition={{ duration: 0.7, ease: 'easeOut' }}
                    className="absolute inset-y-0 left-0 rounded-xl"
                    style={{ background: isSelected ? 'var(--accent)' : 'var(--border)', opacity: isSelected ? 0.15 : 0.5, zIndex: 0 }} />
                )}

                {/* Stake bar fill (secondary, below) */}
                {hasStake && (hasVoted || ended) && (
                  <motion.div initial={{ width: 0 }} animate={{ width: `${stakePct}%` }}
                    transition={{ duration: 0.7, ease: 'easeOut', delay: 0.15 }}
                    className="absolute bottom-0 left-0 h-1 rounded-b-xl"
                    style={{ background: 'var(--bullish)', opacity: 0.5, zIndex: 1 }} />
                )}

                <div className="relative z-10 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {isSelected && (
                      <CheckCircle2 size={14} strokeWidth={2.5} style={{ color: 'var(--accent)', flexShrink: 0 }} />
                    )}
                    <span className="text-sm font-medium" style={{ color: isSelected ? 'var(--ink)' : 'var(--ink-2)' }}>
                      {option.label}
                    </span>
                  </div>
                  {(hasVoted || ended) && (
                    <div className="flex items-center gap-2">
                      {hasStake && optionStake > 0n && (
                        <span className="text-xs tabular-nums" style={{ color: 'var(--bullish)', opacity: 0.8 }}>
                          {formatNativeAmount(optionStake)}
                        </span>
                      )}
                      <AnimatedNumber
                        value={pct}
                        suffix="%"
                        duration={0.4}
                        className="text-sm tabular-nums font-semibold"
                        style={{ color: isSelected ? 'var(--accent)' : 'var(--muted)' }}
                        aria-hidden="true"
                      />
                    </div>
                  )}
                </div>
              </button>
            </div>
          )
        })}
      </div>

      {/* Claim reward button (eligible winners after poll ends) */}
      {canClaim && ended && (
        <motion.button
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          whileTap={{ scale: 0.96 }}
          onClick={() => {
            if (!isConnected) { toast.error('Connect your wallet to claim.'); return }
            onClaim?.(poll.id)
          }}
          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl font-semibold text-sm min-h-[44px] transition-all hover:opacity-90"
          style={{ background: 'var(--bullish)', color: '#fff' }}
        >
          <Trophy size={16} />
          Claim Reward
        </motion.button>
      )}

      {/* Footer hint */}
      {!hasVoted && (
        <p className="text-xs text-center" style={{ color: 'var(--subtle)' }}>
          {ended
            ? 'This poll has ended'
            : isConnected
            ? 'Tap an option to cast your vote'
            : 'Connect wallet to vote in polls'}
        </p>
      )}
    </motion.div>
  )
}
