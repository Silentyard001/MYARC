import { TrendingUp, Minus, TrendingDown } from 'lucide-react'
import type { Sentiment } from '../data/projects'

interface SentimentBadgeProps {
  sentiment: Sentiment
  size?: 'sm' | 'md'
}

export function SentimentBadge({ sentiment, size = 'md' }: SentimentBadgeProps) {
  const cfg = {
    bullish: {
      label: 'Bullish',
      icon: TrendingUp,
      style: { background: 'rgba(26,128,71,0.10)', color: 'var(--bullish)' },
    },
    neutral: {
      label: 'Neutral',
      icon: Minus,
      style: { background: 'rgba(107,101,128,0.10)', color: 'var(--neutral)' },
    },
    bearish: {
      label: 'Bearish',
      icon: TrendingDown,
      style: { background: 'rgba(186,43,76,0.10)', color: 'var(--bearish)' },
    },
  }

  const { label, icon: Icon, style } = cfg[sentiment]

  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full font-medium ${size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-xs'}`}
      style={style}
    >
      <Icon size={size === 'sm' ? 10 : 12} strokeWidth={2.5} />
      {label}
    </span>
  )
}
