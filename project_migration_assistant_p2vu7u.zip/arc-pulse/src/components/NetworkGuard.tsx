/**
 * NetworkGuard
 *
 * Renders a blocking modal overlay when the connected wallet is on the wrong
 * chain. Offers a one-click switch to Arc Testnet using wagmi's useSwitchChain.
 * If the wallet doesn't know the chain yet, it passes wallet_addEthereumChain
 * with the full Arc Testnet config so the user is prompted to add it.
 */
import { useSwitchChain } from 'wagmi'
import { motion, AnimatePresence } from 'framer-motion'
import { AlertTriangle, Zap } from 'lucide-react'
import { ARC_TESTNET_CHAIN_ID } from '../config'

interface NetworkGuardProps {
  isWrongChain: boolean
}

export function NetworkGuard({ isWrongChain }: NetworkGuardProps) {
  const { switchChain, isPending } = useSwitchChain()

  const handleSwitch = () => {
    switchChain({ chainId: ARC_TESTNET_CHAIN_ID })
  }

  return (
    <AnimatePresence>
      {isWrongChain && (
        <motion.div
          key="network-guard"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4"
          style={{ background: 'rgba(10,20,35,0.65)', backdropFilter: 'blur(6px)' }}
        >
          <motion.div
            initial={{ opacity: 0, y: 40, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.97 }}
            transition={{ type: 'spring', stiffness: 380, damping: 32 }}
            className="w-full max-w-sm rounded-3xl p-6 space-y-5"
            style={{
              background: 'var(--surface-strong)',
              border: '1px solid var(--border-strong)',
              boxShadow: '0 24px 60px rgba(0,0,0,0.28)',
            }}
          >
            {/* Icon */}
            <div
              className="w-12 h-12 rounded-2xl flex items-center justify-center"
              style={{ background: 'rgba(186,43,76,0.10)' }}
            >
              <AlertTriangle size={22} style={{ color: 'var(--danger)' }} strokeWidth={2} />
            </div>

            {/* Copy */}
            <div className="space-y-1.5">
              <h2 className="display font-bold text-lg" style={{ color: 'var(--ink)' }}>
                Wrong Network
              </h2>
              <p className="text-sm text-pretty leading-relaxed" style={{ color: 'var(--muted)' }}>
                MYARC runs on Arc Testnet (Chain ID 5042002) where USDC is the native
                gas token. Please switch to continue.
              </p>
            </div>

            {/* Switch button */}
            <button
              onClick={handleSwitch}
              disabled={isPending}
              className="w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl font-semibold text-sm transition-opacity disabled:opacity-60"
              style={{ background: 'var(--accent)', color: 'var(--bg)' }}
            >
              <Zap size={14} strokeWidth={2.5} />
              {isPending ? 'Switching…' : 'Switch to Arc Testnet'}
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
