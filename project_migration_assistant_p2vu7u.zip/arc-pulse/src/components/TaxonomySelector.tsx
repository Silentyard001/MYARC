/**
 * TaxonomySelector
 *
 * Searchable selector for primary category (single) and use cases / tags (multi).
 *
 * The dropdown panel renders via ReactDOM.createPortal into document.body so it
 * escapes every stacking context and overflow clip that would otherwise trap an
 * absolute-positioned child inside a scroll container.  The panel position is
 * computed from the trigger's getBoundingClientRect on each open.
 *
 * Single-select: shows a filled dot indicator, selects + closes immediately.
 * Multi-select:  shows a checkbox indicator, chips rendered below trigger.
 */

import { useState, useRef, useEffect, useMemo, useCallback } from 'react'
import { createPortal } from 'react-dom'
import { Search, X, Check, ChevronDown } from 'lucide-react'

export type SelectorItem = {
  id: string
  label: string
  group?: string
  active?: boolean
}

interface TaxonomySelectorProps {
  items: SelectorItem[]
  selected: string[]
  onChange: (ids: string[]) => void
  max?: number
  placeholder?: string
  singleSelect?: boolean
  label?: string
  required?: boolean
  hint?: string
}

// ── Panel position ────────────────────────────────────────────────────────────
interface PanelRect {
  top: number
  bottom: number
  left: number
  width: number
  spaceBelow: number
  spaceAbove: number
}

function getPanelRect(trigger: HTMLElement): PanelRect {
  const r = trigger.getBoundingClientRect()
  const spaceBelow = window.innerHeight - r.bottom - 8
  const spaceAbove = r.top - 8
  return {
    top: r.bottom + window.scrollY,
    bottom: window.innerHeight - r.top + window.scrollY,
    left: r.left + window.scrollX,
    width: r.width,
    spaceBelow,
    spaceAbove,
  }
}

// ── Component ─────────────────────────────────────────────────────────────────
export function TaxonomySelector({
  items,
  selected,
  onChange,
  max = 5,
  placeholder = 'Search...',
  singleSelect = false,
  label,
  required,
  hint,
}: TaxonomySelectorProps) {
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState('')
  const [panelRect, setPanelRect] = useState<PanelRect | null>(null)

  const triggerRef = useRef<HTMLButtonElement>(null)
  const panelRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  // Compute panel position when opening
  const openPanel = useCallback(() => {
    if (triggerRef.current) {
      setPanelRect(getPanelRect(triggerRef.current))
    }
    setOpen(true)
  }, [])

  const closePanel = useCallback(() => {
    setOpen(false)
    setQuery('')
  }, [])

  const toggleOpen = () => (open ? closePanel() : openPanel())

  // Reposition on scroll / resize while open
  useEffect(() => {
    if (!open) return
    const reposition = () => {
      if (triggerRef.current) setPanelRect(getPanelRect(triggerRef.current))
    }
    window.addEventListener('scroll', reposition, true)
    window.addEventListener('resize', reposition)
    return () => {
      window.removeEventListener('scroll', reposition, true)
      window.removeEventListener('resize', reposition)
    }
  }, [open])

  // Close on outside click / touch
  useEffect(() => {
    if (!open) return
    const handler = (e: MouseEvent | TouchEvent) => {
      const target = e.target as Node
      if (
        !triggerRef.current?.contains(target) &&
        !panelRef.current?.contains(target)
      ) {
        closePanel()
      }
    }
    document.addEventListener('mousedown', handler)
    document.addEventListener('touchstart', handler)
    return () => {
      document.removeEventListener('mousedown', handler)
      document.removeEventListener('touchstart', handler)
    }
  }, [open, closePanel])

  // Auto-focus search on open
  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 50)
  }, [open])

  // Close on Escape
  useEffect(() => {
    if (!open) return
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') closePanel() }
    document.addEventListener('keydown', handler)
    return () => document.removeEventListener('keydown', handler)
  }, [open, closePanel])

  const filteredItems = useMemo(() => {
    const q = query.toLowerCase().trim()
    if (!q) return items
    return items.filter(
      (i) => i.label.toLowerCase().includes(q) || i.group?.toLowerCase().includes(q),
    )
  }, [items, query])

  const grouped = useMemo(() => {
    const map = new Map<string, SelectorItem[]>()
    for (const item of filteredItems) {
      const g = item.group ?? ''
      if (!map.has(g)) map.set(g, [])
      map.get(g)!.push(item)
    }
    return Array.from(map.entries())
  }, [filteredItems])

  const toggle = (id: string) => {
    if (singleSelect) {
      onChange([id])
      closePanel()
      return
    }
    if (selected.includes(id)) {
      onChange(selected.filter((s) => s !== id))
    } else if (selected.length < max) {
      onChange([...selected, id])
    }
  }

  const remove = (id: string) => onChange(selected.filter((s) => s !== id))

  const selectedItems = items.filter((i) => selected.includes(i.id))
  const atMax = !singleSelect && selected.length >= max

  // Panel max-height: prefer below, fall back to above
  const PANEL_MAX_H = 260
  const panelStyle: React.CSSProperties = panelRect
    ? panelRect.spaceBelow >= Math.min(PANEL_MAX_H, 180)
      ? {
          position: 'absolute',
          top: panelRect.top + 4,
          left: panelRect.left,
          width: panelRect.width,
          maxHeight: Math.min(PANEL_MAX_H, panelRect.spaceBelow),
          zIndex: 9999,
        }
      : {
          // Open upward
          position: 'absolute',
          bottom: panelRect.bottom + 4,
          left: panelRect.left,
          width: panelRect.width,
          maxHeight: Math.min(PANEL_MAX_H, panelRect.spaceAbove),
          zIndex: 9999,
        }
    : { display: 'none' }

  // ── Render ──────────────────────────────────────────────────────────────────
  return (
    <div className="relative">
      {label && (
        <p
          className="text-xs font-semibold uppercase tracking-widest mb-1.5"
          style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}
        >
          {label}
          {required && <span style={{ color: 'var(--bearish)' }}> *</span>}
        </p>
      )}
      {hint && (
        <p className="text-xs mb-1.5" style={{ color: 'var(--muted)' }}>
          {hint}
        </p>
      )}

      {/* Trigger button */}
      <button
        ref={triggerRef}
        type="button"
        onClick={toggleOpen}
        aria-haspopup="listbox"
        aria-expanded={open}
        className="w-full flex items-center justify-between gap-2 px-3.5 py-3 rounded-xl border text-left transition-colors"
        style={{
          background: 'var(--surface-muted)',
          borderColor: open ? 'var(--accent)' : 'var(--border)',
          color: selectedItems.length === 0 ? 'var(--subtle)' : 'var(--ink)',
          minHeight: '44px',
        }}
      >
        <span className="text-sm truncate flex-1">
          {selectedItems.length === 0
            ? placeholder
            : singleSelect
              ? selectedItems[0]?.label
              : `${selectedItems.length} selected`}
        </span>
        <ChevronDown
          size={15}
          style={{
            color: 'var(--subtle)',
            flexShrink: 0,
            transform: open ? 'rotate(180deg)' : 'rotate(0deg)',
            transition: 'transform 150ms',
          }}
        />
      </button>

      {/* Selected chips (multi only) */}
      {!singleSelect && selectedItems.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mt-2">
          {selectedItems.map((item) => (
            <span
              key={item.id}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium"
              style={{ background: 'var(--accent)', color: 'var(--bg)' }}
            >
              {item.label}
              <button
                type="button"
                onClick={() => remove(item.id)}
                className="flex items-center"
                style={{ color: 'var(--bg)', opacity: 0.75 }}
              >
                <X size={10} />
              </button>
            </span>
          ))}
        </div>
      )}

      {/* Portal panel — escapes every overflow/stacking context */}
      {open &&
        panelRect &&
        createPortal(
          <div
            ref={panelRef}
            role="listbox"
            aria-multiselectable={!singleSelect}
            style={{
              ...panelStyle,
              // --surface-muted is solid in both light (#eceef4) and dark (#1f2f44) themes.
              // Never use --surface here: in dark mode it resolves to rgba(255,255,255,0.07).
              background: 'var(--surface-muted)',
              border: '1px solid var(--border)',
              borderRadius: '12px',
              boxShadow:
                '0 4px 6px -1px rgba(0,0,0,0.1), 0 12px 32px -4px rgba(0,0,0,0.25), 0 0 0 1px rgba(255,255,255,0.04)',
              display: 'flex',
              flexDirection: 'column',
              overflow: 'hidden',
            }}
          >
            {/* Search */}
            <div
              className="flex items-center gap-2 px-3 py-2.5"
              style={{
                borderBottom: '1px solid var(--border)',
                flexShrink: 0,
                background: 'var(--surface-muted)',
              }}
            >
              <Search size={13} style={{ color: 'var(--subtle)', flexShrink: 0 }} />
              <input
                ref={inputRef}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={placeholder}
                className="flex-1 bg-transparent outline-none text-sm"
                style={{ color: 'var(--ink)' }}
              />
              {query && (
                <button type="button" onClick={() => setQuery('')}>
                  <X size={13} style={{ color: 'var(--subtle)' }} />
                </button>
              )}
            </div>

            {/* Max limit notice */}
            {atMax && (
              <div
                className="px-3 py-1.5 text-xs"
                style={{
                  color: 'var(--muted)',
                  background: 'var(--surface-muted)',
                  flexShrink: 0,
                  borderBottom: '1px solid var(--border)',
                }}
              >
                Maximum {max} selected
              </div>
            )}

            {/* Options list */}
            <div className="overflow-y-auto flex-1" style={{ overscrollBehavior: 'contain' }}>
              {grouped.length === 0 ? (
                <p className="px-4 py-3 text-sm" style={{ color: 'var(--muted)' }}>
                  No results
                </p>
              ) : (
                grouped.map(([group, groupItems]) => (
                  <div key={group}>
                    {group && (
                      <p
                        className="px-3 pt-2 pb-1 text-[10px] font-semibold uppercase tracking-widest"
                        style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}
                      >
                        {group}
                      </p>
                    )}
                    {groupItems.map((item) => {
                      const isSelected = selected.includes(item.id)
                      const disabled = !isSelected && atMax
                      return (
                        <button
                          key={item.id}
                          type="button"
                          role="option"
                          aria-selected={isSelected}
                          disabled={disabled}
                          onClick={() => toggle(item.id)}
                          className="w-full flex items-center gap-2.5 px-3 py-2.5 text-sm text-left transition-colors"
                          style={{
                            color: disabled
                              ? 'var(--subtle)'
                              : isSelected
                                ? 'var(--accent)'
                                : 'var(--ink)',
                            background: isSelected
                              ? 'color-mix(in srgb, var(--accent) 8%, transparent)'
                              : 'transparent',
                            cursor: disabled ? 'not-allowed' : 'pointer',
                            minHeight: '40px',
                          }}
                        >
                          {/* Indicator: dot for single-select, checkbox for multi */}
                          {singleSelect ? (
                            <span
                              className="flex-shrink-0"
                              style={{
                                width: 16,
                                height: 16,
                                borderRadius: '50%',
                                border: isSelected
                                  ? '5px solid var(--accent)'
                                  : '1.5px solid var(--border)',
                                background: 'transparent',
                                display: 'inline-block',
                                flexShrink: 0,
                              }}
                            />
                          ) : (
                            <span
                              className="w-4 h-4 rounded flex items-center justify-center flex-shrink-0"
                              style={{
                                background: isSelected ? 'var(--accent)' : 'transparent',
                                border: isSelected ? 'none' : '1.5px solid var(--border)',
                              }}
                            >
                              {isSelected && (
                                <Check size={10} strokeWidth={3} style={{ color: 'var(--bg)' }} />
                              )}
                            </span>
                          )}
                          <span className="flex-1 min-w-0">{item.label}</span>
                        </button>
                      )
                    })}
                  </div>
                ))
              )}
            </div>
          </div>,
          document.body,
        )}
    </div>
  )
}
