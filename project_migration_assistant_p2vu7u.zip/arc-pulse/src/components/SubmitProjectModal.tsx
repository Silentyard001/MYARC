/**
 * SubmitProjectModal
 *
 * Bottom-sheet form for submitting a new project to MYARC.
 * Opens when the user clicks "Submit Project" in the Discover tab.
 * Wallet must be connected to submit. On success, the project is
 * inserted to Supabase pending approval.
 *
 * Classification:
 *   - Primary Category (required, exactly 1) — category selector
 *   - Use Cases (optional, max 5)            — searchable multi-select
 *   - Tags (optional, max 5)                 — searchable multi-select with alias resolution
 *
 * Logo system:
 *   Tier 1: Initials + 24-color palette (+ custom hex)
 *   Tier 2: URL-based logo (optional) — validated by loading it as an Image
 */

import { useState, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  X, Send, Lock,
  Globe, Calendar, Palette, Check, Image,
} from 'lucide-react'
import { toast } from 'sonner'
import type { Project } from '../data/projects'
import { supabase } from '../lib/supabase'
import type { TaxonomyResult } from '../hooks/useTaxonomy'
import { TaxonomySelector } from './TaxonomySelector'

// ── 24-colour palette (4 rows × 6) ────────────────────────────────────────────
const PALETTE_ROWS = [
  ['#1a8047', '#22c55e', '#10b981', '#14b8a6', '#06b6d4', '#0ea5e9'],
  ['#3b82f6', '#6366f1', '#8b5cf6', '#a855f7', '#d946ef', '#ec4899'],
  ['#ef4444', '#f97316', '#f59e0b', '#eab308', '#84cc16', '#22d3ee'],
  ['#64748b', '#475569', '#334155', '#1e293b', '#7c3aed', '#be185d'],
]
const ALL_PALETTE_COLORS = PALETTE_ROWS.flat()

function normHex(colorValue: string): string {
  if (colorValue.startsWith('#')) return colorValue
  const m = colorValue.match(/bg-\[([^\]]+)\]/)
  return m ? m[1] : '#1e293b'
}

interface SubmitProjectModalProps {
  isOpen: boolean
  onClose: () => void
  onSubmit: (project: Project) => void
  isConnected: boolean
  address?: string
  taxonomy: TaxonomyResult
}

const EMPTY_FORM = {
  name: '',
  tagline: '',
  description: '',
  primaryCategory: '',
  useCases: [] as string[],
  canonicalTags: [] as string[],
  logoInitials: '',
  logoColor: '#1e293b',
  logoUrl: '',
  launchDate: '',
  website: '',
  tvl: '',
}

type FormState = typeof EMPTY_FORM

function FieldLabel({ children, required }: { children: React.ReactNode; required?: boolean }) {
  return (
    <p className="text-xs font-semibold uppercase tracking-widest mb-1.5"
      style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
      {children}
      {required && <span style={{ color: 'var(--bearish)' }}> *</span>}
    </p>
  )
}

function TextInput({
  value, onChange, placeholder, maxLength, multiline = false,
}: {
  value: string
  onChange: (v: string) => void
  placeholder: string
  maxLength?: number
  multiline?: boolean
}) {
  const shared = {
    value,
    placeholder,
    maxLength,
    onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => onChange(e.target.value),
    className: 'w-full bg-transparent outline-none text-sm leading-relaxed',
    style: { color: 'var(--ink)', fontFamily: "'DM Sans', sans-serif" } as React.CSSProperties,
    onFocus: (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>) => {
      e.currentTarget.closest('[data-input-wrap]')?.setAttribute('data-focused', 'true')
    },
    onBlur: (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>) => {
      e.currentTarget.closest('[data-input-wrap]')?.removeAttribute('data-focused')
    },
  }

  return (
    <div
      data-input-wrap
      className="px-3.5 py-3 rounded-xl border transition-colors"
      style={{ background: 'var(--surface-muted)', borderColor: 'var(--border)' }}
    >
      {multiline
        ? <textarea {...shared} rows={3} style={{ ...shared.style, resize: 'none' }} />
        : <input {...shared} />}
    </div>
  )
}

export function SubmitProjectModal({
  isOpen, onClose, onSubmit, isConnected, address, taxonomy,
}: SubmitProjectModalProps) {
  const [form, setForm] = useState<FormState>(EMPTY_FORM)
  const [submitting, setSubmitting] = useState(false)
  const [logoUrlError, setLogoUrlError] = useState<string | null>(null)
  const [customHex, setCustomHex] = useState('')
  const [customHexError, setCustomHexError] = useState<string | null>(null)
  const logoUrlPreviewRef = useRef<HTMLImageElement | null>(null)

  const set = (key: keyof FormState) => (value: string) =>
    setForm((f) => ({ ...f, [key]: value }))

  const handleCustomHexChange = (raw: string) => {
    setCustomHex(raw)
    setCustomHexError(null)
    const normalized = raw.startsWith('#') ? raw : `#${raw}`
    if (/^#[0-9a-fA-F]{6}$/.test(normalized)) {
      setForm((f) => ({ ...f, logoColor: normalized }))
    } else if (raw.length > 0) {
      setCustomHexError('Enter a valid 6-digit hex (e.g. #3b82f6)')
    }
  }

  const isCustomActive = !ALL_PALETTE_COLORS.includes(normHex(form.logoColor))

  const isValid =
    form.name.trim().length >= 2 &&
    form.tagline.trim().length >= 5 &&
    form.description.trim().length >= 20 &&
    form.primaryCategory.length > 0 &&
    form.logoInitials.trim().length >= 1 &&
    form.launchDate.trim().length >= 4 &&
    !logoUrlError

  const validateLogoUrl = (url: string): Promise<boolean> => {
    if (!url.trim()) return Promise.resolve(true)
    return new Promise((resolve) => {
      const img = new window.Image()
      const timer = setTimeout(() => { img.src = ''; resolve(false) }, 3000)
      img.onload = () => { clearTimeout(timer); resolve(true) }
      img.onerror = () => { clearTimeout(timer); resolve(false) }
      img.src = url
    })
  }

  const handleSubmit = async () => {
    if (!isValid || submitting) return
    setSubmitting(true)

    if (form.logoUrl.trim()) {
      const ok = await validateLogoUrl(form.logoUrl.trim())
      if (!ok) {
        setLogoUrlError('Logo URL could not be loaded — please check the link')
        setSubmitting(false)
        return
      }
    }

    const slug = form.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')

    const newProject: Project = {
      id: slug,
      name: form.name.trim(),
      tagline: form.tagline.trim(),
      description: form.description.trim(),
      tags: [],  // legacy field — empty for new submissions
      primaryCategory: form.primaryCategory,
      useCases: form.useCases,
      canonicalTags: form.canonicalTags,
      logoInitials: form.logoInitials.trim().slice(0, 2).toUpperCase(),
      logoColor: form.logoColor,
      logoUrl: form.logoUrl.trim() || undefined,
      votes: { bullish: 0, neutral: 0, bearish: 0 },
      reviews: [],
      launchDate: form.launchDate.trim(),
      website: form.website.trim() || undefined,
      tvl: form.tvl.trim() || undefined,
    }

    if (supabase) {
      void supabase.from('submitted_projects').insert({
        id: slug,
        name: newProject.name,
        tagline: newProject.tagline,
        description: newProject.description,
        tags: [],
        primary_category: newProject.primaryCategory,
        use_cases: newProject.useCases,
        canonical_tags: newProject.canonicalTags,
        logo_initials: newProject.logoInitials,
        logo_color: newProject.logoColor,
        logo_url: newProject.logoUrl ?? null,
        launch_date: newProject.launchDate,
        website: newProject.website ?? null,
        tvl: newProject.tvl ?? null,
        submitter_address: address ?? '0x0000000000000000000000000000000000000000',
        approved: false,
      }).then(({ error }) => {
        if (error) {
          toast.error('Submission failed. Please try again.')
        } else {
          toast.success('Project submitted for review. It will appear in Discover once approved.')
          setForm(EMPTY_FORM)
          setCustomHex('')
          onClose()
        }
        setSubmitting(false)
      })
    } else {
      onSubmit(newProject)
      toast.success(`${newProject.name} added to MYARC.`)
      setForm(EMPTY_FORM)
      setCustomHex('')
      setSubmitting(false)
      onClose()
    }
  }

  const handleClose = () => {
    setForm(EMPTY_FORM)
    setCustomHex('')
    setLogoUrlError(null)
    onClose()
  }

  const activeHex = normHex(form.logoColor)

  // Selector items
  const categoryItems = taxonomy.activeCategories.map((c) => ({ id: c.id, label: c.label }))
  const useCaseItems  = taxonomy.activeUseCases.map((u) => ({ id: u.id, label: u.label, group: u.group }))
  const tagItems      = taxonomy.activeTags.map((t) => ({ id: t.id, label: t.label }))

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            key="submit-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={handleClose}
            className="fixed inset-0 z-40"
            style={{ background: 'rgba(18,45,69,0.40)', backdropFilter: 'blur(4px)' }}
          />

          {/* Sheet */}
          <motion.div
            key="submit-sheet"
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', stiffness: 360, damping: 36 }}
            className="fixed bottom-0 left-0 right-0 z-50 rounded-t-3xl overflow-hidden"
            style={{
              background: 'var(--surface-strong)',
              maxHeight: '92dvh',
              boxShadow: '0 -8px 40px rgba(18,45,69,0.20)',
            }}
          >
            {/* Drag handle */}
            <div className="flex justify-center pt-3 pb-1">
              <div className="w-10 h-1 rounded-full" style={{ background: 'var(--border-strong)' }} />
            </div>

            <div className="overflow-y-auto" style={{ maxHeight: 'calc(92dvh - 24px)' }}>
              <div className="px-5 pb-12 space-y-5">
                {/* Header */}
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="display font-semibold text-xl" style={{ color: 'var(--ink)' }}>
                      Submit a Project
                    </h2>
                    <p className="text-sm mt-0.5" style={{ color: 'var(--muted)' }}>
                      Add an Arc-native project to the community registry
                    </p>
                  </div>
                  <button
                    onClick={handleClose}
                    className="p-2 rounded-xl flex-shrink-0"
                    style={{ background: 'var(--surface-muted)', color: 'var(--muted)' }}
                  >
                    <X size={18} />
                  </button>
                </div>

                {/* Wallet gate */}
                {!isConnected ? (
                  <div
                    className="flex items-center gap-3 p-4 rounded-2xl"
                    style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}
                  >
                    <Lock size={16} style={{ color: 'var(--subtle)', flexShrink: 0 }} />
                    <p className="text-sm" style={{ color: 'var(--muted)' }}>
                      Connect your wallet to submit a project.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-5">
                    {/* Name */}
                    <div>
                      <FieldLabel required>Project Name</FieldLabel>
                      <TextInput value={form.name} onChange={set('name')} placeholder="e.g. ArcSwap" maxLength={40} />
                    </div>

                    {/* Tagline */}
                    <div>
                      <FieldLabel required>Tagline</FieldLabel>
                      <TextInput value={form.tagline} onChange={set('tagline')} placeholder="One short phrase describing the project" maxLength={80} />
                    </div>

                    {/* Description */}
                    <div>
                      <FieldLabel required>Description</FieldLabel>
                      <TextInput value={form.description} onChange={set('description')} placeholder="What does this project do? Who is it for? What makes it unique on Arc?" maxLength={400} multiline />
                      <p className="text-xs mt-1 text-right tabular-nums" style={{ color: 'var(--subtle)' }}>
                        {form.description.length}/400
                      </p>
                    </div>

                    {/* ── Classification ──────────────────────────────────── */}
                    <div
                      className="rounded-2xl p-4 space-y-4"
                      style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}
                    >
                      <div>
                        <p className="text-xs font-semibold uppercase tracking-widest mb-0.5"
                          style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                          Classification
                        </p>
                        <p className="text-xs" style={{ color: 'var(--muted)' }}>
                          Help the community find your project in the right context.
                        </p>
                      </div>

                      {/* Primary Category */}
                      <TaxonomySelector
                        items={categoryItems}
                        selected={form.primaryCategory ? [form.primaryCategory] : []}
                        onChange={(ids) => setForm((f) => ({ ...f, primaryCategory: ids[0] ?? '' }))}
                        singleSelect
                        label="Primary Category"
                        required
                        placeholder="What is this project?"
                        hint="Choose the single best category that describes what this project is."
                      />
                      {!form.primaryCategory && (
                        <p className="text-xs -mt-2" style={{ color: 'var(--subtle)' }}>
                          Required — choose the best fit; use "Other" if none apply.
                        </p>
                      )}

                      {/* Use Cases */}
                      <TaxonomySelector
                        items={useCaseItems}
                        selected={form.useCases}
                        onChange={(ids) => setForm((f) => ({ ...f, useCases: ids }))}
                        max={5}
                        label="Use Cases"
                        placeholder="What does it enable?"
                        hint="Up to 5 — what specific functions or workflows does this project support?"
                      />

                      {/* Tags */}
                      <TaxonomySelector
                        items={tagItems}
                        selected={form.canonicalTags}
                        onChange={(ids) => setForm((f) => ({ ...f, canonicalTags: ids }))}
                        max={5}
                        label="Tags"
                        placeholder="Specific descriptors..."
                        hint="Up to 5 — specific attributes like USDC, B2B, audited, open-source."
                      />
                    </div>

                    {/* Logo initials */}
                    <div>
                      <FieldLabel required>Logo Initials</FieldLabel>
                      <TextInput
                        value={form.logoInitials}
                        onChange={(v) => set('logoInitials')(v.toUpperCase().slice(0, 2))}
                        placeholder="e.g. AS"
                        maxLength={2}
                      />
                    </div>

                    {/* Logo URL */}
                    <div>
                      <div className="flex items-center gap-2 mb-1.5">
                        <Image size={12} style={{ color: 'var(--subtle)' }} />
                        <FieldLabel>Logo URL (optional)</FieldLabel>
                      </div>
                      <div className="flex items-center gap-2">
                        {form.logoUrl.trim() && !logoUrlError && (
                          <img
                            ref={logoUrlPreviewRef}
                            src={form.logoUrl.trim()}
                            alt="logo preview"
                            onError={() => setLogoUrlError('Logo URL could not be loaded — please check the link')}
                            onLoad={() => setLogoUrlError(null)}
                            className="w-10 h-10 rounded-xl object-cover flex-shrink-0"
                            style={{ border: '1px solid var(--border)' }}
                          />
                        )}
                        <div className="flex-1">
                          <TextInput
                            value={form.logoUrl}
                            onChange={(v) => { set('logoUrl')(v); setLogoUrlError(null) }}
                            placeholder="https://yourproject.io/logo.png or IPFS URL"
                            maxLength={500}
                          />
                        </div>
                      </div>
                      {logoUrlError && (
                        <p className="text-xs mt-1" style={{ color: 'var(--bearish)' }}>{logoUrlError}</p>
                      )}
                    </div>

                    {/* Color palette */}
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <Palette size={12} style={{ color: 'var(--subtle)' }} />
                        <FieldLabel required>Logo Color</FieldLabel>
                      </div>

                      <div className="space-y-2">
                        {PALETTE_ROWS.map((row, ri) => (
                          <div key={ri} className="flex gap-2">
                            {row.map((hex) => {
                              const isActive = activeHex === hex
                              return (
                                <motion.button
                                  key={hex}
                                  whileHover={{ scale: 1.1 }}
                                  whileTap={{ scale: 0.95 }}
                                  onClick={() => { set('logoColor')(hex); setCustomHex('') }}
                                  className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 transition-all"
                                  style={{
                                    background: hex,
                                    boxShadow: isActive
                                      ? `0 0 0 2px ${hex} inset, 0 0 0 3.5px var(--bg), 0 0 0 5.5px var(--accent)`
                                      : 'none',
                                  }}
                                >
                                  <Check
                                    size={14}
                                    strokeWidth={3}
                                    style={{ color: 'white', opacity: isActive ? 1 : 0, transition: 'opacity 120ms' }}
                                  />
                                </motion.button>
                              )
                            })}
                          </div>
                        ))}
                      </div>

                      {/* Custom hex input */}
                      <div className="flex items-center gap-3 mt-3">
                        <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em', flexShrink: 0 }}>
                          Custom
                        </p>
                        <div
                          className="w-7 h-7 rounded-full flex-shrink-0 transition-colors"
                          style={{
                            background: isCustomActive ? activeHex : (customHex.length > 0 ? (customHex.startsWith('#') ? customHex : `#${customHex}`) : 'var(--surface-muted)'),
                            border: '1px solid var(--border)',
                          }}
                        />
                        <div
                          data-input-wrap
                          className="flex-1 px-3 py-2 rounded-xl border transition-colors"
                          style={{ background: 'var(--surface-muted)', borderColor: isCustomActive ? 'var(--accent)' : 'var(--border)' }}
                        >
                          <input
                            value={customHex}
                            onChange={(e) => handleCustomHexChange(e.target.value)}
                            placeholder="#000000"
                            maxLength={7}
                            className="w-full bg-transparent outline-none text-sm mono"
                            style={{ color: 'var(--ink)' }}
                          />
                        </div>
                      </div>
                      {customHexError && (
                        <p className="text-xs mt-1" style={{ color: 'var(--bearish)' }}>{customHexError}</p>
                      )}
                    </div>

                    {/* Logo preview */}
                    {(form.logoInitials || (form.logoUrl && !logoUrlError)) && (
                      <div className="flex items-center gap-3 p-3 rounded-xl" style={{ background: 'var(--surface-muted)' }}>
                        {form.logoUrl && !logoUrlError ? (
                          <img
                            src={form.logoUrl}
                            alt="logo"
                            className="w-11 h-11 rounded-xl object-cover flex-shrink-0"
                            style={{ border: '1px solid var(--border)' }}
                            onError={() => setLogoUrlError('Logo URL could not be loaded — please check the link')}
                          />
                        ) : (
                          <div
                            className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0"
                            style={{ background: activeHex }}
                          >
                            <span className="display text-white font-bold text-sm">{form.logoInitials.slice(0, 2)}</span>
                          </div>
                        )}
                        <div>
                          <p className="display font-semibold text-sm" style={{ color: 'var(--ink)' }}>
                            {form.name || 'Project Name'}
                          </p>
                          <p className="text-xs" style={{ color: 'var(--muted)' }}>
                            {form.tagline || 'Tagline goes here'}
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Launch date */}
                    <div>
                      <div className="flex items-center gap-2 mb-1.5">
                        <Calendar size={12} style={{ color: 'var(--subtle)' }} />
                        <FieldLabel required>Launch Date</FieldLabel>
                      </div>
                      <TextInput value={form.launchDate} onChange={set('launchDate')} placeholder="e.g. Sep 2026" maxLength={20} />
                    </div>

                    {/* Optional fields */}
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="flex items-center gap-2 mb-1.5">
                          <Globe size={12} style={{ color: 'var(--subtle)' }} />
                          <FieldLabel>Website</FieldLabel>
                        </div>
                        <TextInput value={form.website} onChange={set('website')} placeholder="https://..." maxLength={120} />
                      </div>
                      <div>
                        <FieldLabel>Self-reported TVL</FieldLabel>
                        <TextInput value={form.tvl} onChange={set('tvl')} placeholder="e.g. $1.2M" maxLength={20} />
                      </div>
                    </div>
                    {form.tvl.trim() && (
                      <p className="text-xs -mt-3" style={{ color: 'var(--subtle)' }}>
                        TVL is self-reported and not independently verified.
                      </p>
                    )}

                    {/* Submitter info */}
                    <div
                      className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs"
                      style={{ background: 'var(--surface-muted)', color: 'var(--subtle)', border: '1px solid var(--border)' }}
                    >
                      <span>Submitting as</span>
                      <span className="mono font-medium" style={{ color: 'var(--ink-2)' }}>
                        {address ? `${address.slice(0, 6)}...${address.slice(-4)}` : '—'}
                      </span>
                    </div>

                    {/* Validation hint */}
                    {!isValid && (
                      <p className="text-xs" style={{ color: 'var(--subtle)' }}>
                        {!form.primaryCategory
                          ? 'Choose a primary category to continue.'
                          : 'Fill in all required fields to submit.'}
                      </p>
                    )}

                    {/* Submit button */}
                    <motion.button
                      whileTap={{ scale: 0.97 }}
                      onClick={() => void handleSubmit()}
                      disabled={!isValid || submitting}
                      className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-semibold text-sm transition-all min-h-[48px]"
                      style={
                        isValid && !submitting
                          ? { background: 'var(--accent)', color: 'var(--bg)' }
                          : { background: 'var(--surface-muted)', color: 'var(--subtle)', cursor: 'not-allowed' }
                      }
                    >
                      <Send size={15} />
                      {submitting ? 'Submitting...' : 'Submit Project'}
                    </motion.button>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}
