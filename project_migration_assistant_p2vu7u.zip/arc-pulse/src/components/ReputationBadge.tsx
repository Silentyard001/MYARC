/**
 * ReputationBadge
 *
 * A small colored pill showing the user's reputation tier.
 * Tiers: Newcomer | Analyst | Pioneer | Whale
 */

import { Shield } from 'lucide-react'
import { TIER_COLORS, type ReputationTier } from '../hooks/useReputation'

interface ReputationBadgeProps {
  tier: ReputationTier
  score?: number
  /** 'sm' (default) for inline review rows; 'md' for headers */
  size?: 'sm' | 'md'
}

export function ReputationBadge({ tier, score, size = 'sm' }: ReputationBadgeProps) {
  const { bg, color } = TIER_COLORS[tier]
  const iconSize = size === 'md' ? 13 : 11
  const textClass = size === 'md' ? 'text-xs' : 'text-[11px]'

  return (
    <span
      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full font-semibold ${textClass} flex-shrink-0`}
      style={{ background: bg, color }}
    >
      <Shield size={iconSize} strokeWidth={2.5} />
      {tier}
      {score !== undefined && (
        <span className="tabular-nums opacity-70">{score}</span>
      )}
    </span>
  )
}
