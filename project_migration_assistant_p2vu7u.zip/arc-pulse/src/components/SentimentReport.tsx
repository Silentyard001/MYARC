/**
 * SentimentReport
 *
 * A print-ready structured sentiment report for a verified project owner.
 * Rendered into a hidden div; the Generate Report button calls window.print()
 * which, with the @media print stylesheet in index.css, hides the app shell
 * and renders only this component full-width for "Save as PDF".
 *
 * Props:
 *   project   — full Project object (with reviews, votes, etc.)
 *   analytics — ProjectAnalyticsResult from useProjectAnalytics
 *   allProjects — all seed + submitted projects (for comparative note)
 */

import { PROJECTS } from '../data/projects'
import type { Project } from '../data/projects'
import type { ProjectAnalyticsResult } from '../hooks/useProjectAnalytics'

// ── Pure-SVG line chart (print-safe, no canvas, no library) ──────────────────
function ReportLineChart({
  data,
  width = 560,
  height = 80,
  color = '#1a8047',
}: {
  data: (number | null)[]
  width?: number
  height?: number
  color?: string
}) {
  const filled = data.map((v) => v ?? 0)
  if (filled.every((v) => v === 0)) return null
  const min = Math.min(...filled)
  const max = Math.max(...filled)
  const range = max - min || 1
  const pad = 6

  const pts = filled.map((v, i) => {
    const x = pad + (i / (filled.length - 1)) * (width - pad * 2)
    const y = pad + (1 - (v - min) / range) * (height - pad * 2)
    return `${x},${y}`
  })

  return (
    <svg width={width} height={height} style={{ overflow: 'visible', display: 'block' }}>
      <polyline
        points={pts.join(' ')}
        fill="none"
        stroke={color}
        strokeWidth={2.5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {filled.map((v, i) => {
        const x = pad + (i / (filled.length - 1)) * (width - pad * 2)
        const y = pad + (1 - (v - min) / range) * (height - pad * 2)
        return <circle key={i} cx={x} cy={y} r={3.5} fill={color} />
      })}
    </svg>
  )
}

// ── Pure-SVG bar chart ────────────────────────────────────────────────────────
function ReportBarChart({
  data,
  labels,
  width = 560,
  height = 80,
  color = '#122d45',
}: {
  data: number[]
  labels?: string[]
  width?: number
  height?: number
  color?: string
}) {
  const max = Math.max(...data, 1)
  const barW = Math.floor((width - (data.length - 1) * 6) / data.length)

  return (
    <svg width={width} height={height + 18} style={{ display: 'block' }}>
      {data.map((v, i) => {
        const barH = Math.round((v / max) * height)
        const x = i * (barW + 6)
        const y = height - barH
        return (
          <g key={i}>
            <rect x={x} y={y} width={barW} height={barH} rx={3} fill={color} opacity={0.75} />
            {labels?.[i] && (
              <text x={x + barW / 2} y={height + 14} textAnchor="middle" fontSize={10} fill="#8a849c">
                {labels[i]}
              </text>
            )}
          </g>
        )
      })}
    </svg>
  )
}

// ── Section header ────────────────────────────────────────────────────────────
function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div style={{ marginBottom: 32 }}>
      <h2 style={{
        fontSize: 11,
        fontWeight: 700,
        letterSpacing: '0.10em',
        textTransform: 'uppercase',
        color: '#8a849c',
        margin: '0 0 12px 0',
        paddingBottom: 6,
        borderBottom: '1px solid #e5e7eb',
        fontFamily: "'DM Sans', sans-serif",
      }}>
        {title}
      </h2>
      {children}
    </div>
  )
}

// ── Main report ───────────────────────────────────────────────────────────────
export function SentimentReport({
  project,
  analytics,
  allProjects: _allProjects,
}: {
  project: Project
  analytics: ProjectAnalyticsResult
  allProjects?: Project[]
}) {
  // oxlint-disable-next-line react/purity -- print-only component; stable timestamp is intentional
  const nowMs = Date.now()
  const now = new Date(nowMs)
  const periodStart = new Date(nowMs - 30 * 86400000)
  const fmtDate = (d: Date) => d.toLocaleDateString('en', { year: 'numeric', month: 'long', day: 'numeric' })

  // Sentiment breakdown
  const bd = analytics.sentimentBreakdown
  const total = bd.bullish + bd.neutral + bd.bearish
  const bullPct = total > 0 ? Math.round((bd.bullish / total) * 100) : 0
  const neutralPct = total > 0 ? Math.round((bd.neutral / total) * 100) : 0
  const bearPct = total > 0 ? Math.round((bd.bearish / total) * 100) : 0

  // Sentiment health score
  const healthScore = Math.round(bullPct * 1 - bearPct * 1.5)
  const healthColor = healthScore > 20 ? '#1a8047' : healthScore < 0 ? '#ba2b4c' : '#6b6580'

  // Top 3 most helpful reviews
  const topReviews = [...project.reviews]
    .sort((a, b) => b.helpful - a.helpful)
    .slice(0, 3)

  // Comparative note — % of seed projects with lower bullish sentiment
  const allProjects = PROJECTS
  const otherBullPcts = allProjects
    .filter((p) => p.id !== project.id)
    .map((p) => {
      const t = p.votes.bullish + p.votes.neutral + p.votes.bearish
      return t > 0 ? (p.votes.bullish / t) * 100 : 0
    })
  const lowerCount = otherBullPcts.filter((pct) => pct < bullPct).length
  const comparativePct = otherBullPcts.length > 0
    ? Math.round((lowerCount / otherBullPcts.length) * 100)
    : 0

  // Total reviews in period (last 30d)
  const periodReviews = analytics.reviewVolume.reduce((s, v) => s + v, 0)

  const trendData = analytics.timeline.map((v) => v ?? 0)

  return (
    <div
      id="myarc-report"
      style={{
        width: 680,
        maxWidth: '100%',
        margin: '0 auto',
        padding: '48px 40px',
        fontFamily: "'DM Sans', sans-serif",
        color: '#122d45',
        background: '#ffffff',
        lineHeight: 1.6,
      }}
    >
      {/* ── Report header ───────────────────────────────────────────────────── */}
      <div style={{ marginBottom: 40, paddingBottom: 24, borderBottom: '2px solid #122d45' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 16 }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
              <div style={{
                width: 44, height: 44, borderRadius: 12, background: '#122d45',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: '#ffffff', fontWeight: 700, fontSize: 16,
              }}>
                {project.logoInitials}
              </div>
              <div>
                <h1 style={{ margin: 0, fontSize: 26, fontWeight: 700, color: '#122d45', fontFamily: "'Space Grotesk', sans-serif" }}>
                  {project.name}
                </h1>
                <p style={{ margin: 0, fontSize: 13, color: '#6b6580' }}>
                  {project.tagline}
                  {' · '}
                  <span style={{
                    display: 'inline-flex', alignItems: 'center', gap: 4,
                    background: 'rgba(26,92,255,0.08)', color: '#1a5cff',
                    padding: '1px 8px', borderRadius: 20, fontSize: 11, fontWeight: 600,
                  }}>
                    Verified
                  </span>
                </p>
              </div>
            </div>
          </div>
          <div style={{ textAlign: 'right', flexShrink: 0 }}>
            <p style={{ margin: 0, fontSize: 12, color: '#8a849c' }}>Sentiment Report</p>
            <p style={{ margin: '2px 0 0', fontSize: 13, fontWeight: 600, color: '#334155' }}>
              {fmtDate(now)}
            </p>
            <p style={{ margin: '2px 0 0', fontSize: 11, color: '#8a849c' }}>
              Period: {fmtDate(periodStart)} – {fmtDate(now)}
            </p>
          </div>
        </div>
      </div>

      {/* ── Executive summary ───────────────────────────────────────────────── */}
      <Section title="Executive Summary">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 16 }}>
          {[
            { label: 'Bullish', value: `${bullPct}%`, sub: `${bd.bullish.toLocaleString()} votes`, color: '#1a8047' },
            { label: 'Neutral', value: `${neutralPct}%`, sub: `${bd.neutral.toLocaleString()} votes`, color: '#6b6580' },
            { label: 'Bearish', value: `${bearPct}%`, sub: `${bd.bearish.toLocaleString()} votes`, color: '#ba2b4c' },
            { label: 'Health Score', value: `${healthScore > 0 ? '+' : ''}${healthScore}`, sub: 'sentiment index', color: healthColor },
          ].map(({ label, value, sub, color }) => (
            <div key={label} style={{
              padding: '14px 16px', borderRadius: 12, background: '#f8f9fa',
              border: '1px solid #e5e7eb', textAlign: 'center',
            }}>
              <p style={{ margin: 0, fontSize: 24, fontWeight: 700, color, fontFamily: "'Space Grotesk', sans-serif" }}>
                {value}
              </p>
              <p style={{ margin: '2px 0 0', fontSize: 11, fontWeight: 600, color: '#334155' }}>{label}</p>
              <p style={{ margin: '1px 0 0', fontSize: 10, color: '#8a849c' }}>{sub}</p>
            </div>
          ))}
        </div>
        <div style={{
          padding: '10px 16px', borderRadius: 10, background: '#f8f9fa',
          border: '1px solid #e5e7eb', display: 'flex', gap: 24,
        }}>
          <span style={{ fontSize: 13, color: '#334155' }}>
            <strong>{total.toLocaleString()}</strong> total votes &nbsp;·&nbsp;
            <strong>{project.reviews.length}</strong> reviews &nbsp;·&nbsp;
            <strong>{periodReviews}</strong> reviews in period
          </span>
        </div>
      </Section>

      {/* ── 7-day sentiment trend ────────────────────────────────────────────── */}
      {trendData.some((v) => v > 0) && (
        <Section title="7-Day Sentiment Trend (Bullish %)">
          <div style={{ padding: '16px 0 4px' }}>
            <ReportLineChart data={analytics.timeline} width={600} height={80} color="#1a8047" />
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6 }}>
              {analytics.dayLabels.map((l) => (
                <span key={l} style={{ fontSize: 10, color: '#8a849c', width: 600 / 7, textAlign: 'center' }}>
                  {l}
                </span>
              ))}
            </div>
          </div>
        </Section>
      )}

      {/* ── Community highlights ─────────────────────────────────────────────── */}
      {topReviews.length > 0 && (
        <Section title="Community Highlights">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {topReviews.map((review) => (
              <div key={review.id} style={{
                padding: '14px 18px',
                borderRadius: 12,
                borderLeft: '3px solid #122d45',
                background: '#f8f9fa',
                border: '1px solid #e5e7eb',
                borderLeftWidth: 3,
                borderLeftColor: '#122d45',
              }}>
                <p style={{ margin: '0 0 6px', fontSize: 14, color: '#334155', fontStyle: 'italic', lineHeight: 1.5 }}>
                  "{review.body.length > 120 ? review.body.slice(0, 120) + '…' : review.body}"
                </p>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ fontSize: 11, color: '#8a849c' }}>{review.author}</span>
                  <span style={{
                    fontSize: 10, fontWeight: 600,
                    color: review.sentiment === 'bullish' ? '#1a8047' : review.sentiment === 'bearish' ? '#ba2b4c' : '#6b6580',
                    background: review.sentiment === 'bullish' ? 'rgba(26,128,71,0.10)' : review.sentiment === 'bearish' ? 'rgba(186,43,76,0.10)' : 'rgba(107,101,128,0.10)',
                    padding: '2px 7px', borderRadius: 20, textTransform: 'capitalize',
                  }}>
                    {review.sentiment}
                  </span>
                  <span style={{ fontSize: 11, color: '#8a849c' }}>{review.helpful} helpful</span>
                </div>
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* ── Review volume ────────────────────────────────────────────────────── */}
      <Section title="Review Volume (Last 7 Days)">
        <div style={{ padding: '12px 0 4px' }}>
          <ReportBarChart
            data={analytics.reviewVolume}
            labels={analytics.dayLabels}
            width={600}
            height={72}
            color="#122d45"
          />
        </div>
      </Section>

      {/* ── Top reviewers ────────────────────────────────────────────────────── */}
      {analytics.topReviewers.length > 0 && (
        <Section title="Top Reviewers">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {analytics.topReviewers.slice(0, 5).map((r, i) => (
              <div key={r.address} style={{
                display: 'flex', alignItems: 'center', gap: 12,
                padding: '8px 14px', borderRadius: 10, background: '#f8f9fa',
                border: '1px solid #e5e7eb',
              }}>
                <span style={{ fontSize: 12, fontWeight: 700, color: '#8a849c', width: 20, textAlign: 'center' }}>
                  {i + 1}
                </span>
                <span style={{ fontSize: 12, fontFamily: 'monospace', color: '#334155', flex: 1 }}>
                  {r.address.slice(0, 10)}…{r.address.slice(-8)}
                </span>
                <span style={{ fontSize: 12, fontWeight: 600, color: '#1a8047' }}>
                  {r.count} review{r.count !== 1 ? 's' : ''}
                </span>
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* ── Comparative note ─────────────────────────────────────────────────── */}
      <Section title="Ecosystem Context">
        <div style={{
          padding: '14px 18px', borderRadius: 12,
          background: bullPct >= 50 ? 'rgba(26,128,71,0.05)' : 'rgba(107,101,128,0.05)',
          border: `1px solid ${bullPct >= 50 ? 'rgba(26,128,71,0.15)' : 'rgba(107,101,128,0.15)'}`,
        }}>
          <p style={{ margin: 0, fontSize: 14, color: '#334155', lineHeight: 1.6 }}>
            <strong style={{ color: '#122d45' }}>{comparativePct}%</strong> of Arc ecosystem projects have a lower
            bullish sentiment score than {project.name}. Current bullish rating:{' '}
            <strong style={{ color: '#1a8047' }}>{bullPct}%</strong>.
          </p>
        </div>
      </Section>

      {/* ── Footer ───────────────────────────────────────────────────────────── */}
      <div style={{
        marginTop: 40, paddingTop: 20, borderTop: '1px solid #e5e7eb',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      }}>
        <div>
          <p style={{ margin: 0, fontSize: 13, fontWeight: 700, color: '#122d45', fontFamily: "'Space Grotesk', sans-serif" }}>
            MYARC
          </p>
          <p style={{ margin: '1px 0 0', fontSize: 11, color: '#8a849c' }}>
            Community sentiment infrastructure for the Arc ecosystem
          </p>
        </div>
        <p style={{ margin: 0, fontSize: 10, color: '#8a849c' }}>
          Generated {now.toISOString().slice(0, 19).replace('T', ' ')} UTC
        </p>
      </div>
    </div>
  )
}
