/**
 * AnimatedNumber — smoothly interpolates a numeric display value.
 *
 * Uses Framer Motion's `useMotionValue` + `animate` so the rendered digit
 * tracks from the previous value to the new one rather than cutting abruptly.
 *
 * Props:
 *   value        — the target number to display
 *   duration     — animation duration in seconds (default 0.4)
 *   format       — optional formatter (default: toLocaleString with commas)
 *   className    — forwarded to the wrapping <span>
 *   style        — forwarded to the wrapping <span>
 *   suffix       — optional string appended after the number (e.g. "%")
 *   'aria-hidden'— forwarded; set to "true" when the parent carries the aria label
 */

import { useEffect, useRef } from 'react'
import { useMotionValue, useTransform, animate, useReducedMotion, motion } from 'framer-motion'

interface AnimatedNumberProps {
  value: number
  duration?: number
  format?: (n: number) => string
  suffix?: string
  className?: string
  style?: React.CSSProperties
  'aria-hidden'?: 'true' | boolean
}

export function AnimatedNumber({
  value,
  duration = 0.4,
  format,
  suffix = '',
  className,
  style,
  'aria-hidden': ariaHidden,
}: AnimatedNumberProps) {
  const prefersReduced = useReducedMotion()
  const motionVal = useMotionValue(value)
  const mountedRef = useRef(false)

  // On first mount, jump to target with no animation.
  // On subsequent changes, interpolate.
  useEffect(() => {
    if (!mountedRef.current) {
      mountedRef.current = true
      motionVal.set(value)
      return
    }
    if (prefersReduced) {
      motionVal.set(value)
      return
    }
    const controls = animate(motionVal, value, {
      duration,
      ease: [0.25, 0.1, 0.25, 1], // cubic-bezier ease-out
    })
    return () => controls.stop()
  }, [value, duration, prefersReduced, motionVal])

  const formatted = useTransform(motionVal, (v) => {
    const rounded = Math.round(v)
    const str = format ? format(rounded) : rounded.toLocaleString()
    return str + suffix
  })

  return (
    <motion.span
      className={className}
      style={style}
      aria-hidden={ariaHidden}
    >
      {formatted}
    </motion.span>
  )
}
