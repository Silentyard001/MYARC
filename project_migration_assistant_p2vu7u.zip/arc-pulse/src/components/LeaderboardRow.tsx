import type { Project } from '../data/projects'
import { VoteBar } from './VoteBar'
import { TvlSparkline } from './TvlSparkline'
import { AnimatedNumber } from './AnimatedNumber'

interface LeaderboardRowProps {
  project: Project
  rank: number
  onSelect: (project: Project) => void
}

export function LeaderboardRow({ project, rank, onSelect }: LeaderboardRowProps) {
  const total = project.votes.bullish + project.votes.neutral + project.votes.bearish
  const bullPct = total > 0 ? Math.round((project.votes.bullish / total) * 100) : 0
  const bearPct = total > 0 ? Math.round((project.votes.bearish / total) * 100) : 0

  // Semantic trend color: green only when bullish is genuinely dominant,
  // red when bearish dominates, neutral gray when closely contested.
  const sentimentColor =
    bullPct >= 55 ? 'var(--bullish)'
    : bearPct >= 55 ? 'var(--bearish)'
    : 'var(--neutral)'

  const rankColor =
    rank === 1 ? '#f59e0b'
    : rank === 2 ? '#94a3b8'
    : rank === 3 ? '#b45309'
    : 'var(--subtle)'

  const rankSize = rank <= 3 ? 'text-base' : 'text-sm'

  return (
    <button
      onClick={() => onSelect(project)}
      className="w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl border transition-all hover:opacity-80 text-left min-h-[44px]"
      style={{ background: 'var(--surface)', borderColor: rank <= 3 ? 'var(--border-strong)' : 'var(--border)' }}
    >
      <span className={`display font-bold w-6 text-center flex-shrink-0 ${rankSize}`} style={{ color: rankColor }}>
        {rank}
      </span>

      <div
        className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${project.logoColor}`}
      >
        <span className="display text-white font-bold text-xs">{project.logoInitials}</span>
      </div>

      <div className="flex-1 min-w-0 space-y-1">
        <div className="flex items-center justify-between gap-2">
          <span className="display font-semibold text-sm truncate" style={{ color: 'var(--ink)' }}>
            {project.name}
          </span>
          <div className="flex items-center gap-2 flex-shrink-0">
            {project.tvlHistory && (
              <TvlSparkline data={project.tvlHistory} width={44} height={16} fill={false} />
            )}
            <AnimatedNumber
              value={bullPct}
              suffix="%"
              duration={0.4}
              className="text-sm font-semibold tabular-nums"
              style={{ color: sentimentColor }}
              aria-hidden="true"
            />
          </div>
        </div>
        <VoteBar votes={project.votes} size="sm" />
      </div>
    </button>
  )
}
