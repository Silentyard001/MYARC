/**
 * ProjectLogo
 *
 * Three-tier logo rendering:
 *   1. project.logoUrl (from project_overrides or submitted data) — URL-based image
 *   2. Initials + logoColor avatar — fallback when no URL or image fails
 *
 * Size variants:
 *   sm  — 32px  (TrendingStrip chips)
 *   md  — 40px  (ProjectCard)
 *   lg  — 56px  (ProjectDetailSheet header, FeaturedBanner)
 */
import { useState } from 'react'
import type { Project } from '../data/projects'

const SIZE_MAP = {
  sm: { px: 28, text: '10px', radius: '8px' },
  md: { px: 44, text: '14px', radius: '12px' },
  lg: { px: 56, text: '18px', radius: '14px' },
}

// Resolve a Tailwind bg class or raw hex to a CSS color value
function resolveColor(logoColor: string): string {
  if (logoColor.startsWith('#')) return logoColor
  // Extract hex from Tailwind JIT class like bg-[#122d45]
  const match = logoColor.match(/bg-\[([^\]]+)\]/)
  return match ? match[1] : '#122d45'
}

interface ProjectLogoProps {
  project: Project
  size?: 'sm' | 'md' | 'lg'
  className?: string
  /** Show shimmer overlay (e.g. while uploading a new logo) */
  isUploading?: boolean
}

export function ProjectLogo({ project, size = 'md', className = '', isUploading = false }: ProjectLogoProps) {
  const { px, text, radius } = SIZE_MAP[size]
  const [imgError, setImgError] = useState(false)
  const [imgLoaded, setImgLoaded] = useState(false)

  const bgColor = resolveColor(project.logoColor)
  const showImage = Boolean(project.logoUrl) && !imgError

  return (
    <div
      className={`relative flex-shrink-0 ${className}`}
      style={{ width: px, height: px, borderRadius: radius, overflow: 'hidden' }}
    >
      {/* Initials fallback — always rendered, image sits on top */}
      <div
        className="absolute inset-0 flex items-center justify-center"
        style={{ background: bgColor, borderRadius: radius }}
      >
        <span
          className="display text-white font-bold select-none"
          style={{ fontSize: text, lineHeight: 1 }}
        >
          {project.logoInitials}
        </span>
      </div>

      {/* URL-based image layer — fades in on load */}
      {showImage && (
        <img
          src={project.logoUrl}
          alt={project.name}
          onError={() => setImgError(true)}
          onLoad={() => setImgLoaded(true)}
          className="absolute inset-0 w-full h-full object-cover"
          style={{
            borderRadius: radius,
            opacity: imgLoaded ? 1 : 0,
            transition: 'opacity 200ms ease',
          }}
        />
      )}

      {/* Shimmer overlay while uploading */}
      {isUploading && (
        <div
          className="absolute inset-0 animate-pulse"
          style={{ background: 'rgba(0,0,0,0.35)', borderRadius: radius }}
        />
      )}
    </div>
  )
}
