/**
 * AdminPanel
 *
 * Full-screen bottom-sheet modal accessible only to the contract owner.
 * Tabs: Featured | Sponsored | Polls | Submissions | Verification | Revenue
 *
 * All write operations use getAdminClient() which returns the session-bearing
 * Supabase client. Admin RLS policies verify the JWT wallet_address claim.
 */
import { useState, useEffect, useMemo, useCallback } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  X, Star, Megaphone, DollarSign, CheckCircle2, ShieldCheck,
  Pause, Play, UserPlus, UserMinus, Settings2, Vote, Inbox,
  Plus, Minus as MinusIcon, Check, Trash2, Send, Pin, MessageSquare,
  Folders, History, RotateCcw, AlertTriangle, Edit3,
  Bell, Ban, Eye, RefreshCw, BarChart2, TrendingUp, Users, FileText, Award, Code, Tag,
} from 'lucide-react'
import { useTaxonomy } from '../hooks/useTaxonomy'
import type { Category, UseCase, CanonicalTag } from '../data/taxonomy'
import { usePublicClient, useAccount, useWriteContract } from 'wagmi'
import { parseAbi, keccak256, toHex } from 'viem'
import { toast } from 'sonner'
import { ARC_TESTNET_CHAIN_ID } from '../config'
import { PROJECTS, POLLS } from '../data/projects'
import type { Project } from '../data/projects'
import type { AdminConfigResult } from '../hooks/useAdminConfig'
import type { ProjectOverride } from '../hooks/useProjectOverrides'
import { RevenueTab } from './RevenueTab'
import { ProjectLogo } from './ProjectLogo'
import { supabase, getAdminClient } from '../lib/supabase'
import type { SupabaseClient } from '@supabase/supabase-js'
import { usePinnedReviews } from '../hooks/usePinnedReviews'
import { useReviewResponses } from '../hooks/useReviewResponses'
import type { ReviewResponse } from '../hooks/useReviewResponses'
import { useAnnouncements } from '../hooks/useAnnouncements'
import { usePlatformAnalytics } from '../hooks/usePlatformAnalytics'
import type { PlatformAnalyticsResult } from '../hooks/usePlatformAnalytics'
import { usePlatformMomentum } from '../hooks/usePlatformMomentum'
import type { UsePlatformMomentumReturn } from '../hooks/usePlatformMomentum'
import type { Announcement } from '../hooks/useAnnouncements'
import { useModeratedReviews } from '../hooks/useModeratedReviews'
import type { UseBlacklistReturn } from '../hooks/useBlacklist'
import { useVerifiedOwners } from '../hooks/useVerifiedOwners'
import { PulseBadge } from '../widget/PulseBadge'

const OWNER_ABI = parseAbi(['function owner() view returns (address)'])

const VERIFICATION_ABI = parseAbi([
  'function verificationFee() view returns (uint256)',
  'function verificationPaused() view returns (bool)',
  'function setVerificationFee(uint256 fee)',
  'function setVerificationPaused(bool paused)',
  'function addToWhitelist(address wallet)',
  'function removeFromWhitelist(address wallet)',
  'function setCustomFee(address wallet, uint256 fee)',
  'function removeCustomFee(address wallet)',
  'function getEffectiveFee(address wallet) view returns (uint256)',
])

const POLL_ABI = parseAbi([
  'function createPoll(bytes32 pollId, string question, string[] options, uint40 endsAt)',
  'function getPollResult(bytes32 pollId) view returns (uint8 winner, uint256[] optionVotes, uint256 totalStake)',
])

type AdminTab = 'featured' | 'sponsored' | 'polls' | 'submissions' | 'verification' | 'revenue' | 'reviews' | 'projects' | 'log' | 'announcements' | 'blacklist' | 'analytics' | 'widget' | 'profiles' | 'taxonomy'

type ProjectStatus = 'active' | 'inactive' | 'discontinued' | 'under_review' | 'delisted'

interface AdminPanelProps {
  isOpen: boolean
  onClose: () => void
  contractAddress: `0x${string}` | undefined
  adminConfig: AdminConfigResult
  allProjects?: Project[]
  saveProjectOverride?: (id: string, override: Partial<ProjectOverride>, ownerAddress?: string, previousValues?: Record<string, unknown>, action?: string) => Promise<void>
  refetchOverrides?: () => void
  blacklist?: UseBlacklistReturn
  /** Pre-fetched platform momentum — pass from App to avoid a duplicate fetch. */
  platformMomentum?: UsePlatformMomentumReturn
}

// ── Poll creation form state ───────────────────────────────────────────────────
const EMPTY_POLL_FORM = {
  question: '',
  options: ['', ''],
  endDate: '',
  sponsored: false,
  sponsorName: '',
}
type PollFormState = typeof EMPTY_POLL_FORM

interface OnchainPollPreview {
  poll_id: string
  question: string
  options: { id: string; label: string }[]
  ends_at: string
  sponsored: boolean
  sponsor_name: string
  vote_counts: number[]
  total_votes: number
}

// ── Pending submission row ─────────────────────────────────────────────────────
interface PendingSubmission {
  id: string
  name: string
  tagline: string
  description: string
  submitter_address: string
  tags: string[]
  logo_initials: string
  logo_color: string
  logo_url: string | null
  launch_date: string
  website: string | null
}

export function AdminPanel({ isOpen, onClose, contractAddress, adminConfig, allProjects = [], saveProjectOverride, refetchOverrides, blacklist, platformMomentum: platformMomentumProp }: AdminPanelProps) {
  const { address } = useAccount()
  const publicClient = usePublicClient({ chainId: ARC_TESTNET_CHAIN_ID })
  const { featuredIds, sponsoredPolls, setFeatured, setSponsored, isLoading } = adminConfig

  const [activeTab, setActiveTab] = useState<AdminTab>('featured')
  const [contractOwner, setContractOwner] = useState<string | null>(null)

  // Fetch owner() from contract
  useEffect(() => {
    if (!contractAddress || !publicClient) return
    publicClient
      .readContract({ address: contractAddress, abi: OWNER_ABI, functionName: 'owner' })
      .then((o) => setContractOwner((o as string).toLowerCase()))
      .catch(() => { /* ignore */ })
  }, [contractAddress, publicClient])

  const isOwner = Boolean(address && contractOwner && address.toLowerCase() === contractOwner)

  // Sponsor input overrides: pollId → typed value
  const [sponsorEdits, setSponsorEdits] = useState<Record<string, string>>({})
  const sponsorInputs = useMemo(() => {
    const base: Record<string, string> = {}
    for (const p of POLLS) {
      base[p.id] = sponsoredPolls[p.id] ?? p.sponsorName ?? ''
    }
    return { ...base, ...sponsorEdits }
  }, [sponsoredPolls, sponsorEdits])

  // ── Verification tab state ─────────────────────────────────────────────────
  const { writeContract, isPending: isWriting } = useWriteContract()
  const [globalFee, setGlobalFee]   = useState<bigint | null>(null)
  const [isPaused, setIsPaused]     = useState(false)
  const [feeInput, setFeeInput]     = useState('')
  const [wlInput, setWlInput]       = useState('')
  const [cfInput, setCfInput]       = useState('')
  const [cfFeeInput, setCfFeeInput] = useState('')
  const [whitelist, setWhitelist]   = useState<string[]>([])
  const [customFees, setCustomFees] = useState<{ wallet: string; fee: bigint }[]>([])

  useEffect(() => {
    if (!contractAddress || !publicClient || activeTab !== 'verification') return
    Promise.all([
      publicClient.readContract({ address: contractAddress, abi: VERIFICATION_ABI, functionName: 'verificationFee' }),
      publicClient.readContract({ address: contractAddress, abi: VERIFICATION_ABI, functionName: 'verificationPaused' }),
    ]).then(([fee, paused]) => {
      setGlobalFee(fee)
      setFeeInput((Number(fee) / 1e18).toFixed(2))
      setIsPaused(paused)
    }).catch(() => {})

    publicClient.getLogs({
      address: contractAddress,
      event: { type: 'event', name: 'WhitelistAdded', inputs: [{ type: 'address', name: 'wallet', indexed: true }] },
      fromBlock: 0n, toBlock: 'latest',
    }).then((addedLogs) => {
      void publicClient.getLogs({
        address: contractAddress,
        event: { type: 'event', name: 'WhitelistRemoved', inputs: [{ type: 'address', name: 'wallet', indexed: true }] },
        fromBlock: 0n, toBlock: 'latest',
      }).then((removedLogs) => {
        const removed = new Set(removedLogs.map((l) => (l.args as { wallet?: string }).wallet?.toLowerCase()))
        const active = (addedLogs as { args: { wallet?: string } }[])
          .map((l) => l.args.wallet ?? '')
          .filter((w) => w && !removed.has(w.toLowerCase()))
        setWhitelist([...new Set(active)])
      })
    }).catch(() => {})
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [contractAddress, publicClient, activeTab])

  // ── Polls tab state ────────────────────────────────────────────────────────
  const [pollForm, setPollForm] = useState<PollFormState>(EMPTY_POLL_FORM)
  const [pollFormSubmitting, setPollFormSubmitting] = useState(false)
  const [onchainPolls, setOnchainPolls] = useState<OnchainPollPreview[]>([])
  const [pollsLoading, setPollsLoading] = useState(false)

  const loadOnchainPolls = useCallback(async () => {
    if (!supabase) return
    setPollsLoading(true)
    let data: unknown[] | null = null
    try {
      const res = await supabase
        .from('onchain_polls')
        .select('poll_id, question, options, ends_at, sponsored, sponsor_name')
        .order('created_at', { ascending: false })
      data = res.data
    } catch { /* fall through */ }

    if (!data) { setPollsLoading(false); return }

    const rows = data as { poll_id: string; question: string; options: { id: string; label: string }[]; ends_at: string; sponsored: boolean; sponsor_name: string }[]

    // Fetch live vote counts
    let previews: OnchainPollPreview[] = rows.map((r) => ({
      ...r,
      vote_counts: r.options.map(() => 0),
      total_votes: 0,
    }))

    if (contractAddress && publicClient) {
      try {
        const results = await Promise.all(
          previews.map((p) =>
            publicClient.readContract({
              address: contractAddress,
              abi: POLL_ABI,
              functionName: 'getPollResult',
              args: [p.poll_id as `0x${string}`],
            }).then((res) => ({ id: p.poll_id, res })).catch(() => ({ id: p.poll_id, res: null }))
          )
        )
        previews = previews.map((p) => {
          const found = results.find((r) => r.id === p.poll_id)
          if (!found?.res) return p
          const [, optionVotes] = found.res as [number, bigint[], bigint]
          const counts = (optionVotes).map((v) => Number(v))
          return { ...p, vote_counts: counts, total_votes: counts.reduce((a, b) => a + b, 0) }
        })
      } catch { /* keep zeroes */ }
    }

    setOnchainPolls(previews)
    setPollsLoading(false)
  }, [contractAddress, publicClient])

  useEffect(() => {
    if (activeTab === 'polls') void loadOnchainPolls()
  }, [activeTab, loadOnchainPolls])

  const isPollFormValid =
    pollForm.question.trim().length >= 5 &&
    pollForm.options.filter((o) => o.trim().length > 0).length >= 2 &&
    pollForm.endDate !== ''

  const handleCreatePoll = async () => {
    if (!isPollFormValid || !contractAddress || pollFormSubmitting) return
    setPollFormSubmitting(true)

    const question = pollForm.question.trim()
    const options = pollForm.options.filter((o) => o.trim().length > 0).map((o) => o.trim())
    const endsAt = BigInt(Math.floor(new Date(pollForm.endDate).getTime() / 1000))
    const pollId = keccak256(toHex(question))

    try {
      writeContract({
        address: contractAddress,
        abi: POLL_ABI,
        functionName: 'createPoll',
        args: [pollId, question, options, Number(endsAt)],
      })

      // Insert into Supabase
      const adminClient = address ? getAdminClient(address) : supabase
      if (adminClient) {
        await adminClient.from('onchain_polls').upsert({
          poll_id: pollId,
          question,
          options: options.map((label, i) => ({ id: `${pollId}-${i}`, label })),
          ends_at: new Date(pollForm.endDate).toISOString(),
          sponsored: pollForm.sponsored,
          sponsor_name: pollForm.sponsored ? pollForm.sponsorName.trim() : '',
        }, { onConflict: 'poll_id' })
      }

      toast.success('Poll created onchain and saved.')
      setPollForm(EMPTY_POLL_FORM)
      void loadOnchainPolls()
    } catch {
      toast.error('Failed to create poll.')
    } finally {
      setPollFormSubmitting(false)
    }
  }

  const addPollOption = () => {
    if (pollForm.options.length >= 6) return
    setPollForm((f) => ({ ...f, options: [...f.options, ''] }))
  }

  const removePollOption = (i: number) => {
    if (pollForm.options.length <= 2) return
    setPollForm((f) => ({ ...f, options: f.options.filter((_, idx) => idx !== i) }))
  }

  const setPollOption = (i: number, val: string) => {
    setPollForm((f) => {
      const opts = [...f.options]
      opts[i] = val
      return { ...f, options: opts }
    })
  }

  // ── Submissions tab state ──────────────────────────────────────────────────
  const [pendingSubmissions, setPendingSubmissions] = useState<PendingSubmission[]>([])
  const [submissionsLoading, setSubmissionsLoading] = useState(false)

  const loadPendingSubmissions = useCallback(async () => {
    if (!supabase) return
    setSubmissionsLoading(true)
    let data: unknown[] | null = null
    try {
      const res = await supabase
        .from('submitted_projects')
        .select('id, name, tagline, description, submitter_address, tags, logo_initials, logo_color, logo_url, launch_date, website')
        .eq('approved', false)
        .order('created_at', { ascending: false })
      data = res.data
    } catch { /* fall through */ }

    setPendingSubmissions((data as PendingSubmission[] | null) ?? [])
    setSubmissionsLoading(false)
  }, [])

  useEffect(() => {
    if (activeTab === 'submissions') void loadPendingSubmissions()
  }, [activeTab, loadPendingSubmissions])

  const handleApprove = async (id: string, name: string) => {
    if (!address) return
    const client = getAdminClient(address)
    if (!client) return
    await client.from('submitted_projects').update({ approved: true }).eq('id', id)
    toast.success(`${name} approved and now live in Discover.`)
    setPendingSubmissions((prev) => prev.filter((s) => s.id !== id))
  }

  const handleReject = async (id: string, name: string) => {
    if (!address) return
    const client = getAdminClient(address)
    if (!client) return
    await client.from('submitted_projects').delete().eq('id', id)
    toast(`${name} rejected and removed.`)
    setPendingSubmissions((prev) => prev.filter((s) => s.id !== id))
  }

  // ── Verification handlers ──────────────────────────────────────────────────
  const handleSetFee = () => {
    if (!contractAddress) return
    const parsed = parseFloat(feeInput)
    if (isNaN(parsed) || parsed < 0) { toast.error('Invalid fee amount.'); return }
    const feeBigint = BigInt(Math.round(parsed * 1e18))
    writeContract({ address: contractAddress, abi: VERIFICATION_ABI, functionName: 'setVerificationFee', args: [feeBigint] })
    toast(`Verification fee set to ${parsed.toFixed(2)} USDC.`)
    setGlobalFee(feeBigint)
  }

  const handleTogglePause = () => {
    if (!contractAddress) return
    writeContract({ address: contractAddress, abi: VERIFICATION_ABI, functionName: 'setVerificationPaused', args: [!isPaused] })
    toast(!isPaused ? 'Verifications paused.' : 'Verifications resumed.')
    setIsPaused((p) => !p)
  }

  const handleAddToWhitelist = () => {
    if (!contractAddress || !wlInput.trim()) return
    const w = wlInput.trim() as `0x${string}`
    writeContract({ address: contractAddress, abi: VERIFICATION_ABI, functionName: 'addToWhitelist', args: [w] })
    toast(`${w.slice(0, 8)}… added to whitelist.`)
    setWhitelist((prev) => [...new Set([...prev, w])])
    setWlInput('')
  }

  const handleRemoveFromWhitelist = (wallet: string) => {
    if (!contractAddress) return
    writeContract({ address: contractAddress, abi: VERIFICATION_ABI, functionName: 'removeFromWhitelist', args: [wallet as `0x${string}`] })
    toast(`${wallet.slice(0, 8)}… removed from whitelist.`)
    setWhitelist((prev) => prev.filter((w) => w.toLowerCase() !== wallet.toLowerCase()))
  }

  const handleSetCustomFee = () => {
    if (!contractAddress || !cfInput.trim()) return
    const parsed = parseFloat(cfFeeInput)
    if (isNaN(parsed) || parsed < 0) { toast.error('Invalid fee amount.'); return }
    const feeBigint = BigInt(Math.round(parsed * 1e18))
    const w = cfInput.trim() as `0x${string}`
    writeContract({ address: contractAddress, abi: VERIFICATION_ABI, functionName: 'setCustomFee', args: [w, feeBigint] })
    toast(`Custom fee ${parsed.toFixed(2)} USDC set for ${w.slice(0, 8)}….`)
    setCustomFees((prev) => {
      const next = prev.filter((e) => e.wallet.toLowerCase() !== w.toLowerCase())
      return [...next, { wallet: w, fee: feeBigint }]
    })
    setCfInput('')
    setCfFeeInput('')
  }

  const handleRemoveCustomFee = (wallet: string) => {
    if (!contractAddress) return
    writeContract({ address: contractAddress, abi: VERIFICATION_ABI, functionName: 'removeCustomFee', args: [wallet as `0x${string}`] })
    toast(`Custom fee removed for ${wallet.slice(0, 8)}….`)
    setCustomFees((prev) => prev.filter((e) => e.wallet.toLowerCase() !== wallet.toLowerCase()))
  }

  // ── Tabs ───────────────────────────────────────────────────────────────────
  // ── Reviews tab state ─────────────────────────────────────────────────────
  const [reviewsProject, setReviewsProject] = useState<string>(PROJECTS[0]?.id ?? '')
  const selectedProject = PROJECTS.find((p) => p.id === reviewsProject) ?? PROJECTS[0]

  const {
    pinnedIds: adminPinnedIds,
    pinReview: adminPinReview,
    unpinReview: adminUnpinReview,
  } = usePinnedReviews({
    projectId: reviewsProject || null,
    ownerAddress: address,
  })

  const {
    responses: adminResponses,
    postResponse: adminPostResponse,
  } = useReviewResponses({
    projectId: reviewsProject || null,
    responderAddress: address,
  })

  const [adminOpenReplyId, setAdminOpenReplyId] = useState<string | null>(null)
  const [adminReplyBody, setAdminReplyBody]     = useState('')
  const [adminPostingReply, setAdminPostingReply] = useState(false)

  const handleAdminPostReply = async (reviewId: string) => {
    if (!adminReplyBody.trim() || adminPostingReply) return
    setAdminPostingReply(true)
    await adminPostResponse(reviewId, adminReplyBody.trim())
    setAdminReplyBody('')
    setAdminOpenReplyId(null)
    setAdminPostingReply(false)
    toast.success('Response posted.')
  }

  // ── Projects tab state ─────────────────────────────────────────────────────
  const [editingProjectId, setEditingProjectId] = useState<string | null>(null)
  const [editForm, setEditForm] = useState<Partial<ProjectOverride>>({})
  const [selectedProjectIds, setSelectedProjectIds] = useState<Set<string>>(new Set())
  const [bulkStatus, setBulkStatus] = useState<ProjectStatus | ''>('')
  const [reinstateConfirm, setReinstateConfirm] = useState<{ id: string; name: string } | null>(null)
  const [bulkReinstateIds, setBulkReinstateIds] = useState<string[]>([])
  const [isBulkReinstating, setIsBulkReinstating] = useState(false)

  const startEdit = (project: Project) => {
    setEditingProjectId(project.id)
    setEditForm({
      name: project.name,
      tagline: project.tagline ?? '',
      description: project.description ?? '',
      website: project.website ?? '',
      status: (project.status ?? 'active'),
      status_note: project.statusNote ?? '',
      verified_badge_hidden: project.verifiedBadgeHidden ?? false,
    })
  }

  const handleSaveEdit = async (projectId: string) => {
    if (!saveProjectOverride) return
    await saveProjectOverride(projectId, editForm, address)
    // Log the edit
    if (supabase && address) {
      const client = address ? getAdminClient(address) : supabase
      if (client) {
        await client.from('project_edit_log').insert({
          project_id: projectId,
          editor_address: address,
          action: 'edited',
          previous_value: null,
          new_value: editForm,
        })
      }
    }
    setEditingProjectId(null)
    refetchOverrides?.()
    toast.success('Project updated.')
  }

  const handleStatusChange = async (project: Project, newStatus: ProjectStatus) => {
    if (!saveProjectOverride) return
    const override: Partial<ProjectOverride> = { status: newStatus }
    await saveProjectOverride(project.id, override, address)
    if (address) {
      const client = getAdminClient(address)
      if (client) {
        await client.from('project_edit_log').insert({
          project_id: project.id,
          editor_address: address,
          action: `status_changed_to_${newStatus}`,
          previous_value: { status: project.status ?? 'active' },
          new_value: { status: newStatus },
        })
      }
    }
    refetchOverrides?.()
    toast(`Status set to ${newStatus}.`)
  }

  const handleReinstate = async (id: string, name: string) => {
    if (!saveProjectOverride) return
    await saveProjectOverride(id, { status: 'active', status_note: '' }, address)
    if (address) {
      const client = getAdminClient(address)
      if (client) {
        await client.from('project_edit_log').insert({
          project_id: id,
          editor_address: address,
          action: 'reinstated',
          previous_value: null,
          new_value: { status: 'active' },
        })
      }
    }
    refetchOverrides?.()
    toast.success(`${name} reinstated successfully.`)
    setReinstateConfirm(null)
  }

  const handleBulkStatusChange = async () => {
    if (!bulkStatus || !saveProjectOverride || selectedProjectIds.size === 0) return
    await Promise.all(
      [...selectedProjectIds].map((id) => saveProjectOverride(id, { status: bulkStatus }, address))
    )
    refetchOverrides?.()
    setSelectedProjectIds(new Set())
    setBulkStatus('')
    toast(`${selectedProjectIds.size} projects updated to ${bulkStatus}.`)
  }

  const handleBulkReinstate = async () => {
    if (!saveProjectOverride || bulkReinstateIds.length === 0) return
    setIsBulkReinstating(true)
    await Promise.all(
      bulkReinstateIds.map((id) => saveProjectOverride(id, { status: 'active', status_note: '' }, address))
    )
    setIsBulkReinstating(false)
    setBulkReinstateIds([])
    setSelectedProjectIds(new Set())
    refetchOverrides?.()
    toast.success(`${bulkReinstateIds.length} projects reinstated.`)
  }

  const handleRemoveLogo = useCallback(async (project: Project) => {
    if (!saveProjectOverride || !address) return
    // Remove from Supabase Storage (best-effort — filename unknown, so just clear the override)
    if (supabase && project.logoUrl) {
      // Attempt to delete from storage — the path follows {slug}/{filename}
      const urlParts = project.logoUrl.split(`project-logos/`)
      if (urlParts.length > 1) {
        const filePath = urlParts[1].split('?')[0]
        await supabase.storage.from('project-logos').remove([filePath])
      }
    }
    await saveProjectOverride(project.id, { logo_url: null }, address, { logo_url: project.logoUrl }, 'logo_removed')
    refetchOverrides?.()
    toast.success(`Logo removed from ${project.name}.`)
  }, [saveProjectOverride, address, refetchOverrides])

  // ── Log tab state ──────────────────────────────────────────────────────────
  type LogRow = { id: string; project_id: string; editor_address: string; action: string; previous_value: Record<string, unknown> | null; new_value: Record<string, unknown> | null; created_at: string }
  const [logRows, setLogRows] = useState<LogRow[]>([])
  const [logLoading, setLogLoading] = useState(false)
  const [logProjectFilter, setLogProjectFilter] = useState('')
  const [logActionFilter, setLogActionFilter] = useState('')

  const loadLog = useCallback(async () => {
    if (!supabase) return
    setLogLoading(true)
    try {
      const { data } = await supabase.from('project_edit_log').select('*').order('created_at', { ascending: false }).limit(200)
      setLogRows((data as LogRow[] | null) ?? [])
    } catch { /* ignore */ }
    setLogLoading(false)
  }, [])

  useEffect(() => {
    if (activeTab === 'log') void loadLog()
  }, [activeTab, loadLog])

  const filteredLog = useMemo(() => logRows.filter((r) => {
    const nameMatch = !logProjectFilter || r.project_id.toLowerCase().includes(logProjectFilter.toLowerCase())
    const actionMatch = !logActionFilter || r.action.toLowerCase().includes(logActionFilter.toLowerCase())
    return nameMatch && actionMatch
  }), [logRows, logProjectFilter, logActionFilter])

  const exportLogCsv = () => {
    const header = 'timestamp,project_id,editor_address,action,previous_value,new_value'
    const rows = filteredLog.map((r) => [
      r.created_at, r.project_id, r.editor_address, r.action,
      JSON.stringify(r.previous_value ?? ''), JSON.stringify(r.new_value ?? ''),
    ].map((v) => `"${String(v).replace(/"/g, '""')}"`).join(','))
    const csv = [header, ...rows].join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a'); a.href = url; a.download = 'myarc-edit-log.csv'; a.click()
    URL.revokeObjectURL(url)
  }

  // ── Announcements tab state ────────────────────────────────────────────────
  const {
    allAnnouncements,
    refetch: refetchAnnouncements,
  } = useAnnouncements()

  const [annMessage, setAnnMessage]   = useState('')
  const [annType, setAnnType]         = useState<Announcement['type']>('info')
  const [annExpiry, setAnnExpiry]     = useState('')
  const [annPublishing, setAnnPublishing] = useState(false)

  const handlePublishAnnouncement = async () => {
    if (!annMessage.trim() || !address) return
    const client = getAdminClient(address)
    if (!client) return
    setAnnPublishing(true)
    try {
      const { error } = await client.from('announcements').insert({
        message: annMessage.trim(),
        type: annType,
        active: true,
        expires_at: annExpiry ? new Date(annExpiry).toISOString() : null,
      })
      if (error) throw error
      toast.success('Announcement published.')
      setAnnMessage('')
      setAnnExpiry('')
      refetchAnnouncements()
    } catch {
      toast.error('Failed to publish announcement.')
    } finally {
      setAnnPublishing(false)
    }
  }

  const handleToggleAnnouncement = async (ann: Announcement) => {
    if (!address) return
    const client = getAdminClient(address)
    if (!client) return
    await client.from('announcements').update({ active: !ann.active }).eq('id', ann.id)
    toast(ann.active ? 'Announcement deactivated.' : 'Announcement reactivated.')
    refetchAnnouncements()
  }

  const handleDeleteAnnouncement = async (id: string) => {
    if (!address) return
    const client = getAdminClient(address)
    if (!client) return
    await client.from('announcements').delete().eq('id', id)
    toast('Announcement deleted.')
    refetchAnnouncements()
  }

  // ── Platform analytics ────────────────────────────────────────────────────
  const platformAnalytics = usePlatformAnalytics(contractAddress, allProjects)
  // Use the prop when available (avoids a duplicate fetch from App.tsx's hoisted call).
  const platformMomentumInternal = usePlatformMomentum(
    platformMomentumProp ? undefined : contractAddress,
    allProjects,
  )
  const platformMomentum = platformMomentumProp ?? platformMomentumInternal

  // ── Moderation (Reviews tab) ───────────────────────────────────────────────
  const {
    moderatedRows,
    moderateReview,
    refetch: refetchModeration,
  } = useModeratedReviews({
    projectId: reviewsProject || null,
    connectedAddress: address,
  })

  // ── Widget tab state ──────────────────────────────────────────────────────
  const {
    verifiedOwners: widgetVerifiedOwners,
    isLoading: widgetOwnersLoading,
  } = useVerifiedOwners(contractAddress)
  const [copiedEmbedId, setCopiedEmbedId] = useState<string | null>(null)

  // ── Blacklist tab state ────────────────────────────────────────────────────
  const [blInput, setBlInput]   = useState('')
  const [blReason, setBlReason] = useState('')
  const [blConfirm, setBlConfirm] = useState<string | null>(null)  // address pending confirm

  // ── Taxonomy tab state ─────────────────────────────────────────────────────
  const taxonomy = useTaxonomy()
  type TaxSubTab = 'categories' | 'usecases' | 'tags'
  const [taxSubTab, setTaxSubTab] = useState<TaxSubTab>('categories')

  // Category editing
  const [editingCatId, setEditingCatId] = useState<string | null>(null)
  const [catLabelDraft, setCatLabelDraft] = useState('')
  const [newCatLabel, setNewCatLabel] = useState('')

  // Use-case editing
  const [editingUcId, setEditingUcId] = useState<string | null>(null)
  const [ucLabelDraft, setUcLabelDraft] = useState('')
  const [ucGroupDraft, setUcGroupDraft] = useState('')
  const [newUcLabel, setNewUcLabel] = useState('')
  const [newUcGroup, setNewUcGroup] = useState('')

  // Tag editing
  const [editingTagId, setEditingTagId] = useState<string | null>(null)
  const [tagLabelDraft, setTagLabelDraft] = useState('')
  const [tagAliasesDraft, setTagAliasesDraft] = useState('')
  const [newTagLabel, setNewTagLabel] = useState('')
  const [newTagAliases, setNewTagAliases] = useState('')

  // Merge: tag being merged INTO editingTagId
  const [mergeTargetId, setMergeTargetId] = useState('')

  const slugify = (s: string) => s.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')

  const handleSaveCat = (cat: Category) => {
    const updated = taxonomy.categories.map((c) =>
      c.id === cat.id ? { ...c, label: catLabelDraft || c.label } : c
    )
    taxonomy.saveCategories(updated)
    setEditingCatId(null)
    toast.success('Category saved.')
  }

  const handleToggleCat = (cat: Category) => {
    const updated = taxonomy.categories.map((c) =>
      c.id === cat.id ? { ...c, active: !c.active } : c
    )
    taxonomy.saveCategories(updated)
    toast(cat.active ? `"${cat.label}" deactivated.` : `"${cat.label}" activated.`)
  }

  const handleAddCat = () => {
    const label = newCatLabel.trim()
    if (!label) return
    const id = slugify(label)
    if (taxonomy.categories.some((c) => c.id === id)) {
      toast.error('A category with that id already exists.'); return
    }
    const newCat: Category = { id, label, active: true, order: taxonomy.categories.length + 1 }
    taxonomy.saveCategories([...taxonomy.categories, newCat])
    setNewCatLabel('')
    toast.success(`Category "${label}" created.`)
  }

  const handleSaveUc = (uc: UseCase) => {
    const updated = taxonomy.useCases.map((u) =>
      u.id === uc.id ? { ...u, label: ucLabelDraft || u.label, group: ucGroupDraft || u.group } : u
    )
    taxonomy.saveUseCases(updated)
    setEditingUcId(null)
    toast.success('Use case saved.')
  }

  const handleToggleUc = (uc: UseCase) => {
    const updated = taxonomy.useCases.map((u) =>
      u.id === uc.id ? { ...u, active: !u.active } : u
    )
    taxonomy.saveUseCases(updated)
    toast(uc.active ? `"${uc.label}" deactivated.` : `"${uc.label}" activated.`)
  }

  const handleAddUc = () => {
    const label = newUcLabel.trim()
    const group = newUcGroup.trim() || 'Other'
    if (!label) return
    const id = slugify(label)
    if (taxonomy.useCases.some((u) => u.id === id)) {
      toast.error('A use case with that id already exists.'); return
    }
    const newUc: UseCase = { id, label, group, active: true, order: taxonomy.useCases.length + 1 }
    taxonomy.saveUseCases([...taxonomy.useCases, newUc])
    setNewUcLabel('')
    setNewUcGroup('')
    toast.success(`Use case "${label}" created.`)
  }

  const handleSaveTag = (tag: CanonicalTag) => {
    const aliases = tagAliasesDraft.split(',').map((a) => a.trim()).filter(Boolean)
    const updated = taxonomy.tags.map((t) =>
      t.id === tag.id ? { ...t, label: tagLabelDraft || t.label, aliases } : t
    )
    taxonomy.saveTags(updated)
    setEditingTagId(null)
    toast.success('Tag saved.')
  }

  const handleToggleTag = (tag: CanonicalTag) => {
    const updated = taxonomy.tags.map((t) =>
      t.id === tag.id ? { ...t, active: !t.active } : t
    )
    taxonomy.saveTags(updated)
    toast(tag.active ? `"${tag.label}" deactivated.` : `"${tag.label}" activated.`)
  }

  const handleAddTag = () => {
    const label = newTagLabel.trim()
    if (!label) return
    const id = slugify(label)
    if (taxonomy.tags.some((t) => t.id === id)) {
      toast.error('A tag with that id already exists.'); return
    }
    const aliases = newTagAliases.split(',').map((a) => a.trim()).filter(Boolean)
    const newTag: CanonicalTag = { id, label, aliases, active: true, order: taxonomy.tags.length + 1 }
    taxonomy.saveTags([...taxonomy.tags, newTag])
    setNewTagLabel('')
    setNewTagAliases('')
    toast.success(`Tag "${label}" created.`)
  }

  const handleMergeTag = (keepId: string) => {
    const dropId = mergeTargetId.trim()
    if (!dropId || dropId === keepId) { toast.error('Select a different tag to merge.'); return }
    const keepTag = taxonomy.tags.find((t) => t.id === keepId)
    const dropTag = taxonomy.tags.find((t) => t.id === dropId)
    if (!keepTag || !dropTag) { toast.error('Tag not found.'); return }
    // Merge aliases, deactivate the dropped tag
    const mergedAliases = [...new Set([...keepTag.aliases, dropTag.id, dropTag.label, ...dropTag.aliases])]
    const updated = taxonomy.tags.map((t) => {
      if (t.id === keepId) return { ...t, aliases: mergedAliases }
      if (t.id === dropId) return { ...t, active: false }
      return t
    })
    taxonomy.saveTags(updated)
    setMergeTargetId('')
    setEditingTagId(null)
    toast.success(`"${dropTag.label}" merged into "${keepTag.label}".`)
  }

  const STATUS_OPTIONS: { value: ProjectStatus; label: string; color: string }[] = [
    { value: 'active',        label: 'Active',        color: 'var(--bullish)' },
    { value: 'inactive',      label: 'Inactive',      color: 'var(--ink-2)' },
    { value: 'under_review',  label: 'Under Review',  color: '#d97706' },
    { value: 'discontinued',  label: 'Discontinued',  color: 'var(--muted)' },
    { value: 'delisted',      label: 'Delisted',      color: 'var(--bearish)' },
  ]

  const getStatusColor = (status: string) => STATUS_OPTIONS.find((o) => o.value === status)?.color ?? 'var(--muted)'
  const INACTIVE_STATUSES = new Set(['inactive', 'discontinued', 'delisted'])

  const TABS: { id: AdminTab; label: string; icon: typeof Star }[] = [
    { id: 'featured',      label: 'Featured',      icon: Star },
    { id: 'sponsored',     label: 'Sponsored',     icon: Megaphone },
    { id: 'polls',         label: 'Polls',         icon: Vote },
    { id: 'submissions',   label: 'Submissions',   icon: Inbox },
    { id: 'projects',      label: 'Projects',      icon: Folders },
    { id: 'verification',  label: 'Verification',  icon: ShieldCheck },
    { id: 'revenue',       label: 'Revenue',       icon: DollarSign },
    { id: 'reviews',       label: 'Reviews',       icon: MessageSquare },
    { id: 'announcements', label: 'Announce',      icon: Bell },
    { id: 'blacklist',     label: 'Blacklist',     icon: Ban },
    { id: 'analytics',    label: 'Analytics',     icon: BarChart2 },
    { id: 'profiles',     label: 'Profiles',      icon: Users },
    { id: 'widget',       label: 'Widget',        icon: Code },
    { id: 'taxonomy',     label: 'Taxonomy',      icon: Tag },
    { id: 'log',          label: 'Log',           icon: History },
  ]

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            key="admin-backdrop"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-40"
            style={{ background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(4px)' }}
            onClick={onClose}
          />
          <motion.div
            key="admin-sheet"
            initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }}
            transition={{ type: 'spring', stiffness: 340, damping: 38 }}
            className="fixed inset-x-0 bottom-0 z-50 flex flex-col rounded-t-3xl"
            style={{ background: 'var(--sheet-bg)', maxHeight: '92dvh', border: '1px solid var(--border)', borderBottom: 'none' }}
          >
            {/* Drag handle */}
            <div className="flex justify-center pt-3 pb-1">
              <div className="w-10 h-1 rounded-full" style={{ background: 'var(--border-strong)' }} />
            </div>

            {/* Header */}
            <div className="flex items-center justify-between px-5 py-3"
              style={{ borderBottom: '1px solid var(--border)' }}>
              <div className="space-y-0.5">
                <h2 className="display font-semibold text-base" style={{ color: 'var(--ink)' }}>Admin Panel</h2>
                {contractOwner && (
                  <p className="text-xs font-mono" style={{ color: 'var(--subtle)' }}>
                    Owner: {contractOwner.slice(0, 10)}...{contractOwner.slice(-4)}
                  </p>
                )}
              </div>
              <button onClick={onClose}
                className="w-9 h-9 flex items-center justify-center rounded-full min-h-[44px] min-w-[44px] hover:opacity-70 transition-opacity"
                style={{ background: 'var(--surface-muted)' }}>
                <X size={18} style={{ color: 'var(--ink-2)' }} />
              </button>
            </div>

            {/* Not-owner gate */}
            {!isOwner && (
              <div className="flex-1 flex items-center justify-center px-6 py-12">
                <div className="text-center space-y-3 max-w-xs">
                  <div className="w-14 h-14 rounded-2xl mx-auto flex items-center justify-center"
                    style={{ background: 'rgba(186,43,76,0.08)' }}>
                    <X size={24} style={{ color: 'var(--bearish)' }} />
                  </div>
                  <p className="font-semibold" style={{ color: 'var(--ink)' }}>
                    {address ? 'Not the contract owner' : 'Connect your wallet'}
                  </p>
                  <p className="text-sm" style={{ color: 'var(--subtle)' }}>
                    This panel is only accessible to the MYARC contract owner.
                  </p>
                </div>
              </div>
            )}

            {isOwner && (
              <>
                {/* Tab bar — horizontal scroll */}
                <div className="flex overflow-x-auto px-4 pt-3 pb-0 gap-1"
                  style={{ scrollbarWidth: 'none' }}>
                  {TABS.map(({ id, label, icon: Icon }) => (
                    <button key={id}
                      onClick={() => setActiveTab(id)}
                      className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium transition-all flex-shrink-0"
                      style={activeTab === id
                        ? { background: 'var(--surface-strong)', color: 'var(--ink)' }
                        : { color: 'var(--muted)' }}>
                      <Icon size={13} />
                      {label}
                    </button>
                  ))}
                </div>

                {/* Scrollable content */}
                <div className="flex-1 overflow-y-auto px-5 pt-4 pb-safe-or-6">

                  {/* ── Featured tab ─────────────────────────────────────── */}
                  {activeTab === 'featured' && (
                    <div className="space-y-2 pb-6">
                      <p className="text-xs" style={{ color: 'var(--muted)' }}>
                        Featured projects appear first in Discover and in the Featured banner strip.
                      </p>
                      {isLoading && [0, 1, 2].map((i) => (
                        <div key={i} className="h-14 rounded-2xl animate-pulse" style={{ background: 'var(--surface-muted)' }} />
                      ))}
                      {!isLoading && PROJECTS.map((project) => {
                        const isFeatured = featuredIds.has(project.id)
                        return (
                          <motion.div key={project.id}
                            initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
                            className="flex items-center gap-3 px-4 py-3 rounded-2xl"
                            style={{
                              background: isFeatured ? 'rgba(26,92,255,0.06)' : 'var(--surface-muted)',
                              border: `1px solid ${isFeatured ? 'var(--accent)' : 'var(--border)'}`,
                            }}>
                            <ProjectLogo project={project} size="sm" />
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-semibold truncate" style={{ color: 'var(--ink)' }}>{project.name}</p>
                              <p className="text-xs truncate" style={{ color: 'var(--subtle)' }}>{project.tagline}</p>
                            </div>
                            <button
                              onClick={() => {
                                void setFeatured(project.id, !isFeatured, address).then(() => {
                                  toast(isFeatured ? `${project.name} removed from Featured.` : `${project.name} is now Featured.`, { duration: 2000 })
                                })
                              }}
                              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold min-h-[36px] transition-all hover:opacity-85 flex-shrink-0"
                              style={isFeatured
                                ? { background: 'var(--accent)', color: 'var(--bg)' }
                                : { background: 'var(--surface)', color: 'var(--muted)', border: '1px solid var(--border)' }}>
                              {isFeatured ? <><CheckCircle2 size={12} /> Featured</> : <><Star size={12} /> Feature</>}
                            </button>
                          </motion.div>
                        )
                      })}
                    </div>
                  )}

                  {/* ── Sponsored tab ────────────────────────────────────── */}
                  {activeTab === 'sponsored' && (
                    <div className="space-y-3 pb-6">
                      <p className="text-xs" style={{ color: 'var(--muted)' }}>
                        Sponsored polls show a label below the question.
                      </p>
                      {POLLS.map((poll) => {
                        const isSponsored = poll.id in sponsoredPolls
                        return (
                          <motion.div key={poll.id}
                            initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
                            className="rounded-2xl px-4 py-3 space-y-2"
                            style={{
                              background: isSponsored ? 'rgba(26,92,255,0.06)' : 'var(--surface-muted)',
                              border: `1px solid ${isSponsored ? 'var(--accent)' : 'var(--border)'}`,
                            }}>
                            <p className="text-sm font-medium leading-snug" style={{ color: 'var(--ink)' }}>
                              {poll.question}
                            </p>
                            <div className="flex items-center gap-2">
                              <input
                                type="text" placeholder="Sponsor name"
                                value={sponsorInputs[poll.id] ?? ''}
                                onChange={(e) => setSponsorEdits((prev) => ({ ...prev, [poll.id]: e.target.value }))}
                                className="flex-1 px-3 py-2 rounded-xl text-sm border bg-transparent outline-none min-h-[40px]"
                                style={{ borderColor: 'var(--border)', color: 'var(--ink)', fontFamily: "'DM Sans', sans-serif" }}
                              />
                              <button
                                onClick={() => {
                                  const name = sponsorInputs[poll.id] ?? ''
                                  void setSponsored(poll.id, !isSponsored, name, address).then(() => {
                                    toast(!isSponsored ? `Poll marked as sponsored by ${name}.` : 'Sponsorship removed.', { duration: 2000 })
                                  })
                                }}
                                className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold min-h-[40px] transition-all hover:opacity-85 flex-shrink-0"
                                style={isSponsored
                                  ? { background: 'var(--accent)', color: 'var(--bg)' }
                                  : { background: 'var(--surface)', color: 'var(--muted)', border: '1px solid var(--border)' }}>
                                {isSponsored ? 'Sponsored' : 'Sponsor'}
                              </button>
                            </div>
                          </motion.div>
                        )
                      })}
                    </div>
                  )}

                  {/* ── Polls tab ─────────────────────────────────────────── */}
                  {activeTab === 'polls' && (
                    <div className="space-y-6 pb-6">

                      {/* Create poll form */}
                      <div className="space-y-4">
                        <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                          Create Poll
                        </p>

                        {/* Question */}
                        <div className="space-y-1.5">
                          <p className="text-xs" style={{ color: 'var(--muted)' }}>Question</p>
                          <input
                            type="text" maxLength={200}
                            placeholder="Ask the community something..."
                            value={pollForm.question}
                            onChange={(e) => setPollForm((f) => ({ ...f, question: e.target.value }))}
                            className="w-full px-3 py-2.5 rounded-xl text-sm border bg-transparent outline-none min-h-[44px]"
                            style={{ borderColor: 'var(--border)', color: 'var(--ink)', fontFamily: "'DM Sans', sans-serif" }}
                          />
                          <p className="text-xs text-right tabular-nums" style={{ color: 'var(--subtle)' }}>
                            {pollForm.question.length}/200
                          </p>
                        </div>

                        {/* Options */}
                        <div className="space-y-2">
                          <p className="text-xs" style={{ color: 'var(--muted)' }}>Options (2–6)</p>
                          {pollForm.options.map((opt, i) => (
                            <div key={i} className="flex items-center gap-2">
                              <input
                                type="text" maxLength={80}
                                placeholder={`Option ${i + 1}`}
                                value={opt}
                                onChange={(e) => setPollOption(i, e.target.value)}
                                className="flex-1 px-3 py-2.5 rounded-xl text-sm border bg-transparent outline-none min-h-[44px]"
                                style={{ borderColor: 'var(--border)', color: 'var(--ink)', fontFamily: "'DM Sans', sans-serif" }}
                              />
                              {pollForm.options.length > 2 && (
                                <button onClick={() => removePollOption(i)}
                                  className="w-9 h-9 flex items-center justify-center rounded-xl min-h-[44px] min-w-[44px] hover:opacity-70 transition-opacity flex-shrink-0"
                                  style={{ background: 'var(--surface-muted)', color: 'var(--bearish)' }}>
                                  <MinusIcon size={14} />
                                </button>
                              )}
                            </div>
                          ))}
                          {pollForm.options.length < 6 && (
                            <button onClick={addPollOption}
                              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium min-h-[40px] transition-all hover:opacity-85"
                              style={{ background: 'var(--surface-muted)', color: 'var(--accent)', border: '1px solid var(--border)' }}>
                              <Plus size={12} /> Add option
                            </button>
                          )}
                        </div>

                        {/* End date */}
                        <div className="space-y-1.5">
                          <p className="text-xs" style={{ color: 'var(--muted)' }}>End date</p>
                          <input
                            type="datetime-local"
                            value={pollForm.endDate}
                            min={new Date(Date.now() + 60000).toISOString().slice(0, 16)}
                            onChange={(e) => setPollForm((f) => ({ ...f, endDate: e.target.value }))}
                            className="w-full px-3 py-2.5 rounded-xl text-sm border bg-transparent outline-none min-h-[44px]"
                            style={{ borderColor: 'var(--border)', color: 'var(--ink)', fontFamily: "'DM Sans', sans-serif" }}
                          />
                        </div>

                        {/* Sponsored toggle */}
                        <div className="flex items-center justify-between gap-3 px-4 py-3 rounded-2xl"
                          style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
                          <p className="text-sm font-medium" style={{ color: 'var(--ink)' }}>Sponsored poll</p>
                          <button
                            onClick={() => setPollForm((f) => ({ ...f, sponsored: !f.sponsored }))}
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold min-h-[36px] transition-all"
                            style={pollForm.sponsored
                              ? { background: 'var(--accent)', color: 'var(--bg)' }
                              : { background: 'var(--surface)', color: 'var(--muted)', border: '1px solid var(--border)' }}>
                            {pollForm.sponsored ? <><Check size={11} /> On</> : 'Off'}
                          </button>
                        </div>
                        {pollForm.sponsored && (
                          <input
                            type="text" placeholder="Sponsor name"
                            value={pollForm.sponsorName}
                            onChange={(e) => setPollForm((f) => ({ ...f, sponsorName: e.target.value }))}
                            className="w-full px-3 py-2.5 rounded-xl text-sm border bg-transparent outline-none min-h-[44px]"
                            style={{ borderColor: 'var(--border)', color: 'var(--ink)', fontFamily: "'DM Sans', sans-serif" }}
                          />
                        )}

                        <button
                          onClick={() => { void handleCreatePoll() }}
                          disabled={!isPollFormValid || pollFormSubmitting || isWriting}
                          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl font-semibold text-sm transition-all min-h-[48px]"
                          style={isPollFormValid && !pollFormSubmitting
                            ? { background: 'var(--accent)', color: 'var(--bg)' }
                            : { background: 'var(--surface-muted)', color: 'var(--subtle)', cursor: 'not-allowed' }}>
                          <Send size={14} />
                          {pollFormSubmitting ? 'Creating…' : 'Create Poll'}
                        </button>
                      </div>

                      {/* Existing polls */}
                      <div className="space-y-3">
                        <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                          Existing Polls
                        </p>
                        {pollsLoading && (
                          <div className="h-20 rounded-2xl animate-pulse" style={{ background: 'var(--surface-muted)' }} />
                        )}
                        {!pollsLoading && onchainPolls.length === 0 && (
                          <p className="text-xs px-1" style={{ color: 'var(--subtle)' }}>No on-chain polls yet.</p>
                        )}
                        {onchainPolls.map((p) => (
                          <div key={p.poll_id} className="rounded-2xl px-4 py-3 space-y-1.5"
                            style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
                            <p className="text-sm font-medium leading-snug" style={{ color: 'var(--ink)' }}>{p.question}</p>
                            <div className="flex items-center gap-3 text-xs" style={{ color: 'var(--subtle)' }}>
                              <span>Ends: {new Date(p.ends_at).toLocaleDateString()}</span>
                              <span>{p.total_votes} votes</span>
                              {p.sponsored && (
                                <span className="px-1.5 py-0.5 rounded-full text-[10px]"
                                  style={{ background: 'rgba(26,92,255,0.08)', color: 'var(--accent)' }}>
                                  Sponsored: {p.sponsor_name}
                                </span>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* ── Submissions tab ───────────────────────────────────── */}
                  {activeTab === 'submissions' && (
                    <div className="space-y-3 pb-6">
                      <p className="text-xs" style={{ color: 'var(--muted)' }}>
                        Pending submissions from community members. Approve to show in Discover, reject to delete.
                      </p>
                      {submissionsLoading && (
                        <div className="h-20 rounded-2xl animate-pulse" style={{ background: 'var(--surface-muted)' }} />
                      )}
                      {!submissionsLoading && pendingSubmissions.length === 0 && (
                        <div className="py-10 flex flex-col items-center gap-2 text-center">
                          <Inbox size={28} style={{ color: 'var(--muted)' }} />
                          <p className="text-sm font-medium" style={{ color: 'var(--ink)' }}>No pending submissions</p>
                          <p className="text-xs" style={{ color: 'var(--subtle)' }}>
                            New submissions will appear here for review.
                          </p>
                        </div>
                      )}
                      {pendingSubmissions.map((s) => (
                        <motion.div key={s.id}
                          initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
                          className="rounded-2xl p-4 space-y-3"
                          style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
                          <div className="flex items-start gap-3">
                            <ProjectLogo
                              project={{ id: s.id, name: s.name, logoInitials: s.logo_initials, logoColor: s.logo_color, logoUrl: s.logo_url ?? undefined } as Project}
                              size="sm"
                            />
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>{s.name}</p>
                              <p className="text-xs" style={{ color: 'var(--subtle)' }}>{s.tagline}</p>
                              <p className="text-xs mt-0.5 font-mono" style={{ color: 'var(--muted)' }}>
                                {s.submitter_address.slice(0, 10)}…{s.submitter_address.slice(-4)}
                              </p>
                            </div>
                          </div>
                          <p className="text-xs leading-relaxed" style={{ color: 'var(--ink-2)' }}>{s.description}</p>
                          <div className="flex gap-2">
                            <button
                              onClick={() => { void handleApprove(s.id, s.name) }}
                              className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-xs font-semibold min-h-[44px] transition-all hover:opacity-85"
                              style={{ background: 'var(--bullish)', color: 'var(--bg)' }}>
                              <CheckCircle2 size={13} /> Approve
                            </button>
                            <button
                              onClick={() => { void handleReject(s.id, s.name) }}
                              className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-xs font-semibold min-h-[44px] transition-all hover:opacity-85"
                              style={{ background: 'rgba(186,43,76,0.10)', color: 'var(--bearish)', border: '1px solid rgba(186,43,76,0.20)' }}>
                              <Trash2 size={13} /> Reject
                            </button>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  )}

                  {/* ── Verification tab ──────────────────────────────────── */}
                  {activeTab === 'verification' && (
                    <div className="space-y-6 pb-6">
                      {/* Global fee */}
                      <div className="space-y-2">
                        <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>Global Fee</p>
                        <p className="text-xs" style={{ color: 'var(--muted)' }}>
                          Default fee for wallets not whitelisted or custom-priced.
                          {globalFee !== null && (
                            <> Current: <strong style={{ color: 'var(--ink-2)' }}>{(Number(globalFee) / 1e18).toFixed(2)} USDC</strong></>
                          )}
                        </p>
                        <div className="flex gap-2">
                          <input type="number" min="0" step="0.01" placeholder="Fee in USDC"
                            value={feeInput} onChange={(e) => setFeeInput(e.target.value)}
                            className="flex-1 px-3 py-2 rounded-xl text-sm border bg-transparent outline-none min-h-[44px]"
                            style={{ borderColor: 'var(--border)', color: 'var(--ink)', fontFamily: "'DM Sans', sans-serif" }} />
                          <button onClick={handleSetFee} disabled={isWriting}
                            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold min-h-[44px] transition-all hover:opacity-85 flex-shrink-0"
                            style={{ background: 'var(--accent)', color: 'var(--bg)', opacity: isWriting ? 0.6 : 1 }}>
                            <Settings2 size={13} /> Set Fee
                          </button>
                        </div>
                      </div>

                      {/* Pause toggle */}
                      <div className="space-y-2">
                        <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>Verification Gate</p>
                        <div className="flex items-center justify-between gap-3 px-4 py-3 rounded-2xl"
                          style={{
                            background: isPaused ? 'rgba(186,43,76,0.07)' : 'var(--surface-muted)',
                            border: `1px solid ${isPaused ? 'var(--bearish)' : 'var(--border)'}`,
                          }}>
                          <div>
                            <p className="text-sm font-semibold" style={{ color: isPaused ? 'var(--bearish)' : 'var(--ink)' }}>
                              {isPaused ? 'Verifications paused' : 'Verifications active'}
                            </p>
                            {isPaused && <p className="text-xs mt-0.5" style={{ color: 'var(--bearish)' }}>No new project claims accepted while paused.</p>}
                          </div>
                          <button onClick={handleTogglePause} disabled={isWriting}
                            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold min-h-[44px] transition-all hover:opacity-85 flex-shrink-0"
                            style={{ background: isPaused ? 'var(--bullish)' : 'var(--bearish)', color: 'var(--bg)', opacity: isWriting ? 0.6 : 1 }}>
                            {isPaused ? <><Play size={13} /> Resume</> : <><Pause size={13} /> Pause</>}
                          </button>
                        </div>
                      </div>

                      {/* Whitelist */}
                      <div className="space-y-2">
                        <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>Whitelist (Free)</p>
                        <div className="flex gap-2">
                          <input type="text" placeholder="0x wallet address" value={wlInput} onChange={(e) => setWlInput(e.target.value)}
                            className="flex-1 px-3 py-2 rounded-xl text-sm border bg-transparent outline-none min-h-[44px] font-mono"
                            style={{ borderColor: 'var(--border)', color: 'var(--ink)', fontFamily: 'monospace' }} />
                          <button onClick={handleAddToWhitelist} disabled={isWriting || !wlInput.trim()}
                            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold min-h-[44px] transition-all hover:opacity-85 flex-shrink-0"
                            style={{ background: 'var(--bullish)', color: 'var(--bg)', opacity: (isWriting || !wlInput.trim()) ? 0.5 : 1 }}>
                            <UserPlus size={13} /> Add
                          </button>
                        </div>
                        {whitelist.length > 0 && (
                          <div className="space-y-1.5">
                            {whitelist.map((w) => (
                              <div key={w} className="flex items-center gap-2 px-3 py-2 rounded-xl"
                                style={{ background: 'rgba(16,185,129,0.06)', border: '1px solid rgba(16,185,129,0.18)' }}>
                                <span className="text-xs font-mono flex-1 truncate" style={{ color: 'var(--ink-2)' }}>
                                  {w.slice(0, 10)}…{w.slice(-6)}
                                </span>
                                <button onClick={() => handleRemoveFromWhitelist(w)} disabled={isWriting}
                                  className="flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded-lg min-h-[32px] transition-all hover:opacity-70"
                                  style={{ background: 'var(--surface-muted)', color: 'var(--bearish)' }}>
                                  <UserMinus size={11} /> Remove
                                </button>
                              </div>
                            ))}
                          </div>
                        )}
                        {whitelist.length === 0 && <p className="text-xs px-1" style={{ color: 'var(--subtle)' }}>No whitelisted wallets yet.</p>}
                      </div>

                      {/* Custom fees */}
                      <div className="space-y-2">
                        <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>Custom Fees</p>
                        <div className="flex gap-2">
                          <input type="text" placeholder="0x wallet" value={cfInput} onChange={(e) => setCfInput(e.target.value)}
                            className="flex-1 px-3 py-2 rounded-xl text-sm border bg-transparent outline-none min-h-[44px] font-mono"
                            style={{ borderColor: 'var(--border)', color: 'var(--ink)', fontFamily: 'monospace' }} />
                          <input type="number" min="0" step="0.01" placeholder="USDC" value={cfFeeInput} onChange={(e) => setCfFeeInput(e.target.value)}
                            className="w-24 px-3 py-2 rounded-xl text-sm border bg-transparent outline-none min-h-[44px]"
                            style={{ borderColor: 'var(--border)', color: 'var(--ink)', fontFamily: "'DM Sans', sans-serif" }} />
                          <button onClick={handleSetCustomFee} disabled={isWriting || !cfInput.trim()}
                            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold min-h-[44px] transition-all hover:opacity-85 flex-shrink-0"
                            style={{ background: 'var(--accent)', color: 'var(--bg)', opacity: (isWriting || !cfInput.trim()) ? 0.5 : 1 }}>
                            Set
                          </button>
                        </div>
                        {customFees.length > 0 && (
                          <div className="space-y-1.5">
                            {customFees.map(({ wallet: w, fee: f }) => (
                              <div key={w} className="flex items-center gap-2 px-3 py-2 rounded-xl"
                                style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
                                <span className="text-xs font-mono flex-1 truncate" style={{ color: 'var(--ink-2)' }}>{w.slice(0, 10)}…{w.slice(-6)}</span>
                                <span className="text-xs font-semibold tabular-nums flex-shrink-0" style={{ color: 'var(--accent)' }}>
                                  {(Number(f) / 1e18).toFixed(2)} USDC
                                </span>
                                <button onClick={() => handleRemoveCustomFee(w)} disabled={isWriting}
                                  className="flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded-lg min-h-[32px] transition-all hover:opacity-70"
                                  style={{ background: 'var(--surface)', color: 'var(--bearish)', border: '1px solid var(--border)' }}>
                                  <UserMinus size={11} /> Remove
                                </button>
                              </div>
                            ))}
                          </div>
                        )}
                        {customFees.length === 0 && <p className="text-xs px-1" style={{ color: 'var(--subtle)' }}>No custom fees set.</p>}
                      </div>
                    </div>
                  )}

                  {/* ── Projects tab ──────────────────────────────────────── */}
                  {activeTab === 'projects' && (
                    <div className="space-y-6 pb-6">
                      {/* Bulk actions */}
                      {selectedProjectIds.size > 0 && (
                        <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }}
                          className="flex items-center gap-2 px-4 py-3 rounded-2xl"
                          style={{ background: 'rgba(26,92,255,0.07)', border: '1px solid rgba(26,92,255,0.20)' }}>
                          <span className="text-xs font-semibold flex-1" style={{ color: 'var(--accent)' }}>
                            {selectedProjectIds.size} selected
                          </span>
                          <select
                            value={bulkStatus}
                            onChange={(e) => setBulkStatus(e.target.value as ProjectStatus | '')}
                            className="px-2 py-1.5 rounded-xl text-xs border bg-transparent outline-none min-h-[36px]"
                            style={{ borderColor: 'var(--border)', color: 'var(--ink)', fontFamily: "'DM Sans', sans-serif" }}>
                            <option value=''>Set status…</option>
                            {STATUS_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                          </select>
                          <button onClick={() => { void handleBulkStatusChange() }}
                            disabled={!bulkStatus}
                            className="px-3 py-1.5 rounded-xl text-xs font-semibold min-h-[36px] transition-all hover:opacity-85"
                            style={{ background: 'var(--accent)', color: 'var(--bg)', opacity: bulkStatus ? 1 : 0.4 }}>
                            Apply
                          </button>
                          <button
                            onClick={() => {
                              const ids = [...selectedProjectIds]
                              setBulkReinstateIds(ids)
                              void handleBulkReinstate()
                            }}
                            disabled={isBulkReinstating}
                            className="px-3 py-1.5 rounded-xl text-xs font-semibold min-h-[36px] transition-all hover:opacity-85"
                            style={{ background: 'var(--bullish)', color: 'var(--bg)' }}>
                            <RotateCcw size={11} className="inline mr-1" />
                            Reinstate
                          </button>
                        </motion.div>
                      )}

                      {/* Submitted projects section */}
                      {allProjects.filter((p) => !PROJECTS.find((s) => s.id === p.id)).length > 0 && (
                        <div className="space-y-2">
                          <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                            Submitted Projects
                          </p>
                          {allProjects.filter((p) => !PROJECTS.find((s) => s.id === p.id)).map((project) => (
                            <ProjectManagementRow
                              key={project.id}
                              project={project}
                              isEditing={editingProjectId === project.id}
                              editForm={editForm}
                              setEditForm={setEditForm}
                              isSelected={selectedProjectIds.has(project.id)}
                              onToggleSelect={() => setSelectedProjectIds((prev) => {
                                const next = new Set(prev)
                                if (next.has(project.id)) next.delete(project.id)
                                else next.add(project.id)
                                return next
                              })}
                              onEdit={() => startEdit(project)}
                              onSave={() => { void handleSaveEdit(project.id) }}
                              onCancel={() => setEditingProjectId(null)}
                              onStatusChange={(s) => { void handleStatusChange(project, s) }}
                              onReinstate={() => setReinstateConfirm({ id: project.id, name: project.name })}
                              onRemoveLogo={project.logoUrl ? () => { void handleRemoveLogo(project) } : undefined}
                              statusOptions={STATUS_OPTIONS}
                              getStatusColor={getStatusColor}
                              isInactive={project.status ? INACTIVE_STATUSES.has(project.status) : false}
                            />
                          ))}
                        </div>
                      )}

                      {/* Seeded projects section */}
                      <div className="space-y-2">
                        <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                          Seeded Projects
                        </p>
                        <p className="text-xs" style={{ color: 'var(--muted)' }}>
                          Changes write to Supabase overrides — never to source code.
                        </p>
                        {allProjects.filter((p) => PROJECTS.find((s) => s.id === p.id)).map((project) => (
                          <ProjectManagementRow
                            key={project.id}
                            project={project}
                            isEditing={editingProjectId === project.id}
                            editForm={editForm}
                            setEditForm={setEditForm}
                            isSelected={selectedProjectIds.has(project.id)}
                            onToggleSelect={() => setSelectedProjectIds((prev) => {
                              const next = new Set(prev)
                              if (next.has(project.id)) next.delete(project.id)
                              else next.add(project.id)
                              return next
                            })}
                            onEdit={() => startEdit(project)}
                            onSave={() => { void handleSaveEdit(project.id) }}
                            onCancel={() => setEditingProjectId(null)}
                            onStatusChange={(s) => { void handleStatusChange(project, s) }}
                            onReinstate={() => setReinstateConfirm({ id: project.id, name: project.name })}
                            onRemoveLogo={project.logoUrl ? () => { void handleRemoveLogo(project) } : undefined}
                            statusOptions={STATUS_OPTIONS}
                            getStatusColor={getStatusColor}
                            isInactive={project.status ? INACTIVE_STATUSES.has(project.status) : false}
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {/* ── Widget tab ─────────────────────────────────────────── */}
                  {activeTab === 'widget' && (
                    <div className="space-y-6 pb-6">
                      <div>
                        <h3 className="text-base font-semibold mb-1" style={{ color: 'var(--ink)' }}>Embeddable Pulse Badge</h3>
                        <p className="text-sm" style={{ color: 'var(--ink-2)' }}>
                          Verified project owners can embed a live sentiment badge on their website.
                          Install tracking is coming soon.
                        </p>
                      </div>

                      {widgetOwnersLoading ? (
                        <div className="space-y-3">
                          {[0,1,2].map(i => (
                            <div key={i} className="h-16 rounded-xl animate-pulse" style={{ background: 'var(--surface-muted)' }} />
                          ))}
                        </div>
                      ) : Object.keys(widgetVerifiedOwners).length === 0 ? (
                        <div className="rounded-xl px-4 py-8 text-center text-sm" style={{ background: 'var(--surface-muted)', color: 'var(--muted)' }}>
                          No verified projects yet.
                        </div>
                      ) : (
                        <div className="space-y-3">
                          {allProjects
                            .filter(p => widgetVerifiedOwners[p.id])
                            .map(p => {
                              const total = p.votes.bullish + p.votes.neutral + p.votes.bearish
                              const pct = total > 0 ? Math.round((p.votes.bullish / total) * 100) : 0
                              const origin = window.location.origin
                              const embedCode = `<iframe src="${origin}/widget/${p.id}" width="200" height="72" frameborder="0" style="border:none;"></iframe>`
                              const copied = copiedEmbedId === p.id
                              return (
                                <div key={p.id} className="rounded-xl p-4 flex items-center gap-4" style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
                                  {/* Live badge preview */}
                                  <div className="flex-shrink-0">
                                    <PulseBadge
                                      projectId={p.id}
                                      contractAddress={contractAddress ?? ''}
                                      size="sm"
                                      theme="dark"
                                    />
                                  </div>
                                  {/* Project info */}
                                  <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-2">
                                      <span className="text-sm font-semibold truncate" style={{ color: 'var(--ink)' }}>{p.name}</span>
                                      <span
                                        className="text-xs font-semibold tabular-nums px-1.5 py-0.5 rounded-md"
                                        style={{
                                          color: pct >= 60 ? 'var(--bullish)' : pct >= 40 ? '#d97706' : 'var(--bearish)',
                                          background: pct >= 60 ? 'rgba(26,128,71,0.1)' : pct >= 40 ? 'rgba(217,119,6,0.1)' : 'rgba(186,43,76,0.1)',
                                        }}
                                      >
                                        {pct}% Bullish
                                      </span>
                                    </div>
                                    <p className="text-xs truncate mt-0.5" style={{ color: 'var(--muted)', fontFamily: "'JetBrains Mono', monospace" }}>
                                      {widgetVerifiedOwners[p.id]}
                                    </p>
                                  </div>
                                  {/* Copy embed button */}
                                  <button
                                    onClick={() => {
                                      void navigator.clipboard.writeText(embedCode).then(() => {
                                        setCopiedEmbedId(p.id)
                                        setTimeout(() => setCopiedEmbedId(null), 2000)
                                        toast.success('Embed code copied')
                                      })
                                    }}
                                    className="flex-shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium min-h-[36px] transition-all hover:opacity-80"
                                    style={copied
                                      ? { background: 'rgba(26,128,71,0.12)', color: 'var(--bullish)' }
                                      : { background: 'var(--surface-muted)', color: 'var(--ink-2)', border: '1px solid var(--border)' }
                                    }
                                  >
                                    {copied ? <><Check size={12} /> Copied</> : <><Code size={12} /> Copy Embed</>}
                                  </button>
                                </div>
                              )
                            })}
                        </div>
                      )}

                      {/* Install tracking placeholder */}
                      <div className="rounded-xl px-4 py-4 flex items-center gap-3" style={{ background: 'var(--surface-muted)', border: '1px dashed var(--border)' }}>
                        <BarChart2 size={16} style={{ color: 'var(--muted)', flexShrink: 0 }} />
                        <div>
                          <p className="text-sm font-medium" style={{ color: 'var(--ink-2)' }}>Install tracking — coming soon</p>
                          <p className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>Track how many sites have installed your badge and how many impressions it receives.</p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* ── Profiles tab ──────────────────────────────────────── */}
                  {activeTab === 'profiles' && (
                    <AdminProfilesTab supabase={supabase} />
                  )}

                  {/* ── Taxonomy tab ──────────────────────────────────────── */}
                  {activeTab === 'taxonomy' && (
                    <div className="space-y-5 pb-6">
                      <p className="text-xs" style={{ color: 'var(--muted)' }}>
                        Manage the controlled vocabulary for project classification. Changes are saved locally and reflected immediately in submission and discovery. Inactive items remain resolvable for existing projects but are hidden from new submissions.
                      </p>

                      {/* Sub-tab bar */}
                      <div className="flex gap-1">
                        {(['categories', 'usecases', 'tags'] as TaxSubTab[]).map((sub) => (
                          <button key={sub}
                            onClick={() => setTaxSubTab(sub)}
                            className="px-3 py-1.5 rounded-xl text-xs font-semibold transition-all"
                            style={taxSubTab === sub
                              ? { background: 'var(--surface-strong)', color: 'var(--ink)' }
                              : { color: 'var(--muted)' }}>
                            {sub === 'categories' ? 'Categories' : sub === 'usecases' ? 'Use Cases' : 'Tags'}
                          </button>
                        ))}
                      </div>

                      {/* ── Categories sub-tab ──────────────────────────── */}
                      {taxSubTab === 'categories' && (
                        <div className="space-y-2">
                          <p className="text-xs" style={{ color: 'var(--muted)' }}>
                            Categories define what a project IS. Exactly one is required per project. Deactivated categories are hidden from new submissions but remain resolvable.
                          </p>
                          {taxonomy.categories.map((cat) => (
                            <div key={cat.id} className="rounded-2xl px-4 py-3 space-y-2"
                              style={{
                                background: cat.active ? 'var(--surface-muted)' : 'rgba(100,116,139,0.06)',
                                border: `1px solid ${cat.active ? 'var(--border)' : 'rgba(100,116,139,0.20)'}`,
                                opacity: cat.active ? 1 : 0.65,
                              }}>
                              {editingCatId === cat.id ? (
                                <div className="flex items-center gap-2">
                                  <input
                                    value={catLabelDraft}
                                    onChange={(e) => setCatLabelDraft(e.target.value)}
                                    className="flex-1 px-3 py-1.5 rounded-xl text-sm border bg-transparent outline-none"
                                    style={{ borderColor: 'var(--accent)', color: 'var(--ink)' }}
                                    autoFocus
                                  />
                                  <button onClick={() => handleSaveCat(cat)}
                                    className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold min-h-[36px]"
                                    style={{ background: 'var(--accent)', color: 'var(--bg)' }}>
                                    <Check size={12} /> Save
                                  </button>
                                  <button onClick={() => setEditingCatId(null)}
                                    className="px-3 py-1.5 rounded-xl text-xs font-semibold min-h-[36px]"
                                    style={{ background: 'var(--surface-muted)', color: 'var(--muted)', border: '1px solid var(--border)' }}>
                                    Cancel
                                  </button>
                                </div>
                              ) : (
                                <div className="flex items-center gap-2">
                                  <span className="flex-1 text-sm font-medium" style={{ color: 'var(--ink)' }}>{cat.label}</span>
                                  <span className="text-xs font-mono" style={{ color: 'var(--subtle)' }}>{cat.id}</span>
                                  <button onClick={() => { setEditingCatId(cat.id); setCatLabelDraft(cat.label) }}
                                    className="p-1.5 rounded-lg min-h-[32px] min-w-[32px] flex items-center justify-center hover:opacity-70 transition-opacity"
                                    style={{ background: 'var(--surface)', color: 'var(--ink-2)', border: '1px solid var(--border)' }}>
                                    <Edit3 size={12} />
                                  </button>
                                  <button onClick={() => handleToggleCat(cat)}
                                    className="flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-semibold min-h-[32px] transition-all hover:opacity-85"
                                    style={cat.active
                                      ? { background: 'rgba(16,185,129,0.10)', color: 'var(--bullish)', border: '1px solid rgba(16,185,129,0.20)' }
                                      : { background: 'rgba(100,116,139,0.10)', color: 'var(--muted)', border: '1px solid var(--border)' }}>
                                    {cat.active ? <><Eye size={11} /> Active</> : <><Eye size={11} /> Inactive</>}
                                  </button>
                                </div>
                              )}
                            </div>
                          ))}

                          {/* Add new category */}
                          <div className="flex items-center gap-2 pt-1">
                            <input
                              value={newCatLabel}
                              onChange={(e) => setNewCatLabel(e.target.value)}
                              placeholder="New category name…"
                              className="flex-1 px-3 py-2 rounded-xl text-sm border bg-transparent outline-none min-h-[40px]"
                              style={{ borderColor: 'var(--border)', color: 'var(--ink)' }}
                              onKeyDown={(e) => { if (e.key === 'Enter') handleAddCat() }}
                            />
                            <button onClick={handleAddCat} disabled={!newCatLabel.trim()}
                              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold min-h-[40px] transition-all hover:opacity-85"
                              style={{ background: 'var(--accent)', color: 'var(--bg)', opacity: newCatLabel.trim() ? 1 : 0.4 }}>
                              <Plus size={12} /> Add
                            </button>
                          </div>
                        </div>
                      )}

                      {/* ── Use Cases sub-tab ───────────────────────────── */}
                      {taxSubTab === 'usecases' && (
                        <div className="space-y-2">
                          <p className="text-xs" style={{ color: 'var(--muted)' }}>
                            Use cases describe what a project DOES. Up to 5 per project.
                          </p>
                          {/* Group header display */}
                          {Array.from(new Set(taxonomy.useCases.map((u) => u.group))).map((group) => (
                            <div key={group} className="space-y-1.5">
                              <p className="text-[10px] font-semibold uppercase tracking-widest pt-2"
                                style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                                {group}
                              </p>
                              {taxonomy.useCases.filter((u) => u.group === group).map((uc) => (
                                <div key={uc.id} className="rounded-2xl px-4 py-2.5 space-y-2"
                                  style={{
                                    background: uc.active ? 'var(--surface-muted)' : 'rgba(100,116,139,0.06)',
                                    border: `1px solid ${uc.active ? 'var(--border)' : 'rgba(100,116,139,0.20)'}`,
                                    opacity: uc.active ? 1 : 0.65,
                                  }}>
                                  {editingUcId === uc.id ? (
                                    <div className="space-y-2">
                                      <div className="flex gap-2">
                                        <input value={ucLabelDraft} onChange={(e) => setUcLabelDraft(e.target.value)}
                                          placeholder="Label" autoFocus
                                          className="flex-1 px-3 py-1.5 rounded-xl text-sm border bg-transparent outline-none"
                                          style={{ borderColor: 'var(--accent)', color: 'var(--ink)' }} />
                                        <input value={ucGroupDraft} onChange={(e) => setUcGroupDraft(e.target.value)}
                                          placeholder="Group"
                                          className="w-28 px-3 py-1.5 rounded-xl text-sm border bg-transparent outline-none"
                                          style={{ borderColor: 'var(--border)', color: 'var(--ink)' }} />
                                      </div>
                                      <div className="flex gap-2">
                                        <button onClick={() => handleSaveUc(uc)}
                                          className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold min-h-[32px]"
                                          style={{ background: 'var(--accent)', color: 'var(--bg)' }}>
                                          <Check size={12} /> Save
                                        </button>
                                        <button onClick={() => setEditingUcId(null)}
                                          className="px-3 py-1.5 rounded-xl text-xs font-semibold min-h-[32px]"
                                          style={{ background: 'var(--surface-muted)', color: 'var(--muted)', border: '1px solid var(--border)' }}>
                                          Cancel
                                        </button>
                                      </div>
                                    </div>
                                  ) : (
                                    <div className="flex items-center gap-2">
                                      <span className="flex-1 text-sm font-medium" style={{ color: 'var(--ink)' }}>{uc.label}</span>
                                      <span className="text-xs font-mono" style={{ color: 'var(--subtle)' }}>{uc.id}</span>
                                      <button onClick={() => { setEditingUcId(uc.id); setUcLabelDraft(uc.label); setUcGroupDraft(uc.group) }}
                                        className="p-1.5 rounded-lg min-h-[32px] min-w-[32px] flex items-center justify-center hover:opacity-70"
                                        style={{ background: 'var(--surface)', color: 'var(--ink-2)', border: '1px solid var(--border)' }}>
                                        <Edit3 size={12} />
                                      </button>
                                      <button onClick={() => handleToggleUc(uc)}
                                        className="flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-semibold min-h-[32px]"
                                        style={uc.active
                                          ? { background: 'rgba(16,185,129,0.10)', color: 'var(--bullish)', border: '1px solid rgba(16,185,129,0.20)' }
                                          : { background: 'rgba(100,116,139,0.10)', color: 'var(--muted)', border: '1px solid var(--border)' }}>
                                        {uc.active ? 'Active' : 'Inactive'}
                                      </button>
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>
                          ))}

                          {/* Add new use case */}
                          <div className="flex gap-2 flex-wrap pt-1">
                            <input value={newUcLabel} onChange={(e) => setNewUcLabel(e.target.value)}
                              placeholder="New use case name…"
                              className="flex-1 px-3 py-2 rounded-xl text-sm border bg-transparent outline-none min-h-[40px] min-w-[140px]"
                              style={{ borderColor: 'var(--border)', color: 'var(--ink)' }} />
                            <input value={newUcGroup} onChange={(e) => setNewUcGroup(e.target.value)}
                              placeholder="Group (e.g. Payments)"
                              className="w-36 px-3 py-2 rounded-xl text-sm border bg-transparent outline-none min-h-[40px]"
                              style={{ borderColor: 'var(--border)', color: 'var(--ink)' }} />
                            <button onClick={handleAddUc} disabled={!newUcLabel.trim()}
                              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold min-h-[40px]"
                              style={{ background: 'var(--accent)', color: 'var(--bg)', opacity: newUcLabel.trim() ? 1 : 0.4 }}>
                              <Plus size={12} /> Add
                            </button>
                          </div>
                        </div>
                      )}

                      {/* ── Tags sub-tab ─────────────────────────────────── */}
                      {taxSubTab === 'tags' && (
                        <div className="space-y-2">
                          <p className="text-xs" style={{ color: 'var(--muted)' }}>
                            Tags are specific descriptors. Up to 5 per project. Aliases normalize variants to one canonical tag.
                          </p>
                          {taxonomy.tags.map((tag) => (
                            <div key={tag.id} className="rounded-2xl px-4 py-3 space-y-2"
                              style={{
                                background: tag.active ? 'var(--surface-muted)' : 'rgba(100,116,139,0.06)',
                                border: `1px solid ${tag.active ? 'var(--border)' : 'rgba(100,116,139,0.20)'}`,
                                opacity: tag.active ? 1 : 0.65,
                              }}>
                              {editingTagId === tag.id ? (
                                <div className="space-y-2">
                                  <div className="flex gap-2">
                                    <input value={tagLabelDraft} onChange={(e) => setTagLabelDraft(e.target.value)}
                                      placeholder="Label" autoFocus
                                      className="flex-1 px-3 py-1.5 rounded-xl text-sm border bg-transparent outline-none"
                                      style={{ borderColor: 'var(--accent)', color: 'var(--ink)' }} />
                                  </div>
                                  <input value={tagAliasesDraft} onChange={(e) => setTagAliasesDraft(e.target.value)}
                                    placeholder="Aliases, comma-separated (e.g. stablecoins, stable-coin)"
                                    className="w-full px-3 py-1.5 rounded-xl text-sm border bg-transparent outline-none"
                                    style={{ borderColor: 'var(--border)', color: 'var(--ink)' }} />
                                  {/* Merge */}
                                  <div className="flex gap-2 items-center">
                                    <select value={mergeTargetId} onChange={(e) => setMergeTargetId(e.target.value)}
                                      className="flex-1 px-3 py-1.5 rounded-xl text-sm border bg-transparent outline-none"
                                      style={{ borderColor: 'var(--border)', color: 'var(--ink)' }}>
                                      <option value=''>Merge another tag into this one…</option>
                                      {taxonomy.tags.filter((t) => t.id !== tag.id).map((t) => (
                                        <option key={t.id} value={t.id}>{t.label}</option>
                                      ))}
                                    </select>
                                    <button onClick={() => handleMergeTag(tag.id)} disabled={!mergeTargetId}
                                      className="px-3 py-1.5 rounded-xl text-xs font-semibold min-h-[32px]"
                                      style={{ background: mergeTargetId ? 'var(--bearish)' : 'var(--surface-muted)', color: mergeTargetId ? 'var(--bg)' : 'var(--subtle)', opacity: mergeTargetId ? 1 : 0.5 }}>
                                      Merge
                                    </button>
                                  </div>
                                  <div className="flex gap-2">
                                    <button onClick={() => handleSaveTag(tag)}
                                      className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold min-h-[32px]"
                                      style={{ background: 'var(--accent)', color: 'var(--bg)' }}>
                                      <Check size={12} /> Save
                                    </button>
                                    <button onClick={() => { setEditingTagId(null); setMergeTargetId('') }}
                                      className="px-3 py-1.5 rounded-xl text-xs font-semibold min-h-[32px]"
                                      style={{ background: 'var(--surface-muted)', color: 'var(--muted)', border: '1px solid var(--border)' }}>
                                      Cancel
                                    </button>
                                  </div>
                                </div>
                              ) : (
                                <div className="flex items-start gap-2">
                                  <div className="flex-1 min-w-0 space-y-0.5">
                                    <span className="text-sm font-medium" style={{ color: 'var(--ink)' }}>{tag.label}</span>
                                    {tag.aliases.length > 0 && (
                                      <p className="text-xs" style={{ color: 'var(--subtle)' }}>
                                        Aliases: {tag.aliases.join(', ')}
                                      </p>
                                    )}
                                  </div>
                                  <span className="text-xs font-mono flex-shrink-0 mt-0.5" style={{ color: 'var(--subtle)' }}>{tag.id}</span>
                                  <button onClick={() => { setEditingTagId(tag.id); setTagLabelDraft(tag.label); setTagAliasesDraft(tag.aliases.join(', ')); setMergeTargetId('') }}
                                    className="p-1.5 rounded-lg min-h-[32px] min-w-[32px] flex items-center justify-center hover:opacity-70 flex-shrink-0"
                                    style={{ background: 'var(--surface)', color: 'var(--ink-2)', border: '1px solid var(--border)' }}>
                                    <Edit3 size={12} />
                                  </button>
                                  <button onClick={() => handleToggleTag(tag)}
                                    className="flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-semibold min-h-[32px] flex-shrink-0"
                                    style={tag.active
                                      ? { background: 'rgba(16,185,129,0.10)', color: 'var(--bullish)', border: '1px solid rgba(16,185,129,0.20)' }
                                      : { background: 'rgba(100,116,139,0.10)', color: 'var(--muted)', border: '1px solid var(--border)' }}>
                                    {tag.active ? 'Active' : 'Inactive'}
                                  </button>
                                </div>
                              )}
                            </div>
                          ))}

                          {/* Add new tag */}
                          <div className="flex gap-2 flex-wrap pt-1">
                            <input value={newTagLabel} onChange={(e) => setNewTagLabel(e.target.value)}
                              placeholder="New tag label…"
                              className="flex-1 px-3 py-2 rounded-xl text-sm border bg-transparent outline-none min-h-[40px] min-w-[120px]"
                              style={{ borderColor: 'var(--border)', color: 'var(--ink)' }} />
                            <input value={newTagAliases} onChange={(e) => setNewTagAliases(e.target.value)}
                              placeholder="Aliases (comma-separated)"
                              className="flex-1 px-3 py-2 rounded-xl text-sm border bg-transparent outline-none min-h-[40px] min-w-[160px]"
                              style={{ borderColor: 'var(--border)', color: 'var(--ink)' }} />
                            <button onClick={handleAddTag} disabled={!newTagLabel.trim()}
                              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold min-h-[40px]"
                              style={{ background: 'var(--accent)', color: 'var(--bg)', opacity: newTagLabel.trim() ? 1 : 0.4 }}>
                              <Plus size={12} /> Add
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* ── Log tab ───────────────────────────────────────────── */}
                  {activeTab === 'log' && (
                    <div className="space-y-4 pb-6">
                      {/* Filters + export */}
                      <div className="flex gap-2 flex-wrap">
                        <input type="text" placeholder="Filter by project…"
                          value={logProjectFilter}
                          onChange={(e) => setLogProjectFilter(e.target.value)}
                          className="flex-1 px-3 py-2 rounded-xl text-sm border bg-transparent outline-none min-h-[44px] min-w-[120px]"
                          style={{ borderColor: 'var(--border)', color: 'var(--ink)', fontFamily: "'DM Sans', sans-serif" }} />
                        <input type="text" placeholder="Filter by action…"
                          value={logActionFilter}
                          onChange={(e) => setLogActionFilter(e.target.value)}
                          className="flex-1 px-3 py-2 rounded-xl text-sm border bg-transparent outline-none min-h-[44px] min-w-[120px]"
                          style={{ borderColor: 'var(--border)', color: 'var(--ink)', fontFamily: "'DM Sans', sans-serif" }} />
                        <button onClick={exportLogCsv}
                          className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold min-h-[44px] transition-all hover:opacity-85 flex-shrink-0"
                          style={{ background: 'var(--surface-muted)', color: 'var(--ink-2)', border: '1px solid var(--border)' }}>
                          <History size={13} /> Export CSV
                        </button>
                      </div>

                      {logLoading && (
                        <div className="h-20 rounded-2xl animate-pulse" style={{ background: 'var(--surface-muted)' }} />
                      )}
                      {!logLoading && filteredLog.length === 0 && (
                        <p className="text-xs px-1" style={{ color: 'var(--subtle)' }}>No log entries yet.</p>
                      )}
                      {filteredLog.map((row) => (
                        <div key={row.id} className="rounded-2xl p-4 space-y-2"
                          style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-xs font-mono px-2 py-0.5 rounded-full"
                              style={{ background: 'rgba(26,92,255,0.10)', color: 'var(--accent)' }}>
                              {row.action}
                            </span>
                            <span className="text-xs font-semibold" style={{ color: 'var(--ink)' }}>{row.project_id}</span>
                            <span className="ml-auto text-xs tabular-nums" style={{ color: 'var(--muted)' }}>
                              {new Date(row.created_at).toLocaleString()}
                            </span>
                          </div>
                          <p className="text-xs font-mono truncate" style={{ color: 'var(--subtle)' }}>
                            {row.editor_address.slice(0, 10)}…{row.editor_address.slice(-4)}
                          </p>
                          {(row.previous_value || row.new_value) && (
                            <div className="grid grid-cols-2 gap-2 mt-1">
                              {row.previous_value && (
                                <div className="rounded-xl px-3 py-2"
                                  style={{ background: 'rgba(186,43,76,0.06)', border: '1px solid rgba(186,43,76,0.15)' }}>
                                  <p className="text-[10px] font-semibold mb-1" style={{ color: 'var(--bearish)' }}>Before</p>
                                  <pre className="text-[10px] whitespace-pre-wrap break-all leading-relaxed" style={{ color: 'var(--ink-2)', fontFamily: 'monospace' }}>
                                    {JSON.stringify(row.previous_value, null, 2)}
                                  </pre>
                                </div>
                              )}
                              {row.new_value && (
                                <div className="rounded-xl px-3 py-2"
                                  style={{ background: 'rgba(16,185,129,0.06)', border: '1px solid rgba(16,185,129,0.15)' }}>
                                  <p className="text-[10px] font-semibold mb-1" style={{ color: 'var(--bullish)' }}>After</p>
                                  <pre className="text-[10px] whitespace-pre-wrap break-all leading-relaxed" style={{ color: 'var(--ink-2)', fontFamily: 'monospace' }}>
                                    {JSON.stringify(row.new_value, null, 2)}
                                  </pre>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}

                  {/* ── Analytics tab ─────────────────────────────────────── */}
                  {activeTab === 'analytics' && (
                    <PlatformAnalyticsTab analytics={platformAnalytics} momentum={platformMomentum} />
                  )}

                  {/* ── Revenue tab ───────────────────────────────────────── */}
                  {activeTab === 'revenue' && <RevenueTab contractAddress={contractAddress} />}

                  {/* ── Reviews tab ───────────────────────────────────────── */}
                  {activeTab === 'reviews' && (
                    <div className="space-y-4 pb-6">
                      {/* Project selector */}
                      <div className="space-y-1.5">
                        <p className="text-xs" style={{ color: 'var(--muted)' }}>Select project to manage reviews</p>
                        <div className="flex flex-wrap gap-2">
                          {PROJECTS.map((p) => (
                            <button key={p.id}
                              onClick={() => { setReviewsProject(p.id); setAdminOpenReplyId(null) }}
                              className="px-3 py-1.5 rounded-full text-xs font-medium min-h-[36px] transition-all"
                              style={reviewsProject === p.id
                                ? { background: 'var(--accent)', color: 'var(--bg)' }
                                : { background: 'var(--surface-muted)', color: 'var(--ink-2)', border: '1px solid var(--border)' }}>
                              {p.name}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Review list */}
                      {selectedProject && (
                        <div className="space-y-3">
                          <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                            {selectedProject.reviews.length} Review{selectedProject.reviews.length !== 1 ? 's' : ''}
                          </p>
                          {selectedProject.reviews.length === 0 && (
                            <p className="text-xs px-1" style={{ color: 'var(--subtle)' }}>No reviews yet.</p>
                          )}
                          {selectedProject.reviews.map((review) => {
                            const isPinned    = adminPinnedIds.has(review.id)
                            const respList: ReviewResponse[] = adminResponses[review.id] ?? []
                            const isReplying  = adminOpenReplyId === review.id

                            return (
                              <div key={review.id}
                                className="rounded-2xl p-4 space-y-2.5"
                                style={{
                                  background: isPinned ? 'rgba(26,92,255,0.05)' : 'var(--surface-muted)',
                                  border: `1px solid ${isPinned ? 'var(--accent)' : 'var(--border)'}`,
                                  borderLeft: isPinned ? '3px solid var(--accent)' : undefined,
                                }}>
                                {/* Author + sentiment */}
                                <div className="flex items-start justify-between gap-2">
                                  <div className="space-y-0.5 flex-1 min-w-0">
                                    <p className="text-xs font-mono truncate" style={{ color: 'var(--ink-2)' }}>
                                      {review.author}
                                    </p>
                                    <p className="text-sm leading-snug text-pretty" style={{ color: 'var(--ink)' }}>
                                      {review.body}
                                    </p>
                                  </div>
                                  {isPinned && (
                                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-semibold flex-shrink-0"
                                      style={{ background: 'rgba(26,92,255,0.10)', color: 'var(--accent)' }}>
                                      <Pin size={9} strokeWidth={2.5} /> Pinned
                                    </span>
                                  )}
                                </div>

                                {/* Existing responses */}
                                {respList.length > 0 && (
                                  <div className="ml-2 pl-3 space-y-1.5"
                                    style={{ borderLeft: '2px solid rgba(26,92,255,0.20)' }}>
                                    {respList.map((r) => (
                                      <p key={r.id} className="text-xs leading-relaxed" style={{ color: 'var(--ink-2)' }}>
                                        <span className="font-semibold" style={{ color: 'var(--accent)' }}>Owner: </span>
                                        {r.body}
                                      </p>
                                    ))}
                                  </div>
                                )}

                                {/* Action row */}
                                <div className="flex items-center gap-2 flex-wrap">
                                  {/* Pin / Unpin */}
                                  <button
                                    onClick={() => {
                                      if (isPinned) void adminUnpinReview(review.id).then(() => toast('Review unpinned.'))
                                      else void adminPinReview(review.id).then(() => toast.success('Review pinned.'))
                                    }}
                                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold min-h-[36px] transition-all hover:opacity-85"
                                    style={isPinned
                                      ? { background: 'rgba(26,92,255,0.10)', color: 'var(--accent)', border: '1px solid rgba(26,92,255,0.25)' }
                                      : { background: 'var(--surface)', color: 'var(--muted)', border: '1px solid var(--border)' }}>
                                    <Pin size={11} strokeWidth={2.5} />
                                    {isPinned ? 'Unpin' : 'Pin'}
                                  </button>

                                  {/* Reply toggle */}
                                  <button
                                    onClick={() => {
                                      if (isReplying) { setAdminOpenReplyId(null) }
                                      else { setAdminOpenReplyId(review.id); setAdminReplyBody('') }
                                    }}
                                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold min-h-[36px] transition-all hover:opacity-85"
                                    style={isReplying
                                      ? { background: 'var(--accent)', color: 'var(--bg)' }
                                      : { background: 'var(--surface)', color: 'var(--muted)', border: '1px solid var(--border)' }}>
                                    <MessageSquare size={11} />
                                    {isReplying ? 'Cancel' : 'Reply'}
                                  </button>
                                </div>

                                {/* Inline reply form */}
                                <AnimatePresence>
                                  {isReplying && (
                                    <motion.div
                                      initial={{ opacity: 0, height: 0 }}
                                      animate={{ opacity: 1, height: 'auto' }}
                                      exit={{ opacity: 0, height: 0 }}
                                      style={{ overflow: 'hidden' }}
                                    >
                                      <div className="pt-1 space-y-2">
                                        <textarea
                                          value={adminReplyBody}
                                          onChange={(e) => setAdminReplyBody(e.target.value.slice(0, 280))}
                                          placeholder="Write a response as verified owner..."
                                          rows={2}
                                          className="w-full resize-none rounded-xl px-3 py-2.5 text-sm outline-none"
                                          style={{ background: 'var(--surface)', color: 'var(--ink)', border: '1.5px solid var(--border)', fontFamily: "'DM Sans', sans-serif" }}
                                          onFocus={(e) => { e.target.style.borderColor = 'var(--focus)' }}
                                          onBlur={(e)  => { e.target.style.borderColor = 'var(--border)' }}
                                        />
                                        <div className="flex items-center justify-between gap-2">
                                          <span className="text-xs tabular-nums" style={{ color: 'var(--subtle)' }}>
                                            {adminReplyBody.length}/280
                                          </span>
                                          <button
                                            onClick={() => { void handleAdminPostReply(review.id) }}
                                            disabled={adminReplyBody.trim().length < 1 || adminPostingReply}
                                            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold min-h-[36px] transition-all hover:opacity-85"
                                            style={adminReplyBody.trim().length >= 1
                                              ? { background: 'var(--accent)', color: 'var(--bg)' }
                                              : { background: 'var(--surface-muted)', color: 'var(--subtle)', cursor: 'not-allowed' }}>
                                            <Send size={11} />
                                            {adminPostingReply ? 'Posting…' : 'Post Reply'}
                                          </button>
                                        </div>
                                      </div>
                                    </motion.div>
                                  )}
                                </AnimatePresence>
                              </div>
                            )
                          })}
                        </div>
                      )}

                      {/* ── Moderation section ─────────────────────────── */}
                      {moderatedRows.length > 0 && (
                        <div className="space-y-3 pt-2">
                          <div className="flex items-center justify-between">
                            <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                              Moderated Reviews
                            </p>
                            <button
                              onClick={refetchModeration}
                              className="flex items-center gap-1 px-2 py-1 rounded-lg text-xs min-h-[32px] hover:opacity-70 transition-opacity"
                              style={{ color: 'var(--subtle)' }}
                            >
                              <RefreshCw size={11} /> Refresh
                            </button>
                          </div>
                          {moderatedRows.map((row) => {
                            const isHidden = row.action === 'hidden'
                            return (
                              <div key={row.id}
                                className="rounded-xl p-3 space-y-1.5"
                                style={{
                                  background: isHidden ? 'rgba(186,43,76,0.05)' : 'var(--surface-muted)',
                                  border: `1px solid ${isHidden ? 'rgba(186,43,76,0.20)' : 'var(--border)'}`,
                                }}>
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full"
                                    style={{
                                      background: isHidden ? 'rgba(186,43,76,0.12)' : 'rgba(26,128,71,0.10)',
                                      color: isHidden ? 'var(--bearish)' : 'var(--bullish)',
                                    }}>
                                    {isHidden ? 'Hidden' : 'Restored'}
                                  </span>
                                  <span className="mono text-xs flex-1 truncate" style={{ color: 'var(--ink-2)' }}>
                                    Review #{row.review_id.slice(0, 8)}
                                  </span>
                                  <span className="text-[10px] tabular-nums" style={{ color: 'var(--muted)' }}>
                                    {new Date(row.created_at).toLocaleDateString()}
                                  </span>
                                </div>
                                {row.reason && (
                                  <p className="text-xs italic" style={{ color: 'var(--subtle)' }}>
                                    Reason: {row.reason}
                                  </p>
                                )}
                                {isHidden && (
                                  <button
                                    onClick={() => {
                                      void moderateReview(row.review_id, 'restored').then(() => {
                                        toast.success('Review restored.')
                                        refetchModeration()
                                      })
                                    }}
                                    className="flex items-center gap-1 px-3 py-1 rounded-lg text-xs font-semibold min-h-[32px] hover:opacity-85 transition-opacity"
                                    style={{ background: 'rgba(26,128,71,0.10)', color: 'var(--bullish)', border: '1px solid rgba(26,128,71,0.20)' }}
                                  >
                                    <Eye size={11} /> Restore
                                  </button>
                                )}
                              </div>
                            )
                          })}
                        </div>
                      )}
                    </div>
                  )}

                  {/* ── Announcements tab ─────────────────────────────────── */}
                  {activeTab === 'announcements' && (
                    <div className="space-y-5 pb-6">
                      {/* Compose form */}
                      <div className="p-4 rounded-2xl space-y-3"
                        style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
                        <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                          New Announcement
                        </p>

                        {/* Message */}
                        <div className="space-y-1">
                          <div className="flex items-center justify-between">
                            <label className="text-xs font-medium" style={{ color: 'var(--ink-2)' }}>Message</label>
                            <span className="text-xs tabular-nums" style={{ color: annMessage.length > 250 ? 'var(--bearish)' : 'var(--subtle)' }}>
                              {annMessage.length}/280
                            </span>
                          </div>
                          <textarea
                            value={annMessage}
                            onChange={(e) => setAnnMessage(e.target.value.slice(0, 280))}
                            placeholder="Write a platform-wide announcement…"
                            rows={3}
                            className="w-full resize-none rounded-xl px-3.5 py-2.5 text-sm outline-none"
                            style={{ background: 'var(--surface)', color: 'var(--ink)', border: '1.5px solid var(--border)', fontFamily: "'DM Sans', sans-serif" }}
                            onFocus={(e) => { e.target.style.borderColor = 'var(--focus)' }}
                            onBlur={(e) => { e.target.style.borderColor = 'var(--border)' }}
                          />
                        </div>

                        {/* Type chips */}
                        <div className="space-y-1">
                          <label className="text-xs font-medium" style={{ color: 'var(--ink-2)' }}>Type</label>
                          <div className="flex gap-2">
                            {(['info', 'warning', 'success'] as const).map((t) => {
                              const colors: Record<string, { bg: string; color: string }> = {
                                info:    { bg: 'rgba(26,92,255,0.10)',  color: 'var(--accent)' },
                                warning: { bg: 'rgba(245,158,11,0.10)', color: '#d97706' },
                                success: { bg: 'rgba(26,128,71,0.10)',  color: 'var(--bullish)' },
                              }
                              const active = annType === t
                              return (
                                <button key={t}
                                  onClick={() => setAnnType(t)}
                                  className="flex-1 py-2 rounded-xl text-xs font-semibold capitalize border transition-all min-h-[36px]"
                                  style={active
                                    ? { background: colors[t].bg, color: colors[t].color, borderColor: colors[t].color }
                                    : { background: 'var(--surface)', color: 'var(--muted)', borderColor: 'var(--border)' }}>
                                  {t}
                                </button>
                              )
                            })}
                          </div>
                        </div>

                        {/* Optional expiry */}
                        <div className="space-y-1">
                          <label className="text-xs font-medium" style={{ color: 'var(--ink-2)' }}>Expires (optional)</label>
                          <input
                            type="datetime-local"
                            value={annExpiry}
                            onChange={(e) => setAnnExpiry(e.target.value)}
                            className="w-full px-3 py-2 rounded-xl text-sm border bg-transparent outline-none min-h-[44px]"
                            style={{ borderColor: 'var(--border)', color: 'var(--ink)', fontFamily: "'DM Sans', sans-serif" }}
                          />
                        </div>

                        <button
                          onClick={() => { void handlePublishAnnouncement() }}
                          disabled={annMessage.trim().length < 1 || annPublishing}
                          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-semibold min-h-[44px] transition-all hover:opacity-85"
                          style={annMessage.trim().length >= 1
                            ? { background: 'var(--accent)', color: 'var(--bg)' }
                            : { background: 'var(--surface-muted)', color: 'var(--subtle)', cursor: 'not-allowed' }}>
                          <Bell size={14} />
                          {annPublishing ? 'Publishing…' : 'Publish'}
                        </button>
                      </div>

                      {/* Announcement list */}
                      <div className="space-y-2">
                        <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                          All Announcements
                        </p>
                        {allAnnouncements.length === 0 && (
                          <p className="text-xs px-1" style={{ color: 'var(--subtle)' }}>No announcements yet.</p>
                        )}
                        {allAnnouncements.map((ann) => {
                          const isExpired = ann.expires_at ? new Date(ann.expires_at) < new Date() : false
                          const isLive    = ann.active && !isExpired
                          return (
                            <motion.div key={ann.id}
                              initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }}
                              className="rounded-2xl p-4 space-y-2"
                              style={{
                                background: 'var(--surface-muted)',
                                border: `1px solid ${isLive ? 'rgba(26,128,71,0.30)' : 'var(--border)'}`,
                              }}>
                              <div className="flex items-center gap-2 flex-wrap">
                                {isLive ? (
                                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                                    style={{ background: 'rgba(26,128,71,0.12)', color: 'var(--bullish)' }}>
                                    Live
                                  </span>
                                ) : isExpired ? (
                                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                                    style={{ background: 'var(--surface)', color: 'var(--muted)', border: '1px solid var(--border)' }}>
                                    Expired
                                  </span>
                                ) : (
                                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                                    style={{ background: 'rgba(100,116,139,0.12)', color: 'var(--subtle)' }}>
                                    Inactive
                                  </span>
                                )}
                                <span className="text-[10px] px-1.5 py-0.5 rounded-full capitalize"
                                  style={{
                                    background: ann.type === 'info' ? 'rgba(26,92,255,0.08)' : ann.type === 'warning' ? 'rgba(245,158,11,0.10)' : 'rgba(26,128,71,0.08)',
                                    color: ann.type === 'info' ? 'var(--accent)' : ann.type === 'warning' ? '#d97706' : 'var(--bullish)',
                                  }}>
                                  {ann.type}
                                </span>
                                <span className="ml-auto text-[10px] tabular-nums" style={{ color: 'var(--muted)' }}>
                                  {new Date(ann.created_at).toLocaleString()}
                                </span>
                              </div>
                              <p className="text-sm leading-snug" style={{ color: 'var(--ink)' }}>{ann.message}</p>
                              {ann.expires_at && (
                                <p className="text-[11px]" style={{ color: 'var(--subtle)' }}>
                                  Expires: {new Date(ann.expires_at).toLocaleString()}
                                </p>
                              )}
                              <div className="flex gap-2 pt-1">
                                <button
                                  onClick={() => { void handleToggleAnnouncement(ann) }}
                                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold min-h-[36px] transition-all hover:opacity-85"
                                  style={ann.active
                                    ? { background: 'rgba(245,158,11,0.10)', color: '#d97706', border: '1px solid rgba(245,158,11,0.30)' }
                                    : { background: 'rgba(26,128,71,0.10)', color: 'var(--bullish)', border: '1px solid rgba(26,128,71,0.25)' }}>
                                  {ann.active ? <><Pause size={11} /> Deactivate</> : <><Play size={11} /> Reactivate</>}
                                </button>
                                <button
                                  onClick={() => { void handleDeleteAnnouncement(ann.id) }}
                                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold min-h-[36px] transition-all hover:opacity-85"
                                  style={{ background: 'rgba(186,43,76,0.08)', color: 'var(--bearish)', border: '1px solid rgba(186,43,76,0.20)' }}>
                                  <Trash2 size={11} /> Delete
                                </button>
                              </div>
                            </motion.div>
                          )
                        })}
                      </div>
                    </div>
                  )}

                  {/* ── Blacklist tab ─────────────────────────────────────── */}
                  {activeTab === 'blacklist' && (
                    <div className="space-y-5 pb-6">
                      {/* Warning notice */}
                      <div className="flex items-start gap-3 p-4 rounded-xl"
                        style={{ background: 'rgba(186,43,76,0.07)', border: '1px solid rgba(186,43,76,0.22)' }}>
                        <AlertTriangle size={16} style={{ color: 'var(--bearish)', flexShrink: 0, marginTop: 1 }} />
                        <p className="text-xs leading-relaxed" style={{ color: 'var(--bearish)' }}>
                          Blacklisting a wallet removes their votes from all sentiment counts and hides
                          their reviews platform-wide. This cannot be undone without manual restoration.
                        </p>
                      </div>

                      {/* Add wallet form */}
                      <div className="p-4 rounded-2xl space-y-3"
                        style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
                        <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                          Add to Blacklist
                        </p>
                        <input
                          type="text"
                          value={blInput}
                          onChange={(e) => setBlInput(e.target.value)}
                          placeholder="0x wallet address…"
                          className="w-full px-3.5 py-2.5 rounded-xl text-sm border bg-transparent outline-none min-h-[44px] font-mono"
                          style={{ borderColor: 'var(--border)', color: 'var(--ink)' }}
                        />
                        <input
                          type="text"
                          value={blReason}
                          onChange={(e) => setBlReason(e.target.value)}
                          placeholder="Reason (optional)"
                          className="w-full px-3.5 py-2.5 rounded-xl text-sm border bg-transparent outline-none min-h-[44px]"
                          style={{ borderColor: 'var(--border)', color: 'var(--ink)', fontFamily: "'DM Sans', sans-serif" }}
                        />
                        <button
                          onClick={() => {
                            const addr = blInput.trim()
                            if (!addr.startsWith('0x') || addr.length < 10) {
                              toast.error('Enter a valid wallet address.')
                              return
                            }
                            setBlConfirm(addr)
                          }}
                          disabled={!blInput.trim()}
                          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-semibold min-h-[44px] transition-all hover:opacity-85"
                          style={blInput.trim()
                            ? { background: 'rgba(186,43,76,0.90)', color: '#fff' }
                            : { background: 'var(--surface-muted)', color: 'var(--subtle)', cursor: 'not-allowed' }}>
                          <Ban size={14} /> Blacklist Wallet
                        </button>
                      </div>

                      {/* Blacklist table */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                            Blacklisted Wallets ({blacklist?.blacklistRows.length ?? 0})
                          </p>
                          <button onClick={() => blacklist?.refetch()}
                            className="flex items-center gap-1 text-xs px-2 py-1 rounded-lg min-h-[32px] hover:opacity-70 transition-opacity"
                            style={{ color: 'var(--subtle)' }}>
                            <RefreshCw size={11} /> Refresh
                          </button>
                        </div>

                        {blacklist?.isLoading && (
                          <div className="h-16 rounded-2xl animate-pulse" style={{ background: 'var(--surface-muted)' }} />
                        )}
                        {!blacklist?.isLoading && (blacklist?.blacklistRows.length ?? 0) === 0 && (
                          <p className="text-xs px-1" style={{ color: 'var(--subtle)' }}>No blacklisted wallets.</p>
                        )}
                        {blacklist?.blacklistRows.map((row) => (
                          <motion.div key={row.id}
                            initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }}
                            className="rounded-2xl p-4 space-y-2"
                            style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="mono text-xs flex-1 truncate font-semibold" style={{ color: 'var(--ink)' }}>
                                {row.address}
                              </span>
                              <span className="text-[10px] tabular-nums" style={{ color: 'var(--muted)' }}>
                                {new Date(row.blacklisted_at).toLocaleDateString()}
                              </span>
                            </div>
                            {row.reason && (
                              <p className="text-xs" style={{ color: 'var(--subtle)' }}>Reason: {row.reason}</p>
                            )}
                            <p className="text-[10px] font-mono" style={{ color: 'var(--muted)' }}>
                              By: {row.blacklisted_by.slice(0, 10)}…
                            </p>
                            <button
                              onClick={() => {
                                void blacklist.unblacklistWallet(row.address).then(() => {
                                  toast.success(`${row.address.slice(0, 8)}… removed from blacklist.`)
                                })
                              }}
                              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold min-h-[36px] hover:opacity-85 transition-opacity"
                              style={{ background: 'rgba(26,128,71,0.10)', color: 'var(--bullish)', border: '1px solid rgba(26,128,71,0.25)' }}>
                              <UserMinus size={11} /> Remove
                            </button>
                          </motion.div>
                        ))}
                      </div>
                    </div>
                  )}

                </div>
              </>
            )}
          </motion.div>

          {/* ── Blacklist confirmation dialog ──────────────────────────── */}
          <AnimatePresence>
            {blConfirm && (
              <>
                <motion.div
                  key="bl-backdrop"
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                  className="fixed inset-0 z-[60]"
                  style={{ background: 'rgba(0,0,0,0.45)' }}
                  onClick={() => setBlConfirm(null)}
                />
                <motion.div
                  key="bl-dialog"
                  initial={{ opacity: 0, scale: 0.92 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.92 }}
                  transition={{ type: 'spring', stiffness: 400, damping: 35 }}
                  className="fixed inset-x-4 z-[61] mx-auto rounded-3xl p-6 space-y-4"
                  style={{ maxWidth: 360, top: '50%', transform: 'translateY(-50%)', background: 'var(--sheet-bg)', border: '1px solid var(--border)', boxShadow: '0 24px 48px rgba(0,0,0,0.24)' }}>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0"
                      style={{ background: 'rgba(186,43,76,0.10)' }}>
                      <Ban size={18} style={{ color: 'var(--bearish)' }} />
                    </div>
                    <div>
                      <p className="font-semibold text-sm" style={{ color: 'var(--ink)' }}>Confirm blacklist?</p>
                      <p className="text-xs mt-0.5 break-all font-mono" style={{ color: 'var(--subtle)' }}>
                        {blConfirm}
                      </p>
                    </div>
                  </div>
                  <p className="text-xs leading-relaxed" style={{ color: 'var(--subtle)' }}>
                    Blacklisting a wallet removes their votes from all sentiment counts and hides
                    their reviews platform-wide. This cannot be undone without manual restoration.
                  </p>
                  {blReason && (
                    <p className="text-xs px-3 py-2 rounded-lg italic" style={{ background: 'var(--surface-muted)', color: 'var(--ink-2)' }}>
                      Reason: {blReason}
                    </p>
                  )}
                  <div className="flex gap-3">
                    <button onClick={() => setBlConfirm(null)}
                      className="flex-1 py-3 rounded-xl text-sm font-semibold min-h-[44px] hover:opacity-80 transition-opacity"
                      style={{ background: 'var(--surface-muted)', color: 'var(--ink-2)', border: '1px solid var(--border)' }}>
                      Cancel
                    </button>
                    <button
                      onClick={() => {
                        if (!blConfirm) return
                        void blacklist?.blacklistWallet(blConfirm, blReason || undefined).then(() => {
                          toast.success(`${blConfirm.slice(0, 8)}… blacklisted.`)
                          setBlInput('')
                          setBlReason('')
                          setBlConfirm(null)
                        })
                      }}
                      className="flex-1 py-3 rounded-xl text-sm font-semibold min-h-[44px] transition-all hover:opacity-85"
                      style={{ background: 'rgba(186,43,76,0.90)', color: '#fff' }}>
                      Blacklist
                    </button>
                  </div>
                </motion.div>
              </>
            )}
          </AnimatePresence>

          {/* ── Reinstate confirmation dialog ──────────────────────────── */}
          <AnimatePresence>
            {reinstateConfirm && (
              <>
                <motion.div
                  key="reinstate-backdrop"
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                  className="fixed inset-0 z-[60]"
                  style={{ background: 'rgba(0,0,0,0.45)' }}
                  onClick={() => setReinstateConfirm(null)}
                />
                <motion.div
                  key="reinstate-dialog"
                  initial={{ opacity: 0, scale: 0.92 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.92 }}
                  transition={{ type: 'spring', stiffness: 400, damping: 35 }}
                  className="fixed inset-x-4 z-[61] mx-auto rounded-3xl p-6 space-y-4"
                  style={{ maxWidth: 360, top: '50%', transform: 'translateY(-50%)', background: 'var(--sheet-bg)', border: '1px solid var(--border)', boxShadow: '0 24px 48px rgba(0,0,0,0.24)' }}>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0"
                      style={{ background: 'rgba(16,185,129,0.10)' }}>
                      <RotateCcw size={18} style={{ color: 'var(--bullish)' }} />
                    </div>
                    <div>
                      <p className="font-semibold text-sm" style={{ color: 'var(--ink)' }}>Reinstate project?</p>
                      <p className="text-xs mt-0.5" style={{ color: 'var(--subtle)' }}>
                        This will restore <strong>{reinstateConfirm.name}</strong> to Active and make it visible in Discover.
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <button onClick={() => setReinstateConfirm(null)}
                      className="flex-1 py-3 rounded-xl text-sm font-semibold min-h-[44px] transition-all hover:opacity-80"
                      style={{ background: 'var(--surface-muted)', color: 'var(--ink-2)', border: '1px solid var(--border)' }}>
                      Cancel
                    </button>
                    <button onClick={() => { void handleReinstate(reinstateConfirm.id, reinstateConfirm.name) }}
                      className="flex-1 py-3 rounded-xl text-sm font-semibold min-h-[44px] transition-all hover:opacity-85"
                      style={{ background: 'var(--bullish)', color: 'var(--bg)' }}>
                      Reinstate
                    </button>
                  </div>
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </>
      )}
    </AnimatePresence>
  )
}

// ── ProjectManagementRow sub-component ────────────────────────────────────────
interface ProjectRowProps {
  project: Project
  isEditing: boolean
  editForm: Partial<ProjectOverride>
  setEditForm: (f: Partial<ProjectOverride>) => void
  isSelected: boolean
  onToggleSelect: () => void
  onEdit: () => void
  onSave: () => void
  onCancel: () => void
  onStatusChange: (s: ProjectStatus) => void
  onReinstate: () => void
  onRemoveLogo?: () => void
  statusOptions: { value: ProjectStatus; label: string; color: string }[]
  getStatusColor: (s: string) => string
  isInactive: boolean
}

function ProjectManagementRow({
  project, isEditing, editForm, setEditForm, isSelected, onToggleSelect,
  onEdit, onSave, onCancel, onStatusChange, onReinstate, onRemoveLogo,
  statusOptions, getStatusColor, isInactive,
}: ProjectRowProps) {
  const status = project.status ?? 'active'
  return (
    <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl overflow-hidden"
      style={{ border: `1px solid ${isSelected ? 'var(--accent)' : 'var(--border)'}`, background: isSelected ? 'rgba(26,92,255,0.04)' : 'var(--surface-muted)' }}>
      {/* Header row */}
      <div className="flex items-center gap-3 px-4 py-3">
        <input type="checkbox" checked={isSelected} onChange={onToggleSelect}
          className="w-4 h-4 rounded flex-shrink-0" />
        <ProjectLogo project={project} size="sm" />
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold truncate" style={{ color: 'var(--ink)' }}>{project.name}</p>
          <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full"
            style={{ background: `${getStatusColor(status)}22`, color: getStatusColor(status) }}>
            {status.replace('_', ' ')}
          </span>
        </div>
        {/* Quick status dropdown */}
        <select value={status}
          onChange={(e) => onStatusChange(e.target.value as ProjectStatus)}
          className="px-2 py-1.5 rounded-xl text-xs border bg-transparent outline-none min-h-[36px] flex-shrink-0"
          style={{ borderColor: 'var(--border)', color: 'var(--ink)', fontFamily: "'DM Sans', sans-serif" }}>
          {statusOptions.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
        {isInactive && (
          <button onClick={onReinstate}
            className="flex items-center gap-1 px-2 py-1.5 rounded-xl text-xs font-semibold min-h-[36px] flex-shrink-0 transition-all hover:opacity-85"
            style={{ background: 'rgba(16,185,129,0.10)', color: 'var(--bullish)', border: '1px solid rgba(16,185,129,0.20)' }}>
            <RotateCcw size={11} /> Reinstate
          </button>
        )}
        {project.logoUrl && onRemoveLogo && (
          <button onClick={onRemoveLogo}
            className="flex items-center gap-1 px-2 py-1.5 rounded-xl text-xs font-semibold min-h-[36px] flex-shrink-0 transition-all hover:opacity-85"
            style={{ background: 'rgba(190,24,93,0.08)', color: 'var(--bearish)', border: '1px solid rgba(190,24,93,0.20)' }}
            title="Remove logo">
            <Trash2 size={11} /> Logo
          </button>
        )}
        <button onClick={isEditing ? onCancel : onEdit}
          className="flex items-center gap-1 px-2 py-1.5 rounded-xl text-xs font-semibold min-h-[36px] flex-shrink-0 transition-all hover:opacity-85"
          style={isEditing
            ? { background: 'var(--surface-muted)', color: 'var(--ink-2)', border: '1px solid var(--border)' }
            : { background: 'var(--surface)', color: 'var(--accent)', border: '1px solid var(--border)' }}>
          {isEditing ? <X size={11} /> : <Edit3 size={11} />}
          {isEditing ? 'Cancel' : 'Edit'}
        </button>
      </div>

      {/* Inline edit form */}
      <AnimatePresence>
        {isEditing && (
          <motion.div
            initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}
            style={{ overflow: 'hidden', borderTop: '1px solid var(--border)' }}>
            <div className="px-4 py-4 space-y-3">
              {(['name', 'tagline', 'website', 'status_note'] as const).map((field) => (
                <div key={field} className="space-y-1">
                  <p className="text-xs capitalize" style={{ color: 'var(--muted)' }}>
                    {field === 'status_note' ? 'Status note' : field}
                  </p>
                  <input type="text"
                    value={(editForm[field] ?? '')}
                    onChange={(e) => setEditForm({ ...editForm, [field]: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl text-sm border bg-transparent outline-none min-h-[40px]"
                    style={{ borderColor: 'var(--border)', color: 'var(--ink)', fontFamily: "'DM Sans', sans-serif" }} />
                </div>
              ))}
              <div className="space-y-1">
                <p className="text-xs" style={{ color: 'var(--muted)' }}>Description</p>
                <textarea rows={3} value={(editForm.description ?? '')}
                  onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                  className="w-full px-3 py-2.5 rounded-xl text-sm border bg-transparent outline-none resize-none"
                  style={{ borderColor: 'var(--border)', color: 'var(--ink)', fontFamily: "'DM Sans', sans-serif" }} />
              </div>
              {/* Hide verified badge */}
              <div className="flex items-center justify-between gap-3 px-4 py-2.5 rounded-xl"
                style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
                <div>
                  <p className="text-sm font-medium" style={{ color: 'var(--ink)' }}>Hide verified badge</p>
                  <p className="text-xs" style={{ color: 'var(--muted)' }}>Suppresses the on-chain verification badge</p>
                </div>
                <button
                  onClick={() => setEditForm({ ...editForm, verified_badge_hidden: !editForm.verified_badge_hidden })}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold min-h-[36px] transition-all"
                  style={editForm.verified_badge_hidden
                    ? { background: 'var(--bearish)', color: 'var(--bg)' }
                    : { background: 'var(--surface-muted)', color: 'var(--muted)', border: '1px solid var(--border)' }}>
                  {editForm.verified_badge_hidden ? <><AlertTriangle size={11} /> Hidden</> : 'Visible'}
                </button>
              </div>
              <button onClick={onSave}
                className="w-full flex items-center justify-center gap-1.5 py-3 rounded-xl text-sm font-semibold min-h-[44px] transition-all hover:opacity-85"
                style={{ background: 'var(--accent)', color: 'var(--bg)' }}>
                <Check size={14} /> Save Changes
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}

// ── PlatformAnalyticsTab sub-component ───────────────────────────────────────

interface PlatformAnalyticsTabProps {
  analytics: PlatformAnalyticsResult
  momentum: UsePlatformMomentumReturn
}

function SkeletonRect({ h = 'h-10' }: { h?: string }) {
  return <div className={`${h} rounded-2xl animate-pulse`} style={{ background: 'var(--surface-muted)' }} />
}

function KpiCard({
  icon: Icon, label, value, sub, color,
}: {
  icon: typeof BarChart2
  label: string
  value: string | number
  sub?: string
  color?: string
}) {
  return (
    <div className="p-4 rounded-2xl space-y-2" style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
      <div className="flex items-center gap-2">
        <div className="w-7 h-7 rounded-xl flex items-center justify-center flex-shrink-0"
          style={{ background: color ? `${color}18` : 'rgba(26,92,255,0.10)' }}>
          <Icon size={14} style={{ color: color ?? 'var(--accent)' }} />
        </div>
        <p className="text-xs font-medium" style={{ color: 'var(--muted)' }}>{label}</p>
      </div>
      <p className="display text-2xl font-bold tabular-nums leading-none" style={{ color: 'var(--ink)' }}>
        {typeof value === 'number' ? value.toLocaleString() : value}
      </p>
      {sub && <p className="text-xs tabular-nums" style={{ color: 'var(--subtle)' }}>{sub}</p>}
    </div>
  )
}

/** Pure-SVG line chart — same approach as TvlSparkline */
function LineChart({ data, labels, color = 'var(--accent)', height = 72 }: {
  data: number[]
  labels: string[]
  color?: string
  height?: number
}) {
  const W = 320
  const H = height
  const PAD = { t: 8, b: 20, l: 0, r: 0 }
  const max = Math.max(...data, 1)
  const pts = data.map((v, i) => {
    const x = PAD.l + (i / (data.length - 1)) * (W - PAD.l - PAD.r)
    const y = PAD.t + (1 - v / max) * (H - PAD.t - PAD.b)
    return `${x},${y}`
  })
  const polyline = pts.join(' ')
  // Filled area
  const areaPath = `M${pts[0]} L${pts.slice(1).join(' L')} L${W - PAD.r},${H - PAD.b} L${PAD.l},${H - PAD.b} Z`

  // Show every 3rd label to avoid crowding
  const labelStep = Math.max(1, Math.floor(data.length / 5))

  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{ width: '100%', height }} preserveAspectRatio="none">
      <defs>
        <linearGradient id="la-grad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.18" />
          <stop offset="100%" stopColor={color} stopOpacity="0.01" />
        </linearGradient>
      </defs>
      <path d={areaPath} fill="url(#la-grad)" />
      <polyline points={polyline} fill="none" stroke={color} strokeWidth="1.8" strokeLinejoin="round" strokeLinecap="round" />
      {data.map((_, i) => {
        if (i % labelStep !== 0 && i !== data.length - 1) return null
        const x = PAD.l + (i / (data.length - 1)) * (W - PAD.l - PAD.r)
        return (
          <text key={i} x={x} y={H - 4} textAnchor="middle"
            style={{ fontSize: 8, fill: 'var(--subtle)', fontFamily: 'DM Sans, sans-serif' }}>
            {labels[i]}
          </text>
        )
      })}
    </svg>
  )
}

/** Pure-SVG bar chart */
function BarChart({ data, labels, color = 'var(--accent)', height = 72 }: {
  data: number[]
  labels: string[]
  color?: string
  height?: number
}) {
  const W = 320
  const H = height
  const PAD = { t: 8, b: 20 }
  const max = Math.max(...data, 1)
  const barW = (W / data.length) * 0.6
  const gap   = W / data.length
  const labelStep = Math.max(1, Math.floor(data.length / 5))

  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{ width: '100%', height }} preserveAspectRatio="none">
      {data.map((v, i) => {
        const barH = ((v / max) * (H - PAD.t - PAD.b))
        const x = i * gap + (gap - barW) / 2
        const y = PAD.t + (H - PAD.t - PAD.b) - barH
        return (
          <g key={i}>
            <rect x={x} y={y} width={barW} height={Math.max(barH, 1)}
              rx="2" fill={color} fillOpacity="0.70" />
            {(i % labelStep === 0 || i === data.length - 1) && (
              <text x={x + barW / 2} y={H - 4} textAnchor="middle"
                style={{ fontSize: 8, fill: 'var(--subtle)', fontFamily: 'DM Sans, sans-serif' }}>
                {labels[i]}
              </text>
            )}
          </g>
        )
      })}
    </svg>
  )
}

function PlatformAnalyticsTab({ analytics, momentum }: PlatformAnalyticsTabProps) {
  const {
    totalVotesAllTime, totalVotesLast7d, totalVotesLast30d,
    uniqueVotersAllTime, uniqueVotersLast7d,
    totalReviewsAllTime, totalReviewsLast7d,
    verifiedProjectCount,
    mostActiveProject7d,
    ecosystemSentiment,
    dailyVoteVolume14d, dailyNewWallets14d, dayLabels14d,
    pollVotersCount, platformVotersCount,
    isLoading, error, refetch,
  } = analytics

  const totalSentiment = ecosystemSentiment.bullish + ecosystemSentiment.neutral + ecosystemSentiment.bearish
  const pct = (n: number) => totalSentiment > 0 ? Math.round((n / totalSentiment) * 100) : 0

  const pollParticipation = platformVotersCount > 0
    ? Math.round((pollVotersCount / platformVotersCount) * 100)
    : 0

  return (
    <div className="space-y-5 pb-6">
      {/* Header + refresh */}
      <div className="flex items-center justify-between">
        <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
          Platform Overview
        </p>
        <button
          onClick={refetch}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium min-h-[36px] hover:opacity-80 transition-opacity"
          style={{ background: 'var(--surface-muted)', color: 'var(--ink-2)', border: '1px solid var(--border)' }}>
          <RefreshCw size={12} />
          Refresh
        </button>
      </div>

      {error && (
        <p className="text-xs px-3 py-2 rounded-xl" style={{ background: 'rgba(186,43,76,0.07)', color: 'var(--bearish)', border: '1px solid rgba(186,43,76,0.20)' }}>
          {error}
        </p>
      )}

      {/* KPI 2x2 grid */}
      {isLoading ? (
        <div className="grid grid-cols-2 gap-3">
          {[0, 1, 2, 3].map((i) => <SkeletonRect key={i} h="h-24" />)}
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3">
          <KpiCard
            icon={TrendingUp}
            label="Total Votes"
            value={totalVotesAllTime}
            sub={`+${totalVotesLast7d} this week · +${totalVotesLast30d} this month`}
            color="var(--accent)"
          />
          <KpiCard
            icon={Users}
            label="Active Wallets (7d)"
            value={uniqueVotersLast7d}
            sub={`${uniqueVotersAllTime.toLocaleString()} all-time unique`}
            color="var(--bullish)"
          />
          <KpiCard
            icon={FileText}
            label="Total Reviews"
            value={totalReviewsAllTime}
            sub={`+${totalReviewsLast7d} this week`}
            color="#7c3aed"
          />
          <KpiCard
            icon={Award}
            label="Verified Projects"
            value={verifiedProjectCount}
            sub={mostActiveProject7d ? `Most active: ${mostActiveProject7d}` : 'No votes this week'}
            color="#d97706"
          />
        </div>
      )}

      {/* 14-day vote volume line chart */}
      <div className="rounded-2xl p-4 space-y-2" style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
        <p className="text-xs font-semibold" style={{ color: 'var(--ink-2)' }}>Vote Volume — 14 days</p>
        {isLoading ? <SkeletonRect h="h-20" /> : (
          <LineChart data={dailyVoteVolume14d} labels={dayLabels14d} color="var(--accent)" height={80} />
        )}
      </div>

      {/* 14-day new wallets bar chart */}
      <div className="rounded-2xl p-4 space-y-2" style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
        <p className="text-xs font-semibold" style={{ color: 'var(--ink-2)' }}>New Wallets — 14 days</p>
        {isLoading ? <SkeletonRect h="h-20" /> : (
          <BarChart data={dailyNewWallets14d} labels={dayLabels14d} color="var(--bullish)" height={80} />
        )}
      </div>

      {/* Ecosystem sentiment */}
      <div className="rounded-2xl p-4 space-y-3" style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
        <p className="text-xs font-semibold" style={{ color: 'var(--ink-2)' }}>Ecosystem Sentiment</p>
        {isLoading ? <SkeletonRect h="h-16" /> : (
          <div className="space-y-2.5">
            {[
              { label: 'Bullish', value: ecosystemSentiment.bullish, p: pct(ecosystemSentiment.bullish), color: 'var(--bullish)' },
              { label: 'Neutral', value: ecosystemSentiment.neutral, p: pct(ecosystemSentiment.neutral), color: 'var(--neutral)' },
              { label: 'Bearish', value: ecosystemSentiment.bearish, p: pct(ecosystemSentiment.bearish), color: 'var(--bearish)' },
            ].map(({ label, value, p, color }) => (
              <div key={label} className="space-y-1">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold tabular-nums" style={{ color }}>{p}%</p>
                  <p className="text-xs tabular-nums" style={{ color: 'var(--subtle)' }}>{value.toLocaleString()} votes</p>
                </div>
                <div className="h-1.5 rounded-full overflow-hidden" style={{ background: 'var(--border)' }}>
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{ width: `${p}%`, background: color }}
                  />
                </div>
                <p className="text-[10px]" style={{ color: 'var(--muted)' }}>{label}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Poll participation rate */}
      <div className="rounded-2xl px-4 py-3 flex items-center justify-between gap-3"
        style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
        <div>
          <p className="text-xs font-semibold" style={{ color: 'var(--ink-2)' }}>Poll Participation Rate</p>
          <p className="text-xs mt-0.5" style={{ color: 'var(--subtle)' }}>
            Unique poll voters vs. total platform voters
          </p>
        </div>
        {isLoading ? (
          <div className="w-16 h-8 rounded-xl animate-pulse" style={{ background: 'var(--surface)' }} />
        ) : (
          <p className="display text-2xl font-bold tabular-nums" style={{ color: 'var(--accent)' }}>
            {pollParticipation}%
          </p>
        )}
      </div>

      {/* Most active project callout */}
      {!isLoading && mostActiveProject7d && (
        <div className="rounded-2xl px-4 py-3 flex items-center gap-3"
          style={{ background: 'rgba(26,92,255,0.06)', border: '1px solid rgba(26,92,255,0.20)' }}>
          <TrendingUp size={16} style={{ color: 'var(--accent)', flexShrink: 0 }} />
          <div>
            <p className="text-xs font-semibold" style={{ color: 'var(--accent)' }}>Most Active This Week</p>
            <p className="text-sm font-bold" style={{ color: 'var(--ink)' }}>{mostActiveProject7d}</p>
          </div>
        </div>
      )}

      {/* ── Community Momentum diagnostics ──────────────────────────────────── */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
            Community Momentum
          </p>
          {momentum.error && (
            <p className="text-[10px]" style={{ color: 'var(--bearish)' }}>Momentum data unavailable</p>
          )}
        </div>

        <p className="text-[11px] leading-relaxed" style={{ color: 'var(--muted)' }}>
          Read-only diagnostic view. Scores are derived from on-chain activity — votes, reviews, boosts, and new-wallet participation. No manual overrides.
        </p>

        {momentum.isLoading ? (
          <div className="space-y-2">
            {[0, 1, 2].map((i) => <SkeletonRect key={i} h="h-14" />)}
          </div>
        ) : momentum.ranked.length === 0 ? (
          <div className="rounded-2xl px-4 py-3 text-center"
            style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
            <p className="text-xs" style={{ color: 'var(--muted)' }}>
              No on-chain activity found — momentum scores require at least one vote, review, or boost.
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {momentum.ranked.map((result, rank) => {
              const sentimentPct = result.signals.sentimentScore
              const sentimentColor = sentimentPct === null ? 'var(--muted)'
                : sentimentPct >= 60 ? 'var(--bullish)'
                : sentimentPct >= 40 ? 'var(--neutral)'
                : 'var(--bearish)'
              return (
                <div key={result.projectSlug}
                  className="rounded-2xl p-3 space-y-2"
                  style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
                  {/* Row 1: rank + slug + momentum index */}
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-[10px] font-bold tabular-nums w-5 flex-shrink-0"
                        style={{ color: rank === 0 ? 'var(--accent)' : 'var(--muted)' }}>
                        #{rank + 1}
                      </span>
                      <span className="text-sm font-semibold truncate" style={{ color: 'var(--ink)' }}>
                        {result.projectSlug}
                      </span>
                      {result.signals.insufficientHistory && (
                        <span className="text-[9px] px-1.5 py-0.5 rounded-full flex-shrink-0"
                          style={{ background: 'rgba(217,119,6,0.12)', color: '#d97706' }}>
                          new
                        </span>
                      )}
                    </div>
                    {/* Momentum index badge */}
                    <div className="flex items-center gap-1 flex-shrink-0">
                      <span className="text-[10px] font-medium" style={{ color: 'var(--muted)' }}>M</span>
                      <span className="display text-lg font-bold tabular-nums leading-none"
                        style={{ color: result.momentumIndex >= 60 ? 'var(--bullish)' : result.momentumIndex >= 30 ? 'var(--accent)' : 'var(--muted)' }}>
                        {result.momentumIndex}
                      </span>
                    </div>
                  </div>

                  {/* Row 2: signal pills */}
                  <div className="flex flex-wrap gap-1.5">
                    <span className="text-[10px] px-2 py-0.5 rounded-full tabular-nums"
                      style={{ background: 'var(--surface)', color: 'var(--ink-2)', border: '1px solid var(--border)' }}>
                      {result.signals.votes.d7}v 7d
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full tabular-nums"
                      style={{ background: 'var(--surface)', color: 'var(--ink-2)', border: '1px solid var(--border)' }}>
                      {result.signals.reviews.d7}r 7d
                    </span>
                    {result.signals.boosts.d7 > 0 && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full tabular-nums"
                        style={{ background: 'var(--surface)', color: 'var(--ink-2)', border: '1px solid var(--border)' }}>
                        {result.signals.boosts.d7}b 7d
                      </span>
                    )}
                    {result.signals.newParticipants7d > 0 && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full"
                        style={{ background: 'rgba(26,92,255,0.08)', color: 'var(--accent)', border: '1px solid rgba(26,92,255,0.18)' }}>
                        +{result.signals.newParticipants7d} new
                      </span>
                    )}
                    {sentimentPct !== null && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full tabular-nums"
                        style={{ background: 'var(--surface)', color: sentimentColor, border: '1px solid var(--border)' }}>
                        {sentimentPct}% bullish
                      </span>
                    )}
                  </div>

                  {/* Row 3: explainers */}
                  <p className="text-[10px] leading-relaxed" style={{ color: 'var(--subtle)' }}>
                    {result.explainers.join(' · ')}
                  </p>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}

// ── Admin Profiles tab ────────────────────────────────────────────────────────

interface ProfileAdminRow {
  user_id: string
  wallet_address: string
  username: string | null
  display_name: string | null
  wallet_visibility: string
  created_at: string
  updated_at: string
}

interface AdminProfilesTabProps {
  supabase: SupabaseClient | null
}

/**
 * Admin-only profiles management tab.
 *
 * Capabilities:
 *  - Search profiles by username or display name
 *  - View userId, wallet address, username, display name, wallet visibility
 *  - Moderate usernames (clear a username to free it)
 *
 * Admin visibility: this tab shows wallet addresses regardless of walletVisibility.
 * That is intentional — admins need wallet addresses for moderation.
 * These addresses are NOT exposed through public endpoints or public UI.
 *
 * Reserved username enforcement is handled by Supabase unique constraint +
 * validateUsername() in useProfile.ts — the admin can clear a username to free it.
 */
function AdminProfilesTab({ supabase: sb }: AdminProfilesTabProps) {
  const [search, setSearch]         = useState('')
  const [profiles, setProfiles]     = useState<ProfileAdminRow[]>([])
  const [isLoading, setIsLoading]   = useState(false)
  const [error, setError]           = useState<string | null>(null)
  const [clearingId, setClearingId] = useState<string | null>(null)
  const [clearedIds, setClearedIds] = useState<Set<string>>(new Set())
  const { address: adminAddress }   = useAccount()

  const runSearch = useCallback(async () => {
    if (!sb) { setError('Supabase not configured.'); return }
    setIsLoading(true)
    setError(null)
    try {
      const q = search.trim().toLowerCase()
      let query = sb.from('profiles').select(
        'user_id, wallet_address, username, display_name, wallet_visibility, created_at, updated_at'
      ).order('created_at', { ascending: false }).limit(50)
      if (q) {
        // Filter by username or display_name (partial, case-insensitive)
        query = query.or(`username.ilike.%${q}%,display_name.ilike.%${q}%,wallet_address.ilike.%${q}%`)
      }
      const { data, error: fetchErr } = await query
      if (fetchErr) throw new Error((fetchErr as { message?: string }).message ?? 'Query failed')
      setProfiles((data ?? []))
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Query failed')
    } finally {
      setIsLoading(false)
    }
  }, [sb, search])

  // Load profiles on mount — this is data synchronisation with Supabase (external system),
  // which is precisely the use case useEffect is designed for.
  // oxlint-disable-next-line react/set-state-in-effect
  useEffect(() => { void runSearch() }, []) // eslint-disable-line react-hooks/exhaustive-deps

  const clearUsername = useCallback(async (userId: string) => {
    if (!sb || !adminAddress) return
    const adminClient = getAdminClient(adminAddress)
    if (!adminClient) { toast.error('Admin client not available.'); return }
    setClearingId(userId)
    try {
      const { error: updateErr } = await adminClient
        .from('profiles')
        .update({ username: null, updated_at: new Date().toISOString() })
        .eq('user_id', userId)
      if (updateErr) throw new Error((updateErr as { message?: string }).message ?? 'Update failed')
      setClearedIds((prev) => new Set([...prev, userId]))
      setProfiles((prev) => prev.map((p) => p.user_id === userId ? { ...p, username: null } : p))
      toast.success('Username cleared.')
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to clear username')
    } finally {
      setClearingId(null)
    }
  }, [sb, adminAddress])

  if (!sb) {
    return (
      <div className="py-12 text-center text-sm" style={{ color: 'var(--muted)' }}>
        Supabase not configured. Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to enable profile management.
      </div>
    )
  }

  return (
    <div className="space-y-4 pb-6">
      <div>
        <h3 className="text-base font-semibold mb-1" style={{ color: 'var(--ink)' }}>Profile Management</h3>
        <p className="text-xs" style={{ color: 'var(--muted)' }}>
          Admin view — wallet addresses visible regardless of user privacy setting.
          Do not share wallet addresses from this panel via public channels.
        </p>
      </div>

      {/* Search bar */}
      <div className="flex gap-2">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') void runSearch() }}
          placeholder="Search username, display name, or wallet…"
          className="flex-1 px-3 py-2 rounded-xl text-sm border bg-transparent outline-none min-h-[44px]"
          style={{ borderColor: 'var(--border)', color: 'var(--ink)', fontFamily: "'DM Sans', sans-serif" }}
        />
        <button
          onClick={() => void runSearch()}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold min-h-[44px] transition-all hover:opacity-85"
          style={{ background: 'var(--accent)', color: 'var(--bg)' }}
        >
          Search
        </button>
      </div>

      {/* Error */}
      {error && (
        <div className="px-4 py-3 rounded-xl text-sm"
          style={{ background: 'rgba(186,43,76,0.06)', border: '1px solid rgba(186,43,76,0.15)', color: 'var(--bearish)' }}>
          {error}
        </div>
      )}

      {/* Loading */}
      {isLoading && (
        <div className="space-y-2">
          {[0,1,2].map((i) => (
            <div key={i} className="h-16 rounded-xl animate-pulse" style={{ background: 'var(--surface-muted)' }} />
          ))}
        </div>
      )}

      {/* Results */}
      {!isLoading && profiles.length === 0 && !error && (
        <div className="py-8 text-center text-sm" style={{ color: 'var(--muted)' }}>
          No profiles found.
        </div>
      )}

      {!isLoading && profiles.length > 0 && (
        <div className="space-y-2">
          <p className="text-xs" style={{ color: 'var(--subtle)' }}>{profiles.length} result{profiles.length !== 1 ? 's' : ''}</p>
          {profiles.map((p) => (
            <div key={p.user_id}
              className="rounded-xl p-3 space-y-1.5"
              style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
              {/* Top row: username + display name */}
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0 flex-1 space-y-0.5">
                  {p.username ? (
                    <p className="text-sm font-semibold" style={{ color: 'var(--accent)' }}>@{p.username}</p>
                  ) : (
                    <p className="text-sm italic" style={{ color: 'var(--subtle)' }}>No username</p>
                  )}
                  {p.display_name && (
                    <p className="text-xs" style={{ color: 'var(--ink-2)' }}>{p.display_name}</p>
                  )}
                </div>
                {/* Wallet visibility badge */}
                <span
                  className="flex-shrink-0 text-[10px] font-semibold px-2 py-0.5 rounded-full"
                  style={p.wallet_visibility === 'public'
                    ? { background: 'rgba(26,128,71,0.1)', color: 'var(--bullish)' }
                    : { background: 'var(--surface-muted)', color: 'var(--subtle)' }}
                >
                  Wallet {p.wallet_visibility}
                </span>
              </div>

              {/* Admin identity fields */}
              <div className="space-y-0.5">
                <p className="text-[10px] font-medium" style={{ color: 'var(--subtle)' }}>
                  userId: <span className="mono" style={{ color: 'var(--ink-2)' }}>{p.user_id}</span>
                </p>
                <p className="text-[10px] font-medium" style={{ color: 'var(--subtle)' }}>
                  wallet: <span className="mono" style={{ color: 'var(--ink-2)' }}>{p.wallet_address}</span>
                </p>
                <p className="text-[10px]" style={{ color: 'var(--subtle)' }}>
                  joined {new Date(p.created_at).toLocaleDateString('en', { year: 'numeric', month: 'short', day: 'numeric' })}
                </p>
              </div>

              {/* Actions */}
              {p.username && !clearedIds.has(p.user_id) && (
                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={() => void clearUsername(p.user_id)}
                    disabled={clearingId === p.user_id}
                    className="flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-lg min-h-[32px] transition-all hover:opacity-85"
                    style={{ background: 'rgba(186,43,76,0.08)', color: 'var(--bearish)', border: '1px solid rgba(186,43,76,0.2)' }}
                  >
                    <Trash2 size={11} />
                    {clearingId === p.user_id ? 'Clearing…' : 'Clear username'}
                  </button>
                  <span className="text-[10px]" style={{ color: 'var(--subtle)' }}>
                    Frees @{p.username} for re-registration
                  </span>
                </div>
              )}
              {clearedIds.has(p.user_id) && (
                <p className="text-[10px]" style={{ color: 'var(--bullish)' }}>Username cleared.</p>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
