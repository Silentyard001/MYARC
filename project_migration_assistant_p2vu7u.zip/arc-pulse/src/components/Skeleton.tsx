/**
 * Skeleton components
 *
 * Used during Web3 provider hydration and data-fetching states.
 * SkeletonCard  — placeholder for a ProjectCard
 * SkeletonRow   — placeholder for a LeaderboardRow
 * SkeletonPoll  — placeholder for a PollWidget
 * SkeletonStats — placeholder for the hero stats strip
 */

import { motion } from 'framer-motion'

// Shared shimmer animation
const shimmer = {
  initial: { opacity: 0.5 },
  animate: { opacity: [0.5, 0.85, 0.5] },
  transition: { duration: 1.6, repeat: Infinity, ease: 'easeInOut' as const },
}

function Bone({ className = '', style = {} }: { className?: string; style?: React.CSSProperties }) {
  return (
    <motion.div
      {...shimmer}
      className={`rounded-lg ${className}`}
      style={{ background: 'var(--surface-muted)', ...style }}
    />
  )
}

export function SkeletonStats() {
  return (
    <div className="grid grid-cols-3 gap-3 pt-6 pb-4">
      {[0, 1, 2].map((i) => (
        <div
          key={i}
          className="rounded-2xl p-3.5"
          style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}
        >
          <Bone className="h-6 w-12 mx-auto mb-1.5" />
          <Bone className="h-3 w-16 mx-auto" />
        </div>
      ))}
    </div>
  )
}

export function SkeletonCard() {
  return (
    <div
      className="rounded-2xl border p-5 space-y-4"
      style={{
        background: 'var(--surface)',
        borderColor: 'var(--border)',
      }}
    >
      {/* Header */}
      <div className="flex items-start gap-3">
        <Bone className="w-11 h-11 rounded-xl flex-shrink-0" />
        <div className="flex-1 space-y-2 pt-0.5">
          <Bone className="h-4 w-32" />
          <Bone className="h-3 w-48" />
        </div>
      </div>

      {/* Tags */}
      <div className="flex gap-2">
        <Bone className="h-5 w-14 rounded-full" />
        <Bone className="h-5 w-20 rounded-full" />
        <Bone className="h-5 w-12 rounded-full ml-auto" />
      </div>

      {/* Vote bar */}
      <Bone className="h-2 w-full rounded-full" />

      {/* Vote buttons */}
      <div className="flex gap-2">
        <Bone className="flex-1 h-[60px] rounded-xl" />
        <Bone className="flex-1 h-[60px] rounded-xl" />
        <Bone className="flex-1 h-[60px] rounded-xl" />
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between">
        <Bone className="h-4 w-24" />
        <Bone className="h-4 w-20" />
      </div>
    </div>
  )
}

export function SkeletonRow() {
  return (
    <div
      className="flex items-center gap-3 px-4 py-3.5 rounded-2xl border"
      style={{ background: 'var(--surface)', borderColor: 'var(--border)', minHeight: '60px' }}
    >
      <Bone className="w-6 h-4 rounded" />
      <Bone className="w-9 h-9 rounded-xl flex-shrink-0" />
      <div className="flex-1 space-y-2">
        <div className="flex items-center justify-between">
          <Bone className="h-4 w-28" />
          <Bone className="h-4 w-10" />
        </div>
        <Bone className="h-1.5 w-full rounded-full" />
      </div>
    </div>
  )
}

/** Alias for LeaderboardRow skeleton (same shape as SkeletonRow) */
export { SkeletonRow as SkeletonLeaderboardRow }

export function SkeletonPollWidget() {
  return <SkeletonPoll />
}

export function SkeletonPoll() {
  return (
    <div
      className="rounded-2xl border p-5 space-y-4"
      style={{
        background: 'var(--surface)',
        borderColor: 'var(--border)',
      }}
    >
      <div className="space-y-2">
        <Bone className="h-3 w-16 rounded-full" />
        <Bone className="h-5 w-3/4" />
      </div>
      <Bone className="h-3 w-28" />
      <div className="space-y-2.5">
        {[0, 1, 2, 3].map((i) => (
          <Bone key={i} className="h-11 w-full rounded-xl" />
        ))}
      </div>
    </div>
  )
}
