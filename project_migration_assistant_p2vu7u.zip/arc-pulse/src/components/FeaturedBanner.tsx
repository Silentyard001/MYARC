/**
 * FeaturedBanner
 *
 * A curated presentation stage for featured projects.
 * Intentionally distinct from the regular project feed — more breathing room,
 * a subtly elevated surface, and the silver sheen system.
 *
 * Visual intent:
 *   Regular cards = information
 *   Featured cards = presentation
 *
 * The difference is achieved through surface, spacing, and typography weight —
 * not through bright borders, glow, or added decoration.
 */
import { useRef } from 'react'
import { motion } from 'framer-motion'
import { Star } from 'lucide-react'
import type { Project } from '../data/projects'
import { AnimatedNumber } from './AnimatedNumber'
import { VoteBar } from './VoteBar'
import { ProjectLogo } from './ProjectLogo'

interface FeaturedBannerProps {
  projects: Project[]
  onSelect: (project: Project) => void
}

export function FeaturedBanner({ projects, onSelect }: FeaturedBannerProps) {
  const featured = projects.filter((p) => p.featured)
  const scrollRef = useRef<HTMLDivElement>(null)

  if (featured.length === 0) return null

  return (
    <div
      className="rounded-2xl overflow-hidden"
      style={{
        background: 'var(--featured-stage-bg)',
        border: '1px solid var(--featured-stage-border)',
        /* Faint inner top-edge highlight — gives the stage a subtle illuminated
           quality in dark mode without a heavy border or glow effect.
           In light mode, var(--card-shadow) adds a gentle outer lift instead. */
        boxShadow: 'inset 0 1px 0 rgba(172,198,233,0.10), var(--card-shadow)',
        padding: '20px',
      }}
    >
      {/* Section label — slightly more weight than Trending/other labels */}
      <div className="flex items-center gap-2 mb-4">
        <Star
          size={12}
          strokeWidth={0}
          fill="var(--accent)"
          style={{ color: 'var(--accent)', flexShrink: 0 }}
        />
        <span
          className="text-xs font-semibold uppercase tracking-widest"
          style={{ color: 'var(--accent)', letterSpacing: '0.09em' }}
        >
          Featured
        </span>
      </div>

      {/* Scroll strip */}
      <div
        ref={scrollRef}
        className="flex gap-3 overflow-x-auto"
        style={{ scrollbarWidth: 'none', WebkitOverflowScrolling: 'touch', paddingBottom: '2px' }}
      >
        {featured.map((project, i) => (
          <FeaturedCard key={project.id} project={project} onSelect={onSelect} index={i} />
        ))}
      </div>
    </div>
  )
}

function FeaturedCard({
  project,
  onSelect,
  index,
}: {
  project: Project
  onSelect: (p: Project) => void
  index: number
}) {
  const total = project.votes.bullish + project.votes.neutral + project.votes.bearish
  const bullPct = total > 0 ? Math.round((project.votes.bullish / total) * 100) : 0

  // Stagger the first reflection so cards don't all sweep simultaneously.
  // Base delay 1.4 s + 0.9 s per card index; set as a CSS custom property
  // so the ::after pseudo-element inherits it (inline animationDelay only
  // affects the element itself, not its pseudo-elements).
  const shineDelay = `${1.4 + index * 0.9}s`

  return (
    <motion.button
      initial={{ opacity: 0, x: 12 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.07 }}
      whileTap={{ scale: 0.97 }}
      onClick={() => onSelect(project)}
      className="featured-card-shine flex-shrink-0 w-52 rounded-xl p-4 text-left relative transition-opacity hover:opacity-90"
      style={{
        background: 'var(--surface-featured)',
        border: '1px solid var(--accent)',
        // CSS custom property — inherited by ::after, controls animation-delay
        // for both the sweep and the border glow.
        ['--shine-delay' as string]: shineDelay,
      }}
    >
      {/* All content above the sheen layers */}
      <div className="featured-card-content space-y-3">
        {/* Logo + name — slightly stronger presentation than a regular card */}
        <div className="flex items-center gap-2.5">
          <ProjectLogo project={project} size="sm" />
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span
                className="display font-bold text-sm leading-tight truncate"
                style={{ color: 'var(--ink)' }}
              >
                {project.name}
              </span>
            </div>
            <p className="text-xs leading-snug truncate mt-0.5" style={{ color: 'var(--muted)' }}>
              {project.tagline}
            </p>
          </div>
        </div>

        {/* Sentiment bar */}
        <VoteBar votes={project.votes} size="sm" />

        {/* Bullish % — concise sentiment readout */}
        <div className="flex items-center justify-between">
          <span className="text-[11px]" style={{ color: 'var(--subtle)' }}>
            Community sentiment
          </span>
          <span
            className="text-[11px] font-semibold tabular-nums"
            style={{
              color:
                bullPct >= 60 ? 'var(--bullish)'
                : bullPct <= 35 ? 'var(--bearish)'
                : 'var(--neutral)',
            }}
          >
            <AnimatedNumber value={bullPct} suffix="% bullish" duration={0.4} aria-hidden="true" />
          </span>
        </div>
      </div>
    </motion.button>
  )
}
