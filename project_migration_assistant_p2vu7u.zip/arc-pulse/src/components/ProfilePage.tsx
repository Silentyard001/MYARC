/**
 * ProfilePage
 *
 * Public wallet profile page — fully readable without a wallet connected.
 * Route: /profile/:address
 *
 * Shows: identity (username / display name / bio / wallet), reputation tier +
 * score, prediction accuracy, full vote history, reviews posted, helpful votes
 * received, and a copy-link button.
 *
 * If the viewer IS the profile owner, an "Edit Profile" button opens the
 * ProfileSettingsModal so they can update their identity without leaving the page.
 */

import { useMemo, useState, useEffect, useRef } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { ArrowLeft, Copy, TrendingUp, TrendingDown, Minus, MessageSquare, ThumbsUp, Target, Edit2, User } from 'lucide-react'
import { toast } from 'sonner'
import { ReputationBadge } from './ReputationBadge'
import { ProfileSettingsModal } from './ProfileSettingsModal'
import { useReputation } from '../hooks/useReputation'
import { fetchPublicProfile } from '../hooks/useProfile'
import type { UserProfile, ProfileUpdatePayload } from '../hooks/useProfile'
import type { AuthStatus } from '../hooks/useAuth'
import { formatUsername, shortAddress } from '../utils/username'
import type { Project, Sentiment } from '../data/projects'
import type { StoredReview } from '../App'

interface ProfilePageProps {
  projects: Project[]
  userVotesByAddress: Record<string, Record<string, Sentiment>>
  reviewOverrides: Record<string, StoredReview[]>
  seedHelpfulDeltas: Record<string, number>
  /** The currently connected wallet address (may differ from the profile address) */
  connectedAddress?: string
  /**
   * The connected user's own profile (passed from App so we don't double-fetch).
   * Only non-null when connectedAddress === profileAddress.
   */
  ownProfile?: UserProfile | null
  /** Passed from App so the settings modal can persist changes. */
  onUpdateProfile?: (payload: ProfileUpdatePayload) => Promise<{ ok: boolean; error?: string }>
  /**
   * When set, overrides the `:address` route param as the profile address.
   * Used by username routing — the wrapper resolves username → wallet address
   * before rendering this component.
   */
  overrideAddress?: string
  /** Phase 3: auth status for the connected wallet. Forwarded to ProfileSettingsModal. */
  authStatus?: AuthStatus
  /** Phase 3: triggers SIWE authentication flow. Forwarded to ProfileSettingsModal. */
  onSignIn?: () => Promise<unknown>
}

function sentimentIcon(s: Sentiment) {
  if (s === 'bullish') return <TrendingUp size={13} style={{ color: 'var(--bullish)' }} />
  if (s === 'bearish') return <TrendingDown size={13} style={{ color: 'var(--bearish)' }} />
  return <Minus size={13} style={{ color: 'var(--neutral)' }} />
}

function sentimentColor(s: Sentiment) {
  if (s === 'bullish') return { background: 'rgba(26,128,71,0.10)', color: 'var(--bullish)' }
  if (s === 'bearish') return { background: 'rgba(186,43,76,0.10)', color: 'var(--bearish)' }
  return { background: 'rgba(107,101,128,0.10)', color: 'var(--neutral)' }
}

export function ProfilePage({
  projects,
  userVotesByAddress,
  reviewOverrides,
  seedHelpfulDeltas,
  connectedAddress,
  ownProfile,
  onUpdateProfile,
  overrideAddress,
  authStatus,
  onSignIn,
}: ProfilePageProps) {
  const { address: routeAddress } = useParams<{ address: string }>()
  const navigate = useNavigate()

  // overrideAddress is set when we arrive via /profile/@username (resolved by wrapper)
  const profileAddress = overrideAddress ?? routeAddress ?? ''
  const isOwnProfile =
    Boolean(connectedAddress) &&
    connectedAddress!.toLowerCase() === profileAddress.toLowerCase()

  // Public profile data (identity fields)
  // For own profile: always use ownProfile prop (live, updated after saves).
  // For other profiles: fetch from Supabase/localStorage asynchronously.
  const [fetchedProfile, setFetchedProfile] = useState<UserProfile | null>(null)
  const lastFetchedAddress = useRef<string>('')
  const [isSettingsOpen, setIsSettingsOpen] = useState(false)

  useEffect(() => {
    if (isOwnProfile) return // own profile comes from ownProfile prop — no fetch needed
    if (lastFetchedAddress.current === profileAddress) return
    lastFetchedAddress.current = profileAddress
    void fetchPublicProfile(profileAddress).then((p) => setFetchedProfile(p))
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profileAddress])

  // Resolved profile: own profile takes priority; fall back to fetched
  const publicProfile: UserProfile | null = isOwnProfile ? (ownProfile ?? null) : fetchedProfile

  const reputation = useReputation({
    address: profileAddress,
    projects,
    userVotes: userVotesByAddress[profileAddress.toLowerCase()] ?? {},
    reviewOverrides,
    seedHelpfulDeltas,
  })

  // Collect all reviews by this address
  const postedReviews = useMemo(() => {
    const result: { project: Project; review: StoredReview }[] = []
    const addr = profileAddress.toLowerCase()
    for (const project of projects) {
      const extras = reviewOverrides[project.id] ?? []
      for (const r of extras) {
        if (r.authorFull.toLowerCase() === addr) result.push({ project, review: r })
      }
      for (const r of project.reviews) {
        if (r.authorFull.toLowerCase() === addr) result.push({ project, review: r })
      }
    }
    return result.sort((a, b) => b.review.timestamp - a.review.timestamp)
  }, [profileAddress, projects, reviewOverrides])

  // Total helpful votes received
  const totalHelpfulReceived = useMemo(() => {
    let total = 0
    const addr = profileAddress.toLowerCase()
    for (const project of projects) {
      const extras = reviewOverrides[project.id] ?? []
      for (const r of extras) {
        if (r.authorFull.toLowerCase() === addr) total += r.helpful
      }
      for (const r of project.reviews) {
        if (r.authorFull.toLowerCase() === addr) {
          total += (seedHelpfulDeltas[r.id] ?? 0) + r.helpful
        }
      }
    }
    return total
  }, [profileAddress, projects, reviewOverrides, seedHelpfulDeltas])

  const voteHistory = useMemo(() =>
    Object.entries(userVotesByAddress[profileAddress.toLowerCase()] ?? {}).map(([projectId, sentiment]) => ({
      projectId,
      sentiment,
      projectName: projects.find((p) => p.id === projectId)?.name ?? projectId,
    })),
  [userVotesByAddress, profileAddress, projects])

  function copyProfileLink() {
    // Prefer @username canonical URL; fall back to wallet-address URL
    const slug = publicProfile?.username
      ? `@${publicProfile.username}`
      : profileAddress
    const url = `${window.location.origin}/profile/${slug}`
    navigator.clipboard.writeText(url).then(
      () => toast('Profile link copied.', { duration: 2000 }),
      () => toast.error('Could not copy link.')
    )
  }

  // ── Identity display helpers ───────────────────────────────────────────────
  const displayedUsername = formatUsername(publicProfile?.username)
  const displayedName     = publicProfile?.displayName || null
  const displayedBio      = publicProfile?.bio ?? null
  const walletLine = (() => {
    if (!publicProfile) return null
    if (publicProfile.walletVisibility === 'public') return shortAddress(publicProfile.walletAddress)
    // walletVisibility === 'hidden': show nothing (omit the wallet line entirely)
    return null
  })()

  return (
    <div className="min-h-dvh" style={{ background: 'var(--bg-gradient)', backgroundAttachment: 'fixed' }}>
      {/* Header */}
      <header
        className="sticky top-0 z-30 px-4 py-3"
        style={{ background: 'var(--nav-bg)', backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)', borderBottom: '1px solid var(--border)' }}
      >
        <div className="max-w-2xl mx-auto flex items-center gap-3">
          <button
            onClick={() => { void navigate(-1) }}
            className="p-2 rounded-xl min-h-[44px] min-w-[44px] flex items-center justify-center transition-opacity hover:opacity-70"
            style={{ background: 'var(--surface-muted)', color: 'var(--muted)' }}
          >
            <ArrowLeft size={18} />
          </button>
          <span className="display font-semibold text-base flex-1" style={{ color: 'var(--ink)' }}>
            {displayedUsername ?? displayedName ?? 'Profile'}
          </span>
          {isOwnProfile && onUpdateProfile && (
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium min-h-[44px] transition-opacity hover:opacity-70"
              style={{ background: 'var(--surface-muted)', color: 'var(--muted)', border: '1px solid var(--border)' }}
            >
              <Edit2 size={13} />
              Edit
            </button>
          )}
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 pb-20 space-y-6 pt-6">
        {/* Identity card */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2 }}
          className="p-5 rounded-2xl space-y-4"
          style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-3 min-w-0 flex-1">
              {/* Avatar */}
              <div className="flex-shrink-0">
                {publicProfile?.avatarUrl ? (
                  <img
                    src={publicProfile.avatarUrl}
                    alt="Avatar"
                    className="w-12 h-12 rounded-full object-cover"
                    style={{ border: '1px solid var(--border)' }}
                    onError={(e) => { (e.target as HTMLImageElement).style.display = 'none' }}
                  />
                ) : (
                  <div className="w-12 h-12 rounded-full flex items-center justify-center"
                    style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
                    <User size={22} style={{ color: 'var(--muted)' }} />
                  </div>
                )}
              </div>

              {/* Identity text */}
              <div className="space-y-1 min-w-0">
                {/* Display name or "Anonymous User" */}
                <p className="display font-semibold text-base leading-tight" style={{ color: 'var(--ink)' }}>
                  {displayedName || 'Anonymous User'}
                </p>

                {/* @username */}
                {displayedUsername && (
                  <p className="text-sm font-medium" style={{ color: 'var(--accent)' }}>
                    {displayedUsername}
                  </p>
                )}

                {/* Wallet line */}
                {walletLine !== null && (
                  <p className="mono text-xs" style={{ color: 'var(--subtle)' }}>
                    {walletLine}
                  </p>
                )}

                {/* Bio */}
                {displayedBio && (
                  <p className="text-sm leading-relaxed pt-0.5" style={{ color: 'var(--ink-2)' }}>
                    {displayedBio}
                  </p>
                )}

                <div className="flex items-center gap-2 flex-wrap pt-1">
                  <ReputationBadge tier={reputation.tier} score={reputation.score} size="md" />
                </div>

                {reputation.predictionAccuracy.total > 0 && (
                  <div className="flex items-center gap-1.5 text-xs" style={{ color: 'var(--muted)' }}>
                    <Target size={12} />
                    <span className="tabular-nums font-semibold" style={{ color: 'var(--ink-2)' }}>
                      {reputation.predictionAccuracy.pct}%
                    </span>
                    <span>
                      accuracy ({reputation.predictionAccuracy.correct}/{reputation.predictionAccuracy.total} predictions)
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Copy link */}
            <button
              onClick={copyProfileLink}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium flex-shrink-0 min-h-[44px] transition-opacity hover:opacity-70"
              style={{ background: 'var(--surface-muted)', color: 'var(--muted)', border: '1px solid var(--border)' }}
            >
              <Copy size={13} />
              Copy link
            </button>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-3 gap-3 pt-1">
            {[
              { label: 'Votes',   value: voteHistory.length,       Icon: TrendingUp   },
              { label: 'Reviews', value: postedReviews.length,      Icon: MessageSquare },
              { label: 'Helpful', value: totalHelpfulReceived,      Icon: ThumbsUp     },
            ].map(({ label, value, Icon }) => (
              <div key={label} className="text-center space-y-0.5 p-2.5 rounded-xl"
                style={{ background: 'var(--surface-muted)' }}>
                <Icon size={14} style={{ color: 'var(--subtle)', margin: '0 auto 2px' }} />
                <p className="display font-bold text-lg tabular-nums" style={{ color: 'var(--ink)' }}>{value}</p>
                <p className="text-xs" style={{ color: 'var(--subtle)' }}>{label}</p>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Vote history */}
        {voteHistory.length > 0 && (
          <motion.section
            initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.08 }}
            className="space-y-2"
          >
            <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
              Votes ({voteHistory.length})
            </p>
            {voteHistory.map(({ projectId, sentiment, projectName }) => (
              <div key={projectId}
                className="flex items-center justify-between px-4 py-3 rounded-xl min-h-[44px]"
                style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
                <span className="text-sm font-medium" style={{ color: 'var(--ink)' }}>{projectName}</span>
                <span className="flex items-center gap-1.5 text-xs font-semibold capitalize px-2 py-1 rounded-full"
                  style={sentimentColor(sentiment)}>
                  {sentimentIcon(sentiment)}
                  {sentiment}
                </span>
              </div>
            ))}
          </motion.section>
        )}

        {/* Reviews posted */}
        {postedReviews.length > 0 && (
          <motion.section
            initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.12 }}
            className="space-y-2"
          >
            <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
              Reviews ({postedReviews.length})
            </p>
            {postedReviews.map(({ project, review }) => (
              <div key={review.id} className="p-4 rounded-2xl space-y-2"
                style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold" style={{ color: 'var(--ink-2)' }}>{project.name}</span>
                  <span className="flex items-center gap-1 text-xs capitalize px-2 py-0.5 rounded-full"
                    style={sentimentColor(review.sentiment)}>
                    {sentimentIcon(review.sentiment)}
                    {review.sentiment}
                  </span>
                </div>
                <p className="text-sm leading-relaxed" style={{ color: 'var(--ink-2)' }}>{review.body}</p>
                {review.helpful > 0 && (
                  <div className="flex items-center gap-1.5 text-xs" style={{ color: 'var(--subtle)' }}>
                    <ThumbsUp size={11} />
                    <span className="tabular-nums">{review.helpful} helpful</span>
                  </div>
                )}
              </div>
            ))}
          </motion.section>
        )}

        {/* Empty state */}
        {voteHistory.length === 0 && postedReviews.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }}
            className="py-16 text-center space-y-2"
          >
            <p className="font-medium" style={{ color: 'var(--ink-2)' }}>
              {displayedName || (displayedUsername ?? 'This user')} has no activity yet
            </p>
            <p className="text-sm" style={{ color: 'var(--subtle)' }}>
              Votes and reviews will appear here once they are cast.
            </p>
          </motion.div>
        )}
      </main>

      {/* Profile settings modal — only renders when viewer is the owner */}
      {isOwnProfile && onUpdateProfile && (
        <ProfileSettingsModal
          isOpen={isSettingsOpen}
          onClose={() => setIsSettingsOpen(false)}
          profile={publicProfile}
          onSave={onUpdateProfile}
          authStatus={authStatus}
          onSignIn={onSignIn}
        />
      )}
    </div>
  )
}
