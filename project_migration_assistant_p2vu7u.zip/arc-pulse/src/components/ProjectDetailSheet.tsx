import { useState, useMemo, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, ThumbsUp, TrendingUp, Minus, TrendingDown, Send, Lock, Globe, Link2, Flag, ExternalLink, BadgeCheck, ShieldCheck, Edit3, Download, BarChart2, Bookmark, BookmarkCheck, AlertCircle, Heart, Check, Pin, MessageSquare, FileText, Bell, Camera, AlertTriangle, EyeOff, Eye, ChevronUp, Zap, Code, Flame } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { toast } from 'sonner'
import { usePublicClient, useWriteContract } from 'wagmi'
import { parseAbi, parseEther } from 'viem'
import { useSimulatedWrite } from '../hooks/useSimulatedWrite'
import { supabase, getAdminClient } from '../lib/supabase'
import type { Project, Sentiment } from '../data/projects'
import { VoteBar } from './VoteBar'
import { AnimatedNumber } from './AnimatedNumber'
import { ProjectLogo } from './ProjectLogo'
import { MilestoneShareCard } from './MilestoneShareCard'
import { useMilestones } from '../hooks/useMilestones'
import type { MomentumResult } from '../lib/momentum'
import { SentimentBadge } from './SentimentBadge'
import { useReputation, TIER_COLORS } from '../hooks/useReputation'
import { useReviewFlags } from '../hooks/useReviewFlags'
import { usePinnedReviews } from '../hooks/usePinnedReviews'
import { useReviewResponses } from '../hooks/useReviewResponses'
import type { ReviewResponse } from '../hooks/useReviewResponses'
import { useModeratedReviews } from '../hooks/useModeratedReviews'
import { useReviewUpvotes } from '../hooks/useReviewUpvotes'
import { useProjectAnalytics } from '../hooks/useProjectAnalytics'
import { ARC_TESTNET_CHAIN_ID } from '../config'
import { slugToBytes32 } from '../utils/projectId'
import type { StoredReview } from '../App'
import { SentimentReport } from './SentimentReport'
import { PulseBadge } from '../widget/PulseBadge'
import { IdentityLabel } from './IdentityLabel'
import { useProfileCache } from '../hooks/useProfileCache'
import type { TaxonomyResult } from '../hooks/useTaxonomy'

const VERIFY_ABI = parseAbi([
  'function verifyProject(bytes32 projectId) payable',
  'function getVerificationFee() view returns (uint256)',
  'function getEffectiveFee(address wallet) view returns (uint256)',
])

const TIP_ABI = parseAbi([
  'function tipReviewer(bytes32 projectId, uint256 reviewIndex) payable',
  'function getTipProtocolFeeBps() view returns (uint256)',
])

/** Preset tip amounts in USDC (Arc 18-decimal native). */
const TIP_PRESETS: { label: string; value: bigint }[] = [
  { label: '0.5',  value: parseEther('0.5') },
  { label: '1',    value: parseEther('1')   },
  { label: '2',    value: parseEther('2')   },
  { label: '5',    value: parseEther('5')   },
]

const BOOST_ABI = parseAbi([
  'function upvoteReview(bytes32 projectId, uint256 reviewIndex) payable',
  'function upvoteProtocolFeeBps() view returns (uint256)',
])

/** Preset boost amounts in USDC (Arc 18-decimal native — same denomination as tips). */
const BOOST_PRESETS: { label: string; value: bigint }[] = [
  { label: '0.01', value: parseEther('0.01') },
  { label: '0.05', value: parseEther('0.05') },
  { label: '0.1',  value: parseEther('0.1')  },
  { label: '0.5',  value: parseEther('0.5')  },
]

// ── Detail sheet tabs ─────────────────────────────────────────────────────────
type SheetTab = 'reviews' | 'analytics'

interface ProjectDetailSheetProps {
  project: Project | null
  userVote: Sentiment | null
  onVote: (projectId: string, sentiment: Sentiment) => void
  onClose: () => void
  onReview: (projectId: string, body: string, sentiment: Sentiment) => void
  onHelpful?: (projectId: string, reviewId: string) => void
  helpfulVoted?: Record<string, boolean>
  isConnected?: boolean
  connectedAddress?: string
  allProjects?: Project[]
  reviewOverrides?: Record<string, StoredReview[]>
  seedHelpfulDeltas?: Record<string, number>
  /** slug → verified owner address */
  verifiedOwners?: Record<string, string>
  /** localStorage project overrides: slug → Partial<Project> */
  projectOverrides?: Record<string, Partial<Project>>
  onSaveProjectOverride?: (projectId: string, patch: Partial<Project>) => void
  isWatched?: boolean
  onToggleWatchlist?: (projectId: string) => void
  /** MYARC contract address — enables on-chain analytics + Supabase flags */
  contractAddress?: `0x${string}`
  /**
   * Increment this from the parent after every confirmed on-chain write that
   * affects this project (vote, retract, review). Triggers an analytics refetch
   * without requiring the sheet to close and reopen.
   */
  analyticsRefetchKey?: number
  /** ISO date of last generated report (from useAdminConfig) */
  lastReportGenerated?: string | null
  /** Called after generating a report */
  markReportGenerated?: () => void
  /** Supabase-backed save for project_overrides (used for logo upload) */
  saveProjectOverrideSupabase?: (id: string, patch: Record<string, unknown>, ownerAddress?: string, prev?: Record<string, unknown>, action?: string) => Promise<void>
  /** Refetch overrides after logo upload */
  refetchOverrides?: () => void
  /** Returns true if a given wallet address is blacklisted */
  isBlacklisted?: (address: string) => boolean
  /**
   * Full ranked platform momentum array from usePlatformMomentum.
   * The sheet looks up the current project's result by slug.
   * Optional — milestones are hidden when this is not provided.
   */
  platformMomentum?: MomentumResult[]
  /** Taxonomy for displaying category / use cases / tags */
  taxonomy?: TaxonomyResult
}

function timeAgo(ms: number): string {
  const diff = Date.now() - ms
  const d = Math.floor(diff / 86400000)
  if (d === 0) return 'Today'
  if (d === 1) return '1 day ago'
  return `${d} days ago`
}

function formatResponseTime(ms: number): string {
  const d = new Date(ms)
  return d.toLocaleDateString('en', { month: 'short', day: 'numeric' })
}

function copyShareLink(projectId: string) {
  const url = new URL(window.location.href)
  url.searchParams.set('project', projectId)
  navigator.clipboard.writeText(url.toString()).then(
    () => toast('Link copied to clipboard.', { duration: 2000 }),
    () => toast.error('Could not copy link.')
  )
}

/** Inline author reputation badge. */
function AuthorRepBadge({
  authorFull,
  allProjects,
  reviewOverrides,
  seedHelpfulDeltas,
}: {
  authorFull: string
  allProjects: Project[]
  reviewOverrides: Record<string, StoredReview[]>
  seedHelpfulDeltas: Record<string, number>
}) {
  const rep = useReputation({
    address: authorFull,
    projects: allProjects,
    userVotes: {},
    reviewOverrides,
    seedHelpfulDeltas,
  })
  const { bg, color } = TIER_COLORS[rep.tier]
  return (
    <span
      className="inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-semibold flex-shrink-0"
      style={{ background: bg, color }}
      title={`${rep.tier} · ${rep.score} pts`}
    >
      {rep.tier}
    </span>
  )
}

// ── Pure-SVG line chart ───────────────────────────────────────────────────────
function LineChart({
  data,
  width = 280,
  height = 64,
  color = 'var(--bullish)',
}: {
  data: number[]
  width?: number
  height?: number
  color?: string
}) {
  if (data.length < 2) return null
  const min = Math.min(...data)
  const max = Math.max(...data)
  const range = max - min || 1
  const pad = 4

  const pts = data.map((v, i) => {
    const x = pad + (i / (data.length - 1)) * (width - pad * 2)
    const y = pad + (1 - (v - min) / range) * (height - pad * 2)
    return `${x},${y}`
  })

  return (
    <svg width={width} height={height} style={{ overflow: 'visible' }}>
      <polyline
        points={pts.join(' ')}
        fill="none"
        stroke={color}
        strokeWidth={2}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {data.map((v, i) => {
        const x = pad + (i / (data.length - 1)) * (width - pad * 2)
        const y = pad + (1 - (v - min) / range) * (height - pad * 2)
        return (
          <circle key={i} cx={x} cy={y} r={3} fill={color} />
        )
      })}
    </svg>
  )
}

// ── Pure-SVG bar chart ────────────────────────────────────────────────────────
function BarChart({
  data,
  labels,
  width = 280,
  height = 64,
  color = 'var(--accent)',
}: {
  data: number[]
  labels?: string[]
  width?: number
  height?: number
  color?: string
}) {
  if (data.length === 0) return null
  const max = Math.max(...data, 1)
  const barW = Math.floor((width - (data.length - 1) * 4) / data.length)

  return (
    <svg width={width} height={height + 16}>
      {data.map((v, i) => {
        const barH = Math.round((v / max) * height)
        const x = i * (barW + 4)
        const y = height - barH
        return (
          <g key={i}>
            <rect x={x} y={y} width={barW} height={barH} rx={2} fill={color} opacity={0.8} />
            {labels?.[i] && (
              <text
                x={x + barW / 2}
                y={height + 13}
                textAnchor="middle"
                fontSize={9}
                fill="var(--subtle)"
              >
                {labels[i]}
              </text>
            )}
          </g>
        )
      })}
    </svg>
  )
}

// Module-level timestamp so analytics charts don't call Date.now() during render
const ANALYTICS_NOW = Date.now()
const ANALYTICS_DAY = 86400000

// ── Analytics skeleton ────────────────────────────────────────────────────────
function AnalyticsSkeleton() {
  const shimmer = {
    initial: { opacity: 0.5 },
    animate: { opacity: [0.5, 0.85, 0.5] as number[] },
    transition: { duration: 1.6, repeat: Infinity, ease: 'easeInOut' as const },
  }
  return (
    <div className="space-y-6">
      {[80, 120, 96, 80].map((h, i) => (
        <motion.div key={i} {...shimmer}
          className="rounded-2xl" style={{ background: 'var(--surface-muted)', height: h }} />
      ))}
    </div>
  )
}

// ── Analytics tab ─────────────────────────────────────────────────────────────
function AnalyticsTab({
  project,
  reviewOverrides,
  seedHelpfulDeltas,
  contractAddress,
  analyticsRefetchKey = 0,
  lastReportGenerated,
  markReportGenerated,
  allProjects = [],
}: {
  project: Project
  reviewOverrides: Record<string, StoredReview[]>
  seedHelpfulDeltas: Record<string, number>
  contractAddress?: `0x${string}`
  analyticsRefetchKey?: number
  lastReportGenerated?: string | null
  markReportGenerated?: () => void
  allProjects?: Project[]
}) {
  // ── On-chain analytics (when contract address available) ──────────────────
  const onchain = useProjectAnalytics(
    contractAddress ? project.id : null,
    contractAddress
  )

  // Re-fetch analytics after a confirmed on-chain write on this project.
  // analyticsRefetchKey starts at 0 on mount; any increment signals a new confirmation.
  useEffect(() => {
    if (analyticsRefetchKey > 0) onchain.refetch()
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [analyticsRefetchKey])

  // ── Session-derived fallback (no contract / still loading) ─────────────────
  const allReviews = useMemo(() => {
    const overrides = reviewOverrides[project.id] ?? []
    const seedReviews = project.reviews.map((r) =>
      seedHelpfulDeltas[r.id] ? { ...r, helpful: r.helpful + seedHelpfulDeltas[r.id] } : r
    )
    return [...overrides, ...seedReviews]
  }, [project, reviewOverrides, seedHelpfulDeltas])

  const sessionSentimentTrend = useMemo(() =>
    Array.from({ length: 7 }, (_, i) => {
      const dayStart = ANALYTICS_NOW - (6 - i) * ANALYTICS_DAY
      const dayEnd   = dayStart + ANALYTICS_DAY
      const dayReviews = allReviews.filter((r) => r.timestamp >= dayStart && r.timestamp < dayEnd)
      if (dayReviews.length === 0) return null
      const bull = dayReviews.filter((r) => r.sentiment === 'bullish').length
      return Math.round((bull / dayReviews.length) * 100)
    }),
  [allReviews])

  const sessionReviewVolume = useMemo(() =>
    Array.from({ length: 7 }, (_, i) => {
      const dayStart = ANALYTICS_NOW - (6 - i) * ANALYTICS_DAY
      const dayEnd   = dayStart + ANALYTICS_DAY
      return allReviews.filter((r) => r.timestamp >= dayStart && r.timestamp < dayEnd).length
    }),
  [allReviews])

  const sessionTopReviewers = useMemo(() => {
    const map: Record<string, { address: string; count: number }> = {}
    for (const r of allReviews) {
      const key = r.authorFull.toLowerCase()
      if (!map[key]) map[key] = { address: r.authorFull, count: 0 }
      map[key].count++
    }
    return Object.values(map).sort((a, b) => b.count - a.count).slice(0, 5)
  }, [allReviews])

  const sessionDayLabels = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(ANALYTICS_NOW - (6 - i) * ANALYTICS_DAY)
    return d.toLocaleDateString('en', { weekday: 'short' }).slice(0, 2)
  })

  // ── Pick data source ──────────────────────────────────────────────────────
  const useOnchainData = contractAddress && !onchain.isLoading && !onchain.error

  const sentimentTrend = useOnchainData ? onchain.timeline : sessionSentimentTrend
  const reviewVolume   = useOnchainData ? onchain.reviewVolume : sessionReviewVolume
  const dayLabels      = useOnchainData ? onchain.dayLabels : sessionDayLabels
  const topReviewers   = useOnchainData
    ? onchain.topReviewers.map((r) => ({ address: r.address, count: r.count }))
    : sessionTopReviewers

  // Sentiment breakdown: prefer on-chain, fall back to project seed votes
  const breakdown = useMemo(() => {
    if (useOnchainData) return onchain.sentimentBreakdown
    return { bullish: project.votes.bullish, neutral: project.votes.neutral, bearish: project.votes.bearish }
  }, [useOnchainData, onchain.sentimentBreakdown, project.votes.bullish, project.votes.neutral, project.votes.bearish])

  // ── Sentiment health ──────────────────────────────────────────────────────
  const total = breakdown.bullish + breakdown.neutral + breakdown.bearish
  const bullPct = total > 0 ? (breakdown.bullish / total) * 100 : 0
  const bearPct = total > 0 ? (breakdown.bearish / total) * 100 : 0
  const healthScore = Math.round(bullPct * 1 - bearPct * 1.5)
  const healthColor = healthScore > 20 ? 'var(--bullish)' : healthScore < 0 ? 'var(--bearish)' : 'var(--neutral)'

  // ── Report due badge ────────────────────────────────────────────────────────
  const isReportDue = (() => {
    if (!lastReportGenerated) return true
    const last = new Date(lastReportGenerated).getTime()
    return Date.now() - last > 30 * 86400000
  })()

  // ── Generate report (print to PDF) ──────────────────────────────────────────
  const handleGenerateReport = () => {
    // Ensure the report container is visible to the print stylesheet
    const container = document.getElementById('myarc-report-container')
    if (container) container.style.display = 'block'
    toast('Report ready — use Print \u2192 Save as PDF to download.', { duration: 4000 })
    markReportGenerated?.()
    // Small delay so React can render the report div before print dialog opens
    setTimeout(() => {
      window.print()
      if (container) container.style.display = 'none'
    }, 120)
  }

  function handleDownload() {
    const report = {
      project: project.id,
      generatedAt: new Date().toISOString(),
      dataSource: contractAddress ? 'onchain' : 'session',
      sentimentTrend,
      reviewVolume,
      sentimentBreakdown: breakdown,
      healthScore,
      topReviewers,
    }
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `myarc-${project.id}-analytics.json`
    a.click()
    URL.revokeObjectURL(url)
    toast('Analytics report downloaded.', { duration: 2000 })
  }

  // Loading state
  if (contractAddress && onchain.isLoading) {
    return <AnalyticsSkeleton />
  }

  // Error state
  if (contractAddress && onchain.error) {
    return (
      <div className="flex items-center gap-3 p-4 rounded-2xl"
        style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
        <AlertCircle size={16} style={{ color: 'var(--bearish)', flexShrink: 0 }} />
        <div>
          <p className="text-sm font-medium" style={{ color: 'var(--ink)' }}>Failed to load on-chain analytics</p>
          <p className="text-xs mt-0.5" style={{ color: 'var(--subtle)' }}>{onchain.error}</p>
        </div>
      </div>
    )
  }

  const trendData = sentimentTrend.map((v) => v ?? 0)
  const hasTrendData = trendData.some((v) => v > 0)

  // Semantic trend line color: compare first non-zero day to last non-zero day.
  // Green = sentiment improving over the period. Red = sentiment declining.
  // Neutral gray = flat or insufficient data to determine direction.
  const trendLineColor = (() => {
    const nonZero = trendData.filter((v) => v > 0)
    if (nonZero.length < 2) return 'var(--neutral)'
    const first = nonZero[0]
    const last  = nonZero[nonZero.length - 1]
    const delta = last - first
    if (delta > 3)  return 'var(--bullish)'
    if (delta < -3) return 'var(--bearish)'
    return 'var(--neutral)'
  })()

  return (
    <div className="space-y-6">
      {/* Data source badge + Report due badge */}
      <div className="flex items-center justify-between gap-2 flex-wrap">
        {contractAddress ? (
          <div className="flex items-center gap-1.5 text-xs" style={{ color: 'var(--subtle)' }}>
            <span className="w-1.5 h-1.5 rounded-full inline-block" style={{ background: 'var(--bullish)' }} />
            Live on-chain data
          </div>
        ) : <div />}
        {isReportDue && (
          <div className="flex items-center gap-1 px-2 py-1 rounded-full text-[11px] font-semibold"
            style={{ background: 'rgba(186,43,76,0.10)', color: 'var(--bearish)', border: '1px solid rgba(186,43,76,0.20)' }}>
            <Bell size={10} strokeWidth={2.5} />
            Report due
          </div>
        )}
      </div>

      {/* Sentiment Health score */}
      <div className="p-4 rounded-2xl space-y-1 text-center" style={{ background: 'var(--surface-muted)' }}>
        <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
          Sentiment Health
        </p>
        <p className="display font-bold text-4xl tabular-nums" style={{ color: healthColor }}>
          {healthScore > 0 ? '+' : ''}{healthScore}
        </p>
        <p className="text-xs" style={{ color: 'var(--subtle)' }}>
          bullish% × 1 − bearish% × 1.5
        </p>
      </div>

      {/* Vote breakdown */}
      <div className="space-y-2">
        <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
          Vote Breakdown
        </p>
        <div className="grid grid-cols-3 gap-2">
          {(['bullish', 'neutral', 'bearish'] as const).map((s) => {
            const count = breakdown[s]
            const pct = total > 0 ? Math.round((count / total) * 100) : 0
            const color = s === 'bullish' ? 'var(--bullish)' : s === 'bearish' ? 'var(--bearish)' : 'var(--neutral)'
            return (
              <div key={s} className="p-3 rounded-xl text-center space-y-0.5"
                style={{ background: 'var(--surface-muted)' }}>
                <AnimatedNumber
                  value={count}
                  duration={0.4}
                  className="display font-bold text-lg tabular-nums"
                  style={{ color }}
                  aria-hidden="true"
                />
                <AnimatedNumber
                  value={pct}
                  suffix="%"
                  duration={0.4}
                  className="text-xs tabular-nums"
                  style={{ color: 'var(--subtle)' }}
                  aria-hidden="true"
                />
                <p className="text-xs capitalize" style={{ color: 'var(--muted)' }}>{s}</p>
              </div>
            )
          })}
        </div>
      </div>

      {/* Sentiment trend chart */}
      {hasTrendData && (
        <div className="space-y-2">
          <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
            Bullish Sentiment (7d)
          </p>
          <div className="p-3 rounded-2xl overflow-hidden" style={{ background: 'var(--surface-muted)' }}>
            <LineChart data={trendData} width={260} height={56} color={trendLineColor} />
          </div>
        </div>
      )}

      {/* Review volume bar chart */}
      <div className="space-y-2">
        <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
          Review Volume (7d)
        </p>
        <div className="p-3 rounded-2xl overflow-hidden" style={{ background: 'var(--surface-muted)' }}>
          <BarChart data={reviewVolume} labels={dayLabels} width={260} height={48} color="var(--accent)" />
        </div>
      </div>

      {/* Top reviewers */}
      {topReviewers.length > 0 && (
        <div className="space-y-2">
          <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
            Top Reviewers {contractAddress ? '(by review count)' : '(by helpful)'}
          </p>
          <div className="space-y-1.5">
            {topReviewers.map((r, i) => (
              <div key={r.address} className="flex items-center gap-2 px-3 py-2 rounded-xl"
                style={{ background: 'var(--surface-muted)' }}>
                <span className="text-xs font-semibold tabular-nums w-5 text-center flex-shrink-0"
                  style={{ color: 'var(--subtle)' }}>
                  {i + 1}
                </span>
                <IdentityLabel
                  address={r.address}
                  fallback={`${r.address.slice(0, 6)}…${r.address.slice(-4)}`}
                  className="text-xs flex-1 truncate"
                  style={{ color: 'var(--ink-2)' }}
                />
                <span className="text-xs tabular-nums font-semibold flex-shrink-0"
                  style={{ color: 'var(--bullish)' }}>
                  {r.count} {contractAddress ? 'reviews' : 'helpful'}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Action buttons row */}
      <div className="flex gap-2">
        <button
          onClick={handleGenerateReport}
          className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-semibold min-h-[44px] transition-all hover:opacity-85"
          style={{ background: 'var(--accent)', color: 'var(--bg)' }}
        >
          <FileText size={15} />
          Generate Report
        </button>
        <button
          onClick={handleDownload}
          className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-sm font-semibold min-h-[44px] transition-all hover:opacity-85"
          style={{ background: 'var(--surface-muted)', color: 'var(--ink-2)', border: '1px solid var(--border)' }}
          title="Download analytics JSON"
        >
          <Download size={15} />
        </button>
      </div>

      {/* Hidden print-only SentimentReport — shown via @media print */}
      <div
        id="myarc-report-container"
        style={{ display: 'none', position: 'fixed', top: 0, left: 0, width: '100%', zIndex: -1, pointerEvents: 'none' }}
        aria-hidden="true"
      >
        <div id="myarc-report">
          <SentimentReport
            project={project}
            analytics={{
              timeline: sentimentTrend,
              reviewVolume,
              dayLabels,
              topReviewers,
              sentimentBreakdown: breakdown,
              isLoading: false,
              error: null,
              refetch: () => {},
            }}
            allProjects={allProjects}
          />
        </div>
      </div>
    </div>
  )
}

// ── Main sheet ────────────────────────────────────────────────────────────────
export function ProjectDetailSheet({
  project,
  userVote,
  onVote,
  onClose,
  onReview,
  onHelpful,
  helpfulVoted = {},
  isConnected = false,
  connectedAddress,
  allProjects = [],
  reviewOverrides = {},
  seedHelpfulDeltas = {},
  verifiedOwners = {},
  projectOverrides = {},
  onSaveProjectOverride,
  isWatched = false,
  onToggleWatchlist,
  contractAddress,
  analyticsRefetchKey = 0,
  lastReportGenerated,
  markReportGenerated,
  saveProjectOverrideSupabase,
  refetchOverrides,
  isBlacklisted,
  platformMomentum,
  taxonomy,
}: ProjectDetailSheetProps) {
  const navigate = useNavigate()
  const [reviewBody, setReviewBody]           = useState('')
  const [reviewSentiment, setReviewSentiment] = useState<Sentiment>('bullish')
  const [submitted, setSubmitted]             = useState(false)
  const [expandedFlagged, setExpandedFlagged] = useState<Set<string>>(new Set())
  const [sheetTab, setSheetTab]               = useState<SheetTab>('reviews')
  const [isEditingProject, setIsEditingProject] = useState(false)
  const [editDescription, setEditDescription]   = useState('')
  const [editWebsite, setEditWebsite]           = useState('')

  // ── Tipping state ──────────────────────────────────────────────────────────
  const [openTipId, setOpenTipId]         = useState<string | null>(null)
  const [selectedTip, setSelectedTip]     = useState<bigint>(TIP_PRESETS[1].value) // default 1 USDC
  const [tipFeeBps, setTipFeeBps]         = useState<bigint>(1000n)
  const { simulateAndWrite, isPending: isTipping } = useSimulatedWrite()

  // ── Boost state ────────────────────────────────────────────────────────────
  const [openBoostId, setOpenBoostId]     = useState<string | null>(null)
  const [selectedBoost, setSelectedBoost] = useState<bigint>(BOOST_PRESETS[1].value) // default 0.05 USDC
  const [boostFeeBps, setBoostFeeBps]     = useState<bigint>(500n)
  const { simulateAndWrite: simulateBoost, isPending: isBoosting } = useSimulatedWrite()

  // ── Embed code generator state ───────────────────────────────────────────
  const [showEmbed, setShowEmbed] = useState(false)

  // ── Logo upload state ─────────────────────────────────────────────────────
  const [isUploadingLogo, setIsUploadingLogo] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // ── Verification fee (read from contract) ────────────────────────────────
  const publicClient = usePublicClient({ chainId: ARC_TESTNET_CHAIN_ID })
  const { writeContract, isPending: isVerifying } = useWriteContract()
  const [verificationFee, setVerificationFee] = useState<bigint | null>(null)

  useEffect(() => {
    if (!contractAddress || !publicClient) return
    const fetcher = connectedAddress
      ? publicClient.readContract({
          address: contractAddress,
          abi: VERIFY_ABI,
          functionName: 'getEffectiveFee',
          args: [connectedAddress as `0x${string}`],
        })
      : publicClient.readContract({
          address: contractAddress,
          abi: VERIFY_ABI,
          functionName: 'getVerificationFee',
        })
    fetcher.then((fee) => setVerificationFee(fee)).catch(() => {})

    // Read tip protocol fee
    publicClient.readContract({
      address: contractAddress,
      abi: TIP_ABI,
      functionName: 'getTipProtocolFeeBps',
    }).then((bps) => setTipFeeBps(bps)).catch(() => {})

    // Read boost protocol fee
    publicClient.readContract({
      address: contractAddress,
      abi: BOOST_ABI,
      functionName: 'upvoteProtocolFeeBps',
    }).then((bps) => setBoostFeeBps(bps)).catch(() => {})
  }, [contractAddress, publicClient, connectedAddress])

  const isFreeVerification = verificationFee === 0n
  const feeUsdcDisplay = verificationFee !== null
    ? isFreeVerification
      ? 'Free'
      : `${(Number(verificationFee / 1_000_000_000_000n) / 1_000_000).toFixed(2)} USDC`
    : null

  /** Computed reviewer payout for display (selectedTip minus protocol fee). */
  const reviewerReceives = selectedTip - (selectedTip * tipFeeBps) / 10_000n
  const reviewerReceivesDisplay = (Number(reviewerReceives / 1_000_000_000_000n) / 1_000_000).toFixed(2)

  /** Computed author payout for display (selectedBoost minus boost protocol fee). */
  const boostAuthorReceives = selectedBoost - (selectedBoost * boostFeeBps) / 10_000n
  const boostAuthorReceivesDisplay = (Number(boostAuthorReceives / 1_000_000_000_000n) / 1_000_000).toFixed(4)

  const handleBoostReview = async (reviewIndex: number, _authorAddress: string) => {
    if (!project || !contractAddress) return
    if (!isConnected) { toast.error('Connect your wallet to boost a review.'); return }
    const result = await simulateBoost({
      address: contractAddress,
      abi: BOOST_ABI,
      functionName: 'upvoteReview',
      args: [slugToBytes32(project.id), BigInt(reviewIndex)],
      chainId: ARC_TESTNET_CHAIN_ID,
      value: selectedBoost,
    })
    if (result) {
      toast.success(`Review boosted — author received ${boostAuthorReceivesDisplay} USDC`)
      setOpenBoostId(null)
      setTimeout(() => { void refetchBoostStats() }, 1000)
    }
  }

  const { getLabel: getTipLabel } = useProfileCache()

  const handleTipReviewer = async (reviewIndex: number, reviewerAddress: string) => {
    if (!project || !contractAddress) return
    if (!isConnected) { toast.error('Connect your wallet to tip a reviewer.'); return }
    const recipientLabel = getTipLabel(reviewerAddress) ?? 'reviewer'
    toast(`Tipping ${(Number(selectedTip / 1_000_000_000_000n) / 1_000_000).toFixed(2)} USDC to ${recipientLabel}...`)
    const result = await simulateAndWrite({
      address: contractAddress,
      abi: TIP_ABI,
      functionName: 'tipReviewer',
      args: [slugToBytes32(project.id), BigInt(reviewIndex)],
      chainId: ARC_TESTNET_CHAIN_ID,
      value: selectedTip,
    })
    if (result) {
      toast.success(`Tipped ${(Number(selectedTip / 1_000_000_000_000n) / 1_000_000).toFixed(2)} USDC to ${recipientLabel}`)
      setOpenTipId(null)
    }
  }

  const handleVerifyProject = () => {
    if (!project || !contractAddress || verificationFee === null) return
    if (!isConnected) { toast.error('Connect your wallet to verify this project.'); return }
    const msg = isFreeVerification
      ? `Verifying ${project.name} — whitelisted, no fee`
      : `Verifying ${project.name} — fee: ${feeUsdcDisplay}`
    toast(msg)
    writeContract({
      address: contractAddress,
      abi: VERIFY_ABI,
      functionName: 'verifyProject',
      args: [slugToBytes32(project.id)],
      value: verificationFee,
    })
  }

  // ── Supabase-backed review flags ──────────────────────────────────────────
  const {
    flagCounts,
    flaggedByMe,
    flagReview: flagReviewRemote,
  } = useReviewFlags({
    projectId: project?.id ?? null,
    connectedAddress,
  })

  // ── Review moderation ─────────────────────────────────────────────────────
  const {
    hiddenReviewIds,
    moderateReview,
  } = useModeratedReviews({
    projectId: project?.id ?? null,
    connectedAddress,
  })

  // per-review "hide reason" dropdown state (owner only)
  const [hideReasonFor, setHideReasonFor] = useState<string | null>(null)
  const [hideReasonVal, setHideReasonVal] = useState('Policy violation')

  // ── Review boost stats (onchain weight + count) ───────────────────────────
  const {
    upvoteStats,
    refetch: refetchBoostStats,
  } = useReviewUpvotes(
    project?.id ?? null,
    contractAddress,
    project?.reviews.length ?? 0,
  )

  // ── Pinned reviews ────────────────────────────────────────────────────────
  const { pinnedIds } = usePinnedReviews({
    projectId: project?.id ?? null,
    ownerAddress: connectedAddress,
  })

  // ── Owner responses to reviews ────────────────────────────────────────────
  const {
    responses: reviewResponses,
    postResponse,
  } = useReviewResponses({
    projectId: project?.id ?? null,
    responderAddress: connectedAddress,
  })

  // ── Reply form state (one open at a time) ─────────────────────────────────
  const [openReplyId, setOpenReplyId]   = useState<string | null>(null)
  const [replyBody, setReplyBody]       = useState('')
  const [isPostingReply, setIsPostingReply] = useState(false)

  const handlePostReply = async (reviewId: string) => {
    if (!replyBody.trim() || isPostingReply) return
    setIsPostingReply(true)
    await postResponse(reviewId, replyBody.trim())
    setReplyBody('')
    setOpenReplyId(null)
    setIsPostingReply(false)
    toast.success('Response posted.')
  }

  const BookmarkIcon = isWatched ? BookmarkCheck : Bookmark

  const isVerified = project
    ? Boolean(verifiedOwners[project.id]) && !project.verifiedBadgeHidden
    : false

  const isOwner = project && connectedAddress
    ? verifiedOwners[project.id] === connectedAddress.toLowerCase()
    : false

  const handleSubmitReview = () => {
    if (!project || reviewBody.trim().length < 10) return
    onReview(project.id, reviewBody.trim(), reviewSentiment)
    setReviewBody('')
    setSubmitted(true)
    setTimeout(() => setSubmitted(false), 3000)
  }

  const handleSaveProjectEdit = () => {
    if (!project) return
    const patch: Partial<Project> = {}
    if (editDescription.trim()) patch.description = editDescription.trim()
    if (editWebsite.trim()) patch.website = editWebsite.trim()
    onSaveProjectOverride?.(project.id, patch)
    setIsEditingProject(false)
    toast.success('Project info updated.')
  }

  const handleOpenEdit = () => {
    if (!project) return
    const override = projectOverrides[project.id] ?? {}
    setEditDescription(override.description ?? project.description)
    setEditWebsite(override.website ?? project.website ?? '')
    setIsEditingProject(true)
  }

  // Apply local project overrides to display
  const displayProject = useMemo(() => {
    if (!project) return null
    const override = projectOverrides[project.id]
    if (!override) return project
    return { ...project, ...override }
  }, [project, projectOverrides])

  // ── Milestones (needs displayProject) ────────────────────────────────────
  const [showMilestones, setShowMilestones] = useState(false)
  const momentumResult = platformMomentum?.find(
    (r) => r.projectSlug === (displayProject?.id ?? '')
  ) ?? null
  const milestones = useMilestones(displayProject?.id ?? null, momentumResult)

  // ── Logo upload handler (needs displayProject) ────────────────────────────
  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file || !displayProject || !connectedAddress || !supabase) return
    if (file.size > 2 * 1024 * 1024) {
      toast.error('File too large — maximum 2MB')
      return
    }
    const ext = file.name.split('.').pop()?.toLowerCase() ?? 'png'
    const path = `${displayProject.id}/${crypto.randomUUID()}.${ext}`
    setIsUploadingLogo(true)
    try {
      const { error: uploadError } = await supabase.storage
        .from('project-logos').upload(path, file, { upsert: true })
      if (uploadError) throw uploadError
      const { data: urlData } = supabase.storage.from('project-logos').getPublicUrl(path)
      const logoUrl = urlData.publicUrl
      const adminClient = getAdminClient(connectedAddress)
      if (adminClient) {
        await adminClient.from('project_overrides').upsert(
          { id: displayProject.id, logo_url: logoUrl, updated_at: new Date().toISOString() },
          { onConflict: 'id' }
        )
        await adminClient.from('project_edit_log').insert({
          project_id: displayProject.id, editor_address: connectedAddress,
          action: 'logo_updated',
          previous_value: { logo_url: displayProject.logoUrl ?? null },
          new_value: { logo_url: logoUrl },
        })
      }
      await saveProjectOverrideSupabase?.(displayProject.id, { logo_url: logoUrl },
        connectedAddress, { logo_url: displayProject.logoUrl ?? null }, 'logo_updated')
      refetchOverrides?.()
      toast.success('Logo updated successfully')
    } catch { toast.error('Logo upload failed — please try again') }
    finally {
      setIsUploadingLogo(false)
      if (fileInputRef.current) fileInputRef.current.value = ''
    }
  }

  // Sort reviews:
  //   1. Pinned first (existing behaviour)
  //   2. Boosted (totalWeight > 0) before unboosted, ordered by weight desc
  //   3. Within unboosted: helpful ≥ 10 then by timestamp desc (existing behaviour)
  const sortedReviews = useMemo(() => {
    if (!displayProject) return []
    return [...displayProject.reviews].sort((a, b) => {
      // Pinned always first
      const aPinned = pinnedIds.has(a.id) ? 1 : 0
      const bPinned = pinnedIds.has(b.id) ? 1 : 0
      if (bPinned !== aPinned) return bPinned - aPinned

      // Boost weight — index in original reviews array
      const aIdx = displayProject.reviews.findIndex((r) => r.id === a.id)
      const bIdx = displayProject.reviews.findIndex((r) => r.id === b.id)
      const aWeight = upvoteStats[aIdx]?.totalWeight ?? 0n
      const bWeight = upvoteStats[bIdx]?.totalWeight ?? 0n
      const aBoosted = aWeight > 0n ? 1 : 0
      const bBoosted = bWeight > 0n ? 1 : 0
      if (bBoosted !== aBoosted) return bBoosted - aBoosted
      // Both boosted: sort by weight desc
      if (aBoosted && bBoosted) return bWeight > aWeight ? 1 : bWeight < aWeight ? -1 : 0

      // Unboosted: preserve existing ordering (helpful threshold then timestamp)
      const aTop = a.helpful >= 10 ? 1 : 0
      const bTop = b.helpful >= 10 ? 1 : 0
      if (bTop !== aTop) return bTop - aTop
      return b.timestamp - a.timestamp
    })
  }, [displayProject, pinnedIds, upvoteStats])

  return (
    <AnimatePresence>
      {/* Backdrop — direct AnimatePresence child, no fragment wrapper */}
      {project && displayProject && (
        <motion.div key="backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          onClick={onClose} className="fixed inset-0 z-40"
          style={{ background: 'rgba(18,45,69,0.35)', backdropFilter: 'blur(4px)' }} />
      )}
      {/* Sheet — direct AnimatePresence child */}
      {project && displayProject && (
        <motion.div key="sheet" initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }}
            transition={{ type: 'spring', stiffness: 360, damping: 36 }}
            className="fixed bottom-0 left-0 right-0 z-50 rounded-t-3xl overflow-hidden"
            style={{ background: 'var(--surface-strong)', maxHeight: '88dvh', boxShadow: '0 -8px 40px rgba(18,45,69,0.18)' }}>

            {/* Drag handle */}
            <div className="flex justify-center pt-3 pb-1">
              <div className="w-10 h-1 rounded-full" style={{ background: 'var(--border-strong)' }} />
            </div>

            <div className="overflow-y-auto" style={{ maxHeight: 'calc(88dvh - 24px)' }}>
              <div className="px-5 pb-10 space-y-5">

                {/* Header */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 min-w-0">
                    <div className="relative">
                      <ProjectLogo project={displayProject} size="lg" isUploading={isUploadingLogo} />
                      {/* Camera overlay — only for verified project owner */}
                      {isOwner && contractAddress && connectedAddress && supabase && (
                        <>
                          <button
                            onClick={() => fileInputRef.current?.click()}
                            disabled={isUploadingLogo}
                            className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center border transition-opacity hover:opacity-80"
                            style={{ background: 'var(--accent)', borderColor: 'var(--bg)', color: 'var(--bg)' }}
                            title="Update logo"
                          >
                            <Camera size={11} strokeWidth={2.5} />
                          </button>
                          <input
                            ref={fileInputRef}
                            type="file"
                            accept="image/png,image/jpeg,image/webp,image/svg+xml"
                            className="hidden"
                            onChange={(e) => { void handleLogoUpload(e) }}
                          />
                        </>
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h2 className="display font-semibold text-xl leading-tight" style={{ color: 'var(--ink)' }}>
                          {displayProject.name}
                        </h2>
                        {isVerified && (
                          <BadgeCheck size={17} style={{ color: 'var(--accent)' }} strokeWidth={2.5} />
                        )}
                        {displayProject.website && (
                          <a href={displayProject.website} target="_blank" rel="noopener noreferrer"
                            className="flex items-center gap-1 text-xs font-medium transition-opacity hover:opacity-70"
                            style={{ color: 'var(--subtle)' }}>
                            <Globe size={12} /> Website
                          </a>
                        )}
                      </div>
                      <p className="text-sm mt-0.5" style={{ color: 'var(--muted)' }}>{displayProject.tagline}</p>
                    </div>
                  </div>

                  {/* Controls: bookmark, share, close */}
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <button
                      onClick={() => onToggleWatchlist?.(project.id)}
                      className="p-2 rounded-xl transition-all hover:opacity-70 min-h-[44px] min-w-[44px] flex items-center justify-center"
                      style={{
                        background: isWatched ? 'rgba(26,92,255,0.08)' : 'var(--surface-muted)',
                        color: isWatched ? 'var(--accent)' : 'var(--muted)',
                      }}
                      title={isWatched ? 'Remove from watchlist' : 'Add to watchlist'}
                    >
                      <BookmarkIcon size={16} />
                    </button>
                    {/* Embed code button — only for verified project owner */}
                    {isOwner && contractAddress && (
                      <button
                        onClick={() => setShowEmbed(true)}
                        className="p-2 rounded-xl transition-colors hover:opacity-70 flex items-center gap-1.5 text-xs font-medium"
                        style={{ background: 'var(--surface-muted)', color: 'var(--muted)' }}
                        title="Get embed code"
                      >
                        <Code size={14} />
                        <span className="hidden sm:inline">Embed</span>
                      </button>
                    )}
                    <button onClick={() => copyShareLink(project.id)}
                      className="p-2 rounded-xl transition-colors hover:opacity-70 flex items-center gap-1.5 text-xs font-medium"
                      style={{ background: 'var(--surface-muted)', color: 'var(--muted)' }}
                      title="Copy share link">
                      <Link2 size={14} />
                      <span className="hidden sm:inline">Share</span>
                    </button>
                    <button onClick={onClose} className="p-2 rounded-xl transition-colors hover:opacity-70"
                      style={{ background: 'var(--surface-muted)', color: 'var(--muted)' }}>
                      <X size={18} />
                    </button>
                  </div>
                </div>

                {/* Status banner */}
                {(displayProject.status === 'under_review' || displayProject.status === 'inactive') && (
                  <div
                    className="flex flex-col gap-1 px-4 py-3 rounded-xl"
                    style={{
                      background: displayProject.status === 'under_review'
                        ? 'rgba(245,158,11,0.10)'
                        : 'rgba(100,116,139,0.10)',
                      border: `1px solid ${displayProject.status === 'under_review' ? 'rgba(245,158,11,0.30)' : 'rgba(100,116,139,0.25)'}`,
                    }}
                  >
                    <div className="flex items-center gap-2">
                      <AlertTriangle size={14} style={{ color: displayProject.status === 'under_review' ? '#f59e0b' : 'var(--muted)', flexShrink: 0 }} />
                      <span className="text-sm font-semibold" style={{ color: displayProject.status === 'under_review' ? '#f59e0b' : 'var(--muted)' }}>
                        {displayProject.status === 'under_review' ? 'Under Review' : 'Inactive'}
                      </span>
                    </div>
                    {displayProject.status === 'under_review' && displayProject.statusNote && (
                      <p className="text-xs pl-6" style={{ color: 'var(--muted)' }}>{displayProject.statusNote}</p>
                    )}
                  </div>
                )}

                {/* Verified owner banner */}
                {isOwner && (
                  <div className="flex items-center justify-between gap-2 px-4 py-3 rounded-xl"
                    style={{ background: 'rgba(26,92,255,0.07)', border: '1px solid rgba(26,92,255,0.18)' }}>
                    <div className="flex items-center gap-2">
                      <ShieldCheck size={15} style={{ color: 'var(--accent)' }} />
                      <span className="text-sm font-medium" style={{ color: 'var(--ink)' }}>
                        You are the verified owner
                      </span>
                    </div>
                    <button
                      onClick={handleOpenEdit}
                      className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg min-h-[36px] transition-all hover:opacity-85"
                      style={{ background: 'var(--accent)', color: 'var(--bg)' }}
                    >
                      <Edit3 size={12} />
                      Edit
                    </button>
                  </div>
                )}

                {/* Unverified verified notice (not owner) */}
                {isVerified && !isOwner && (
                  <div className="flex items-center gap-2 px-3 py-2 rounded-lg"
                    style={{ background: 'rgba(26,92,255,0.05)', border: '1px solid rgba(26,92,255,0.12)' }}>
                    <BadgeCheck size={13} style={{ color: 'var(--accent)' }} />
                    <span className="text-xs" style={{ color: 'var(--muted)' }}>
                      Verified project — owner has claimed this listing
                    </span>
                  </div>
                )}

                {/* Verify project CTA — for unverified projects when connected */}
                {!isVerified && !isOwner && isConnected && contractAddress && (
                  <div className="rounded-xl overflow-hidden"
                    style={{ border: `1px solid ${isFreeVerification ? 'rgba(16,185,129,0.3)' : 'var(--border)'}` }}>
                    {/* Free banner */}
                    {isFreeVerification && (
                      <div className="flex items-center gap-2 px-4 py-2"
                        style={{ background: 'rgba(16,185,129,0.09)' }}>
                        <ShieldCheck size={13} style={{ color: 'var(--bullish)', flexShrink: 0 }} />
                        <p className="text-xs font-semibold" style={{ color: 'var(--bullish)' }}>
                          You have been whitelisted — verify for free
                        </p>
                      </div>
                    )}
                    <div className="flex items-center justify-between gap-3 px-4 py-3"
                      style={{ background: isFreeVerification ? 'rgba(16,185,129,0.04)' : 'var(--surface-muted)' }}>
                    <div className="min-w-0">
                      <p className="text-xs font-semibold" style={{ color: 'var(--ink-2)' }}>Claim this project</p>
                      <p className="text-xs mt-0.5" style={{ color: isFreeVerification ? 'var(--bullish)' : 'var(--subtle)' }}>
                        {feeUsdcDisplay !== null
                          ? `Verification fee: ${feeUsdcDisplay}`
                          : 'Loading fee…'}
                      </p>
                    </div>
                    <button
                      onClick={handleVerifyProject}
                      disabled={isVerifying || verificationFee === null}
                      className="flex-shrink-0 flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-lg min-h-[36px] transition-all hover:opacity-85"
                      style={{ background: 'var(--accent)', color: 'var(--bg)', opacity: isVerifying ? 0.6 : 1 }}
                    >
                      <BadgeCheck size={13} />
                      {isVerifying ? 'Verifying…' : 'Verify'}
                    </button>
                    </div>
                  </div>
                )}

                {/* Edit form overlay */}
                <AnimatePresence>
                  {isEditingProject && (
                    <motion.div
                      key="edit-form"
                      initial={{ opacity: 0, y: -8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -8 }}
                      className="p-4 rounded-2xl space-y-3"
                      style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}
                    >
                      <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                        Edit Project Info
                      </p>
                      <div className="space-y-2">
                        <label className="text-xs font-medium" style={{ color: 'var(--ink-2)' }}>Description</label>
                        <textarea
                          value={editDescription}
                          onChange={(e) => setEditDescription(e.target.value)}
                          rows={3}
                          className="w-full resize-none rounded-xl px-3.5 py-2.5 text-sm outline-none"
                          style={{ background: 'var(--surface)', color: 'var(--ink)', border: '1.5px solid var(--border)', fontFamily: "'DM Sans', sans-serif" }}
                          onFocus={(e) => { e.target.style.borderColor = 'var(--focus)' }}
                          onBlur={(e) => { e.target.style.borderColor = 'var(--border)' }}
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-medium" style={{ color: 'var(--ink-2)' }}>Website URL</label>
                        <input
                          type="url"
                          value={editWebsite}
                          onChange={(e) => setEditWebsite(e.target.value)}
                          placeholder="https://..."
                          className="w-full rounded-xl px-3.5 py-2.5 text-sm outline-none"
                          style={{ background: 'var(--surface)', color: 'var(--ink)', border: '1.5px solid var(--border)', fontFamily: "'DM Sans', sans-serif" }}
                          onFocus={(e) => { e.target.style.borderColor = 'var(--focus)' }}
                          onBlur={(e) => { e.target.style.borderColor = 'var(--border)' }}
                        />
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={handleSaveProjectEdit}
                          className="flex-1 py-2.5 rounded-xl text-sm font-semibold min-h-[44px] transition-all hover:opacity-85"
                          style={{ background: 'var(--accent)', color: 'var(--bg)' }}
                        >
                          Save
                        </button>
                        <button
                          onClick={() => setIsEditingProject(false)}
                          className="px-4 py-2.5 rounded-xl text-sm font-medium min-h-[44px]"
                          style={{ background: 'var(--surface)', color: 'var(--muted)', border: '1px solid var(--border)' }}
                        >
                          Cancel
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Description */}
                <p className="text-sm leading-relaxed text-pretty" style={{ color: 'var(--ink-2)' }}>
                  {displayProject.description}
                </p>

                {/* Meta — taxonomy-aware */}
                <div className="flex gap-2 flex-wrap">
                  {/* Primary category chip */}
                  {displayProject.primaryCategory && taxonomy && (
                    <span className="text-xs px-2.5 py-1 rounded-full font-medium"
                      style={{ background: 'color-mix(in srgb, var(--accent) 12%, transparent)', color: 'var(--accent)' }}>
                      {taxonomy.getCategory(displayProject.primaryCategory)?.label ?? displayProject.primaryCategory}
                    </span>
                  )}
                  {/* Use case chips */}
                  {taxonomy && displayProject.useCases?.map((ucId) => {
                    const uc = taxonomy.getUseCase(ucId)
                    if (!uc) return null
                    return (
                      <span key={ucId} className="text-xs px-2.5 py-1 rounded-full font-medium"
                        style={{ background: 'var(--surface-muted)', color: 'var(--ink-2)' }}>
                        {uc.label}
                      </span>
                    )
                  })}
                  {/* Canonical tag chips */}
                  {taxonomy && displayProject.canonicalTags?.map((tagId) => {
                    const tag = taxonomy.getTag(tagId)
                    if (!tag) return null
                    return (
                      <span key={tagId} className="text-xs px-2.5 py-1 rounded-full font-medium"
                        style={{ background: 'var(--surface-muted)', color: 'var(--subtle)' }}>
                        {tag.label}
                      </span>
                    )
                  })}
                  {/* Legacy tags fallback — shown for unmigrated submitted projects */}
                  {(!displayProject.primaryCategory || !taxonomy) && displayProject.tags.map((t) => (
                    <span key={t} className="text-xs px-2.5 py-1 rounded-full font-medium"
                      style={{ background: 'var(--surface-muted)', color: 'var(--ink-2)' }}>{t}</span>
                  ))}
                  {displayProject.tvl && (
                    <span className="text-xs px-2.5 py-1 rounded-full font-medium tabular-nums"
                      style={{ background: 'rgba(26,128,71,0.08)', color: 'var(--bullish)' }}>
                      TVL {displayProject.tvl}
                      <span className="ml-1 opacity-60">(self-reported)</span>
                    </span>
                  )}
                  <span className="text-xs px-2.5 py-1 rounded-full font-medium"
                    style={{ background: 'var(--surface-muted)', color: 'var(--subtle)' }}>
                    Since {displayProject.launchDate}
                  </span>
                </div>

                {/* Community sentiment */}
                <div className="p-4 rounded-2xl space-y-3" style={{ background: 'var(--surface-muted)' }}>
                  <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                    Community Sentiment
                  </p>
                  <VoteBar votes={displayProject.votes} />
                  <div className="flex gap-2">
                    {(['bullish', 'neutral', 'bearish'] as Sentiment[]).map((s) => {
                      const icons = { bullish: TrendingUp, neutral: Minus, bearish: TrendingDown }
                      const Icon  = icons[s]
                      const active = userVote === s
                      const activeStyles = {
                        bullish: { background: 'rgba(26,128,71,0.12)',  color: 'var(--bullish)', borderColor: 'rgba(26,128,71,0.30)' },
                        neutral: { background: 'rgba(107,101,128,0.12)', color: 'var(--neutral)', borderColor: 'rgba(107,101,128,0.30)' },
                        bearish: { background: 'rgba(186,43,76,0.12)',  color: 'var(--bearish)', borderColor: 'rgba(186,43,76,0.30)' },
                      }
                      return (
                        <motion.button key={s} whileTap={{ scale: 0.94 }} onClick={() => onVote(project.id, s)}
                          className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl border font-medium text-sm transition-all min-h-[44px]"
                          style={active
                            ? { ...activeStyles[s], borderWidth: '1.5px' }
                            : { background: 'var(--surface)', color: 'var(--muted)', borderColor: 'var(--border)', borderWidth: '1.5px' }}>
                          <Icon size={14} strokeWidth={active ? 2.5 : 2} />
                          <span className="capitalize">{s}</span>
                        </motion.button>
                      )
                    })}
                  </div>
                </div>

                {/* Sub-tabs: Reviews | Analytics (owner-only) */}
                {isOwner && (
                  <div className="flex rounded-xl p-1" style={{ background: 'var(--surface-muted)' }}>
                    {([
                      { id: 'reviews' as SheetTab, label: 'Reviews' },
                      { id: 'analytics' as SheetTab, label: 'Analytics', icon: BarChart2 },
                    ]).map(({ id, label, icon: Icon }) => (
                      <button key={id} onClick={() => setSheetTab(id)}
                        className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-sm font-medium transition-all"
                        style={sheetTab === id
                          ? { background: 'var(--surface-strong)', color: 'var(--ink)', boxShadow: '0 1px 4px rgba(18,45,69,0.10)' }
                          : { color: 'var(--muted)' }}>
                        {Icon && <Icon size={13} />}
                        {label}
                      </button>
                    ))}
                  </div>
                )}

                {/* Analytics tab content */}
                {isOwner && sheetTab === 'analytics' && (
                  <AnalyticsTab
                    project={displayProject}
                    reviewOverrides={reviewOverrides}
                    seedHelpfulDeltas={seedHelpfulDeltas}
                    contractAddress={contractAddress}
                    analyticsRefetchKey={analyticsRefetchKey}
                    lastReportGenerated={lastReportGenerated}
                    markReportGenerated={markReportGenerated}
                    allProjects={allProjects}
                  />
                )}

                {/* Reviews tab content */}
                {sheetTab === 'reviews' && (
                  <>
                    {/* ── Milestones section ──────────────────────────────── */}
                    {milestones.achievedCount > 0 && (
                      <div className="space-y-2">
                        <button
                          onClick={() => { setShowMilestones((v) => !v); milestones.markAllSeen() }}
                          className="w-full flex items-center justify-between px-4 py-2.5 rounded-xl transition-opacity hover:opacity-80"
                          style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}
                        >
                          <div className="flex items-center gap-2">
                            <Flame size={14} style={{ color: 'var(--accent)' }} />
                            <span className="text-xs font-semibold" style={{ color: 'var(--ink)' }}>
                              {milestones.achievedCount} community milestone{milestones.achievedCount !== 1 ? 's' : ''}
                            </span>
                            {milestones.newCount > 0 && (
                              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full"
                                style={{ background: 'var(--accent)', color: '#fff' }}>
                                {milestones.newCount} new
                              </span>
                            )}
                          </div>
                          <span className="text-xs" style={{ color: 'var(--subtle)' }}>
                            {showMilestones ? 'Hide' : 'Show'}
                          </span>
                        </button>
                        {showMilestones && (
                          <div className="space-y-1.5">
                            {milestones.achieved.map((m, i) => (
                              <MilestoneShareCard
                                key={m.id}
                                milestone={m}
                                project={displayProject}
                                compact
                                animationDelay={i * 0.04}
                              />
                            ))}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Reviews list */}
                    <div className="space-y-3">
                      <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                        Reviews ({displayProject.reviews.length})
                      </p>
                      {displayProject.reviews.length === 0 && (
                        <div className="py-6 text-center text-sm" style={{ color: 'var(--subtle)' }}>
                          No reviews yet. Be the first.
                        </div>
                      )}
                      {sortedReviews.map((review) => {
                        const alreadyHelpful      = helpfulVoted[review.id]
                        const flagCount           = flagCounts[review.id] ?? 0
                        const isMisleading        = flagCount >= 3
                        const isExpanded          = expandedFlagged.has(review.id)
                        const isOwnReview         = connectedAddress &&
                          review.authorFull.toLowerCase() === connectedAddress.toLowerCase()
                        const alreadyFlagged      = flaggedByMe[review.id] ?? false
                        const isModHidden         = hiddenReviewIds.has(review.id)
                        const isAuthorBlacklisted = isBlacklisted?.(review.authorFull) ?? false
                        const isPinned            = pinnedIds.has(review.id)
                        const reviewResponseList: ReviewResponse[] = reviewResponses[review.id] ?? []
                        const isShowingHideForm   = hideReasonFor === review.id
                        // Boost stats — uses original array index for contract storage lookup
                        const origIdx             = displayProject.reviews.findIndex((r) => r.id === review.id)
                        const boostStat           = upvoteStats[origIdx]
                        const isBoosted           = (boostStat?.totalWeight ?? 0n) > 0n
                        const boostCountDisplay   = boostStat?.count ?? 0
                        const boostWeightDisplay  = boostStat
                          ? (Number(boostStat.totalWeight / 1_000_000_000_000n) / 1_000_000).toFixed(3)
                          : '0.000'

                        // Blacklisted author: show redacted placeholder (no author, no body, no actions)
                        if (isAuthorBlacklisted) {
                          return (
                            <div key={review.id}
                              className="rounded-2xl px-4 py-3"
                              style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
                              <p className="text-xs italic" style={{ color: 'var(--subtle)' }}>
                                Content from this address is not available.
                              </p>
                            </div>
                          )
                        }

                        return (
                          <motion.div
                            key={review.id}
                            layout
                            className="rounded-2xl space-y-2.5 overflow-hidden"
                            style={{
                              background: 'var(--surface-muted)',
                              border: `1px solid ${isPinned ? 'var(--accent)' : 'var(--border)'}`,
                              borderLeft: isPinned ? '3px solid var(--accent)' : undefined,
                              opacity: (isMisleading && !isExpanded) || isModHidden ? 0.7 : 1,
                              transition: 'opacity 0.2s',
                              padding: '1rem',
                            }}
                          >
                            {/* Author row */}
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2 flex-wrap min-w-0">
                                <button
                                  onClick={() => { void navigate(`/profile/${review.authorFull}`) }}
                                  className="text-xs font-medium hover:opacity-70 transition-opacity flex items-center gap-1"
                                  style={{ color: 'var(--ink-2)' }}
                                  title="View profile"
                                >
                                  <IdentityLabel
                                    address={review.authorFull}
                                    fallback={review.author}
                                    style={{ color: 'var(--ink-2)' }}
                                  />
                                  <ExternalLink size={10} style={{ color: 'var(--subtle)' }} />
                                </button>
                                {allProjects.length > 0 && (
                                  <AuthorRepBadge
                                    authorFull={review.authorFull}
                                    allProjects={allProjects}
                                    reviewOverrides={reviewOverrides}
                                    seedHelpfulDeltas={seedHelpfulDeltas}
                                  />
                                )}
                                <SentimentBadge sentiment={review.sentiment} size="sm" />
                                {isPinned && (
                                  <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-semibold flex-shrink-0"
                                    style={{ background: 'rgba(26,92,255,0.10)', color: 'var(--accent)' }}>
                                    <Pin size={9} strokeWidth={2.5} />
                                    Pinned
                                  </span>
                                )}
                                {isModHidden && (
                                  <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-semibold flex-shrink-0"
                                    style={{ background: 'rgba(186,43,76,0.10)', color: 'var(--bearish)' }}>
                                    Hidden
                                  </span>
                                )}
                                {isBoosted && (
                                  <span
                                    className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-semibold flex-shrink-0"
                                    style={{ background: 'rgba(26,92,255,0.10)', color: 'var(--accent)' }}
                                    title="This review has received economic conviction boosts from other users"
                                  >
                                    <Zap size={9} strokeWidth={2.5} />
                                    Boosted
                                  </span>
                                )}
                              </div>
                              <span className="text-xs flex-shrink-0" style={{ color: 'var(--subtle)' }}>
                                {timeAgo(review.timestamp)}
                              </span>
                            </div>

                            {/* Body — moderated hidden shows placeholder */}
                            {isModHidden ? (
                              <p className="text-sm italic" style={{ color: 'var(--subtle)' }}>
                                This review has been removed for policy violations.
                              </p>
                            ) : (
                              <div
                                className={isMisleading && !isExpanded ? 'overflow-hidden' : ''}
                                style={isMisleading && !isExpanded ? { maxHeight: '2.8em', WebkitMaskImage: 'linear-gradient(to bottom, black 60%, transparent)' } : {}}
                              >
                                <p className="text-sm leading-relaxed text-pretty" style={{ color: 'var(--ink-2)' }}>
                                  {review.body}
                                </p>
                              </div>
                            )}

                            {!isModHidden && isMisleading && (
                              <button
                                onClick={() => setExpandedFlagged((prev) => {
                                  const next = new Set(prev)
                                  if (next.has(review.id)) next.delete(review.id)
                                  else next.add(review.id)
                                  return next
                                })}
                                className="text-xs font-medium transition-opacity hover:opacity-70"
                                style={{ color: 'var(--subtle)' }}
                              >
                                {isExpanded ? 'Collapse' : `Show anyway (${flagCount} flags)`}
                              </button>
                            )}

                            {/* Owner moderation controls */}
                            {isOwner && !isOwnReview && (
                              <div className="flex items-center gap-2 flex-wrap">
                                {isModHidden ? (
                                  <button
                                    onClick={() => {
                                      void moderateReview(review.id, 'restored').then(() =>
                                        toast.success('Review restored.')
                                      )
                                    }}
                                    className="flex items-center gap-1.5 text-xs px-2 py-1 rounded-lg min-h-[32px] transition-all hover:opacity-85"
                                    style={{ background: 'rgba(26,128,71,0.10)', color: 'var(--bullish)', border: '1px solid rgba(26,128,71,0.25)' }}
                                  >
                                    <Eye size={11} /> Restore
                                  </button>
                                ) : (
                                  <button
                                    onClick={() => {
                                      setHideReasonFor(isShowingHideForm ? null : review.id)
                                      setHideReasonVal('Policy violation')
                                    }}
                                    className="flex items-center gap-1.5 text-xs px-2 py-1 rounded-lg min-h-[32px] transition-all hover:opacity-85"
                                    style={{ background: 'rgba(186,43,76,0.07)', color: 'var(--bearish)', border: '1px solid rgba(186,43,76,0.20)' }}
                                  >
                                    <EyeOff size={11} /> Hide Review
                                  </button>
                                )}
                              </div>
                            )}

                            {/* Inline hide-reason form */}
                            <AnimatePresence>
                              {isShowingHideForm && (
                                <motion.div
                                  key={`hide-form-${review.id}`}
                                  initial={{ opacity: 0, height: 0 }}
                                  animate={{ opacity: 1, height: 'auto' }}
                                  exit={{ opacity: 0, height: 0 }}
                                  style={{ overflow: 'hidden' }}
                                >
                                  <div className="pt-1 space-y-2">
                                    <select
                                      value={hideReasonVal}
                                      onChange={(e) => setHideReasonVal(e.target.value)}
                                      className="w-full px-3 py-2 rounded-xl text-sm border bg-transparent outline-none min-h-[40px]"
                                      style={{ borderColor: 'var(--border)', color: 'var(--ink)', fontFamily: "'DM Sans', sans-serif" }}
                                    >
                                      <option>Policy violation</option>
                                      <option>Spam</option>
                                      <option>Misleading information</option>
                                      <option>Other</option>
                                    </select>
                                    <div className="flex gap-2">
                                      <button
                                        onClick={() => {
                                          void moderateReview(review.id, 'hidden', hideReasonVal).then(() => {
                                            toast.success('Review hidden.')
                                            setHideReasonFor(null)
                                          })
                                        }}
                                        className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold min-h-[40px] hover:opacity-85 transition-opacity"
                                        style={{ background: 'rgba(186,43,76,0.90)', color: '#fff' }}
                                      >
                                        <EyeOff size={11} /> Confirm Hide
                                      </button>
                                      <button
                                        onClick={() => setHideReasonFor(null)}
                                        className="px-3 py-2 rounded-xl text-xs min-h-[40px]"
                                        style={{ background: 'var(--surface-muted)', color: 'var(--muted)', border: '1px solid var(--border)' }}
                                      >
                                        Cancel
                                      </button>
                                    </div>
                                  </div>
                                </motion.div>
                              )}
                            </AnimatePresence>

                            {/* Helpful + Flag + Tip row — hidden when review is moderated */}
                            {!isModHidden && <div className="flex items-center gap-2 flex-wrap">
                              <button
                                onClick={() => onHelpful?.(project.id, review.id)}
                                disabled={alreadyHelpful}
                                className="flex items-center gap-1.5 text-xs transition-all rounded-lg px-2 py-1 min-h-[32px]"
                                style={alreadyHelpful
                                  ? { background: 'rgba(26,128,71,0.10)', color: 'var(--bullish)', cursor: 'default' }
                                  : { background: 'var(--surface)', color: 'var(--subtle)', border: '1px solid var(--border)', cursor: 'pointer' }}>
                                <ThumbsUp size={12} strokeWidth={alreadyHelpful ? 2.5 : 2} />
                                <span className="tabular-nums">{review.helpful}</span>
                                <span>{alreadyHelpful ? 'Helpful' : 'Helpful?'}</span>
                              </button>

                              {!isOwnReview && (
                                <button
                                  onClick={() => {
                                    if (!isConnected) { toast.error('Connect your wallet to flag a review.'); return }
                                    if (alreadyFlagged) { toast('You already flagged this review.', { duration: 1800 }); return }
                                    void flagReviewRemote(review.id)
                                    toast.success('Review flagged.', { duration: 1800 })
                                  }}
                                  className="flex items-center gap-1.5 text-xs transition-all rounded-lg px-2 py-1 min-h-[32px]"
                                  style={alreadyFlagged
                                    ? { background: 'rgba(186,43,76,0.08)', color: 'var(--bearish)', cursor: 'default' }
                                    : { background: 'var(--surface)', color: 'var(--subtle)', border: '1px solid var(--border)', cursor: 'pointer' }}
                                  title="Flag as misleading"
                                >
                                  <Flag size={12} strokeWidth={alreadyFlagged ? 2.5 : 2} />
                                  <span>{alreadyFlagged ? 'Flagged' : 'Flag'}</span>
                                  {flagCount > 0 && (
                                    <span className="tabular-nums">({flagCount})</span>
                                  )}
                                </button>
                              )}

                              {/* Tip button — hidden on own reviews, only in onchain mode */}
                              {!isOwnReview && contractAddress && (
                                <button
                                  onClick={() => setOpenTipId(openTipId === review.id ? null : review.id)}
                                  className="flex items-center gap-1.5 text-xs transition-all rounded-lg px-2 py-1 min-h-[32px]"
                                  style={openTipId === review.id
                                    ? { background: 'rgba(239,68,68,0.10)', color: '#ef4444', border: '1px solid rgba(239,68,68,0.25)' }
                                    : { background: 'var(--surface)', color: 'var(--subtle)', border: '1px solid var(--border)' }}
                                  title="Tip this reviewer"
                                >
                                  <Heart size={12} strokeWidth={openTipId === review.id ? 2.5 : 2} />
                                  <span>Tip</span>
                                </button>
                              )}

                              {/* Boost button — economic signal, pays author, only in onchain mode, not own review */}
                              {!isOwnReview && contractAddress && (
                                <button
                                  onClick={() => setOpenBoostId(openBoostId === review.id ? null : review.id)}
                                  className="flex items-center gap-1.5 text-xs transition-all rounded-lg px-2 py-1 min-h-[32px] ml-auto"
                                  style={openBoostId === review.id
                                    ? { background: 'rgba(26,92,255,0.12)', color: 'var(--accent)', border: '1px solid rgba(26,92,255,0.30)' }
                                    : { background: 'var(--surface)', color: 'var(--subtle)', border: '1px solid var(--border)' }}
                                  title="Boost this review — economic signal that pays the author"
                                >
                                  <ChevronUp size={12} strokeWidth={openBoostId === review.id ? 2.5 : 2} />
                                  {isBoosted
                                    ? <span>{boostCountDisplay} boost{boostCountDisplay !== 1 ? 's' : ''} · ${boostWeightDisplay}</span>
                                    : <span>Boost</span>
                                  }
                                </button>
                              )}
                            </div>}

                            {/* Inline tip selector */}
                            <AnimatePresence>
                              {openTipId === review.id && (
                                <motion.div
                                  key={`tip-${review.id}`}
                                  initial={{ opacity: 0, height: 0 }}
                                  animate={{ opacity: 1, height: 'auto' }}
                                  exit={{ opacity: 0, height: 0 }}
                                  style={{ overflow: 'hidden' }}
                                >
                                  <div className="pt-2 space-y-2">
                                    {/* Amount chips */}
                                    <div className="flex gap-2 flex-wrap">
                                      {TIP_PRESETS.map((preset) => {
                                        const active = selectedTip === preset.value
                                        return (
                                          <motion.button
                                            layout
                                            key={preset.label}
                                            onClick={() => setSelectedTip(preset.value)}
                                            className="flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-semibold min-h-[32px] transition-all flex-shrink-0"
                                            style={active
                                              ? { background: 'rgba(239,68,68,0.10)', color: '#ef4444', border: '1.5px solid rgba(239,68,68,0.35)' }
                                              : { background: 'var(--surface)', color: 'var(--ink-2)', border: '1px solid var(--border)' }}
                                          >
                                            {active && <Check size={11} />}
                                            {preset.label} USDC
                                          </motion.button>
                                        )
                                      })}
                                    </div>

                                    {/* Reviewer receives line */}
                                    <p className="text-xs" style={{ color: 'var(--subtle)' }}>
                                      Reviewer receives{' '}
                                      <span className="font-semibold" style={{ color: 'var(--ink-2)' }}>
                                        {reviewerReceivesDisplay} USDC
                                      </span>
                                      {' '}({Number(10_000n - tipFeeBps) / 100}% after protocol fee)
                                    </p>

                                    {/* Confirm / Cancel */}
                                    <div className="flex gap-2">
                                      {isConnected ? (
                                        <button
                                          onClick={() => void handleTipReviewer(displayProject.reviews.findIndex((r) => r.id === review.id), review.authorFull)}
                                          disabled={isTipping}
                                          className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold min-h-[40px] transition-all hover:opacity-85"
                                          style={{
                                            background: '#ef4444',
                                            color: '#fff',
                                            opacity: isTipping ? 0.6 : 1,
                                          }}
                                        >
                                          <Heart size={12} />
                                          {isTipping ? 'Sending…' : `Send ${TIP_PRESETS.find(p => p.value === selectedTip)?.label ?? ''} USDC`}
                                        </button>
                                      ) : (
                                        <p className="text-xs py-2" style={{ color: 'var(--subtle)' }}>
                                          Connect your wallet to tip.
                                        </p>
                                      )}
                                      <button
                                        onClick={() => setOpenTipId(null)}
                                        className="px-3 py-2 rounded-xl text-xs font-medium min-h-[40px]"
                                        style={{ background: 'var(--surface-muted)', color: 'var(--muted)', border: '1px solid var(--border)' }}
                                      >
                                        Cancel
                                      </button>
                                    </div>
                                  </div>
                                </motion.div>
                              )}
                            </AnimatePresence>

                            {/* Inline boost selector */}
                            <AnimatePresence>
                              {openBoostId === review.id && (
                                <motion.div
                                  key={`boost-${review.id}`}
                                  initial={{ opacity: 0, height: 0 }}
                                  animate={{ opacity: 1, height: 'auto' }}
                                  exit={{ opacity: 0, height: 0 }}
                                  style={{ overflow: 'hidden' }}
                                >
                                  <div className="pt-2 space-y-2">
                                    {/* Amount chips */}
                                    <div className="flex gap-2 flex-wrap">
                                      {BOOST_PRESETS.map((preset) => {
                                        const active = selectedBoost === preset.value
                                        return (
                                          <motion.button
                                            layout
                                            key={preset.label}
                                            onClick={() => setSelectedBoost(preset.value)}
                                            className="flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-semibold min-h-[32px] transition-all flex-shrink-0"
                                            style={active
                                              ? { background: 'rgba(26,92,255,0.12)', color: 'var(--accent)', border: '1.5px solid rgba(26,92,255,0.35)' }
                                              : { background: 'var(--surface)', color: 'var(--ink-2)', border: '1px solid var(--border)' }}
                                          >
                                            {active && <Check size={11} />}
                                            {preset.label} USDC
                                          </motion.button>
                                        )
                                      })}
                                    </div>

                                    {/* Author receives line */}
                                    <p className="text-xs" style={{ color: 'var(--subtle)' }}>
                                      Author receives{' '}
                                      <span className="font-semibold" style={{ color: 'var(--ink-2)' }}>
                                        {boostAuthorReceivesDisplay} USDC
                                      </span>
                                      {' '}({Number(10_000n - boostFeeBps) / 100}% after protocol fee)
                                    </p>

                                    {/* Confirm / Cancel */}
                                    <div className="flex gap-2">
                                      {isConnected ? (
                                        <button
                                          onClick={() => void handleBoostReview(origIdx, review.authorFull)}
                                          disabled={isBoosting}
                                          className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold min-h-[40px] transition-all hover:opacity-85"
                                          style={{
                                            background: 'var(--accent)',
                                            color: '#fff',
                                            opacity: isBoosting ? 0.6 : 1,
                                          }}
                                        >
                                          <ChevronUp size={12} />
                                          {isBoosting ? 'Boosting…' : `Boost ${BOOST_PRESETS.find(p => p.value === selectedBoost)?.label ?? ''} USDC`}
                                        </button>
                                      ) : (
                                        <p className="text-xs py-2" style={{ color: 'var(--subtle)' }}>
                                          Connect your wallet to boost.
                                        </p>
                                      )}
                                      <button
                                        onClick={() => setOpenBoostId(null)}
                                        className="px-3 py-2 rounded-xl text-xs font-medium min-h-[40px]"
                                        style={{ background: 'var(--surface-muted)', color: 'var(--muted)', border: '1px solid var(--border)' }}
                                      >
                                        Cancel
                                      </button>
                                    </div>
                                  </div>
                                </motion.div>
                              )}
                            </AnimatePresence>

                            {/* Owner responses */}
                            {reviewResponseList.length > 0 && (
                              <div className="ml-3 pl-3 space-y-2"
                                style={{ borderLeft: '2px solid var(--border)' }}>
                                {reviewResponseList.map((resp) => (
                                  <div key={resp.id} className="rounded-xl px-3 py-2 space-y-0.5"
                                    style={{ background: 'rgba(26,92,255,0.05)', border: '1px solid rgba(26,92,255,0.12)' }}>
                                    <div className="flex items-center gap-1.5">
                                      <ShieldCheck size={11} style={{ color: 'var(--accent)', flexShrink: 0 }} />
                                      <span className="text-[10px] font-semibold" style={{ color: 'var(--accent)' }}>
                                        Verified Owner
                                      </span>
                                      <span className="text-[10px]" style={{ color: 'var(--subtle)' }}>
                                        · {formatResponseTime(resp.createdAt)}
                                      </span>
                                    </div>
                                    <p className="text-xs leading-relaxed" style={{ color: 'var(--ink-2)' }}>
                                      {resp.body}
                                    </p>
                                  </div>
                                ))}
                              </div>
                            )}

                            {/* Reply button + inline form (owner only) */}
                            {isOwner && !isOwnReview && (
                              <>
                                {openReplyId !== review.id && (
                                  <button
                                    onClick={() => { setOpenReplyId(review.id); setReplyBody('') }}
                                    className="flex items-center gap-1.5 text-xs font-medium px-2 py-1 rounded-lg min-h-[32px] transition-all hover:opacity-70"
                                    style={{ background: 'var(--surface)', color: 'var(--accent)', border: '1px solid rgba(26,92,255,0.20)' }}
                                  >
                                    <MessageSquare size={11} />
                                    Reply as owner
                                  </button>
                                )}
                                <AnimatePresence>
                                  {openReplyId === review.id && (
                                    <motion.div
                                      key={`reply-${review.id}`}
                                      initial={{ opacity: 0, height: 0 }}
                                      animate={{ opacity: 1, height: 'auto' }}
                                      exit={{ opacity: 0, height: 0 }}
                                      style={{ overflow: 'hidden' }}
                                    >
                                      <div className="pt-1 space-y-2">
                                        <textarea
                                          value={replyBody}
                                          onChange={(e) => setReplyBody(e.target.value.slice(0, 280))}
                                          placeholder="Write a response as verified owner..."
                                          rows={2}
                                          className="w-full resize-none rounded-xl px-3 py-2.5 text-sm outline-none"
                                          style={{ background: 'var(--surface)', color: 'var(--ink)', border: '1.5px solid var(--border)', fontFamily: "'DM Sans', sans-serif" }}
                                          onFocus={(e) => { e.target.style.borderColor = 'var(--focus)' }}
                                          onBlur={(e)  => { e.target.style.borderColor = 'var(--border)' }}
                                        />
                                        <div className="flex items-center justify-between gap-2">
                                          <span className="text-xs tabular-nums" style={{ color: 'var(--subtle)' }}>
                                            {replyBody.length}/280
                                          </span>
                                          <div className="flex gap-2">
                                            <button
                                              onClick={() => { void handlePostReply(review.id) }}
                                              disabled={replyBody.trim().length < 1 || isPostingReply}
                                              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold min-h-[36px] transition-all hover:opacity-85"
                                              style={replyBody.trim().length >= 1
                                                ? { background: 'var(--accent)', color: 'var(--bg)' }
                                                : { background: 'var(--surface-muted)', color: 'var(--subtle)', cursor: 'not-allowed' }}
                                            >
                                              <Send size={11} />
                                              {isPostingReply ? 'Posting…' : 'Post Reply'}
                                            </button>
                                            <button
                                              onClick={() => setOpenReplyId(null)}
                                              className="px-3 py-2 rounded-xl text-xs min-h-[36px]"
                                              style={{ background: 'var(--surface-muted)', color: 'var(--muted)', border: '1px solid var(--border)' }}
                                            >
                                              Cancel
                                            </button>
                                          </div>
                                        </div>
                                      </div>
                                    </motion.div>
                                  )}
                                </AnimatePresence>
                              </>
                            )}
                          </motion.div>
                        )
                      })}
                    </div>

                    {/* Write a review */}
                    <div className="space-y-3">
                      <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                        Write a Review
                      </p>
                      {!isConnected ? (
                        <div className="flex items-center gap-3 p-4 rounded-2xl"
                          style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
                          <Lock size={16} style={{ color: 'var(--subtle)', flexShrink: 0 }} />
                          <p className="text-sm" style={{ color: 'var(--muted)' }}>
                            Connect your wallet to leave a review.
                          </p>
                        </div>
                      ) : (
                        <>
                          <div className="flex gap-2">
                            {(['bullish', 'neutral', 'bearish'] as Sentiment[]).map((s) => (
                              <button key={s} onClick={() => setReviewSentiment(s)}
                                className="flex-1 py-2 rounded-xl text-xs font-medium capitalize border transition-all"
                                style={reviewSentiment === s
                                  ? {
                                      background: s === 'bullish' ? 'rgba(26,128,71,0.10)' : s === 'bearish' ? 'rgba(186,43,76,0.10)' : 'rgba(107,101,128,0.10)',
                                      color: s === 'bullish' ? 'var(--bullish)' : s === 'bearish' ? 'var(--bearish)' : 'var(--neutral)',
                                      borderColor: s === 'bullish' ? 'rgba(26,128,71,0.30)' : s === 'bearish' ? 'rgba(186,43,76,0.30)' : 'rgba(107,101,128,0.30)',
                                    }
                                  : { background: 'var(--surface-muted)', color: 'var(--muted)', borderColor: 'transparent' }}>
                                {s}
                              </button>
                            ))}
                          </div>
                          <textarea value={reviewBody} onChange={(e) => setReviewBody(e.target.value)}
                            placeholder="Share your honest experience with this project..."
                            rows={3} maxLength={400}
                            className="w-full resize-none rounded-xl px-3.5 py-3 text-sm outline-none transition-all leading-relaxed"
                            style={{ background: 'var(--surface-muted)', color: 'var(--ink)', border: '1.5px solid var(--border)', fontFamily: "'DM Sans', sans-serif" }}
                            onFocus={(e) => { e.target.style.borderColor = 'var(--focus)' }}
                            onBlur={(e)  => { e.target.style.borderColor = 'var(--border)' }} />
                          <div className="flex items-center justify-between">
                            <span className="text-xs tabular-nums" style={{ color: 'var(--subtle)' }}>
                              {reviewBody.length}/400
                            </span>
                            <motion.button whileTap={{ scale: 0.96 }} onClick={handleSubmitReview}
                              disabled={reviewBody.trim().length < 10 || submitted}
                              className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all"
                              style={submitted
                                ? { background: 'rgba(26,128,71,0.12)', color: 'var(--bullish)' }
                                : reviewBody.trim().length >= 10
                                ? { background: 'var(--accent)', color: 'var(--bg)' }
                                : { background: 'var(--surface-muted)', color: 'var(--subtle)', cursor: 'not-allowed' }}>
                              {submitted ? 'Review posted' : <><Send size={14} /> Post review</>}
                            </motion.button>
                          </div>
                        </>
                      )}
                    </div>
                  </>
                )}
              </div>
            </div>
        </motion.div>
      )}

      {/* Embed code modal — rendered as sibling AnimatePresence inside main portal */}
      <AnimatePresence>
        {showEmbed && project && contractAddress && (
          <EmbedModal
            key="embed-modal"
            projectId={project.id}
            contractAddress={contractAddress}
            onClose={() => setShowEmbed(false)}
          />
        )}
      </AnimatePresence>
    </AnimatePresence>
  )
}

// ── EmbedModal ────────────────────────────────────────────────────────────────
// Defined outside ProjectDetailSheet to avoid re-declaration on every render.

type EmbedTab = 'react' | 'html' | 'iframe'

interface EmbedModalProps {
  projectId: string
  contractAddress: string
  onClose: () => void
}

function EmbedModal({ projectId, contractAddress, onClose }: EmbedModalProps) {
  const [tab, setTab] = useState<EmbedTab>('html')
  const [theme, setTheme] = useState<'dark' | 'light'>('dark')
  const [size, setSize] = useState<'sm' | 'md' | 'lg'>('md')

  const origin = typeof window !== 'undefined' ? window.location.origin : 'https://myarc.io'
  const iframeW = size === 'sm' ? 120 : size === 'md' ? 200 : 280
  const iframeH = size === 'sm' ? 48  : size === 'md' ? 72  : 96

  const codeByTab: Record<EmbedTab, string> = {
    react: `import { PulseBadge } from '@myarc/widget'

<PulseBadge
  projectId="${projectId}"
  contractAddress="${contractAddress}"
  theme="${theme}"
  size="${size}"
/>`,
    html: `<script src="${origin}/widget/pulse-badge.iife.js"></script>
<div id="pulse-badge"></div>
<script>
  PulseBadge.mount('#pulse-badge', {
    projectId: '${projectId}',
    contractAddress: '${contractAddress}',
    theme: '${theme}',
    size: '${size}',
  });
</script>`,
    iframe: `<iframe
  src="${origin}/widget/${projectId}"
  width="${iframeW}"
  height="${iframeH}"
  frameborder="0"
  style="border:none;"
  title="MYARC badge for ${projectId}"
></iframe>`,
  }

  const copyCode = () => {
    void navigator.clipboard.writeText(codeByTab[tab]).then(() =>
      toast.success('Embed code copied.')
    )
  }

  return (
    <motion.div
      key="embed-backdrop"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      style={{
        position: 'fixed', inset: 0, zIndex: 60,
        background: 'rgba(0,0,0,0.65)', backdropFilter: 'blur(4px)',
        display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
      }}
      onClick={onClose}
    >
      <motion.div
        key="embed-panel"
        initial={{ y: 80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 80, opacity: 0 }}
        transition={{ type: 'spring', stiffness: 320, damping: 32 }}
        style={{
          background: 'var(--surface-strong)',
          border: '1px solid var(--border)',
          borderRadius: '20px 20px 0 0',
          width: '100%',
          maxWidth: '560px',
          maxHeight: '90vh',
          overflowY: 'auto',
          padding: '24px 20px',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-5">
          <h3 className="text-base font-semibold" style={{ color: 'var(--ink)' }}>
            Embed Pulse Badge
          </h3>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:opacity-70"
            style={{ background: 'var(--surface-muted)', color: 'var(--muted)' }}>
            <X size={16} />
          </button>
        </div>

        {/* Theme + size toggles */}
        <div className="flex gap-3 mb-5 flex-wrap">
          <div className="flex gap-1">
            {(['dark', 'light'] as const).map((t) => (
              <button key={t} onClick={() => setTheme(t)}
                className="px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-all"
                style={theme === t
                  ? { background: 'var(--accent)', color: 'var(--bg)' }
                  : { background: 'var(--surface-muted)', color: 'var(--muted)' }}>
                {t}
              </button>
            ))}
          </div>
          <div className="flex gap-1">
            {(['sm', 'md', 'lg'] as const).map((s) => (
              <button key={s} onClick={() => setSize(s)}
                className="px-3 py-1.5 rounded-lg text-xs font-medium uppercase transition-all"
                style={size === s
                  ? { background: 'var(--accent)', color: 'var(--bg)' }
                  : { background: 'var(--surface-muted)', color: 'var(--muted)' }}>
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Live preview — all three sizes */}
        <div className="mb-5 p-4 rounded-xl flex flex-col gap-3 items-start"
          style={{ background: theme === 'dark' ? '#0d1117' : '#f6f8fa', border: '1px solid var(--border)' }}>
          <p className="text-xs mb-1" style={{ color: 'var(--muted)' }}>Live preview</p>
          {(['sm', 'md', 'lg'] as const).map((s) => (
            <div key={s} className="flex items-center gap-3">
              <span className="text-xs uppercase w-4" style={{ color: 'var(--subtle)' }}>{s}</span>
              <PulseBadge
                projectId={projectId}
                contractAddress={contractAddress}
                theme={theme}
                size={s}
              />
            </div>
          ))}
        </div>

        {/* Code tabs */}
        <div className="flex gap-1 mb-3">
          {(['html', 'react', 'iframe'] as const).map((t) => (
            <button key={t} onClick={() => setTab(t)}
              className="px-3 py-1.5 rounded-lg text-xs font-medium uppercase transition-all"
              style={tab === t
                ? { background: 'var(--accent)', color: 'var(--bg)' }
                : { background: 'var(--surface-muted)', color: 'var(--muted)' }}>
              {t}
            </button>
          ))}
        </div>

        {/* Code block */}
        <div className="relative">
          <pre
            className="w-full p-4 rounded-xl text-xs leading-relaxed overflow-x-auto mono"
            style={{
              background: 'var(--surface-muted)',
              color: 'var(--ink)',
              border: '1px solid var(--border)',
              whiteSpace: 'pre-wrap',
              wordBreak: 'break-all',
            }}
          >{codeByTab[tab]}</pre>
          <button
            onClick={copyCode}
            className="absolute top-2 right-2 px-2.5 py-1 rounded-lg text-xs font-medium transition-all hover:opacity-80"
            style={{ background: 'var(--accent)', color: 'var(--bg)' }}
          >
            Copy
          </button>
        </div>
      </motion.div>
    </motion.div>
  )
}
