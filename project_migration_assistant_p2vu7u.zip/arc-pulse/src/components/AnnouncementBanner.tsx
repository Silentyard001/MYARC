/**
 * AnnouncementBanner
 *
 * Full-width strip rendered above the nav. Shows up to 3 active announcements
 * newest-first. Each can be dismissed (session-local via localStorage).
 * Types: info (accent), warning (amber), success (bullish).
 */
import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, AlertTriangle, CheckCircle, Info } from 'lucide-react'
import type { Announcement } from '../hooks/useAnnouncements'

const DISMISSED_KEY = 'myarc:dismissed-announcements'

function getDismissed(): Set<string> {
  try {
    const raw = sessionStorage.getItem(DISMISSED_KEY)
    if (!raw) return new Set()
    return new Set(JSON.parse(raw) as string[])
  } catch {
    return new Set()
  }
}

function saveDismissed(ids: Set<string>) {
  try {
    sessionStorage.setItem(DISMISSED_KEY, JSON.stringify([...ids]))
  } catch { /* ignore */ }
}

const TYPE_STYLES: Record<
  Announcement['type'],
  { bg: string; border: string; color: string; Icon: typeof Info }
> = {
  info: {
    bg: 'rgba(26,92,255,0.08)',
    border: 'rgba(26,92,255,0.20)',
    color: 'var(--accent)',
    Icon: Info,
  },
  warning: {
    bg: 'rgba(245,158,11,0.09)',
    border: 'rgba(245,158,11,0.30)',
    color: '#d97706',
    Icon: AlertTriangle,
  },
  success: {
    bg: 'rgba(26,128,71,0.08)',
    border: 'rgba(26,128,71,0.25)',
    color: 'var(--bullish)',
    Icon: CheckCircle,
  },
}

interface AnnouncementBannerProps {
  announcements: Announcement[]
}

export function AnnouncementBanner({ announcements }: AnnouncementBannerProps) {
  const [dismissed, setDismissed] = useState<Set<string>>(getDismissed)

  useEffect(() => {
    saveDismissed(dismissed)
  }, [dismissed])

  const visible = announcements
    .filter((a) => !dismissed.has(a.id))
    .slice(0, 3) // max 3

  if (visible.length === 0) return null

  return (
    <div className="w-full z-20" style={{ position: 'relative' }}>
      <AnimatePresence initial={false}>
        {visible.map((announcement) => {
          const { bg, border, color, Icon } = TYPE_STYLES[announcement.type]
          return (
            <motion.div
              key={announcement.id}
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.2 }}
              style={{ overflow: 'hidden' }}
            >
              <div
                className="w-full px-4 py-2.5 flex items-center gap-3"
                style={{
                  background: bg,
                  borderBottom: `1px solid ${border}`,
                }}
              >
                <Icon
                  size={14}
                  style={{ color, flexShrink: 0 }}
                  strokeWidth={2.5}
                />
                <p
                  className="flex-1 text-sm font-medium leading-snug"
                  style={{ color }}
                >
                  {announcement.message}
                </p>
                <button
                  onClick={() =>
                    setDismissed((prev) => new Set([...prev, announcement.id]))
                  }
                  className="flex-shrink-0 flex items-center justify-center w-7 h-7 rounded-full transition-opacity hover:opacity-70"
                  style={{ color }}
                  aria-label="Dismiss announcement"
                >
                  <X size={14} />
                </button>
              </div>
            </motion.div>
          )
        })}
      </AnimatePresence>
    </div>
  )
}
