/**
 * TrendingStrip
 *
 * Horizontal scroll strip showing the top-N trending projects as compact chips.
 * Trending score: (votes24h × 3) + (reviews24h × 5) + (abs(bullish% change) × 2)
 * Since we derive 24h activity from review timestamps and current vote state,
 * "votes in last 24h" is approximated from voteDeltas that were recorded today,
 * and "reviews in last 24h" from review timestamps.
 */

import { motion } from 'framer-motion'
import { TrendingUp, TrendingDown } from 'lucide-react'
import type { Project } from '../data/projects'
import { ProjectLogo } from './ProjectLogo'

export interface ProjectWithTrending extends Project {
  trendingScore: number
  /** positive = trending bullish, negative = trending bearish */
  trendDirection: number
}

interface TrendingStripProps {
  projects: ProjectWithTrending[]
  onSelect: (project: Project) => void
  /** How many chips to show (default 3) */
  count?: number
}

export function TrendingStrip({ projects, onSelect, count = 3 }: TrendingStripProps) {
  const top = [...projects]
    .sort((a, b) => b.trendingScore - a.trendingScore)
    .slice(0, count)

  if (top.length === 0) return null

  return (
    <div className="space-y-2 overflow-hidden">
      <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
        Trending Now
      </p>
      <div className="flex gap-2 overflow-x-auto pb-1" style={{ scrollbarWidth: 'none' }}>
        {top.map((p, i) => (
          <motion.button
            key={p.id}
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.06 }}
            onClick={() => onSelect(p)}
            className="flex-shrink-0 flex items-center gap-2 px-3.5 py-2.5 rounded-xl min-h-[44px] transition-all hover:opacity-85"
            style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}
          >
            {/* Logo */}
            <ProjectLogo project={p} size="sm" />

            {/* Name */}
            <span className="text-sm font-medium whitespace-nowrap" style={{ color: 'var(--ink)' }}>
              {p.name}
            </span>

            {/* Trend arrow */}
            {p.trendDirection > 0
              ? <TrendingUp size={14} style={{ color: 'var(--bullish)', flexShrink: 0 }} />
              : <TrendingDown size={14} style={{ color: 'var(--bearish)', flexShrink: 0 }} />
            }
          </motion.button>
        ))}
      </div>
    </div>
  )
}
