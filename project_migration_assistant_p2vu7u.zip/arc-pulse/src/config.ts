/**
 * wagmi + viem configuration
 * Built with Arc Studio — https://studio.arc.io
 *
 * Transport strategy for Arc Testnet:
 *   Primary:   https://rpc.testnet.arc.io  (official Arc RPC)
 *   Fallback:  https://5042002.rpc.thirdweb.com  (public fallback)
 *   Both wrapped in fallback() so viem auto-retries the secondary on any
 *   5xx / timeout from the primary. Each http() transport is configured with
 *   a 10-second per-request timeout and up to 2 retries before failing over.
 */

import { http, fallback, createConfig } from 'wagmi'
import { mainnet } from 'wagmi/chains'
import { arcTestnet } from 'viem/chains'
import { injected } from 'wagmi/connectors'
import { registerChain } from './tracing'

registerChain(arcTestnet.id, arcTestnet.rpcUrls.default.http[0])

const ARC_RPC_PRIMARY = 'https://rpc.testnet.arc.io'
const ARC_RPC_FALLBACK = 'https://5042002.rpc.thirdweb.com'

// rank: false (default) enforces strict priority order — primary is always
// tried first; ThirdWeb is only used when the primary fails. rank: true would
// race all transports and let ThirdWeb win, which blocks eth_getLogs with
// large block ranges due to CORS restrictions on the ThirdWeb public endpoint.
const arcTransport = fallback([
  http(ARC_RPC_PRIMARY, {
    timeout: 10_000,
    retryCount: 2,
    retryDelay: 500,
  }),
  http(ARC_RPC_FALLBACK, {
    timeout: 10_000,
    retryCount: 2,
    retryDelay: 500,
  }),
])

export const config = createConfig({
  chains: [arcTestnet, mainnet],
  connectors: [injected()],
  transports: {
    [arcTestnet.id]: arcTransport,
    [mainnet.id]: http(), // ENS resolution only
  },
})

/** Arc Testnet chain ID — imported from viem/chains, used in guard logic */
export const ARC_TESTNET_CHAIN_ID = arcTestnet.id
