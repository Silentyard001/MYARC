export type Sentiment = 'bullish' | 'neutral' | 'bearish';

export type VoteCounts = {
  bullish: number;
  neutral: number;
  bearish: number;
};

export type Review = {
  id: string;
  author: string; // truncated address
  authorFull: string;
  body: string;
  sentiment: Sentiment;
  timestamp: number; // ms since epoch
  helpful: number;
};

/**
 * @deprecated Use primaryCategory / useCases / tags (taxonomy ids) instead.
 * Kept for backwards-compat with any imported project data that hasn't been
 * migrated yet. New code should not use this type.
 */
export type Tag = 'DeFi' | 'NFT' | 'Gaming' | 'Infrastructure' | 'Bridge' | 'Payments' | 'DAO' | 'Launchpad';

// ─── Historical TVL (6 weekly snapshots, most-recent last) ───────────────────
// Values are in USD millions. Used to render the TvlSparkline component.
export type TvlSnapshot = {
  weekLabel: string; // e.g. "W1", "W2", …
  tvlM: number;      // USD millions
};

// ─── User activity sub-schema ─────────────────────────────────────────────────
export type UserVoteEntry = {
  projectId: string;
  sentiment: Sentiment;
  timestamp: number; // ms since epoch — when the vote was cast optimistically
};

export type UserReviewEntry = {
  projectId: string;
  reviewId: string;
  sentiment: Sentiment;
  body: string;
  timestamp: number;
};

/**
 * Per-wallet activity record.
 * Stored in application state (not persisted to localStorage yet).
 * Maps wallet address → activity.
 */
export type UserActivity = {
  address: string;
  votes: UserVoteEntry[];    // most-recent first
  reviews: UserReviewEntry[]; // most-recent first
};

export type Project = {
  id: string;
  name: string;
  tagline: string;
  description: string;
  /**
   * @deprecated Legacy flat tags — preserved for migration compatibility only.
   * New code reads primaryCategory / useCases / tags instead.
   */
  tags: Tag[];
  /**
   * Taxonomy: primary category id from DEFAULT_CATEGORIES (required for new projects).
   * Falls back to 'other' if absent on legacy data.
   */
  primaryCategory?: string;
  /**
   * Taxonomy: up to 5 use-case ids from DEFAULT_USE_CASES.
   */
  useCases?: string[];
  /**
   * Taxonomy: up to 5 canonical tag ids from DEFAULT_TAGS.
   */
  canonicalTags?: string[];
  logoInitials: string;
  logoColor: string; // Tailwind bg class
  votes: VoteCounts;
  reviews: Review[];
  tvl?: string;            // current TVL label, e.g. "$4.2M"
  tvlHistory?: TvlSnapshot[]; // 6 weekly snapshots for sparkline
  launchDate: string;
  website?: string;
  /** Featured projects always appear first in Discover (except Watched filter) */
  featured?: boolean;
  /** Runtime status merged from project_overrides; defaults to 'active' */
  status?: 'active' | 'inactive' | 'discontinued' | 'under_review' | 'delisted';
  /** Human-readable note explaining the status */
  statusNote?: string;
  /** When true, suppress verified badge regardless of on-chain state */
  verifiedBadgeHidden?: boolean;
  /** URL-based logo — overrides initials avatar when set */
  logoUrl?: string;
};

export const PROJECTS: Project[] = [
  {
    id: 'arcswap',
    name: 'ArcSwap',
    tagline: 'Native DEX for the Arc ecosystem',
    description: 'ArcSwap is the primary decentralized exchange built for Arc, featuring USDC-native liquidity pools, concentrated liquidity positions, and sub-cent gas costs. Swap any token with near-zero friction.',
    tags: ['DeFi'],
    primaryCategory: 'trading-exchanges',
    useCases: ['dex', 'spot-trading', 'liquidity'],
    canonicalTags: ['usdc', 'usdc-native', 'arc-native'],
    logoInitials: 'AS',
    logoColor: 'bg-[#122d45]',
    votes: { bullish: 312, neutral: 48, bearish: 21 },
    tvl: '$4.2M',
    tvlHistory: [
      { weekLabel: 'W1', tvlM: 1.1 },
      { weekLabel: 'W2', tvlM: 1.8 },
      { weekLabel: 'W3', tvlM: 2.4 },
      { weekLabel: 'W4', tvlM: 3.0 },
      { weekLabel: 'W5', tvlM: 3.7 },
      { weekLabel: 'W6', tvlM: 4.2 },
    ],
    launchDate: 'Mar 2026',
    website: 'https://arcswap.example',
    featured: true,
    reviews: [
      { id: 'r1', author: '0x3f2a...9e1c', authorFull: '0x3f2a8b1c9e1c', body: 'Fastest swaps I have ever used. Gas costs are basically nothing on Arc. The concentrated liquidity UI is intuitive too.', sentiment: 'bullish', timestamp: Date.now() - 86400000 * 2, helpful: 24 },
      { id: 'r2', author: '0xab4d...7f3a', authorFull: '0xab4d221f7f3a', body: 'Good fundamentals but the liquidity depth for some pairs is still thin. Will improve as more LPs enter.', sentiment: 'neutral', timestamp: Date.now() - 86400000 * 5, helpful: 11 },
    ],
  },
  {
    id: 'vaultarc',
    name: 'VaultArc',
    tagline: 'USDC yield vaults on Arc',
    description: 'VaultArc deploys your USDC into audited yield strategies across Arc-native protocols. Single-click deposits, auto-compounding, and transparent on-chain reporting. No lock-ups.',
    tags: ['DeFi'],
    primaryCategory: 'financial-services',
    useCases: ['yield', 'asset-management'],
    canonicalTags: ['usdc', 'audited', 'arc-native'],
    logoInitials: 'VA',
    logoColor: 'bg-[#1a8047]',
    votes: { bullish: 187, neutral: 61, bearish: 14 },
    tvl: '$1.8M',
    tvlHistory: [
      { weekLabel: 'W1', tvlM: 0.2 },
      { weekLabel: 'W2', tvlM: 0.5 },
      { weekLabel: 'W3', tvlM: 0.9 },
      { weekLabel: 'W4', tvlM: 1.1 },
      { weekLabel: 'W5', tvlM: 1.5 },
      { weekLabel: 'W6', tvlM: 1.8 },
    ],
    launchDate: 'Apr 2026',
    website: 'https://vaultarc.example',
    reviews: [
      { id: 'r3', author: '0x8c1d...4a22', authorFull: '0x8c1d443b4a22', body: 'Steady 7% APY on USDC with no impermanent loss risk. Perfect for holding stables productively.', sentiment: 'bullish', timestamp: Date.now() - 86400000 * 1, helpful: 18 },
      { id: 'r4', author: '0xf92b...b381', authorFull: '0xf92b001eb381', body: 'Smart contracts are audited by two firms. I feel safe keeping funds here.', sentiment: 'bullish', timestamp: Date.now() - 86400000 * 7, helpful: 9 },
    ],
  },
  {
    id: 'arcquest',
    name: 'ArcQuest',
    tagline: 'Onchain quests and USDC rewards',
    description: 'ArcQuest lets protocols and creators deploy skill-based quest campaigns. Users complete tasks, answer questions, and earn USDC rewards. All payouts are atomic and trustless.',
    tags: ['Gaming', 'Payments'],
    primaryCategory: 'gaming',
    useCases: ['gaming-uc', 'payments', 'creator-economy'],
    canonicalTags: ['usdc', 'arc-native'],
    logoInitials: 'AQ',
    logoColor: 'bg-[#7c3aed]',
    votes: { bullish: 256, neutral: 83, bearish: 37 },
    tvl: '$0.35M',
    tvlHistory: [
      { weekLabel: 'W1', tvlM: 0.08 },
      { weekLabel: 'W2', tvlM: 0.14 },
      { weekLabel: 'W3', tvlM: 0.19 },
      { weekLabel: 'W4', tvlM: 0.31 },
      { weekLabel: 'W5', tvlM: 0.28 },
      { weekLabel: 'W6', tvlM: 0.35 },
    ],
    launchDate: 'May 2026',
    reviews: [
      { id: 'r5', author: '0x1a3f...cc90', authorFull: '0x1a3fcde8cc90', body: 'Completed three quests and earned $12 USDC within an hour. Fun way to learn about Arc protocols.', sentiment: 'bullish', timestamp: Date.now() - 86400000 * 3, helpful: 32 },
      { id: 'r6', author: '0x44bb...1d09', authorFull: '0x44bb887e1d09', body: 'Some quests feel repetitive and the USDC pools drain fast. Need more campaign sponsors.', sentiment: 'bearish', timestamp: Date.now() - 86400000 * 4, helpful: 7 },
    ],
  },
  {
    id: 'bridgearc',
    name: 'BridgeArc',
    tagline: 'CCTP-powered USDC bridge to Arc',
    description: "BridgeArc uses Circle's Cross-Chain Transfer Protocol to move USDC between Arc and other chains in under 30 seconds. No wrapped tokens, no slippage — native USDC in, native USDC out.",
    tags: ['Bridge', 'Infrastructure'],
    primaryCategory: 'bridges-interoperability',
    useCases: ['cross-chain', 'on-off-ramp'],
    canonicalTags: ['usdc', 'cctp', 'arc-native'],
    logoInitials: 'BA',
    logoColor: 'bg-[#0f766e]',
    votes: { bullish: 408, neutral: 55, bearish: 9 },
    tvl: '$6.1M',
    tvlHistory: [
      { weekLabel: 'W1', tvlM: 0.9 },
      { weekLabel: 'W2', tvlM: 2.1 },
      { weekLabel: 'W3', tvlM: 3.4 },
      { weekLabel: 'W4', tvlM: 4.8 },
      { weekLabel: 'W5', tvlM: 5.5 },
      { weekLabel: 'W6', tvlM: 6.1 },
    ],
    launchDate: 'Feb 2026',
    website: 'https://bridgearc.example',
    featured: true,
    reviews: [
      { id: 'r7', author: '0x7d8e...3310', authorFull: '0x7d8e4f913310', body: 'Used this to bring $500 from Base. 22 second transfer. No fees worth mentioning. Incredible.', sentiment: 'bullish', timestamp: Date.now() - 86400000 * 1, helpful: 44 },
      { id: 'r8', author: '0x2c9a...f002', authorFull: '0x2c9a88bcf002', body: 'Reliable but the UI could be more polished. Otherwise does exactly what it promises.', sentiment: 'neutral', timestamp: Date.now() - 86400000 * 9, helpful: 6 },
    ],
  },
  {
    id: 'arcnft',
    name: 'ArcNFTs',
    tagline: 'USDC-priced NFT marketplace',
    description: 'ArcNFTs is a no-fuss NFT marketplace where all listings are denominated in USDC. No price volatility surprises, instant settlement, and creator royalties enforced on-chain.',
    tags: ['NFT'],
    primaryCategory: 'nfts-digital-assets',
    useCases: ['digital-collectibles', 'creator-economy'],
    canonicalTags: ['nft', 'usdc', 'arc-native'],
    logoInitials: 'AN',
    logoColor: 'bg-[#b45309]',
    votes: { bullish: 142, neutral: 97, bearish: 63 },
    tvl: '$0.19M',
    tvlHistory: [
      { weekLabel: 'W1', tvlM: 0.05 },
      { weekLabel: 'W2', tvlM: 0.12 },
      { weekLabel: 'W3', tvlM: 0.09 },
      { weekLabel: 'W4', tvlM: 0.18 },
      { weekLabel: 'W5', tvlM: 0.22 },
      { weekLabel: 'W6', tvlM: 0.19 },
    ],
    launchDate: 'Jun 2026',
    reviews: [
      { id: 'r9', author: '0x6e1c...a841', authorFull: '0x6e1c994fa841', body: 'USDC pricing is a great idea but the collection discovery is poor. Hard to find quality projects.', sentiment: 'neutral', timestamp: Date.now() - 86400000 * 2, helpful: 15 },
      { id: 'r10', author: '0xd4fa...3b12', authorFull: '0xd4fa71203b12', body: 'Sold three pieces here. Creator royalties actually paid out, which is rare.', sentiment: 'bullish', timestamp: Date.now() - 86400000 * 6, helpful: 21 },
    ],
  },
  {
    id: 'arcdao',
    name: 'ArcDAO',
    tagline: 'Governance for the Arc ecosystem',
    description: 'ArcDAO is the on-chain governance hub for Arc ecosystem proposals. Token holders vote on protocol upgrades, grant allocations, and parameter changes. Treasury is held in USDC.',
    tags: ['DAO', 'Infrastructure'],
    primaryCategory: 'daos-governance',
    useCases: ['governance', 'treasury', 'community'],
    canonicalTags: ['dao', 'usdc', 'arc-native'],
    logoInitials: 'AD',
    logoColor: 'bg-[#0369a1]',
    votes: { bullish: 199, neutral: 112, bearish: 28 },
    tvl: '$1.3M',
    tvlHistory: [
      { weekLabel: 'W1', tvlM: 0.4 },
      { weekLabel: 'W2', tvlM: 0.6 },
      { weekLabel: 'W3', tvlM: 0.8 },
      { weekLabel: 'W4', tvlM: 0.9 },
      { weekLabel: 'W5', tvlM: 1.1 },
      { weekLabel: 'W6', tvlM: 1.3 },
    ],
    launchDate: 'Jan 2026',
    reviews: [
      { id: 'r11', author: '0x5512...9c4d', authorFull: '0x5512f0b09c4d', body: 'Governance participation is surprisingly high for a new chain. Good sign for decentralization.', sentiment: 'bullish', timestamp: Date.now() - 86400000 * 8, helpful: 19 },
    ],
  },
];

export type Poll = {
  id: string;
  question: string;
  options: { id: string; label: string; votes: number }[];
  endsAt: number; // ms
  totalVotes: number;
  category: string;
  /** When true, shows a "Sponsored by [sponsorName]" label */
  sponsored?: boolean;
  sponsorName?: string;
};

export const POLLS: Poll[] = [
  {
    id: 'p1',
    question: 'Which Arc sector will see the most growth in Q4 2026?',
    category: 'Ecosystem',
    options: [
      { id: 'o1', label: 'DeFi protocols', votes: 214 },
      { id: 'o2', label: 'Gaming & rewards', votes: 189 },
      { id: 'o3', label: 'Cross-chain infrastructure', votes: 97 },
      { id: 'o4', label: 'NFT marketplaces', votes: 43 },
    ],
    endsAt: Date.now() + 86400000 * 3,
    totalVotes: 543,
  },
  {
    id: 'p2',
    question: 'What feature would most improve your Arc experience?',
    category: 'UX',
    options: [
      { id: 'o5', label: 'Better mobile wallets', votes: 311 },
      { id: 'o6', label: 'More liquidity depth', votes: 278 },
      { id: 'o7', label: 'DEX aggregator', votes: 155 },
      { id: 'o8', label: 'Fiat on-ramp', votes: 129 },
    ],
    endsAt: Date.now() + 86400000 * 7,
    totalVotes: 873,
  },
  {
    id: 'p3',
    question: "Do you feel Arc's current USDC gas model gives you an advantage?",
    category: 'Gas',
    options: [
      { id: 'o9', label: 'Yes, huge advantage', votes: 402 },
      { id: 'o10', label: 'Slight advantage', votes: 218 },
      { id: 'o11', label: 'No difference vs other chains', votes: 61 },
      { id: 'o12', label: 'Still evaluating', votes: 35 },
    ],
    endsAt: Date.now() + 86400000 * 14,
    totalVotes: 716,
  },
  {
    id: 'p4',
    question: 'How much USDC do you bridge to Arc per month?',
    category: 'Usage',
    options: [
      { id: 'o13', label: 'Less than $100', votes: 187 },
      { id: 'o14', label: '$100–$1,000', votes: 312 },
      { id: 'o15', label: '$1,000–$10,000', votes: 94 },
      { id: 'o16', label: 'More than $10,000', votes: 41 },
    ],
    endsAt: Date.now() + 86400000 * 5,
    totalVotes: 634,
    sponsored: true,
    sponsorName: 'BridgeArc',
  },
];
