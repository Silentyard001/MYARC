/**
 * MYARC Project Taxonomy
 *
 * Three-level classification system:
 *   1. Primary Category  — exactly 1, what the project IS
 *   2. Use Cases         — up to 5, what the project DOES
 *   3. Tags              — up to 5, specific descriptors with alias normalization
 *
 * This file is the single source of truth for all taxonomy data.
 * Admin-controlled extension happens via the Taxonomy tab in AdminPanel,
 * which reads/writes to these arrays at runtime (stored in localStorage
 * as an overlay — same pattern as project overrides).
 *
 * active:false entries are hidden from new submission selectors but remain
 * resolvable for existing projects.
 */

// ─── Categories ──────────────────────────────────────────────────────────────

export type Category = {
  id: string            // stable slug, never changes after creation
  label: string         // display name
  active: boolean
  order: number         // ascending sort in selectors
}

export const DEFAULT_CATEGORIES: Category[] = [
  { id: 'payments',               label: 'Payments',                      active: true,  order: 1  },
  { id: 'financial-services',     label: 'Financial Services',            active: true,  order: 2  },
  { id: 'defi',                   label: 'DeFi',                          active: true,  order: 3  },
  { id: 'trading-exchanges',      label: 'Trading & Exchanges',           active: true,  order: 4  },
  { id: 'stablecoins-tokenized',  label: 'Stablecoins & Tokenized Assets',active: true,  order: 5  },
  { id: 'infrastructure',         label: 'Infrastructure',                active: true,  order: 6  },
  { id: 'developer-tools',        label: 'Developer Tools',               active: true,  order: 7  },
  { id: 'wallets-custody',        label: 'Wallets & Custody',             active: true,  order: 8  },
  { id: 'bridges-interoperability',label: 'Bridges & Interoperability',   active: true,  order: 9  },
  { id: 'compliance-identity',    label: 'Compliance & Identity',         active: true,  order: 10 },
  { id: 'ai-agents',              label: 'AI & Agents',                   active: true,  order: 11 },
  { id: 'consumer-social',        label: 'Consumer & Social',             active: true,  order: 12 },
  { id: 'gaming',                 label: 'Gaming',                        active: true,  order: 13 },
  { id: 'nfts-digital-assets',    label: 'NFTs & Digital Assets',         active: true,  order: 14 },
  { id: 'daos-governance',        label: 'DAOs & Governance',             active: true,  order: 15 },
  { id: 'launchpads-token',       label: 'Launchpads & Token Platforms',  active: true,  order: 16 },
  { id: 'other',                  label: 'Other',                         active: true,  order: 17 },
]

// ─── Use Cases ────────────────────────────────────────────────────────────────

export type UseCase = {
  id: string
  label: string
  group: string   // visual grouping in the selector
  active: boolean
  order: number
}

export const DEFAULT_USE_CASES: UseCase[] = [
  // Payments group
  { id: 'payments',           label: 'Payments',            group: 'Payments',      active: true, order: 10 },
  { id: 'cross-border',       label: 'Cross-Border Payments',group: 'Payments',     active: true, order: 11 },
  { id: 'remittances',        label: 'Remittances',          group: 'Payments',     active: true, order: 12 },
  { id: 'p2p-payments',       label: 'P2P Payments',         group: 'Payments',     active: true, order: 13 },
  { id: 'merchant-payments',  label: 'Merchant Payments',    group: 'Payments',     active: true, order: 14 },
  { id: 'payouts',            label: 'Payouts',              group: 'Payments',     active: true, order: 15 },
  { id: 'payroll',            label: 'Payroll',              group: 'Payments',     active: true, order: 16 },
  { id: 'b2b-payments',       label: 'B2B Payments',         group: 'Payments',     active: true, order: 17 },

  // Financial group
  { id: 'financial',          label: 'Financial',            group: 'Financial',    active: true, order: 20 },
  { id: 'lending',            label: 'Lending',              group: 'Financial',    active: true, order: 21 },
  { id: 'borrowing',          label: 'Borrowing',            group: 'Financial',    active: true, order: 22 },
  { id: 'credit',             label: 'Credit',               group: 'Financial',    active: true, order: 23 },
  { id: 'yield',              label: 'Yield',                group: 'Financial',    active: true, order: 24 },
  { id: 'staking',            label: 'Staking',              group: 'Financial',    active: true, order: 25 },
  { id: 'treasury',           label: 'Treasury',             group: 'Financial',    active: true, order: 26 },
  { id: 'fx',                 label: 'FX',                   group: 'Financial',    active: true, order: 27 },
  { id: 'capital-markets',    label: 'Capital Markets',      group: 'Financial',    active: true, order: 28 },
  { id: 'tokenization',       label: 'Tokenization',         group: 'Financial',    active: true, order: 29 },
  { id: 'asset-management',   label: 'Asset Management',     group: 'Financial',    active: true, order: 30 },
  { id: 'derivatives',        label: 'Derivatives',          group: 'Financial',    active: true, order: 31 },
  { id: 'prediction-markets', label: 'Prediction Markets',   group: 'Financial',    active: true, order: 32 },

  // Market group
  { id: 'spot-trading',       label: 'Spot Trading',         group: 'Market',       active: true, order: 40 },
  { id: 'dex',                label: 'DEX',                  group: 'Market',       active: true, order: 41 },
  { id: 'liquidity',          label: 'Liquidity',            group: 'Market',       active: true, order: 42 },
  { id: 'aggregation',        label: 'Aggregation',          group: 'Market',       active: true, order: 43 },
  { id: 'otc',                label: 'OTC',                  group: 'Market',       active: true, order: 44 },

  // Infrastructure group
  { id: 'wallet-infrastructure',label: 'Wallet Infrastructure',group: 'Infrastructure', active: true, order: 50 },
  { id: 'custody',            label: 'Custody',              group: 'Infrastructure', active: true, order: 51 },
  { id: 'cross-chain',        label: 'Cross-Chain',          group: 'Infrastructure', active: true, order: 52 },
  { id: 'account-abstraction',label: 'Account Abstraction',  group: 'Infrastructure', active: true, order: 53 },
  { id: 'smart-accounts',     label: 'Smart Accounts',       group: 'Infrastructure', active: true, order: 54 },
  { id: 'rpc',                label: 'RPC',                  group: 'Infrastructure', active: true, order: 55 },
  { id: 'indexing',           label: 'Indexing',             group: 'Infrastructure', active: true, order: 56 },
  { id: 'oracles',            label: 'Oracles',              group: 'Infrastructure', active: true, order: 57 },
  { id: 'on-off-ramp',        label: 'On/Off-Ramp',          group: 'Infrastructure', active: true, order: 58 },

  // AI group
  { id: 'ai-agents',          label: 'AI Agents',            group: 'AI',           active: true, order: 60 },
  { id: 'agent-payments',     label: 'Agent Payments',       group: 'AI',           active: true, order: 61 },
  { id: 'agent-commerce',     label: 'Agent Commerce',       group: 'AI',           active: true, order: 62 },
  { id: 'autonomous-finance', label: 'Autonomous Finance',   group: 'AI',           active: true, order: 63 },

  // Consumer group
  { id: 'social',             label: 'Social',               group: 'Consumer',     active: true, order: 70 },
  { id: 'creator-economy',    label: 'Creator Economy',      group: 'Consumer',     active: true, order: 71 },
  { id: 'gaming-uc',          label: 'Gaming',               group: 'Consumer',     active: true, order: 72 },
  { id: 'digital-collectibles',label: 'Digital Collectibles',group: 'Consumer',     active: true, order: 73 },
  { id: 'community',          label: 'Community',            group: 'Consumer',     active: true, order: 74 },
  { id: 'governance',         label: 'Governance',           group: 'Consumer',     active: true, order: 75 },
]

// ─── Tags ─────────────────────────────────────────────────────────────────────

export type CanonicalTag = {
  id: string         // stable slug
  label: string      // canonical display form
  aliases: string[]  // normalized variants that resolve to this tag
  active: boolean
  order: number
}

/**
 * Normalize a raw tag string to a canonical tag id.
 * Returns the canonical tag id if found, undefined otherwise.
 */
export function normalizeTag(raw: string, tags: CanonicalTag[]): string | undefined {
  const normalized = raw.trim().toLowerCase().replace(/[_\s]+/g, '-')
  for (const tag of tags) {
    if (tag.id === normalized) return tag.id
    if (tag.label.toLowerCase() === normalized) return tag.id
    if (tag.aliases.some((a) => a.toLowerCase().replace(/[_\s]+/g, '-') === normalized)) return tag.id
  }
  return undefined
}

export const DEFAULT_TAGS: CanonicalTag[] = [
  { id: 'usdc',        label: 'USDC',       aliases: ['usd-coin', 'usdcoin'],             active: true, order: 1  },
  { id: 'b2b',         label: 'B2B',        aliases: ['business-to-business', 'b-2-b'],   active: true, order: 2  },
  { id: 'africa',      label: 'Africa',     aliases: [],                                  active: true, order: 3  },
  { id: 'erc-20',      label: 'ERC-20',     aliases: ['erc20', 'erc 20'],                 active: true, order: 4  },
  { id: 'stablecoin',  label: 'Stablecoin', aliases: ['stablecoins', 'stable-coin', 'stable-coins', 'stablecoin'], active: true, order: 5 },
  { id: 'usdc-native', label: 'USDC-native',aliases: ['usdc native', 'native-usdc'],      active: true, order: 6  },
  { id: 'cctp',        label: 'CCTP',       aliases: ['cross-chain-transfer-protocol'],   active: true, order: 7  },
  { id: 'arc-native',  label: 'Arc-native', aliases: ['arcnative', 'arc native'],         active: true, order: 8  },
  { id: 'open-source', label: 'Open Source',aliases: ['opensource', 'open-src', 'oss'],  active: true, order: 9  },
  { id: 'audited',     label: 'Audited',    aliases: ['audit', 'security-audit'],         active: true, order: 10 },
  { id: 'defi',        label: 'DeFi',       aliases: ['decentralized-finance', 'de-fi'],  active: true, order: 11 },
  { id: 'nft',         label: 'NFT',        aliases: ['nfts', 'non-fungible-token'],      active: true, order: 12 },
  { id: 'dao',         label: 'DAO',        aliases: ['daos', 'decentralized-autonomous-organization'], active: true, order: 13 },
]

// ─── Migration helpers ────────────────────────────────────────────────────────

/**
 * Maps the old Tag union type to the new taxonomy ids.
 * Used during data migration in projects.ts.
 */
export const LEGACY_TAG_MAP: Record<string, { category?: string; useCases?: string[]; tags?: string[] }> = {
  'DeFi':           { category: 'defi',                useCases: ['dex', 'yield'],           tags: ['defi']       },
  'NFT':            { category: 'nfts-digital-assets',  useCases: ['digital-collectibles'],   tags: ['nft']        },
  'Gaming':         { category: 'gaming',               useCases: ['gaming-uc'],              tags: []             },
  'Infrastructure': { category: 'infrastructure',       useCases: ['cross-chain'],            tags: []             },
  'Bridge':         { category: 'bridges-interoperability', useCases: ['cross-chain'],         tags: ['cctp']       },
  'Payments':       { category: 'payments',             useCases: ['payments'],               tags: ['usdc']       },
  'DAO':            { category: 'daos-governance',      useCases: ['governance'],             tags: ['dao']        },
  'Launchpad':      { category: 'launchpads-token',     useCases: [],                         tags: []             },
}
