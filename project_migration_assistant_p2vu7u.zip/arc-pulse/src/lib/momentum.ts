/**
 * MYARC Intelligence Layer — canonical momentum computation
 *
 * This module is the SINGLE authoritative source for all community momentum
 * metrics on MYARC. It is pure TypeScript with no React, no network calls,
 * and no side effects. Every consumer (Rising page, Project Comparison,
 * Milestones, Admin Analytics, Profile) must import from here rather than
 * re-implementing the same math.
 *
 * ─── Architecture ─────────────────────────────────────────────────────────────
 *
 * Data flows in from callers that already have event logs (reusing fetches from
 * usePlatformAnalytics / useProjectAnalytics) — this module never fetches data
 * itself. Hooks wrap this library and own the data-fetching concerns.
 *
 * ─── Momentum Index ───────────────────────────────────────────────────────────
 *
 * The index is derived from four community signals:
 *   1. Vote velocity       — recent vote rate vs. baseline (log-normalized)
 *   2. Review velocity     — recent review rate vs. baseline
 *   3. Boost velocity      — recent economic boost activity (log-normalized)
 *   4. New-wallet score    — genuinely new participants vs. baseline
 *
 * Logarithmic treatment prevents small-absolute-value projects from dominating
 * purely via percentage gains. A project moving 1→5 votes does not automatically
 * outrank one moving 500→800 — absolute activity is factored into the baseline.
 *
 * Final score is clamped to [0, 100] and rounded to an integer.
 * Zero is a valid score (no recent activity) — it is never fabricated.
 *
 * ─── Semantic constraint ──────────────────────────────────────────────────────
 *
 * Momentum is a community activity signal. It MUST NOT be presented as a
 * price prediction, token performance forecast, financial advice, or guarantee
 * of future growth. Use terminology like:
 *   "community momentum"  "activity momentum"
 *   "community acceleration"  "engagement momentum"
 */

// ─── Input types ──────────────────────────────────────────────────────────────

/** A single on-chain vote event with a resolved wall-clock timestamp. */
export interface VoteEvent {
  /** Lowercase wallet address of the voter. */
  voter: string
  /** 0 = Bullish, 1 = Neutral, 2 = Bearish (matching MYARC contract enum). */
  sentiment: number
  /** Wall-clock timestamp in milliseconds. */
  ts: number
  /** Project slug (bytes32-decoded) this vote belongs to. */
  projectSlug: string
}

/** A single vote-retraction event. */
export interface RetractEvent {
  voter: string
  ts: number
  projectSlug: string
}

/** A single review-posted event. */
export interface ReviewEvent {
  author: string
  ts: number
  projectSlug: string
}

/** A single review-upvote (boost) event — the author-received amount. */
export interface BoostEvent {
  /** Upvoter wallet address. */
  upvoter: string
  ts: number
  projectSlug: string
  /** Author-received amount in wei (18-decimal Arc native). */
  authorAmount: bigint
}

// ─── Output types ─────────────────────────────────────────────────────────────

/** Sentiment distribution as integers summing to total live votes. */
export interface SentimentBreakdown {
  bullish: number
  neutral: number
  bearish: number
  /** Bullish percentage 0–100 (null when no votes exist). */
  bullishPct: number | null
  /** 7-day bullish percentage (null when no votes in window). */
  bullishPct7d: number | null
  /** Change in bullish percentage: 7d value minus 30d value.
   *  Positive = sentiment improved, negative = sentiment declined.
   *  null when either window has no votes. */
  sentimentDelta: number | null
}

/** Time-windowed activity counts for a single metric. */
export interface ActivityWindow {
  /** Count in the last 24 hours. */
  h24: number
  /** Count in the 24 hours before that (for change calculation). */
  prev24h: number
  /** Change h24 vs prev24h as a percentage string, e.g. "+143%" or "–12%".
   *  "N/A" when prev24h is 0 and h24 is also 0.
   *  "+∞" when prev24h is 0 and h24 > 0 (new activity from zero). */
  change24hLabel: string
  /** Count in the last 7 days. */
  d7: number
  /** Count in the last 30 days. */
  d30: number
  /** Unique wallet addresses active in the last 7 days. */
  uniqueWallets7d: number
  /** Wallets active in 7d that had NO activity in the prior 30d window. */
  newWallets7d: number
  /** Daily count array for the last 14 days, index 0 = oldest. */
  daily14d: number[]
}

/** The full component signals for a single project. */
export interface ProjectSignals {
  projectSlug: string

  /** Vote activity */
  votes: ActivityWindow

  /** Review activity */
  reviews: ActivityWindow

  /** Boost/upvote economic activity */
  boosts: ActivityWindow
  /** Total author-received boost volume in wei over last 7 days. */
  boostVolume7d: bigint

  /** Wallet participation */
  uniqueParticipants7d: number   // voters + reviewers + boosters, deduplicated
  newParticipants7d: number      // of those, first-time participants on this project

  /** Live sentiment */
  sentiment: SentimentBreakdown

  /** Normalized activity score 0–100 (comparable across projects). */
  activityScore: number

  /**
   * True when the project has less than 48h of history — percentage-change
   * comparisons are unreliable and UIs should show a "too new to compare" notice.
   */
  insufficientHistory: boolean

  /**
   * Convenience aliases for the most common UI display values.
   * These mirror the same data in the sub-objects above.
   */
  /** Total votes all-time. */
  totalVotesAllTime: number
  /** Total reviews all-time. */
  totalReviewsAllTime: number
  /** Vote velocity in last 24h (count). */
  voteVelocity24h: number
  /** Review velocity in last 24h (count). */
  reviewVelocity24h: number
  /** Current bullish percentage 0–100 or null. */
  sentimentScore: number | null
  /** Live sentiment distribution (after retractions). */
  currentSentiment: { bullish: number; neutral: number; bearish: number }
}

/** The full Momentum Index result for a single project. */
export interface MomentumResult {
  projectSlug: string

  /**
   * Community Momentum Index: 0–100.
   * Derived from vote velocity, review velocity, boost velocity, and
   * new-wallet participation. Never manually assigned.
   * A score of 0 means no recent activity — not "bad".
   */
  momentumIndex: number

  /** Component signals used to derive the index — for UI transparency display. */
  signals: ProjectSignals

  /**
   * Human-readable explanation strings for the UI transparency requirement.
   * Example: ["Vote activity +143%", "Review activity +87%", "34 new wallets"]
   * These are derived from the signals — do NOT hardcode them.
   */
  explainers: string[]

  /** ISO timestamp string of when this result was computed. */
  computedAt: string
}

// ─── Constants ────────────────────────────────────────────────────────────────

const DAY_MS   = 86_400_000
const HOUR_MS  = 3_600_000

// Momentum index component weights (must sum to 1.0)
const W_VOTE_VELOCITY    = 0.35
const W_REVIEW_VELOCITY  = 0.25
const W_BOOST_VELOCITY   = 0.20
const W_NEW_WALLETS      = 0.20

// ─── Pure utility helpers ─────────────────────────────────────────────────────

/** Returns items with ts in [now - windowMs, now). */
function inWindow<T extends { ts: number }>(items: T[], now: number, windowMs: number): T[] {
  const cutoff = now - windowMs
  return items.filter((x) => x.ts >= cutoff && x.ts < now)
}

/** Returns items in the half-open window [now - 2*windowMs, now - windowMs). */
function prevWindow<T extends { ts: number }>(items: T[], now: number, windowMs: number): T[] {
  const end   = now - windowMs
  const start = end - windowMs
  return items.filter((x) => x.ts >= start && x.ts < end)
}

/**
 * Logarithmic velocity score.
 *
 * Combines two sub-scores to prevent small-volume projects dominating:
 *
 *   relativeScore = log(1 + recent7d) / (log(1 + recent7d) + log(1 + baselineRate))
 *   absoluteScore = log(1 + recent7d) / log(1 + ABSOLUTE_CAP)
 *
 *   finalScore = 0.5 * relativeScore + 0.5 * absoluteScore
 *
 * The relativeScore rewards acceleration relative to baseline.
 * The absoluteScore rewards raw recent volume — a project with 300 new votes
 * always scores higher here than one with 4, regardless of percentage gain.
 * ABSOLUTE_CAP is chosen so that ~200 recent events saturate the absolute
 * sub-score: log(201)/log(201) = 1.0.
 *
 * Example (the key anti-gaming case):
 *   Small: 4 recent / 5 total  → relative ≈ 0.59, absolute ≈ 0.38  → 0.49
 *   Large: 300 recent / 800 total → relative ≈ 0.52, absolute ≈ 1.00 → 0.76
 */
const ABSOLUTE_CAP = 200

function logVelocityScore(recent7d: number, allTime: number): number {
  if (recent7d === 0) return 0
  const recentLog   = Math.log(1 + recent7d)
  // Baseline rate: average events per 7-day window over all time (min 1 to avoid /0)
  const baselineRate = Math.max(allTime / 4, 1) // approximate 28d baseline
  const baselineLog = Math.log(1 + baselineRate)
  const relativeScore = recentLog / (recentLog + baselineLog)
  const absoluteScore = recentLog / Math.log(1 + ABSOLUTE_CAP)
  return 0.5 * relativeScore + 0.5 * Math.min(1, absoluteScore)
}

/** Format a percentage-change label for the explainers array. */
function pctLabel(prev: number, curr: number): string {
  if (prev === 0 && curr === 0) return 'N/A'
  if (prev === 0) return '+∞'
  const pct = Math.round(((curr - prev) / prev) * 100)
  if (pct >= 0) return `+${pct}%`
  return `${pct}%`
}

/** Format a change label for a count-vs-previous-period comparison. */
function changeLabel(prev24h: number, h24: number): string {
  if (prev24h === 0 && h24 === 0) return 'N/A'
  if (prev24h === 0) return '+∞'
  const pct = Math.round(((h24 - prev24h) / prev24h) * 100)
  if (pct >= 0) return `+${pct}%`
  return `${pct}%`
}

/** Build daily 14d count array for an event set. */
function daily14d<T extends { ts: number }>(items: T[], now: number): number[] {
  const arr = Array(14).fill(0) as number[]
  const cutoff = now - 14 * DAY_MS
  for (const x of items) {
    if (x.ts < cutoff || x.ts >= now) continue
    const daysAgo = Math.floor((now - x.ts) / DAY_MS)
    const idx = 13 - daysAgo
    if (idx >= 0 && idx < 14) arr[idx]++
  }
  return arr
}

/** Build ActivityWindow from a set of events with a voter/author field. */
function buildActivityWindow<T extends { ts: number }>(
  items: T[],
  walletField: keyof T,
  allTimeItems: T[],
  now: number,
): ActivityWindow {
  const h24Items    = inWindow(items, now, HOUR_MS * 24)
  const prev24Items = prevWindow(items, now, HOUR_MS * 24)
  const d7Items     = inWindow(items, now, DAY_MS * 7)
  const d30Items    = inWindow(items, now, DAY_MS * 30)

  // Unique wallets in 7d
  const wallets7d = new Set(d7Items.map((x) => String(x[walletField]).toLowerCase()))

  // New wallets in 7d: active in last 7d but NOT in the 31–37d window
  const olderItems = items.filter((x) => {
    const age = now - x.ts
    return age >= DAY_MS * 7 && age < DAY_MS * 37
  })
  const olderWallets = new Set(olderItems.map((x) => String(x[walletField]).toLowerCase()))
  const newWallets7d = new Set([...wallets7d].filter((w) => !olderWallets.has(w)))

  return {
    h24: h24Items.length,
    prev24h: prev24Items.length,
    change24hLabel: changeLabel(prev24Items.length, h24Items.length),
    d7: d7Items.length,
    d30: d30Items.length,
    uniqueWallets7d: wallets7d.size,
    newWallets7d: newWallets7d.size,
    daily14d: daily14d(allTimeItems, now),
  }
}

// ─── Live sentiment computation ───────────────────────────────────────────────

function computeSentiment(
  votes: VoteEvent[],
  retracts: RetractEvent[],
  now: number,
): SentimentBreakdown {
  // Replay all-time votes + retractions to get current live state
  type Ev = { type: 'vote'; voter: string; sentiment: number; ts: number }
           | { type: 'retract'; voter: string; ts: number }
  const all: Ev[] = [
    ...votes.map((v)    => ({ type: 'vote'    as const, voter: v.voter, sentiment: v.sentiment, ts: v.ts })),
    ...retracts.map((r) => ({ type: 'retract' as const, voter: r.voter, ts: r.ts })),
  ].sort((a, b) => a.ts - b.ts)

  const liveMap = new Map<string, number>()
  for (const ev of all) {
    if (ev.type === 'vote')    liveMap.set(ev.voter.toLowerCase(), ev.sentiment)
    else                       liveMap.delete(ev.voter.toLowerCase())
  }

  // Replay up to 7d ago for 7d sentiment
  const cutoff7d = now - DAY_MS * 7
  const liveMap7d = new Map<string, number>()
  for (const ev of all) {
    if (ev.ts > now) continue
    if (ev.ts < cutoff7d) continue
    if (ev.type === 'vote')    liveMap7d.set(ev.voter.toLowerCase(), ev.sentiment)
    else                       liveMap7d.delete(ev.voter.toLowerCase())
  }

  // 30d snapshot (same logic)
  const cutoff30d = now - DAY_MS * 30
  const liveMap30d = new Map<string, number>()
  for (const ev of all) {
    if (ev.ts > now) continue
    if (ev.ts < cutoff30d) continue
    if (ev.type === 'vote')    liveMap30d.set(ev.voter.toLowerCase(), ev.sentiment)
    else                       liveMap30d.delete(ev.voter.toLowerCase())
  }

  function breakdown(map: Map<string, number>) {
    let b = 0, n = 0, e = 0
    for (const s of map.values()) {
      if (s === 0) b++
      else if (s === 1) n++
      else e++
    }
    return { bullish: b, neutral: n, bearish: e }
  }

  const live = breakdown(liveMap)
  const d7   = breakdown(liveMap7d)
  const d30  = breakdown(liveMap30d)

  const total    = live.bullish + live.neutral + live.bearish
  const total7d  = d7.bullish  + d7.neutral  + d7.bearish
  const total30d = d30.bullish + d30.neutral + d30.bearish

  const bullishPct   = total    > 0 ? Math.round((live.bullish / total)    * 100) : null
  const bullishPct7d = total7d  > 0 ? Math.round((d7.bullish  / total7d)  * 100) : null
  const pct30d       = total30d > 0 ? Math.round((d30.bullish / total30d) * 100) : null

  const sentimentDelta =
    bullishPct7d !== null && pct30d !== null ? bullishPct7d - pct30d : null

  return {
    ...live,
    bullishPct,
    bullishPct7d,
    sentimentDelta,
  }
}

// ─── Main export: computeProjectMomentum ─────────────────────────────────────

/**
 * Compute the full Momentum Index and component signals for a single project.
 *
 * @param projectSlug   - The project identifier (human-readable slug)
 * @param votes         - All Voted events for this project (all-time)
 * @param retracts      - All VoteRetracted events for this project (all-time)
 * @param reviews       - All ReviewPosted events for this project (all-time)
 * @param boosts        - All ReviewUpvoted events for this project (all-time)
 * @param now           - Reference timestamp in ms (pass Date.now() or a stable
 *                        snapshot for reproducible tests)
 */
export function computeProjectMomentum(
  projectSlug: string,
  votes: VoteEvent[],
  retracts: RetractEvent[],
  reviews: ReviewEvent[],
  boosts: BoostEvent[],
  now: number = Date.now(),
): MomentumResult {
  // ── Insufficient history guard ────────────────────────────────────────────
  // A project younger than 24h gets a valid score based on what exists —
  // but percentage-change comparisons that would compare against zero history
  // are explicitly labelled rather than fabricated (handled by pctLabel/changeLabel).

  const voteWindow   = buildActivityWindow(votes,   'voter',   votes,   now)
  const reviewWindow = buildActivityWindow(reviews, 'author',  reviews, now)
  const boostWindow  = buildActivityWindow(boosts,  'upvoter', boosts,  now)

  // Boost volume (wei) in last 7d
  const boostVolume7d = inWindow(boosts, now, DAY_MS * 7)
    .reduce((acc, b) => acc + b.authorAmount, 0n)

  // Combined unique participants (voters + reviewers + boosters) deduplicated
  const participants7d = new Set<string>()
  for (const v of inWindow(votes,   now, DAY_MS * 7)) participants7d.add(v.voter.toLowerCase())
  for (const r of inWindow(reviews, now, DAY_MS * 7)) participants7d.add(r.author.toLowerCase())
  for (const b of inWindow(boosts,  now, DAY_MS * 7)) participants7d.add(b.upvoter.toLowerCase())

  // New participants: participated in 7d but NOT in the prior 30d
  const prior30d = new Set<string>()
  // Anyone who participated before the 7d window but within the last 37d
  const cutoff7d  = now - DAY_MS * 7
  const cutoff37d = now - DAY_MS * 37
  for (const v of votes)   { if (v.ts < cutoff7d && v.ts >= cutoff37d) prior30d.add(v.voter.toLowerCase()) }
  for (const r of reviews) { if (r.ts < cutoff7d && r.ts >= cutoff37d) prior30d.add(r.author.toLowerCase()) }
  for (const b of boosts)  { if (b.ts < cutoff7d && b.ts >= cutoff37d) prior30d.add(b.upvoter.toLowerCase()) }
  const newParticipants7d = [...participants7d].filter((w) => !prior30d.has(w)).length

  // Activity score: linear sum of all 7d events, log-normalized to [0, 100]
  const totalRecent   = voteWindow.d7 + reviewWindow.d7 + boostWindow.d7
  const activityScore = Math.min(100, Math.round(Math.log(1 + totalRecent) * 12))

  const sentiment = computeSentiment(votes, retracts, now)

  // Insufficient history: project has less than 48h of event history
  const allTs = [...votes.map((v) => v.ts), ...reviews.map((r) => r.ts), ...boosts.map((b) => b.ts)]
  const oldestEvent = allTs.length > 0 ? Math.min(...allTs) : now
  const insufficientHistory = allTs.length === 0 || (now - oldestEvent) < DAY_MS * 2

  const signals: ProjectSignals = {
    projectSlug,
    votes: voteWindow,
    reviews: reviewWindow,
    boosts: boostWindow,
    boostVolume7d,
    uniqueParticipants7d: participants7d.size,
    newParticipants7d,
    sentiment,
    activityScore,
    insufficientHistory,
    totalVotesAllTime: votes.length,
    totalReviewsAllTime: reviews.length,
    voteVelocity24h: voteWindow.h24,
    reviewVelocity24h: reviewWindow.h24,
    sentimentScore: sentiment.bullishPct,
    currentSentiment: {
      bullish: sentiment.bullish,
      neutral: sentiment.neutral,
      bearish: sentiment.bearish,
    },
  }

  // ── Momentum Index computation ────────────────────────────────────────────

  // Component velocities (each in [0, 1])
  const voteVelocity   = logVelocityScore(voteWindow.d7,   votes.length)
  const reviewVelocity = logVelocityScore(reviewWindow.d7, reviews.length)
  const boostVelocity  = logVelocityScore(boostWindow.d7,  boosts.length)

  // New-wallet score: log-normalized ratio of new participants vs. total recent
  const newWalletScore = participants7d.size > 0
    ? Math.log(1 + newParticipants7d) / Math.log(1 + Math.max(participants7d.size, 1))
    : 0

  const rawScore =
    voteVelocity   * W_VOTE_VELOCITY   +
    reviewVelocity * W_REVIEW_VELOCITY +
    boostVelocity  * W_BOOST_VELOCITY  +
    newWalletScore * W_NEW_WALLETS

  // Map [0, 1] to [0, 100] via a mild curve (sqrt softens extreme values)
  const momentumIndex = Math.round(Math.sqrt(rawScore) * 100)

  // ── Explainers ────────────────────────────────────────────────────────────

  const explainers: string[] = []

  if (voteWindow.d7 > 0 || voteWindow.prev24h > 0 || voteWindow.h24 > 0) {
    explainers.push(`Vote activity ${pctLabel(voteWindow.d7 === 0 ? voteWindow.prev24h : votes.filter((v) => { const age = now - v.ts; return age >= DAY_MS * 7 && age < DAY_MS * 14 }).length, voteWindow.d7)}`)
  }
  if (reviewWindow.d7 > 0 || reviews.length > 0) {
    const prev7d = reviews.filter((r) => { const age = now - r.ts; return age >= DAY_MS * 7 && age < DAY_MS * 14 }).length
    explainers.push(`Review activity ${pctLabel(prev7d, reviewWindow.d7)}`)
  }
  if (newParticipants7d > 0) {
    explainers.push(`${newParticipants7d} new wallet${newParticipants7d === 1 ? '' : 's'}`)
  }
  if (sentiment.sentimentDelta !== null && Math.abs(sentiment.sentimentDelta) >= 3) {
    const sign = sentiment.sentimentDelta > 0 ? '+' : ''
    explainers.push(`Sentiment ${sign}${sentiment.sentimentDelta} pts`)
  }
  if (boostWindow.d7 > 0) {
    explainers.push(`${boostWindow.d7} boost${boostWindow.d7 === 1 ? '' : 's'}`)
  }
  if (explainers.length === 0) {
    explainers.push('No recent community activity')
  }

  return {
    projectSlug,
    momentumIndex,
    signals,
    explainers,
    computedAt: new Date(now).toISOString(),
  }
}

// ─── Multi-project ranking ────────────────────────────────────────────────────

/**
 * Rank a set of projects by Momentum Index, highest first.
 * Returns the sorted array of MomentumResult — the caller decides how many to show.
 */
export function rankByMomentum(results: MomentumResult[]): MomentumResult[] {
  return [...results].sort((a, b) => b.momentumIndex - a.momentumIndex)
}

/**
 * Return the top N projects by momentum.
 * Convenience wrapper around rankByMomentum.
 */
export function topNByMomentum(results: MomentumResult[], n: number): MomentumResult[] {
  return rankByMomentum(results).slice(0, n)
}

// ─── Milestone helpers ────────────────────────────────────────────────────────

// ─── Milestone system ────────────────────────────────────────────────────────

/**
 * A single community milestone for a project.
 * Milestones are derived deterministically from ProjectSignals — they are
 * never manually assigned or fabricated.
 */
export interface Milestone {
  /** Stable identifier, e.g. "votes-100". Unique within a project. */
  id: string
  /** The project this milestone belongs to. */
  projectSlug: string
  /** Human-readable category for grouping. */
  category: 'votes' | 'reviews' | 'wallets' | 'sentiment' | 'momentum'
  /** Short title, e.g. "100 community votes" */
  label: string
  /** One-sentence description for share cards and detail sheets. */
  description: string
  /** Whether the threshold has been crossed given current signals. */
  achieved: boolean
  /** The measured value at the time of evaluation. */
  value: number
  /** The threshold this milestone tests against. */
  threshold: number
  /**
   * Icon key for the UI layer to resolve — the analytics lib has no
   * React/component dependency. The UI maps this to a lucide icon.
   */
  iconKey: 'vote' | 'review' | 'wallet' | 'sentiment' | 'flame'
}

// Thresholds — derived from what the existing data architecture supports.
// All vote/review counts use all-time totals (not windowed) for correctness.
// Wallet counts use the uniqueParticipants7d proxy since we don't persist
// a cumulative all-time unique-wallet count in the current data model.
const VOTE_THRESHOLDS    = [10, 50, 100, 250, 500, 1_000, 2_500, 5_000]
const REVIEW_THRESHOLDS  = [5, 10, 25, 50, 100, 250]
const WALLET_THRESHOLDS  = [5, 10, 25, 50, 100]
const SENTIMENT_THRESHOLD = 75  // bullish % threshold for "Strong community conviction"
const MOMENTUM_THRESHOLD  = 70  // index threshold for "High momentum"

/**
 * Compute all milestone states for a project from its canonical signals.
 *
 * Returns ALL milestones (achieved and unachieved) so UIs can show progress.
 * Achieved milestones are guaranteed to reflect actual on-chain activity.
 *
 * Do NOT call Date.now() here — this function is pure and deterministic.
 */
export function computeMilestones(signals: ProjectSignals, momentumIndex?: number): Milestone[] {
  type MilestoneBase = Omit<Milestone, 'projectSlug'>
  const milestones: MilestoneBase[] = []

  // Vote milestones — use all-time total for correctness
  for (const t of VOTE_THRESHOLDS) {
    milestones.push({
      id: `votes-${t}`,
      category: 'votes',
      label: `${t.toLocaleString()} community votes`,
      description: `The community cast ${t.toLocaleString()} votes on this project on MYARC.`,
      achieved: signals.totalVotesAllTime >= t,
      value: signals.totalVotesAllTime,
      threshold: t,
      iconKey: 'vote',
    })
  }

  // Review milestones — use all-time total for correctness
  for (const t of REVIEW_THRESHOLDS) {
    milestones.push({
      id: `reviews-${t}`,
      category: 'reviews',
      label: `${t} community review${t === 1 ? '' : 's'}`,
      description: `${t} community members shared a written review of this project.`,
      achieved: signals.totalReviewsAllTime >= t,
      value: signals.totalReviewsAllTime,
      threshold: t,
      iconKey: 'review',
    })
  }

  // Wallet participation milestones
  // Note: uniqueParticipants7d is the best available proxy until a cumulative
  // all-time unique-wallet count is tracked. Explicitly documented on the milestone.
  for (const t of WALLET_THRESHOLDS) {
    milestones.push({
      id: `wallets-${t}`,
      category: 'wallets',
      label: `${t} unique participants (7d)`,
      description: `${t} unique wallets participated in this project's community in the last 7 days.`,
      achieved: signals.uniqueParticipants7d >= t,
      value: signals.uniqueParticipants7d,
      threshold: t,
      iconKey: 'wallet',
    })
  }

  // Sentiment milestone — only meaningful when enough votes exist
  if (signals.totalVotesAllTime >= 10) {
    const bullishPct = signals.sentiment.bullishPct ?? 0
    milestones.push({
      id: `sentiment-${SENTIMENT_THRESHOLD}`,
      category: 'sentiment',
      label: `${SENTIMENT_THRESHOLD}%+ community conviction`,
      description: `Over ${SENTIMENT_THRESHOLD}% of community votes are bullish on this project.`,
      achieved: bullishPct >= SENTIMENT_THRESHOLD,
      value: bullishPct,
      threshold: SENTIMENT_THRESHOLD,
      iconKey: 'sentiment',
    })
  }

  // Momentum milestone — only when momentumIndex is provided
  if (momentumIndex !== undefined) {
    milestones.push({
      id: `momentum-${MOMENTUM_THRESHOLD}`,
      category: 'momentum',
      label: `Community momentum index ${MOMENTUM_THRESHOLD}+`,
      description: `This project reached a community momentum index of ${MOMENTUM_THRESHOLD}+ on MYARC.`,
      achieved: momentumIndex >= MOMENTUM_THRESHOLD,
      value: momentumIndex,
      threshold: MOMENTUM_THRESHOLD,
      iconKey: 'flame',
    })
  }

  // Stamp projectSlug onto every milestone so cross-project lists remain self-descriptive
  return milestones.map((m) => ({ ...m, projectSlug: signals.projectSlug }))
}

/**
 * Return only the milestones that have been achieved, for display in
 * project pages and activity feeds.
 */
export function achievedMilestones(signals: ProjectSignals, momentumIndex?: number): Milestone[] {
  return computeMilestones(signals, momentumIndex).filter((m) => m.achieved)
}

// Types are declared with export interface/export type above — no re-export needed.
