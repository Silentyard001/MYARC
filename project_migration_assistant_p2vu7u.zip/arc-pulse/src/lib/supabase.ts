/**
 * Supabase client
 *
 * Reads VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY from the environment.
 * Returns null when either variable is absent so callers can fall back to
 * local-only behaviour when Supabase is not configured.
 *
 * Tables:
 *   review_flags        — shared review flags (reviewId → flagger address)
 *   featured_projects   — admin-controlled featured status per project
 *   sponsored_polls     — admin-controlled sponsored status per poll
 *   revenue_entries     — manual featured placement revenue entries
 *   onchain_polls       — polls created via the contract + admin panel
 *   submitted_projects  — user-submitted projects pending approval
 *
 * RLS (Phase 3b):
 *   - SELECT open to anon on all tables
 *   - INSERT/UPDATE/DELETE on admin tables requires an authenticated JWT whose
 *     `wallet_address` claim equals the contract owner address. This claim is
 *     set server-side by the auth-verify Edge Function after EIP-191 signature
 *     verification — it cannot be forged by a browser client.
 *   - submitted_projects INSERT open to anon; UPDATE/DELETE restricted to owner
 *
 * ⚠ PREVIOUS MECHANISM (REPLACED):
 *   The old x-owner-address custom header was self-asserted and insecure.
 *   Any client could set that header to the known owner address (which is
 *   public on-chain) and bypass the RLS gate. The header mechanism has been
 *   replaced by the JWT wallet_address claim on all admin tables.
 *   See migration: supabase/migrations/20260929_phase3b_admin_auth.sql
 */
import { createClient, type SupabaseClient } from '@supabase/supabase-js'

const url  = import.meta.env.VITE_SUPABASE_URL  as string | undefined
const akey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined

/**
 * ── profiles table — SQL migration (run once in Supabase SQL editor) ────────
 *
 *   create table profiles (
 *     user_id          uuid        primary key default gen_random_uuid(),
 *     wallet_address   text        unique not null,
 *     username         text        unique,
 *     display_name     text,
 *     avatar_url       text,
 *     bio              text,
 *     wallet_visibility text       not null default 'hidden'
 *                                  check (wallet_visibility in ('hidden', 'public')),
 *     created_at       timestamptz not null default now(),
 *     updated_at       timestamptz not null default now()
 *   );
 *
 *   -- Case-insensitive username uniqueness
 *   create unique index profiles_username_ci on profiles (lower(username))
 *     where username is not null;
 *
 *   -- RLS: anon reads; wallet owner writes own row
 *   alter table profiles enable row level security;
 *
 *   create policy "profiles_anon_read" on profiles
 *     for select using (true);
 *
 *   create policy "profiles_self_write" on profiles
 *     for all
 *     using (lower(wallet_address) = lower(
 *       current_setting('request.headers')::json->>'x-wallet-address'))
 *     with check (lower(wallet_address) = lower(
 *       current_setting('request.headers')::json->>'x-wallet-address'));
 *
 *   -- Backwards-compatible: existing Supabase tables are unaffected.
 *   -- Existing wallet-based relationships are preserved.
 *   -- username is null by default for existing/new users until they set one.
 *   -- wallet_visibility is 'hidden' by default.
 * ─────────────────────────────────────────────────────────────────────────────
 */

export type ProfileRow = {
  user_id: string
  wallet_address: string
  username: string | null
  display_name: string | null
  avatar_url: string | null
  bio: string | null
  wallet_visibility: 'hidden' | 'public'
  created_at: string
  updated_at: string
}

export type ReviewFlagRow = {
  id: string
  review_id: string
  flagger_address: string
  project_id: string
  created_at: string
}

/** Configured Supabase client (anon, read-only writes), or null when env vars are absent. */
export const supabase: SupabaseClient | null =
  url && akey ? createClient(url, akey) : null

/**
 * Returns the shared Supabase client for admin write operations.
 *
 * Phase 3b: the old x-owner-address header mechanism has been replaced.
 * Admin RLS policies now check the `wallet_address` claim in the
 * authenticated JWT (set server-side by auth-verify after signature
 * verification). The shared `supabase` client carries the JWT session
 * established by useAuth.signIn() — no custom header is needed or sent.
 *
 * The `_ownerAddress` parameter is kept for call-site compatibility but is
 * no longer used to set any HTTP header.
 *
 * ⚠ Admin writes will be rejected by RLS unless the connected wallet has
 *   completed the SIWE authentication flow (useAuth.signIn()) and its JWT
 *   wallet_address claim matches the contract owner address.
 */
// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function getAdminClient(_ownerAddress?: string): SupabaseClient | null {
  return supabase
}
