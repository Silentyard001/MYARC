/**
 * Minimal GraphQL client for the MYARC Goldsky subgraph.
 *
 * Usage:
 *   const data = await querySubgraph<{ votes: GqlVote[] }>(VOTES_QUERY, { voter })
 *
 * When VITE_SUBGRAPH_URL is absent this function throws a SubgraphUnavailableError
 * so callers can catch it and fall back to the RPC getLogs path.
 */

// ── Subgraph URL ──────────────────────────────────────────────────────────────

const SUBGRAPH_URL: string | null =
  (import.meta.env.VITE_SUBGRAPH_URL as string | undefined) || null

// ── Error type ────────────────────────────────────────────────────────────────

export class SubgraphUnavailableError extends Error {
  constructor() {
    super('VITE_SUBGRAPH_URL is not configured')
    this.name = 'SubgraphUnavailableError'
  }
}

// ── Core fetch helper ─────────────────────────────────────────────────────────

/**
 * Execute a GraphQL query against the Goldsky subgraph endpoint.
 * Throws `SubgraphUnavailableError` when the URL env var is absent.
 * Throws a plain `Error` on HTTP or GraphQL errors.
 */
export async function querySubgraph<T>(
  query: string,
  variables?: Record<string, unknown>
): Promise<T> {
  if (!SUBGRAPH_URL) throw new SubgraphUnavailableError()

  const res = await fetch(SUBGRAPH_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, variables: variables ?? {} }),
  })

  if (!res.ok) {
    throw new Error(`Subgraph HTTP ${res.status}: ${res.statusText}`)
  }

  const json = (await res.json()) as { data?: T; errors?: { message: string }[] }

  if (json.errors && json.errors.length > 0) {
    throw new Error(`Subgraph error: ${json.errors.map((e) => e.message).join(', ')}`)
  }

  if (json.data === undefined) {
    throw new Error('Subgraph returned no data')
  }

  return json.data
}

/** True when the subgraph URL is configured in this build. */
export const isSubgraphConfigured = !!SUBGRAPH_URL

// ── ReviewUpvote entity ────────────────────────────────────────────────────────

export interface GqlReviewUpvote {
  id: string
  projectId: string
  reviewIndex: string
  upvoter: string
  author: string
  totalAmount: string
  protocolFee: string
  authorAmount: string
  blockNumber: string
  timestamp: string
}

// ── Typed entity interfaces (match schema.graphql) ───────────────────────────

export interface GqlVote {
  id: string
  projectId: string
  voter: string
  sentiment: number
  isChange: boolean
  blockNumber: string
  timestamp: string
}

export interface GqlVoteRetraction {
  id: string
  projectId: string
  voter: string
  blockNumber: string
  timestamp: string
}

export interface GqlReview {
  id: string
  projectId: string
  author: string
  sentiment: number
  reviewIndex: string
  blockNumber: string
  timestamp: string
}

export interface GqlVerifiedProject {
  id: string
  projectId: string
  owner: string
  blockNumber: string
  timestamp: string
}

export interface GqlPollVote {
  id: string
  pollId: string
  voter: string
  optionIndex: number
  stake: string
  blockNumber: string
  timestamp: string
}

export interface GqlPollRewardClaim {
  id: string
  pollId: string
  claimant: string
  amount: string
  blockNumber: string
  timestamp: string
}

// ── Canned queries ─────────────────────────────────────────────────────────────

/** All votes + retractions + reviews for a specific voter address. */
export const ACTIVITY_BY_VOTER_QUERY = /* graphql */ `
  query ActivityByVoter($voter: String!, $first: Int!) {
    votes(first: $first, where: { voter: $voter }, orderBy: blockNumber, orderDirection: asc) {
      id projectId voter sentiment isChange blockNumber timestamp
    }
    voteRetractions(first: $first, where: { voter: $voter }, orderBy: blockNumber, orderDirection: asc) {
      id projectId voter blockNumber timestamp
    }
    reviews(first: $first, where: { author: $voter }, orderBy: blockNumber, orderDirection: asc) {
      id projectId author sentiment reviewIndex blockNumber timestamp
    }
  }
`

/** All votes + retractions + reviews for a specific project (bytes32 hex). */
export const ANALYTICS_BY_PROJECT_QUERY = /* graphql */ `
  query AnalyticsByProject($projectId: String!, $first: Int!) {
    votes(first: $first, where: { projectId: $projectId }, orderBy: blockNumber, orderDirection: asc) {
      id projectId voter sentiment isChange blockNumber timestamp
    }
    voteRetractions(first: $first, where: { projectId: $projectId }, orderBy: blockNumber, orderDirection: asc) {
      id projectId voter blockNumber timestamp
    }
    reviews(first: $first, where: { projectId: $projectId }, orderBy: blockNumber, orderDirection: asc) {
      id projectId author sentiment reviewIndex blockNumber timestamp
    }
  }
`

/** All verified project claims. */
export const VERIFIED_PROJECTS_QUERY = /* graphql */ `
  query VerifiedProjects($first: Int!) {
    verifiedProjects(first: $first, orderBy: blockNumber, orderDirection: asc) {
      id projectId owner blockNumber timestamp
    }
  }
`

/**
 * Platform-wide query for all events required by the Momentum Index.
 * Consumed by usePlatformMomentum as the subgraph-first path.
 *
 * Fetches up to $first of each event type, ordered oldest-first so that
 * the momentum computation sees events in chronological sequence.
 * Callers should use a large $first (e.g. 5000) to capture all history.
 */
export const ALL_EVENTS_QUERY = /* graphql */ `
  query AllEvents($first: Int!) {
    votes(first: $first, orderBy: blockNumber, orderDirection: asc) {
      id projectId voter sentiment isChange blockNumber timestamp
    }
    voteRetractions(first: $first, orderBy: blockNumber, orderDirection: asc) {
      id projectId voter blockNumber timestamp
    }
    reviews(first: $first, orderBy: blockNumber, orderDirection: asc) {
      id projectId author sentiment reviewIndex blockNumber timestamp
    }
    reviewUpvotes(first: $first, orderBy: blockNumber, orderDirection: asc) {
      id projectId reviewIndex upvoter author totalAmount protocolFee authorAmount blockNumber timestamp
    }
  }
`

/** Response shape for ALL_EVENTS_QUERY */
export interface AllEventsQueryResult {
  votes: GqlVote[]
  voteRetractions: GqlVoteRetraction[]
  reviews: GqlReview[]
  reviewUpvotes: GqlReviewUpvote[]
}
