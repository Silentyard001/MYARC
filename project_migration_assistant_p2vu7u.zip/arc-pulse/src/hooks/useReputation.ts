/**
 * useReputation
 *
 * Derives a numeric reputation score and tier for any wallet address.
 *
 * Scoring:
 *   +3  per vote cast
 *   +10 per review posted
 *   +2  per helpful vote received (across seed + user reviews)
 *   +15 early-adopter bonus per project voted on before it reached 100 total votes
 *   +20 per correct prediction (bullish + project bullish% rose; bearish + it fell)
 *
 * Tiers:
 *   0–20   → Newcomer
 *   21–60  → Analyst
 *   61–150 → Pioneer
 *   151+   → Whale
 *
 * Prediction accuracy:
 *   A vote is a "prediction". It is correct when the current bullish% is higher
 *   than 50% and the user voted Bullish, or lower than 50% and voted Bearish.
 *   (Full 30-day hindsight isn't available in the frontend — we approximate by
 *   comparing the project's current bullish% to the 50% midline as a proxy for
 *   "did this project trend in the direction you voted?")
 */

import { useMemo } from 'react'
import type { Project, Sentiment } from '../data/projects'

// ── Types ─────────────────────────────────────────────────────────────────────

export type ReputationTier = 'Newcomer' | 'Analyst' | 'Pioneer' | 'Whale'

export interface PredictionAccuracy {
  correct: number
  total: number
  pct: number
}

export interface UseReputationReturn {
  score: number
  tier: ReputationTier
  predictionAccuracy: PredictionAccuracy
}

// ── Tier thresholds ───────────────────────────────────────────────────────────

function scoreToTier(score: number): ReputationTier {
  if (score >= 151) return 'Whale'
  if (score >= 61)  return 'Pioneer'
  if (score >= 21)  return 'Analyst'
  return 'Newcomer'
}

// ── Tier colors (CSS variable–safe hex values) ────────────────────────────────

export const TIER_COLORS: Record<ReputationTier, { bg: string; color: string }> = {
  Newcomer: { bg: 'rgba(107,101,128,0.12)', color: 'var(--neutral)'  },
  Analyst:  { bg: 'rgba(26,92,255,0.10)',   color: 'var(--accent)'   },
  Pioneer:  { bg: 'rgba(26,128,71,0.12)',   color: 'var(--bullish)'  },
  Whale:    { bg: 'rgba(186,43,76,0.10)',   color: 'var(--bearish)'  },
}

// ── Hook ──────────────────────────────────────────────────────────────────────

interface UseReputationParams {
  address: string | undefined
  /** Live project list (with merged vote deltas). */
  projects: Project[]
  /** Per-project user votes: projectId → sentiment (session + localStorage). */
  userVotes: Record<string, Sentiment>
  /** User-posted reviews: projectId → stored reviews. */
  reviewOverrides: Record<string, { id: string; helpful: number; authorFull: string }[]>
  /** Helpful deltas for seed reviews: reviewId → count */
  seedHelpfulDeltas: Record<string, number>
}

export function useReputation({
  address,
  projects,
  userVotes,
  reviewOverrides,
  seedHelpfulDeltas,
}: UseReputationParams): UseReputationReturn {

  return useMemo<UseReputationReturn>(() => {
    if (!address) {
      return { score: 0, tier: 'Newcomer', predictionAccuracy: { correct: 0, total: 0, pct: 0 } }
    }

    const addr = address.toLowerCase()
    let score = 0

    // ── +3 per vote cast ──────────────────────────────────────────────────────
    const voteCount = Object.keys(userVotes).length
    score += voteCount * 3

    // ── +10 per review posted ─────────────────────────────────────────────────
    let reviewCount = 0
    for (const reviews of Object.values(reviewOverrides)) {
      for (const r of reviews) {
        if (r.authorFull.toLowerCase() === addr) reviewCount++
      }
    }
    score += reviewCount * 10

    // ── +2 per helpful vote received on user's reviews ────────────────────────
    let helpfulReceived = 0
    for (const reviews of Object.values(reviewOverrides)) {
      for (const r of reviews) {
        if (r.authorFull.toLowerCase() === addr) {
          helpfulReceived += r.helpful
        }
      }
    }
    // Also count helpful votes received on seed reviews authored by this address
    // (seed reviews have static authorFull — we match against them)
    for (const project of projects) {
      for (const review of project.reviews) {
        if (review.authorFull.toLowerCase() === addr) {
          helpfulReceived += seedHelpfulDeltas[review.id] ?? 0
        }
      }
    }
    score += helpfulReceived * 2

    // ── +15 early-adopter per project voted before 100 total votes ────────────
    for (const [projectId] of Object.entries(userVotes)) {
      const project = projects.find((p) => p.id === projectId)
      if (!project) continue
      const total = project.votes.bullish + project.votes.neutral + project.votes.bearish
      // If total is still ≤ 100 now, the vote was almost certainly cast early.
      // This is a conservative check — total has only grown since the vote.
      if (total <= 100) score += 15
    }

    // ── Prediction accuracy + +20 per correct prediction ─────────────────────
    let correct = 0
    const total = voteCount
    for (const [projectId, sentiment] of Object.entries(userVotes)) {
      const project = projects.find((p) => p.id === projectId)
      if (!project) continue
      const t = project.votes.bullish + project.votes.neutral + project.votes.bearish
      const bullishPct = t > 0 ? project.votes.bullish / t : 0.5
      // Correct: voted bullish and majority community is bullish (>50%),
      // or voted bearish and majority community is bearish (<50% bullish)
      const isCorrect =
        (sentiment === 'bullish' && bullishPct > 0.5) ||
        (sentiment === 'bearish' && bullishPct < 0.5)
      if (isCorrect) {
        correct++
        score += 20
      }
    }

    const pct = total > 0 ? Math.round((correct / total) * 100) : 0

    return {
      score,
      tier: scoreToTier(score),
      predictionAccuracy: { correct, total, pct },
    }
  }, [address, projects, userVotes, reviewOverrides, seedHelpfulDeltas])
}
