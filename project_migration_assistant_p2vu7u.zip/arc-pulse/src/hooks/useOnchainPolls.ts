/**
 * useOnchainPolls
 *
 * Reads polls from the Supabase `onchain_polls` table and merges with seed
 * data (POLLS) as a fallback when the table is empty or Supabase is absent.
 * Also reads live vote counts from getPollResult for each on-chain poll.
 *
 * Returns the same Poll[] shape the rest of the app already uses.
 */
import { useState, useEffect } from 'react'
import { usePublicClient } from 'wagmi'
import { parseAbi } from 'viem'
import { supabase } from '../lib/supabase'
import { POLLS, type Poll } from '../data/projects'
import { ARC_TESTNET_CHAIN_ID } from '../config'

interface OnchainPollRow {
  poll_id: string
  question: string
  options: { id: string; label: string }[]
  ends_at: string
  sponsored: boolean
  sponsor_name: string
}

const POLL_RESULT_ABI = parseAbi([
  'function getPollResult(bytes32 pollId) view returns (uint8 winner, uint256[] memory optionVotes, uint256 totalStake)',
])

export interface OnchainPollsResult {
  polls: Poll[]
  isLoading: boolean
  refetch: () => void
}

export function useOnchainPolls(
  contractAddress: `0x${string}` | undefined
): OnchainPollsResult {
  const publicClient = usePublicClient({ chainId: ARC_TESTNET_CHAIN_ID })
  const [polls, setPolls] = useState<Poll[]>(POLLS)
  // Start as loading only when Supabase is configured
  const [isLoading, setIsLoading] = useState(Boolean(supabase))
  const [refetchTick, setRefetchTick] = useState(0)

  const refetch = () => setRefetchTick((t) => t + 1)

  useEffect(() => {
    if (!supabase) return

    let cancelled = false

    const run = async () => {
      try {
        const { data, error } = await supabase!
          .from('onchain_polls')
          .select('poll_id, question, options, ends_at, sponsored, sponsor_name')
          .order('created_at', { ascending: true })

        if (cancelled) return
        if (error || !data || (data as unknown[]).length === 0) {
          setPolls(POLLS)
          setIsLoading(false)
          return
        }

        const rows = data as OnchainPollRow[]

        let pollsWithCounts: Poll[] = rows.map((row) => ({
          id: row.poll_id,
          question: row.question,
          options: row.options.map((o) => ({ ...o, votes: 0 })),
          endsAt: new Date(row.ends_at).getTime(),
          totalVotes: 0,
          category: 'Onchain',
          sponsored: row.sponsored,
          sponsorName: row.sponsor_name || undefined,
        }))

        if (contractAddress && publicClient) {
          try {
            const results = await Promise.all(
              pollsWithCounts.map((poll) =>
                publicClient
                  .readContract({
                    address: contractAddress,
                    abi: POLL_RESULT_ABI,
                    functionName: 'getPollResult',
                    args: [poll.id as `0x${string}`],
                  })
                  .then((res) => ({ poll, res }))
                  .catch(() => ({ poll, res: null }))
              )
            )

            pollsWithCounts = results.map(({ poll, res }) => {
              if (!res) return poll
              const [, optionVotes] = res as [number, bigint[], bigint]
              const voteCounts = (optionVotes).map((v) => Number(v))
              const totalVotes = voteCounts.reduce((a, b) => a + b, 0)
              return {
                ...poll,
                options: poll.options.map((o, i) => ({
                  ...o,
                  votes: voteCounts[i] ?? o.votes,
                })),
                totalVotes,
              }
            })
          } catch {
            // keep zero counts on error
          }
        }

        if (!cancelled) {
          const onchainIds = new Set(pollsWithCounts.map((p) => p.id))
          const seedFallbacks = POLLS.filter((p) => !onchainIds.has(p.id))
          setPolls([...pollsWithCounts, ...seedFallbacks])
          setIsLoading(false)
        }
      } catch {
        if (!cancelled) {
          setPolls(POLLS)
          setIsLoading(false)
        }
      }
    }

    void run()
    return () => { cancelled = true }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [contractAddress, publicClient, refetchTick])

  return { polls, isLoading, refetch }
}
