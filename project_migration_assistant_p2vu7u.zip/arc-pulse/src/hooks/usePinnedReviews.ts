/**
 * usePinnedReviews
 *
 * Fetches pinned review IDs for a given project from the Supabase
 * `pinned_reviews` table. Exposes `pinnedIds: Set<string>`, `pinReview`,
 * and `unpinReview`. Falls back to an empty set when Supabase is absent.
 *
 * Table schema:
 *   id          uuid PK default gen_random_uuid()
 *   project_id  text not null
 *   review_id   text not null
 *   pinned_at   timestamptz default now()
 *   unique (project_id, review_id)
 *
 * RLS: anon SELECT open; INSERT/DELETE restricted to owner address header.
 */
import { useState, useEffect, useCallback } from 'react'
import { supabase, getAdminClient } from '../lib/supabase'

interface UsePinnedReviewsParams {
  projectId: string | null
  ownerAddress?: string
}

export interface UsePinnedReviewsResult {
  pinnedIds: Set<string>
  pinReview: (reviewId: string) => Promise<void>
  unpinReview: (reviewId: string) => Promise<void>
  isLoading: boolean
}

export function usePinnedReviews({
  projectId,
  ownerAddress,
}: UsePinnedReviewsParams): UsePinnedReviewsResult {
  const [pinnedIds, setPinnedIds] = useState<Set<string>>(new Set())
  const [isLoading, setIsLoading] = useState(Boolean(supabase && projectId))

  useEffect(() => {
    if (!supabase || !projectId) return
    let cancelled = false

    supabase
      .from('pinned_reviews')
      .select('review_id')
      .eq('project_id', projectId)
      .then(({ data }) => {
        if (cancelled) return
        const ids = new Set<string>(
          (data ?? []).map((r: { review_id: string }) => r.review_id)
        )
        setPinnedIds(ids)
        setIsLoading(false)
      }, () => {
        if (!cancelled) setIsLoading(false)
      })

    return () => { cancelled = true }
  }, [projectId])

  const pinReview = useCallback(async (reviewId: string) => {
    if (!projectId) return
    // Optimistic update
    setPinnedIds((prev) => new Set([...prev, reviewId]))
    const client = ownerAddress ? getAdminClient(ownerAddress) : supabase
    if (!client) return
    await client
      .from('pinned_reviews')
      .upsert({ project_id: projectId, review_id: reviewId }, { onConflict: 'project_id,review_id' })
      .then(undefined, () => {
        // Rollback on error
        setPinnedIds((prev) => { const next = new Set(prev); next.delete(reviewId); return next })
      })
  }, [projectId, ownerAddress])

  const unpinReview = useCallback(async (reviewId: string) => {
    if (!projectId) return
    // Optimistic update
    setPinnedIds((prev) => { const next = new Set(prev); next.delete(reviewId); return next })
    const client = ownerAddress ? getAdminClient(ownerAddress) : supabase
    if (!client) return
    await client
      .from('pinned_reviews')
      .delete()
      .eq('project_id', projectId)
      .eq('review_id', reviewId)
      .then(undefined, () => {
        // Rollback on error
        setPinnedIds((prev) => new Set([...prev, reviewId]))
      })
  }, [projectId, ownerAddress])

  return { pinnedIds, pinReview, unpinReview, isLoading }
}
