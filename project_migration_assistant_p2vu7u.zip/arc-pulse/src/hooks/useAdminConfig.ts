/**
 * useAdminConfig
 *
 * Reads featured_projects and sponsored_polls from Supabase and exposes
 * save functions. Falls back to hardcoded seed values when Supabase is absent.
 * Write operations use getAdminClient() which returns the session-bearing
 * Supabase client. Admin RLS policies verify the JWT wallet_address claim.
 *
 * Tables:
 *   featured_projects  (project_id text PK, featured bool, updated_at timestamptz)
 *   sponsored_polls    (poll_id text PK, sponsored bool, sponsor_name text, updated_at timestamptz)
 */
import { useState, useEffect, useCallback } from 'react'
import { supabase, getAdminClient } from '../lib/supabase'
import { PROJECTS, POLLS } from '../data/projects'

export interface AdminConfigResult {
  /** Set of project IDs that are currently featured */
  featuredIds: Set<string>
  /** Map of poll ID → sponsor name (only entries that are sponsored) */
  sponsoredPolls: Record<string, string>
  /** Toggle a project's featured status */
  setFeatured: (projectId: string, featured: boolean, ownerAddress?: string) => Promise<void>
  /** Toggle a poll's sponsored status and/or update sponsor name */
  setSponsored: (pollId: string, sponsored: boolean, sponsorName: string, ownerAddress?: string) => Promise<void>
  isLoading: boolean
  /** ISO date string of the last generated report, or null */
  lastReportGenerated: string | null
  /** Call after generating a report to update the stored timestamp */
  markReportGenerated: () => void
}

export function useAdminConfig(): AdminConfigResult {
  // Seed from hardcoded data (fallback when Supabase is absent or still loading)
  const seedFeatured = new Set(PROJECTS.filter((p) => p.featured).map((p) => p.id))
  const seedSponsored: Record<string, string> = {}
  for (const p of POLLS) {
    if (p.sponsored && p.sponsorName) seedSponsored[p.id] = p.sponsorName
  }

  const [featuredIds, setFeaturedIds] = useState<Set<string>>(seedFeatured)
  const [sponsoredPolls, setSponsoredPolls] = useState<Record<string, string>>(seedSponsored)
  const [isLoading, setIsLoading] = useState(Boolean(supabase))
  const [lastReportGenerated, setLastReportGenerated] = useState<string | null>(() => {
    try { return localStorage.getItem('myarc:last-report') } catch { return null }
  })

  const markReportGenerated = useCallback(() => {
    const iso = new Date().toISOString()
    try { localStorage.setItem('myarc:last-report', iso) } catch { /* ignore */ }
    setLastReportGenerated(iso)
  }, [])

  // Fetch from Supabase on mount
  useEffect(() => {
    if (!supabase) return

    Promise.all([
      supabase.from('featured_projects').select('project_id, featured'),
      supabase.from('sponsored_polls').select('poll_id, sponsored, sponsor_name'),
    ])
      .then(([fpRes, spRes]) => {
        if (fpRes.data) {
          const ids = new Set<string>()
          for (const row of fpRes.data as { project_id: string; featured: boolean }[]) {
            if (row.featured) ids.add(row.project_id)
          }
          // If the table is empty, fall back to seed values
          if (ids.size > 0 || (fpRes.data as unknown[]).length > 0) {
            setFeaturedIds(ids)
          }
        }
        if (spRes.data) {
          const map: Record<string, string> = {}
          for (const row of spRes.data as { poll_id: string; sponsored: boolean; sponsor_name: string }[]) {
            if (row.sponsored && row.sponsor_name) map[row.poll_id] = row.sponsor_name
          }
          if ((spRes.data as unknown[]).length > 0) {
            setSponsoredPolls(map)
          }
        }
      })
      .catch(() => { /* keep seed values */ })
      .finally(() => setIsLoading(false))
  }, [])

  const setFeatured = useCallback(async (projectId: string, featured: boolean, ownerAddress?: string) => {
    // Optimistic update
    setFeaturedIds((prev) => {
      const next = new Set(prev)
      if (featured) next.add(projectId)
      else next.delete(projectId)
      return next
    })

    const client = ownerAddress ? getAdminClient(ownerAddress) : supabase
    if (client) {
      await client.from('featured_projects').upsert({
        project_id: projectId,
        featured,
        updated_at: new Date().toISOString(),
      }, { onConflict: 'project_id' })
    }
  }, [])

  const setSponsored = useCallback(async (pollId: string, sponsored: boolean, sponsorName: string, ownerAddress?: string) => {
    // Optimistic update
    setSponsoredPolls((prev) => {
      const next = { ...prev }
      if (sponsored && sponsorName) next[pollId] = sponsorName
      else delete next[pollId]
      return next
    })

    const client = ownerAddress ? getAdminClient(ownerAddress) : supabase
    if (client) {
      await client.from('sponsored_polls').upsert({
        poll_id: pollId,
        sponsored,
        sponsor_name: sponsored ? sponsorName : '',
        updated_at: new Date().toISOString(),
      }, { onConflict: 'poll_id' })
    }
  }, [])

  return { featuredIds, sponsoredPolls, setFeatured, setSponsored, isLoading, lastReportGenerated, markReportGenerated }
}
