/**
 * useProjectAnalytics
 *
 * Fetches real on-chain event logs for a specific project and derives
 * analytics data for the owner Analytics tab.
 *
 * Data source (priority order):
 *   1. Goldsky subgraph (when VITE_SUBGRAPH_URL is set) — single GraphQL query.
 *   2. Direct getLogs against the Arc Testnet RPC — fallback when subgraph is absent.
 *
 * Derived outputs:
 *   timeline        — 7-day array of bullish% (or null) by replaying votes per day
 *   reviewVolume    — 7-day array of review counts per day
 *   topReviewers    — sorted by review count desc (up to 5)
 *   sentimentBreakdown — live {bullish, neutral, bearish} after retractions
 *   dayLabels       — ['Mo','Tu',...] for the last 7 days
 */

import { useState, useEffect, useCallback } from 'react'
import { usePublicClient } from 'wagmi'
import { parseAbiItem, decodeEventLog, type Log } from 'viem'
import { ARC_TESTNET_CHAIN_ID } from '../config'
import { slugToBytes32 } from '../utils/projectId'
import { getPaginatedLogs } from '../utils/getLogs'
import {
  querySubgraph,
  SubgraphUnavailableError,
  ANALYTICS_BY_PROJECT_QUERY,
  type GqlVote,
  type GqlVoteRetraction,
  type GqlReview,
} from '../lib/graphql'

// ── ABIs (RPC fallback path) ──────────────────────────────────────────────────

const VOTED_EVENT = parseAbiItem(
  'event Voted(bytes32 indexed projectId, address indexed voter, uint8 sentiment, bool isChange)'
)
const VOTE_RETRACTED_EVENT = parseAbiItem(
  'event VoteRetracted(bytes32 indexed projectId, address indexed voter)'
)
const REVIEW_POSTED_EVENT = parseAbiItem(
  'event ReviewPosted(bytes32 indexed projectId, address indexed author, uint8 sentiment, uint256 reviewIndex)'
)

// ── Types ─────────────────────────────────────────────────────────────────────

export interface SentimentBreakdown {
  bullish: number
  neutral: number
  bearish: number
}

export interface TopReviewer {
  address: string
  count: number
}

export interface ProjectAnalyticsResult {
  /** 7-element array: bullish% (0-100) for each of the last 7 days, or null if no votes */
  timeline: (number | null)[]
  /** 7-element array: review count per day for the last 7 days */
  reviewVolume: number[]
  /** Day-of-week abbreviations (2 chars) for the last 7 days, oldest first */
  dayLabels: string[]
  /** Top reviewers by review count on this project */
  topReviewers: TopReviewer[]
  /** Live sentiment breakdown after retractions */
  sentimentBreakdown: SentimentBreakdown
  isLoading: boolean
  error: string | null
  /** Re-fetch all data (called after confirmed on-chain writes). */
  refetch: () => void
}

// ── Module-level timestamp — stable across re-renders ────────────────────────
const ANALYTICS_NOW_TS = Date.now()
const DAY_MS = 86400000

const SUBGRAPH_PAGE_SIZE = 1000

// ── Hook ─────────────────────────────────────────────────────────────────────

export function useProjectAnalytics(
  projectSlug: string | null,
  contractAddress: `0x${string}` | undefined
): ProjectAnalyticsResult {
  const publicClient = usePublicClient({ chainId: ARC_TESTNET_CHAIN_ID })

  const [result, setResult] = useState<Omit<ProjectAnalyticsResult, 'isLoading' | 'error' | 'refetch'>>({
    timeline: [null, null, null, null, null, null, null] as (number | null)[],
    reviewVolume: [0, 0, 0, 0, 0, 0, 0] as number[],
    dayLabels: Array.from({ length: 7 }, (_, i) => {
      const d = new Date(ANALYTICS_NOW_TS - (6 - i) * DAY_MS)
      return d.toLocaleDateString('en', { weekday: 'short' }).slice(0, 2)
    }),
    topReviewers: [],
    sentimentBreakdown: { bullish: 0, neutral: 0, bearish: 0 },
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [refetchTick, setRefetchTick] = useState(0)
  const refetch = useCallback(() => setRefetchTick((t) => t + 1), [])

  useEffect(() => {
    if (!projectSlug || !contractAddress || !publicClient) return

    let cancelled = false
    setIsLoading(true)
    setError(null)

    const projectId32 = slugToBytes32(projectSlug)

    async function run() {
      if (!publicClient || !contractAddress) return

      try {
        // ── Try subgraph first ────────────────────────────────────────────────
        let gqlVotes: GqlVote[] | null = null
        let gqlRetractions: GqlVoteRetraction[] | null = null
        let gqlReviews: GqlReview[] | null = null

        try {
          const data = await querySubgraph<{
            votes: GqlVote[]
            voteRetractions: GqlVoteRetraction[]
            reviews: GqlReview[]
          }>(ANALYTICS_BY_PROJECT_QUERY, {
            projectId: projectId32.toLowerCase(),
            first: SUBGRAPH_PAGE_SIZE,
          })
          gqlVotes = data.votes
          gqlRetractions = data.voteRetractions
          gqlReviews = data.reviews
        } catch (err) {
          if (!(err instanceof SubgraphUnavailableError)) {
            console.warn('[useProjectAnalytics] subgraph query failed, falling back to RPC:', err)
          }
        }

        if (cancelled) return

        if (gqlVotes !== null && gqlRetractions !== null && gqlReviews !== null) {
          // ── Subgraph path: timestamps come from the subgraph directly ────────
          const derived = deriveAnalyticsFromSubgraph(gqlVotes, gqlRetractions, gqlReviews)
          if (!cancelled) {
            setResult(derived)
            setIsLoading(false)
          }
          return
        }

        // ── RPC fallback path ─────────────────────────────────────────────────
        const derived = await deriveAnalyticsFromRpc(publicClient, contractAddress, projectId32)
        if (!cancelled) {
          setResult(derived)
          setIsLoading(false)
        }
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : 'Failed to fetch analytics')
          setIsLoading(false)
        }
      }
    }

    void run()
    return () => { cancelled = true }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectSlug, contractAddress, refetchTick])

  return { ...result, isLoading, error, refetch }
}

// ── Analytics derivation: subgraph path ──────────────────────────────────────

function deriveAnalyticsFromSubgraph(
  gqlVotes: GqlVote[],
  gqlRetractions: GqlVoteRetraction[],
  gqlReviews: GqlReview[]
): Omit<ProjectAnalyticsResult, 'isLoading' | 'error' | 'refetch'> {
  // Convert subgraph timestamps (seconds as string) to ms numbers
  type VoteEv = { type: 'vote'; voter: string; sentiment: number; ts: number }
  type RetractEv = { type: 'retract'; voter: string; ts: number }
  const allEvents: (VoteEv | RetractEv)[] = []

  for (const v of gqlVotes) {
    allEvents.push({ type: 'vote', voter: v.voter, sentiment: v.sentiment, ts: Number(v.timestamp) * 1000 })
  }
  for (const r of gqlRetractions) {
    allEvents.push({ type: 'retract', voter: r.voter, ts: Number(r.timestamp) * 1000 })
  }
  allEvents.sort((a, b) => a.ts - b.ts)

  return computeAnalytics(allEvents, gqlReviews.map((r) => ({
    author: r.author,
    ts: Number(r.timestamp) * 1000,
  })))
}

// ── Analytics derivation: RPC fallback path ───────────────────────────────────

async function deriveAnalyticsFromRpc(
  publicClient: NonNullable<ReturnType<typeof usePublicClient>>,
  contractAddress: `0x${string}`,
  projectId32: `0x${string}`
): Promise<Omit<ProjectAnalyticsResult, 'isLoading' | 'error' | 'refetch'>> {
  // Arc Testnet RPC enforces a 100 000-block limit — use paginated fetching
  const votedLogs = await getPaginatedLogs(publicClient, {
    address: contractAddress,
    event: VOTED_EVENT,
    args: { projectId: projectId32 },
  })
  const retractedLogs = await getPaginatedLogs(publicClient, {
    address: contractAddress,
    event: VOTE_RETRACTED_EVENT,
    args: { projectId: projectId32 },
  })
  const reviewLogs = await getPaginatedLogs(publicClient, {
    address: contractAddress,
    event: REVIEW_POSTED_EVENT,
    args: { projectId: projectId32 },
  })

  // Batch-fetch unique block timestamps
  const blockSet = new Set<bigint>()
  for (const log of [...votedLogs, ...retractedLogs, ...reviewLogs]) {
    if (log.blockNumber) blockSet.add(log.blockNumber)
  }

  const blockTimestamps = new Map<bigint, number>()
  if (blockSet.size > 0) {
    const results = await Promise.all(
      Array.from(blockSet).map((bn) =>
        publicClient.getBlock({ blockNumber: bn })
          .then((b) => ({ bn, ts: Number(b.timestamp) * 1000 }))
          .catch(() => ({ bn, ts: 0 }))
      )
    )
    for (const { bn, ts } of results) blockTimestamps.set(bn, ts)
  }

  function logTs(log: Log): number {
    return log.blockNumber ? (blockTimestamps.get(log.blockNumber) ?? 0) : 0
  }

  // Sort by block + log index
  const sortLog = (a: Log, b: Log) => {
    const d = Number((a.blockNumber ?? 0n) - (b.blockNumber ?? 0n))
    return d !== 0 ? d : (a.logIndex ?? 0) - (b.logIndex ?? 0)
  }

  type VoteEv = { type: 'vote'; voter: string; sentiment: number; ts: number }
  type RetractEv = { type: 'retract'; voter: string; ts: number }
  const allEvents: (VoteEv | RetractEv)[] = []

  for (const log of [...votedLogs].sort(sortLog)) {
    const d = decodeVoted(log)
    if (d) allEvents.push({ type: 'vote', voter: d.voter, sentiment: d.sentiment, ts: logTs(log) })
  }
  for (const log of [...retractedLogs].sort(sortLog)) {
    const d = decodeRetracted(log)
    if (d) allEvents.push({ type: 'retract', voter: d.voter, ts: logTs(log) })
  }
  allEvents.sort((a, b) => a.ts - b.ts)

  const reviewMeta = reviewLogs.map((log) => {
    const d = decodeReviewPosted(log)
    return d ? { author: d.author, ts: logTs(log) } : null
  }).filter((r): r is NonNullable<typeof r> => r !== null)

  return computeAnalytics(allEvents, reviewMeta)
}

// ── Shared analytics computation ──────────────────────────────────────────────

type VoteEv = { type: 'vote'; voter: string; sentiment: number; ts: number }
type RetractEv = { type: 'retract'; voter: string; ts: number }

function computeAnalytics(
  allEvents: (VoteEv | RetractEv)[],
  reviewMeta: { author: string; ts: number }[]
): Omit<ProjectAnalyticsResult, 'isLoading' | 'error' | 'refetch'> {
  // ── Current sentiment breakdown (live, after retractions) ─────────────────
  const liveVotes = new Map<string, number>()
  for (const ev of allEvents) {
    if (ev.type === 'vote') liveVotes.set(ev.voter, ev.sentiment)
    else liveVotes.delete(ev.voter)
  }

  const breakdown: SentimentBreakdown = { bullish: 0, neutral: 0, bearish: 0 }
  for (const s of liveVotes.values()) {
    if (s === 0) breakdown.bullish++
    else if (s === 1) breakdown.neutral++
    else breakdown.bearish++
  }

  // ── 7-day sentiment timeline ──────────────────────────────────────────────
  const timeline: (number | null)[] = [null, null, null, null, null, null, null]
  for (let i = 0; i < 7; i++) {
    const dayEnd = ANALYTICS_NOW_TS - (6 - i) * DAY_MS + DAY_MS
    const dayVotes = new Map<string, number>()
    for (const ev of allEvents) {
      if (ev.ts === 0 || ev.ts > dayEnd) continue
      if (ev.type === 'vote') dayVotes.set(ev.voter, ev.sentiment)
      else dayVotes.delete(ev.voter)
    }
    const total = dayVotes.size
    if (total === 0) { timeline[i] = null; continue }
    let bull = 0
    for (const s of dayVotes.values()) { if (s === 0) bull++ }
    timeline[i] = Math.round((bull / total) * 100)
  }

  // ── 7-day review volume ───────────────────────────────────────────────────
  const reviewVolume: number[] = [0, 0, 0, 0, 0, 0, 0]
  for (const { ts } of reviewMeta) {
    if (ts === 0) continue
    for (let i = 0; i < 7; i++) {
      const dayStart = ANALYTICS_NOW_TS - (6 - i) * DAY_MS
      const dayEnd = dayStart + DAY_MS
      if (ts >= dayStart && ts < dayEnd) { reviewVolume[i]++; break }
    }
  }

  // ── Top reviewers ─────────────────────────────────────────────────────────
  const reviewerCounts = new Map<string, number>()
  for (const { author } of reviewMeta) {
    reviewerCounts.set(author, (reviewerCounts.get(author) ?? 0) + 1)
  }
  const topReviewers: TopReviewer[] = Array.from(reviewerCounts.entries())
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5)
    .map(([address, count]) => ({ address, count }))

  // ── Day labels ────────────────────────────────────────────────────────────
  const dayLabels = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(ANALYTICS_NOW_TS - (6 - i) * DAY_MS)
    return d.toLocaleDateString('en', { weekday: 'short' }).slice(0, 2)
  })

  return { timeline, reviewVolume, dayLabels, topReviewers, sentimentBreakdown: breakdown }
}

// ── Safe log decoders (RPC path only) ────────────────────────────────────────

function decodeVoted(log: Log): { voter: string; sentiment: number } | null {
  try {
    const { args } = decodeEventLog({ abi: [VOTED_EVENT], data: log.data, topics: log.topics })
    const a = args as { voter: string; sentiment: number }
    return { voter: a.voter.toLowerCase(), sentiment: a.sentiment }
  } catch { return null }
}

function decodeRetracted(log: Log): { voter: string } | null {
  try {
    const { args } = decodeEventLog({ abi: [VOTE_RETRACTED_EVENT], data: log.data, topics: log.topics })
    const a = args as { voter: string }
    return { voter: a.voter.toLowerCase() }
  } catch { return null }
}

function decodeReviewPosted(log: Log): { author: string } | null {
  try {
    const { args } = decodeEventLog({ abi: [REVIEW_POSTED_EVENT], data: log.data, topics: log.topics })
    const a = args as { author: string }
    return { author: a.author.toLowerCase() }
  } catch { return null }
}
