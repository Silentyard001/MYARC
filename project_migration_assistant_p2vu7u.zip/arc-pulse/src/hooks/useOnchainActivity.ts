/**
 * useOnchainActivity
 *
 * Fetches on-chain activity for the connected wallet.
 *
 * Data source (priority order):
 *   1. Goldsky subgraph (when VITE_SUBGRAPH_URL is set) — single GraphQL query,
 *      no per-block RPC calls, scales with chain growth.
 *   2. Direct getLogs against the Arc Testnet RPC — always-available fallback,
 *      used automatically when the subgraph URL is absent or the query throws.
 *
 * Return type is identical regardless of which path ran.
 *
 * Events indexed:
 *   Voted(bytes32 indexed projectId, address indexed voter, uint8 sentiment, bool isChange)
 *   VoteRetracted(bytes32 indexed projectId, address indexed voter)
 *   ReviewPosted(bytes32 indexed projectId, address indexed author, uint8 sentiment, uint256 reviewIndex)
 */

import { useState, useEffect, useCallback } from 'react'
import { usePublicClient } from 'wagmi'
import { type Log, decodeEventLog, parseAbiItem } from 'viem'
import { ARC_TESTNET_CHAIN_ID } from '../config'
import { getPaginatedLogs } from '../utils/getLogs'
import type { UseUserActivityReturn, VoteHistoryItem, ReviewHistoryItem } from './useUserActivity'
import { bytes32ToSlug } from '../utils/projectId'
import type { Project, Poll, Sentiment } from '../data/projects'
import {
  querySubgraph,
  SubgraphUnavailableError,
  ACTIVITY_BY_VOTER_QUERY,
  type GqlVote,
  type GqlVoteRetraction,
  type GqlReview,
} from '../lib/graphql'

// ── Event signatures (RPC fallback path) ─────────────────────────────────────

const VOTED_EVENT = parseAbiItem(
  'event Voted(bytes32 indexed projectId, address indexed voter, uint8 sentiment, bool isChange)'
)
const VOTE_RETRACTED_EVENT = parseAbiItem(
  'event VoteRetracted(bytes32 indexed projectId, address indexed voter)'
)
const REVIEW_POSTED_EVENT = parseAbiItem(
  'event ReviewPosted(bytes32 indexed projectId, address indexed author, uint8 sentiment, uint256 reviewIndex)'
)

// ── getReview ABI (minimal fragment for readContract) ────────────────────────

const GET_REVIEW_ABI = [
  {
    name: 'getReview',
    type: 'function',
    stateMutability: 'view',
    inputs: [
      { name: 'projectId', type: 'bytes32' },
      { name: 'index',     type: 'uint256' },
    ],
    outputs: [
      {
        name: '',
        type: 'tuple',
        components: [
          { name: 'author',    type: 'address' },
          { name: 'sentiment', type: 'uint8'   },
          { name: 'timestamp', type: 'uint40'  },
          { name: 'body',      type: 'string'  },
        ],
      },
    ],
  },
] as const

// ── Sentiment mapping ─────────────────────────────────────────────────────────

function enumToSentiment(n: number): Sentiment {
  if (n === 0) return 'bullish'
  if (n === 1) return 'neutral'
  return 'bearish'
}

// ── Hook interface ────────────────────────────────────────────────────────────

interface UseOnchainActivityOptions {
  contractAddress: `0x${string}` | undefined
  address: `0x${string}` | undefined
  projects: Project[]
  polls: Poll[]
  pollVotes: Record<string, string>
  /** Incrementing this triggers a re-fetch (pass the tx counter from useVoteBySig). */
  refetchKey?: number
}

interface UseOnchainActivityReturn extends UseUserActivityReturn {
  isLoading: boolean
  error: string | null
  refetch: () => void
}

// ── Max entities to fetch from the subgraph in a single query ─────────────────
// Goldsky's default page limit is 1000; raise this if a wallet has more activity.
const SUBGRAPH_PAGE_SIZE = 1000

// ── Hook ─────────────────────────────────────────────────────────────────────

export function useOnchainActivity({
  contractAddress,
  address,
  projects,
  polls,
  pollVotes,
  refetchKey = 0,
}: UseOnchainActivityOptions): UseOnchainActivityReturn {
  const publicClient = usePublicClient({ chainId: ARC_TESTNET_CHAIN_ID })

  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [voteHistory, setVoteHistory] = useState<VoteHistoryItem[]>([])
  const [reviewsPosted, setReviewsPosted] = useState<ReviewHistoryItem[]>([])
  const [refetchTick, setRefetchTick] = useState(0)

  const refetch = useCallback(() => setRefetchTick((t) => t + 1), [])

  useEffect(() => {
    if (!contractAddress || !address || !publicClient) {
      setVoteHistory([])
      setReviewsPosted([])
      return
    }

    let cancelled = false

    async function run() {
      if (!publicClient || !contractAddress || !address) return
      setIsLoading(true)
      setError(null)

      try {
        // ── Try subgraph path first ───────────────────────────────────────────
        let gqlVotes: GqlVote[] | null = null
        let gqlRetractions: GqlVoteRetraction[] | null = null
        let gqlReviews: GqlReview[] | null = null

        try {
          const data = await querySubgraph<{
            votes: GqlVote[]
            voteRetractions: GqlVoteRetraction[]
            reviews: GqlReview[]
          }>(ACTIVITY_BY_VOTER_QUERY, {
            voter: address.toLowerCase(),
            first: SUBGRAPH_PAGE_SIZE,
          })
          gqlVotes = data.votes
          gqlRetractions = data.voteRetractions
          gqlReviews = data.reviews
        } catch (err) {
          if (!(err instanceof SubgraphUnavailableError)) {
            // Log non-config errors but still fall through to RPC path
            console.warn('[useOnchainActivity] subgraph query failed, falling back to RPC:', err)
          }
        }

        if (cancelled) return

        if (gqlVotes !== null && gqlRetractions !== null && gqlReviews !== null) {
          // ── Subgraph path ─────────────────────────────────────────────────
          processSubgraphData(
            gqlVotes,
            gqlRetractions,
            gqlReviews,
            projects,
            contractAddress,
            publicClient,
            cancelled,
            setVoteHistory,
            setReviewsPosted
          ).then(() => {
            if (!cancelled) setIsLoading(false)
          }).catch((err) => {
            if (!cancelled) {
              setError(err instanceof Error ? err.message : 'Failed to process subgraph data')
              setIsLoading(false)
            }
          })
          return
        }

        // ── RPC fallback path ─────────────────────────────────────────────────
        await fetchViaRpc({
          publicClient,
          contractAddress,
          address,
          projects,
          cancelled,
          setVoteHistory,
          setReviewsPosted,
        })
        if (!cancelled) setIsLoading(false)
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : 'Failed to fetch on-chain activity')
          setIsLoading(false)
        }
      }
    }

    void run()
    return () => { cancelled = true }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [contractAddress, address, refetchTick, refetchKey])

  // Poll vote history is still derived from session state
  const pollVoteHistory = Object.entries(pollVotes).map(([pollId, optionId]) => {
    const poll = polls.find((p) => p.id === pollId)
    const option = poll?.options.find((o) => o.id === optionId)
    return {
      pollId,
      question: poll?.question ?? pollId,
      chosenLabel: option?.label ?? optionId,
    }
  })

  return {
    isLoading,
    error,
    refetch,
    voteHistory,
    reviewsPosted,
    pollVoteHistory,
    totalVotesCast: voteHistory.length,
    totalReviewsPosted: reviewsPosted.length,
  }
}

// ── Subgraph data processor ───────────────────────────────────────────────────

async function processSubgraphData(
  gqlVotes: GqlVote[],
  gqlRetractions: GqlVoteRetraction[],
  gqlReviews: GqlReview[],
  projects: Project[],
  contractAddress: `0x${string}`,
  publicClient: NonNullable<ReturnType<typeof usePublicClient>>,
  cancelled: boolean,
  setVoteHistory: (v: VoteHistoryItem[]) => void,
  setReviewsPosted: (r: ReviewHistoryItem[]) => void
): Promise<void> {
  // Build vote map: apply votes chronologically, remove retractions
  // GQL results are already ordered by blockNumber asc
  type VoteEntry = { sentiment: Sentiment; blockNumber: number }
  const voteMap = new Map<string, VoteEntry>()

  // Merge votes and retractions into a single ordered stream
  type VoteEv = { type: 'vote'; projectId: string; sentiment: number; bn: number; li: number }
  type RetractEv = { type: 'retract'; projectId: string; bn: number; li: number }
  const allEvents: (VoteEv | RetractEv)[] = []

  for (const v of gqlVotes) {
    allEvents.push({
      type: 'vote',
      projectId: v.projectId,
      sentiment: v.sentiment,
      bn: Number(v.blockNumber),
      li: 0, // subgraph doesn't expose logIndex directly — block order is sufficient
    })
  }
  for (const r of gqlRetractions) {
    allEvents.push({
      type: 'retract',
      projectId: r.projectId,
      bn: Number(r.blockNumber),
      li: 0,
    })
  }
  allEvents.sort((a, b) => a.bn - b.bn)

  for (const ev of allEvents) {
    const slug = bytes32ToSlug(ev.projectId as `0x${string}`)
    if (ev.type === 'vote') {
      voteMap.set(slug, { sentiment: enumToSentiment(ev.sentiment), blockNumber: ev.bn })
    } else {
      voteMap.delete(slug)
    }
  }

  const votes: VoteHistoryItem[] = []
  for (const [projectId, entry] of voteMap.entries()) {
    const project = projects.find((p) => p.id === projectId)
    votes.push({ projectId, projectName: project?.name ?? projectId, sentiment: entry.sentiment })
  }
  setVoteHistory(votes)

  if (cancelled) return

  // Fetch review bodies from contract (subgraph doesn't store review text)
  const reviewMeta = gqlReviews.map((r) => ({
    id: `onchain-sg-${r.id}`,
    projectId: r.projectId as `0x${string}`,
    projectName: projects.find((p) => p.id === bytes32ToSlug(r.projectId as `0x${string}`))?.name ?? r.projectId,
    sentiment: enumToSentiment(r.sentiment),
    reviewIndex: BigInt(r.reviewIndex),
  }))

  const bodies = await Promise.all(
    reviewMeta.map((r) =>
      publicClient.readContract({
        address: contractAddress,
        abi: GET_REVIEW_ABI,
        functionName: 'getReview',
        args: [r.projectId, r.reviewIndex],
      }).then((result) => {
        const rv = result as unknown as { body: string }
        return rv.body
      }).catch(() => '')
    )
  )

  if (cancelled) return

  setReviewsPosted(
    reviewMeta.map((r, i) => ({
      id: r.id,
      projectName: r.projectName,
      sentiment: r.sentiment,
      body: bodies[i] ?? '',
    }))
  )
}

// ── RPC fallback path ─────────────────────────────────────────────────────────

interface RpcFetchOptions {
  publicClient: NonNullable<ReturnType<typeof usePublicClient>>
  contractAddress: `0x${string}`
  address: `0x${string}`
  projects: Project[]
  cancelled: boolean
  setVoteHistory: (v: VoteHistoryItem[]) => void
  setReviewsPosted: (r: ReviewHistoryItem[]) => void
}

async function fetchViaRpc({
  publicClient,
  contractAddress,
  address,
  projects,
  cancelled,
  setVoteHistory,
  setReviewsPosted,
}: RpcFetchOptions): Promise<void> {
  // Arc Testnet RPC enforces a 100 000-block limit — use paginated fetching
  const votedLogs = await getPaginatedLogs(publicClient, {
    address: contractAddress,
    event: VOTED_EVENT,
    args: { voter: address },
  })
  const retractedLogs = await getPaginatedLogs(publicClient, {
    address: contractAddress,
    event: VOTE_RETRACTED_EVENT,
    args: { voter: address },
  })
  const reviewLogs = await getPaginatedLogs(publicClient, {
    address: contractAddress,
    event: REVIEW_POSTED_EVENT,
    args: { author: address },
  })

  if (cancelled) return

  // Build live vote map
  const voteMap = new Map<string, { sentiment: Sentiment; blockNum: bigint; logIdx: number }>()
  const sortedVoted = [...votedLogs].sort((a, b) => {
    const d = (a.blockNumber ?? 0n) - (b.blockNumber ?? 0n)
    if (d !== 0n) return Number(d)
    return (a.logIndex ?? 0) - (b.logIndex ?? 0)
  })

  for (const log of sortedVoted) {
    const decoded = safeDecodeVoted(log)
    if (!decoded) continue
    const slug = bytes32ToSlug(decoded.projectId)
    voteMap.set(slug, {
      sentiment: enumToSentiment(decoded.sentiment),
      blockNum: log.blockNumber ?? 0n,
      logIdx: log.logIndex ?? 0,
    })
  }
  for (const log of retractedLogs) {
    const decoded = safeDecodeRetracted(log)
    if (!decoded) continue
    voteMap.delete(bytes32ToSlug(decoded.projectId))
  }

  const votes: VoteHistoryItem[] = []
  for (const [projectId, entry] of voteMap.entries()) {
    const project = projects.find((p) => p.id === projectId)
    votes.push({ projectId, projectName: project?.name ?? projectId, sentiment: entry.sentiment })
  }
  setVoteHistory(votes)

  // Reviews
  const decodedReviews = reviewLogs
    .map((log) => {
      const decoded = safeDecodeReviewPosted(log)
      if (!decoded) return null
      const slug = bytes32ToSlug(decoded.projectId)
      const project = projects.find((p) => p.id === slug)
      return {
        id: `onchain-${log.transactionHash ?? ''}-${decoded.reviewIndex}`,
        projectId: decoded.projectId,
        projectName: project?.name ?? slug,
        sentiment: enumToSentiment(decoded.sentiment),
        reviewIndex: decoded.reviewIndex,
      }
    })
    .filter((r): r is NonNullable<typeof r> => r !== null)

  const bodies = await Promise.all(
    decodedReviews.map((r) =>
      publicClient.readContract({
        address: contractAddress,
        abi: GET_REVIEW_ABI,
        functionName: 'getReview',
        args: [r.projectId, r.reviewIndex],
      }).then((result) => {
        const rv = result as unknown as { body: string }
        return rv.body
      }).catch(() => '')
    )
  )

  if (cancelled) return

  setReviewsPosted(
    decodedReviews.map((r, i) => ({
      id: r.id,
      projectName: r.projectName,
      sentiment: r.sentiment,
      body: bodies[i] ?? '',
    }))
  )
}

// ── Safe log decoders ─────────────────────────────────────────────────────────

function safeDecodeVoted(log: Log): { projectId: `0x${string}`; sentiment: number } | null {
  try {
    const { args } = decodeEventLog({ abi: [VOTED_EVENT], data: log.data, topics: log.topics })
    const a = args
    return { projectId: a.projectId, sentiment: a.sentiment }
  } catch { return null }
}

function safeDecodeRetracted(log: Log): { projectId: `0x${string}` } | null {
  try {
    const { args } = decodeEventLog({ abi: [VOTE_RETRACTED_EVENT], data: log.data, topics: log.topics })
    return { projectId: args.projectId }
  } catch { return null }
}

function safeDecodeReviewPosted(log: Log): { projectId: `0x${string}`; sentiment: number; reviewIndex: bigint } | null {
  try {
    const { args } = decodeEventLog({ abi: [REVIEW_POSTED_EVENT], data: log.data, topics: log.topics })
    const a = args
    return { projectId: a.projectId, sentiment: a.sentiment, reviewIndex: a.reviewIndex }
  } catch { return null }
}


