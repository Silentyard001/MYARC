/**
 * useModeratedReviews
 *
 * Fetches moderation state for all reviews of a given project from the
 * `moderated_reviews` Supabase table.
 *
 * Returns:
 *   hiddenReviewIds   — Set of review ids currently moderated as 'hidden'
 *   moderateReview    — upsert a moderation action for a review
 *   isLoading         — true while fetching
 *   refetch           — manually re-fetch
 */
import { useState, useEffect, useCallback } from 'react'
import { supabase, getAdminClient } from '../lib/supabase'

export interface ModeratedReviewRow {
  id: string
  project_id: string
  review_id: string
  action: 'hidden' | 'restored'
  reason: string | null
  moderator_address: string
  created_at: string
}

interface UseModeratedReviewsOptions {
  projectId: string | null
  connectedAddress: string | undefined
}

interface UseModeratedReviewsReturn {
  hiddenReviewIds: Set<string>
  moderatedRows: ModeratedReviewRow[]
  moderateReview: (reviewId: string, action: 'hidden' | 'restored', reason?: string) => Promise<void>
  isLoading: boolean
  refetch: () => void
}

export function useModeratedReviews({
  projectId,
  connectedAddress,
}: UseModeratedReviewsOptions): UseModeratedReviewsReturn {
  const [rows, setRows] = useState<ModeratedReviewRow[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [tick, setTick] = useState(0)

  const refetch = useCallback(() => setTick((t) => t + 1), [])

  useEffect(() => {
    if (!supabase || !projectId) return
    let cancelled = false

    const load = async () => {
      setIsLoading(true)
      const { data, error } = await supabase!
        .from('moderated_reviews')
        .select('*')
        .eq('project_id', projectId)
      if (cancelled) return
      setRows(!error && data ? (data as ModeratedReviewRow[]) : [])
      setIsLoading(false)
    }

    void load()
    return () => { cancelled = true }
  }, [projectId, tick])

  const hiddenReviewIds = new Set<string>(
    rows.filter((r) => r.action === 'hidden').map((r) => r.review_id)
  )

  const moderateReview = useCallback(async (
    reviewId: string,
    action: 'hidden' | 'restored',
    reason?: string,
  ) => {
    if (!projectId || !connectedAddress) return
    const client = getAdminClient(connectedAddress)
    if (!client) return

    await client.from('moderated_reviews').upsert(
      {
        project_id:        projectId,
        review_id:         reviewId,
        action,
        reason:            reason ?? null,
        moderator_address: connectedAddress.toLowerCase(),
      },
      { onConflict: 'project_id,review_id' }
    )

    refetch()
  }, [projectId, connectedAddress, refetch])

  return { hiddenReviewIds, moderatedRows: rows, moderateReview, isLoading, refetch }
}
