/**
 * useProfileCache
 *
 * Lightweight in-memory cache for public profile lookups.
 * Resolves wallet addresses → UserProfile (or null) and memoises results so
 * the same address is never fetched twice in the same page session.
 *
 * Usage:
 *   const { resolve, getProfile } = useProfileCache()
 *   useEffect(() => { void resolve([addr1, addr2]) }, [addr1, addr2])
 *   const profile = getProfile(addr1)   // null while loading, UserProfile after
 *
 * Architecture note:
 *   The cache lives outside React state (module-level Map) so it survives
 *   unmounts and is shared across all component instances. Individual React
 *   state is used only to trigger re-renders when new entries arrive.
 */

import { useState, useCallback, useEffect, useRef } from 'react'
import { fetchPublicProfile, type UserProfile } from './useProfile'

// ── Module-level cache (shared across all hook instances) ─────────────────────

/** null  = confirmed no profile exists
 *  undefined = not yet fetched (key absent from map)
 */
const profileCache = new Map<string, UserProfile | null>()
/** Set of addresses currently being fetched (prevents duplicate in-flight requests) */
const inflight = new Set<string>()
/** Registered update callbacks — called whenever the cache changes */
const listeners = new Set<() => void>()

function notify() {
  for (const cb of listeners) cb()
}

async function fetchAndCache(address: string): Promise<void> {
  const key = address.toLowerCase()
  if (profileCache.has(key) || inflight.has(key)) return
  inflight.add(key)
  try {
    const profile = await fetchPublicProfile(key)
    profileCache.set(key, profile)
    notify()
  } catch {
    profileCache.set(key, null)
    notify()
  } finally {
    inflight.delete(key)
  }
}

// ── Synchronous cache readers (for use outside React render, e.g. toasts) ────

/** Read the cached label for an address without triggering a fetch.
 *  Returns 'Anonymous User' when not yet cached or no profile found. */
export function getCachedLabel(address: string): string {
  const entry = profileCache.get(address.toLowerCase())
  if (!entry) return 'Anonymous User'
  if (entry.username) return `@${entry.username}`
  if (entry.displayName) return entry.displayName
  return 'Anonymous User'
}

// ── Hook ──────────────────────────────────────────────────────────────────────

export interface UseProfileCacheReturn {
  /** Trigger fetch for a list of wallet addresses. Idempotent — already-cached
   *  addresses are skipped. */
  resolve: (addresses: string[]) => void
  /** Synchronous lookup. Returns undefined while loading, null if confirmed
   *  not found, or a UserProfile when resolved. */
  getProfile: (address: string) => UserProfile | null | undefined
  /** Convenience: returns the display label for an address using MYARC
   *  identity rules:
   *    1. @username if available
   *    2. display name if available
   *    3. "Anonymous User" if profile exists but no public identity
   *  Does NOT expose the wallet address — respects walletVisibility.
   *  Returns undefined while loading. */
  getLabel: (address: string) => string | undefined
  /** Returns the address to show publicly.
   *  walletVisibility === 'public': shortened form (0x83F2…A91C)
   *  walletVisibility === 'hidden': null (do not render)
   *  Profile not yet loaded: undefined */
  getPublicAddress: (address: string) => string | null | undefined
}

export function useProfileCache(): UseProfileCacheReturn {
  const [, setTick] = useState(0)
  const mountedRef = useRef(true)

  useEffect(() => {
    mountedRef.current = true
    const cb = () => { if (mountedRef.current) setTick((t) => t + 1) }
    listeners.add(cb)
    return () => {
      mountedRef.current = false
      listeners.delete(cb)
    }
  }, [])

  const resolve = useCallback((addresses: string[]) => {
    for (const addr of addresses) {
      if (!addr) continue
      void fetchAndCache(addr)
    }
  }, [])

  const getProfile = useCallback(
    (address: string): UserProfile | null | undefined =>
      profileCache.get(address.toLowerCase()),
    []
  )

  const getLabel = useCallback((address: string): string | undefined => {
    const entry = profileCache.get(address.toLowerCase())
    if (entry === undefined) return undefined  // still loading
    if (entry === null) return 'Anonymous User'
    if (entry.username) return `@${entry.username}`
    if (entry.displayName) return entry.displayName
    return 'Anonymous User'
  }, [])

  const getPublicAddress = useCallback(
    (address: string): string | null | undefined => {
      const entry = profileCache.get(address.toLowerCase())
      if (entry === undefined) return undefined  // still loading
      if (entry === null) {
        // No profile → treat as default hidden; do not expose
        return null
      }
      if (entry.walletVisibility === 'public') {
        const a = address
        return a.length > 10 ? `${a.slice(0, 6)}…${a.slice(-4)}` : a
      }
      return null  // hidden
    },
    []
  )

  return { resolve, getProfile, getLabel, getPublicAddress }
}
