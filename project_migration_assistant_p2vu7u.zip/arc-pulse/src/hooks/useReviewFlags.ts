/**
 * useReviewFlags
 *
 * Manages review flags backed by Supabase's `review_flags` table.
 * Falls back to a local-only Map when Supabase is not configured
 * (VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY absent).
 *
 * Returns:
 *   flagCounts    — reviewId → total distinct flagger count
 *   flaggedByMe   — reviewId → whether the connected wallet has flagged it
 *   flagReview    — inserts a flag row + updates state optimistically
 *   isLoading     — true while fetching project flags on mount
 */

import { useState, useEffect, useCallback } from 'react'
import { supabase, type ReviewFlagRow } from '../lib/supabase'

interface UseReviewFlagsOptions {
  projectId: string | null
  connectedAddress: string | undefined
}

interface UseReviewFlagsReturn {
  flagCounts: Record<string, number>
  flaggedByMe: Record<string, boolean>
  flagReview: (reviewId: string) => Promise<void>
  isLoading: boolean
}

export function useReviewFlags({
  projectId,
  connectedAddress,
}: UseReviewFlagsOptions): UseReviewFlagsReturn {
  const [flagCounts,  setFlagCounts]  = useState<Record<string, number>>({})
  const [flaggedByMe, setFlaggedByMe] = useState<Record<string, boolean>>({})
  const [isLoading,   setIsLoading]   = useState(false)

  // ── Fetch all flags for the open project ─────────────────────────────────────
  useEffect(() => {
    if (!projectId) {
      setFlagCounts({})
      setFlaggedByMe({})
      return
    }

    // No Supabase → nothing to fetch; local state stays empty (flags won't
    // persist across devices but the UI still works within a session).
    if (!supabase) return

    let cancelled = false
    setIsLoading(true)

    supabase
      .from('review_flags')
      .select('review_id, flagger_address')
      .eq('project_id', projectId)
      .then(({ data, error }) => {
        if (cancelled || error || !data) {
          if (!cancelled) setIsLoading(false)
          return
        }

        const counts: Record<string, number> = {}
        const mine:   Record<string, boolean> = {}
        const meAddr  = connectedAddress?.toLowerCase()

        for (const row of data as Pick<ReviewFlagRow, 'review_id' | 'flagger_address'>[]) {
          counts[row.review_id] = (counts[row.review_id] ?? 0) + 1
          if (meAddr && row.flagger_address === meAddr) {
            mine[row.review_id] = true
          }
        }

        setFlagCounts(counts)
        setFlaggedByMe(mine)
        setIsLoading(false)
      })

    return () => { cancelled = true }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectId])

  // ── Flag a review ─────────────────────────────────────────────────────────────
  const flagReview = useCallback(async (reviewId: string) => {
    if (!projectId || !connectedAddress) return

    const addr = connectedAddress.toLowerCase()

    // Optimistic update
    setFlagCounts((prev) => ({ ...prev, [reviewId]: (prev[reviewId] ?? 0) + 1 }))
    setFlaggedByMe((prev) => ({ ...prev, [reviewId]: true }))

    if (!supabase) return  // local-only mode — optimistic state is all we have

    const { error } = await supabase.from('review_flags').insert({
      review_id:       reviewId,
      flagger_address: addr,
      project_id:      projectId,
    })

    if (error) {
      // Roll back optimistic update on error (e.g. duplicate-key violation)
      setFlagCounts((prev) => {
        const next = { ...prev }
        if ((next[reviewId] ?? 0) > 0) next[reviewId] -= 1
        return next
      })
      setFlaggedByMe((prev) => {
        const next = { ...prev }
        delete next[reviewId]
        return next
      })
    }
  }, [projectId, connectedAddress])

  return { flagCounts, flaggedByMe, flagReview, isLoading }
}
