/**
 * useSimulatedWrite
 *
 * Wraps wagmi's useWriteContract with a pre-flight simulateContract call so
 * that revert reasons are surfaced as Sonner toasts BEFORE the wallet modal
 * opens. The simulation uses the current public client for the target chain.
 *
 * Usage:
 *   const { simulateAndWrite, isPending, isConfirming, isSuccess, hash } =
 *     useSimulatedWrite()
 *
 *   await simulateAndWrite({ address, abi, functionName, args, chainId })
 *
 * On simulation failure  → toast.error with the decoded revert reason; no wallet modal.
 * On simulation success  → writeContractAsync is called; normal wallet flow.
 */

import { useCallback, useState } from 'react'
import { usePublicClient, useWriteContract, useWaitForTransactionReceipt } from 'wagmi'
import {
  type Abi,
  encodeFunctionData,
  decodeErrorResult,
  BaseError,
  ContractFunctionRevertedError,
} from 'viem'
import { toast } from 'sonner'

export interface SimulateWriteParams {
  address: `0x${string}`
  abi: Abi
  functionName: string
  args: readonly unknown[]
  chainId: number
  /** Optional USDC value to attach (gas token on Arc = USDC native) */
  value?: bigint
}

/** Parse a contract revert into a readable message for the user. */
function parseRevertReason(error: unknown): string {
  if (error instanceof BaseError) {
    const revertErr = error.walk((e) => e instanceof ContractFunctionRevertedError)
    if (revertErr instanceof ContractFunctionRevertedError) {
      const name = revertErr.data?.errorName ?? revertErr.message
      const lower = name.toLowerCase()
      if (lower.includes('emptyprojectid')) return 'Invalid project ID.'
      if (lower.includes('emptyreviewbody')) return 'Review body cannot be empty.'
      if (lower.includes('reviewtoolong')) return 'Review is too long (max 400 chars).'
      if (lower.includes('noactivevote')) return 'You have no active vote to retract.'
      if (lower.includes('signatureexpired')) return 'Signature has expired — please re-sign.'
      if (lower.includes('invalidsignature')) return 'Invalid signature — please try again.'
      if (lower.includes('noncealreadyused')) return 'Nonce already used — please re-sign.'
      return `Transaction would fail: ${name}`
    }
  }

  const msg = error instanceof Error ? error.message : String(error)
  const lower = msg.toLowerCase()

  if (lower.includes('user rejected') || lower.includes('user denied')) return ''
  if (lower.includes('insufficient')) return 'Insufficient USDC balance for gas.'
  if (lower.includes('revert')) {
    const match = msg.match(/reason="([^"]+)"/i) ?? msg.match(/revert reason: ([^\n]+)/i)
    return match ? `Transaction would fail: ${match[1]}` : 'Transaction would revert — check your inputs.'
  }

  return 'Simulation failed — check your inputs and try again.'
}

export function useSimulatedWrite() {
  const publicClient = usePublicClient()
  const { writeContractAsync, isPending, data: hash } = useWriteContract()
  const { isLoading: isConfirming, isSuccess } =
    useWaitForTransactionReceipt({ hash })

  const [isSimulating, setIsSimulating] = useState(false)

  const simulateAndWrite = useCallback(
    async (params: SimulateWriteParams): Promise<`0x${string}` | null> => {
      if (!publicClient) {
        toast.error('No RPC connection — please try again shortly.')
        return null
      }

      // Encode the call so we can use eth_call for simulation
      // This avoids viem's strict overloaded-generic type constraints while
      // still giving us full revert decoding via BaseError / ContractFunctionRevertedError.
      const data = encodeFunctionData({
        abi: params.abi,
        functionName: params.functionName,
        args: params.args,
      })

      setIsSimulating(true)
      try {
        await publicClient.call({
          to: params.address,
          data,
          value: params.value,
        })
      } catch (err) {
        // Attempt to decode a known ABI error from the raw return data
        if (err instanceof BaseError) {
          const rawErr = err.walk(
            (e): e is BaseError & { data: `0x${string}` } =>
              e instanceof BaseError && typeof (e as { data?: unknown }).data === 'string'
          )
          if (rawErr) {
            try {
              const decoded = decodeErrorResult({ abi: params.abi, data: (rawErr as unknown as { data: `0x${string}` }).data })
              const lower = decoded.errorName.toLowerCase()
              const readableMap: Record<string, string> = {
                emptyprojectid: 'Invalid project ID.',
                emptyreviewbody: 'Review body cannot be empty.',
                reviewtoolong: 'Review is too long (max 400 chars).',
                noactivevote: 'You have no active vote to retract.',
                signatureexpired: 'Signature expired — please re-sign.',
                invalidsignature: 'Invalid signature — please try again.',
                noncealreadyused: 'Nonce already used — please re-sign.',
              }
              const readable = readableMap[lower] ?? `Transaction would fail: ${decoded.errorName}`
              toast.error(readable)
              setIsSimulating(false)
              return null
            } catch {
              // Fallthrough to generic handler
            }
          }
        }

        const msg = parseRevertReason(err)
        if (msg) toast.error(msg)
        setIsSimulating(false)
        return null
      } finally {
        setIsSimulating(false)
      }

      // Simulation passed — open the wallet modal
      try {
        const txHash = await writeContractAsync({
          address: params.address,
          abi: params.abi,
          functionName: params.functionName,
          args: params.args,
          value: params.value,
        })
        return txHash
      } catch (err) {
        const msg = parseRevertReason(err)
        if (msg) toast.error(msg)
        return null
      }
    },
    [publicClient, writeContractAsync]
  )

  return {
    simulateAndWrite,
    isSimulating,
    isPending: isSimulating || isPending,
    isConfirming,
    isSuccess,
    hash,
  }
}
