/**
 * useReviewUpvotes
 *
 * Batch-fetches getReviewUpvoteStats(projectId, index) for every review index
 * in a project via Promise.all of publicClient.readContract calls.
 * Reads directly from contract storage — no subgraph required.
 *
 * Returns:
 *   upvoteStats: Record<number, { count: number; totalWeight: bigint }>
 *   refetch():   re-runs all reads on demand (call after a confirmed upvote)
 */

import { useState, useEffect, useCallback, useRef } from 'react'
import { usePublicClient } from 'wagmi'
import { parseAbi } from 'viem'
import { slugToBytes32 } from '../utils/projectId'
import { ARC_TESTNET_CHAIN_ID } from '../config'

const UPVOTE_ABI = parseAbi([
  'function getReviewUpvoteStats(bytes32 projectId, uint256 reviewIndex) view returns (uint256 count, uint256 totalWeight)',
])

export interface ReviewUpvoteStat {
  count: number
  totalWeight: bigint
}

export function useReviewUpvotes(
  projectId: string | null,
  contractAddress: `0x${string}` | undefined,
  reviewCount: number,
) {
  const publicClient = usePublicClient({ chainId: ARC_TESTNET_CHAIN_ID })
  const [upvoteStats, setUpvoteStats] = useState<Record<number, ReviewUpvoteStat>>({})
  const mountedRef = useRef(true)

  const refetch = useCallback(async () => {
    if (!contractAddress || !publicClient || reviewCount === 0 || !projectId) return

    const projectIdBytes32 = slugToBytes32(projectId)

    const results = await Promise.all(
      Array.from({ length: reviewCount }, (_, i) =>
        publicClient.readContract({
          address: contractAddress,
          abi: UPVOTE_ABI,
          functionName: 'getReviewUpvoteStats',
          args: [projectIdBytes32, BigInt(i)],
        })
      )
    ).catch(() => null)

    if (!mountedRef.current || !results) return

    const stats: Record<number, ReviewUpvoteStat> = {}
    results.forEach(([count, totalWeight], i) => {
      stats[i] = { count: Number(count), totalWeight }
    })
    setUpvoteStats(stats)
  }, [projectId, contractAddress, reviewCount, publicClient])

  useEffect(() => {
    mountedRef.current = true
    void refetch()
    return () => { mountedRef.current = false }
  }, [refetch])

  return { upvoteStats, refetch }
}
