/**
 * useSubmittedProjects
 *
 * Fetches approved submitted projects from Supabase `submitted_projects` table
 * and maps them to the Project type. Falls back to an empty array when Supabase
 * is absent or the table has no approved rows.
 */
import { useState, useEffect, useCallback } from 'react'
import { supabase } from '../lib/supabase'
import type { Project, Tag } from '../data/projects'

interface SubmittedProjectRow {
  id: string
  name: string
  tagline: string
  description: string
  tags: Tag[]
  logo_initials: string
  logo_color: string
  launch_date: string
  website: string | null
  tvl: string | null
  submitter_address: string
  approved: boolean
}

export interface UseSubmittedProjectsResult {
  submittedProjects: Project[]
  isLoading: boolean
  refetch: () => void
}

export function useSubmittedProjects(): UseSubmittedProjectsResult {
  const [submittedProjects, setSubmittedProjects] = useState<Project[]>([])
  const [isLoading, setIsLoading] = useState(Boolean(supabase))
  const [refetchTick, setRefetchTick] = useState(0)

  const refetch = useCallback(() => setRefetchTick((t) => t + 1), [])

  useEffect(() => {
    if (!supabase) return

    let cancelled = false

    const run = async () => {
      try {
        const { data, error } = await supabase!
          .from('submitted_projects')
          .select('id, name, tagline, description, tags, logo_initials, logo_color, launch_date, website, tvl, submitter_address, approved')
          .eq('approved', true)
          .order('created_at', { ascending: false })

        if (cancelled) return
        if (error || !data) {
          setIsLoading(false)
          return
        }

        const mapped: Project[] = (data as SubmittedProjectRow[]).map((row) => ({
          id: row.id,
          name: row.name,
          tagline: row.tagline,
          description: row.description,
          tags: row.tags,
          logoInitials: row.logo_initials,
          logoColor: row.logo_color,
          votes: { bullish: 0, neutral: 0, bearish: 0 },
          reviews: [],
          launchDate: row.launch_date,
          website: row.website ?? undefined,
          tvl: row.tvl ?? undefined,
        }))

        if (!cancelled) {
          setSubmittedProjects(mapped)
          setIsLoading(false)
        }
      } catch {
        if (!cancelled) setIsLoading(false)
      }
    }

    void run()
    return () => { cancelled = true }
  }, [refetchTick])

  return { submittedProjects, isLoading, refetch }
}
