/**
 * useMilestones — derives community milestones from a MomentumResult and
 * tracks which ones are newly achieved since the last visit using localStorage.
 *
 * Consumes the canonical momentum library exclusively — no independent metric
 * calculation is performed here.
 */
import { useMemo, useEffect } from 'react'
import { computeMilestones, achievedMilestones } from '../lib/momentum'
import type { MomentumResult, Milestone } from '../lib/momentum'

const STORAGE_KEY_PREFIX = 'myarc:milestones-seen:'

export interface UseMilestonesReturn {
  /** All milestones (achieved and pending) for display with progress. */
  all: Milestone[]
  /** Only achieved milestones, sorted category → threshold. */
  achieved: Milestone[]
  /**
   * Milestones that were achieved now but whose id was NOT in the last-seen
   * set stored in localStorage. These are "new" since the user last visited
   * this project's milestone list.
   */
  newlyAchieved: Milestone[]
  /** Call this when the user opens the milestone panel to mark all as seen. */
  markAllSeen: () => void
  /** Total achieved count. */
  achievedCount: number
  /** Count of new (unseen) achieved milestones. */
  newCount: number
}

/**
 * @param projectSlug  - Human-readable project slug
 * @param result       - MomentumResult from usePlatformMomentum / useProjectMomentum
 *                       Pass null when momentum data is not yet available.
 */
export function useMilestones(
  projectSlug: string | null | undefined,
  result: MomentumResult | null | undefined,
): UseMilestonesReturn {
  const storageKey = projectSlug ? `${STORAGE_KEY_PREFIX}${projectSlug}` : null

  const { all, achieved } = useMemo(() => {
    if (!result) return { all: [], achieved: [] }
    const allMs = computeMilestones(result.signals, result.momentumIndex)
    const achMs = achievedMilestones(result.signals, result.momentumIndex)
    return { all: allMs, achieved: achMs }
  }, [result])

  // Load the set of milestone ids the user has already seen
  const seenIds = useMemo<Set<string>>(() => {
    if (!storageKey) return new Set()
    try {
      const raw = localStorage.getItem(storageKey)
      if (!raw) return new Set()
      return new Set(JSON.parse(raw) as string[])
    } catch {
      return new Set()
    }
  }, [storageKey])

  const newlyAchieved = useMemo(
    () => achieved.filter((m) => !seenIds.has(m.id)),
    [achieved, seenIds],
  )

  // Persist newly achieved milestones so they won't show as "new" again
  // (without requiring the user to explicitly open the panel)
  useEffect(() => {
    if (!storageKey || achieved.length === 0) return
    try {
      const existing = JSON.parse(localStorage.getItem(storageKey) ?? '[]') as string[]
      const merged = Array.from(new Set([...existing, ...achieved.map((m) => m.id)]))
      localStorage.setItem(storageKey, JSON.stringify(merged))
    } catch {
      // localStorage unavailable — degrade gracefully
    }
  }, [storageKey, achieved])

  const markAllSeen = useMemo(() => () => {
    if (!storageKey) return
    try {
      const ids = achieved.map((m) => m.id)
      const existing = JSON.parse(localStorage.getItem(storageKey) ?? '[]') as string[]
      const merged = Array.from(new Set([...existing, ...ids]))
      localStorage.setItem(storageKey, JSON.stringify(merged))
    } catch {
      // degrade gracefully
    }
  }, [storageKey, achieved])

  return {
    all,
    achieved,
    newlyAchieved,
    markAllSeen,
    achievedCount: achieved.length,
    newCount: newlyAchieved.length,
  }
}
