/**
 * useReviewResponses
 *
 * Fetches project-owner responses to reviews from the Supabase
 * `review_responses` table. Exposes `responses: Record<string, ReviewResponse[]>`
 * (reviewId → array of responses) and `postResponse(reviewId, body)`.
 *
 * Table schema:
 *   id                 uuid PK default gen_random_uuid()
 *   project_id         text not null
 *   review_id          text not null
 *   responder_address  text not null
 *   body               text not null
 *   created_at         timestamptz default now()
 *
 * RLS: anon SELECT open; INSERT restricted to owner address header.
 */
import { useState, useEffect, useCallback } from 'react'
import { supabase, getAdminClient } from '../lib/supabase'

export interface ReviewResponse {
  id: string
  reviewId: string
  responderAddress: string
  body: string
  createdAt: number // ms timestamp
}

interface UseReviewResponsesParams {
  projectId: string | null
  responderAddress?: string
}

export interface UseReviewResponsesResult {
  responses: Record<string, ReviewResponse[]>
  postResponse: (reviewId: string, body: string) => Promise<void>
  isLoading: boolean
}

export function useReviewResponses({
  projectId,
  responderAddress,
}: UseReviewResponsesParams): UseReviewResponsesResult {
  const [responses, setResponses] = useState<Record<string, ReviewResponse[]>>({})
  const [isLoading, setIsLoading] = useState(Boolean(supabase && projectId))

  useEffect(() => {
    if (!supabase || !projectId) return
    let cancelled = false

    supabase
      .from('review_responses')
      .select('id, review_id, responder_address, body, created_at')
      .eq('project_id', projectId)
      .order('created_at', { ascending: true })
      .then(({ data }) => {
        if (cancelled) return
        const map: Record<string, ReviewResponse[]> = {}
        for (const row of (data ?? []) as {
          id: string
          review_id: string
          responder_address: string
          body: string
          created_at: string
        }[]) {
          const entry: ReviewResponse = {
            id: row.id,
            reviewId: row.review_id,
            responderAddress: row.responder_address,
            body: row.body,
            createdAt: new Date(row.created_at).getTime(),
          }
          if (!map[row.review_id]) map[row.review_id] = []
          map[row.review_id].push(entry)
        }
        setResponses(map)
        setIsLoading(false)
      }, () => {
        if (!cancelled) setIsLoading(false)
      })

    return () => { cancelled = true }
  }, [projectId])

  const postResponse = useCallback(async (reviewId: string, body: string) => {
    if (!projectId || !responderAddress || !body.trim()) return

    const optimistic: ReviewResponse = {
      id: `optimistic-${Date.now()}`,
      reviewId,
      responderAddress,
      body: body.trim(),
      createdAt: Date.now(),
    }

    // Optimistic update
    setResponses((prev) => ({
      ...prev,
      [reviewId]: [...(prev[reviewId] ?? []), optimistic],
    }))

    const client = getAdminClient(responderAddress)
    if (!client) return

    const { data, error } = await client
      .from('review_responses')
      .insert({
        project_id: projectId,
        review_id: reviewId,
        responder_address: responderAddress,
        body: body.trim(),
      })
      .select('id, review_id, responder_address, body, created_at')
      .single()

    if (!error && data) {
      // Replace optimistic entry with confirmed one
      const confirmed: ReviewResponse = {
        id: (data as { id: string }).id,
        reviewId: (data as { review_id: string }).review_id,
        responderAddress: (data as { responder_address: string }).responder_address,
        body: (data as { body: string }).body,
        createdAt: new Date((data as { created_at: string }).created_at).getTime(),
      }
      setResponses((prev) => ({
        ...prev,
        [reviewId]: [
          ...(prev[reviewId] ?? []).filter((r) => r.id !== optimistic.id),
          confirmed,
        ],
      }))
    }
  }, [projectId, responderAddress])

  return { responses, postResponse, isLoading }
}
