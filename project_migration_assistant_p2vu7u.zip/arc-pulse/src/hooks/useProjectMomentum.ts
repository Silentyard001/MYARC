/**
 * useProjectMomentum
 *
 * Computes the Momentum Index and component signals for a single project by
 * reusing the event-fetch infrastructure from useProjectAnalytics — no new
 * network calls are made beyond what that hook already does.
 *
 * Data flow:
 *   1. Fetch Voted + VoteRetracted + ReviewPosted events via getPaginatedLogs
 *      (subgraph path when available, RPC fallback otherwise) — same logic as
 *      useProjectAnalytics, consolidated into one fetch per project.
 *   2. ReviewUpvoted events are fetched additionally for boost signals.
 *   3. All events are passed to computeProjectMomentum() from src/lib/momentum.ts.
 *
 * Returns MomentumResult (with isLoading / error / refetch) so that any UI
 * can render the Momentum Index and its component explainers.
 */

import { useState, useEffect, useCallback } from 'react'
import { usePublicClient } from 'wagmi'
import { parseAbiItem, decodeEventLog, type Log } from 'viem'
import { ARC_TESTNET_CHAIN_ID } from '../config'
import { slugToBytes32, bytes32ToSlug } from '../utils/projectId'
import { getPaginatedLogs } from '../utils/getLogs'
import {
  computeProjectMomentum,
  type MomentumResult,
  type VoteEvent,
  type RetractEvent,
  type ReviewEvent,
  type BoostEvent,
} from '../lib/momentum'
import {
  querySubgraph,
  SubgraphUnavailableError,
  ANALYTICS_BY_PROJECT_QUERY,
  type GqlVote,
  type GqlVoteRetraction,
  type GqlReview,
} from '../lib/graphql'

// ── Event ABIs ────────────────────────────────────────────────────────────────

const VOTED_EVENT = parseAbiItem(
  'event Voted(bytes32 indexed projectId, address indexed voter, uint8 sentiment, bool isChange)'
)
const VOTE_RETRACTED_EVENT = parseAbiItem(
  'event VoteRetracted(bytes32 indexed projectId, address indexed voter)'
)
const REVIEW_POSTED_EVENT = parseAbiItem(
  'event ReviewPosted(bytes32 indexed projectId, address indexed author, uint8 sentiment, uint256 reviewIndex)'
)
const REVIEW_UPVOTED_EVENT = parseAbiItem(
  'event ReviewUpvoted(bytes32 indexed projectId, uint256 indexed reviewIndex, address indexed upvoter, address author, uint256 totalAmount, uint256 protocolFee)'
)

// ── Return type ───────────────────────────────────────────────────────────────

export interface UseProjectMomentumReturn {
  momentum: MomentumResult | null
  isLoading: boolean
  error: string | null
  refetch: () => void
}

const SUBGRAPH_PAGE_SIZE = 1000

// ── Hook ──────────────────────────────────────────────────────────────────────

export function useProjectMomentum(
  projectSlug: string | null,
  contractAddress: `0x${string}` | undefined,
): UseProjectMomentumReturn {
  const publicClient = usePublicClient({ chainId: ARC_TESTNET_CHAIN_ID })
  const [momentum, setMomentum] = useState<MomentumResult | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [refetchTick, setRefetchTick] = useState(0)
  const refetch = useCallback(() => setRefetchTick((t) => t + 1), [])

  useEffect(() => {
    if (!projectSlug || !contractAddress || !publicClient) return

    let cancelled = false
    setIsLoading(true)
    setError(null)

    const projectId32 = slugToBytes32(projectSlug)

    async function run() {
      if (!publicClient || !contractAddress) return

      try {
        const now = Date.now()

        // ── Try subgraph first (votes + retractions + reviews) ────────────────
        let gqlVotes: GqlVote[] | null = null
        let gqlRetractions: GqlVoteRetraction[] | null = null
        let gqlReviews: GqlReview[] | null = null

        try {
          const data = await querySubgraph<{
            votes: GqlVote[]
            voteRetractions: GqlVoteRetraction[]
            reviews: GqlReview[]
          }>(ANALYTICS_BY_PROJECT_QUERY, {
            projectId: projectId32.toLowerCase(),
            first: SUBGRAPH_PAGE_SIZE,
          })
          gqlVotes = data.votes
          gqlRetractions = data.voteRetractions
          gqlReviews = data.reviews
        } catch (err) {
          if (!(err instanceof SubgraphUnavailableError)) {
            console.warn('[useProjectMomentum] subgraph failed, falling back to RPC:', err)
          }
        }

        if (cancelled) return

        let votes: VoteEvent[]
        let retracts: RetractEvent[]
        let reviews: ReviewEvent[]

        if (gqlVotes !== null && gqlRetractions !== null && gqlReviews !== null) {
          // ── Subgraph path ─────────────────────────────────────────────────
          const slug = projectSlug!
          votes = gqlVotes.map((v) => ({
            voter: v.voter.toLowerCase(),
            sentiment: v.sentiment,
            ts: Number(v.timestamp) * 1000,
            projectSlug: slug,
          }))
          retracts = gqlRetractions.map((r) => ({
            voter: r.voter.toLowerCase(),
            ts: Number(r.timestamp) * 1000,
            projectSlug: slug,
          }))
          reviews = gqlReviews.map((r) => ({
            author: r.author.toLowerCase(),
            ts: Number(r.timestamp) * 1000,
            projectSlug: slug,
          }))
        } else {
          // ── RPC fallback path ─────────────────────────────────────────────
          const [votedLogs, retractedLogs, reviewLogs] = await Promise.all([
            getPaginatedLogs(publicClient, {
              address: contractAddress,
              event: VOTED_EVENT,
              args: { projectId: projectId32 },
            }),
            getPaginatedLogs(publicClient, {
              address: contractAddress,
              event: VOTE_RETRACTED_EVENT,
              args: { projectId: projectId32 },
            }),
            getPaginatedLogs(publicClient, {
              address: contractAddress,
              event: REVIEW_POSTED_EVENT,
              args: { projectId: projectId32 },
            }),
          ])

          if (cancelled) return

          // Batch-fetch unique block timestamps
          const blockSet = new Set<bigint>()
          for (const log of [...votedLogs, ...retractedLogs, ...reviewLogs]) {
            if (log.blockNumber) blockSet.add(log.blockNumber)
          }
          const blockTs = new Map<bigint, number>()
          if (blockSet.size > 0) {
            const results = await Promise.all(
              Array.from(blockSet).map((bn) =>
                publicClient.getBlock({ blockNumber: bn })
                  .then((b) => ({ bn, ts: Number(b.timestamp) * 1000 }))
                  .catch(() => ({ bn, ts: 0 }))
              )
            )
            for (const { bn, ts } of results) blockTs.set(bn, ts)
          }

          if (cancelled) return

          const logTs = (log: Log): number =>
            log.blockNumber ? (blockTs.get(log.blockNumber) ?? 0) : 0

          const rpcSlug = projectSlug!
          votes = votedLogs
            .map((log) => {
              try {
                const { args } = decodeEventLog({ abi: [VOTED_EVENT], data: log.data, topics: log.topics })
                const a = args as { voter: `0x${string}`; sentiment: number }
                return { voter: a.voter.toLowerCase(), sentiment: a.sentiment, ts: logTs(log), projectSlug: rpcSlug }
              } catch { return null }
            })
            .filter((v): v is NonNullable<typeof v> => v !== null)

          retracts = retractedLogs
            .map((log) => {
              try {
                const { args } = decodeEventLog({ abi: [VOTE_RETRACTED_EVENT], data: log.data, topics: log.topics })
                const a = args as { voter: `0x${string}` }
                return { voter: a.voter.toLowerCase(), ts: logTs(log), projectSlug: rpcSlug }
              } catch { return null }
            })
            .filter((v): v is NonNullable<typeof v> => v !== null)

          reviews = reviewLogs
            .map((log) => {
              try {
                const { args } = decodeEventLog({ abi: [REVIEW_POSTED_EVENT], data: log.data, topics: log.topics })
                const a = args as { author: `0x${string}` }
                return { author: a.author.toLowerCase(), ts: logTs(log), projectSlug: rpcSlug }
              } catch { return null }
            })
            .filter((r): r is NonNullable<typeof r> => r !== null)
        }

        // ── ReviewUpvoted events (always via RPC — not in subgraph yet) ───────
        const boostLogs = await getPaginatedLogs(publicClient, {
          address: contractAddress,
          event: REVIEW_UPVOTED_EVENT,
          args: { projectId: projectId32 },
        }).catch(() => [])

        if (cancelled) return

        // Fetch block timestamps for boost logs (reuse existing map where possible)
        const boostBlockSet = new Set<bigint>()
        for (const log of boostLogs) {
          if (log.blockNumber) boostBlockSet.add(log.blockNumber)
        }
        const boostBlockTs = new Map<bigint, number>()
        if (boostBlockSet.size > 0) {
          const results = await Promise.all(
            Array.from(boostBlockSet).map((bn) =>
              publicClient.getBlock({ blockNumber: bn })
                .then((b) => ({ bn, ts: Number(b.timestamp) * 1000 }))
                .catch(() => ({ bn, ts: 0 }))
            )
          )
          for (const { bn, ts } of results) boostBlockTs.set(bn, ts)
        }

        const boostLogTs = (log: Log): number =>
          log.blockNumber ? (boostBlockTs.get(log.blockNumber) ?? 0) : 0

        const boosts: BoostEvent[] = boostLogs
          .map((log) => {
            try {
              const { args } = decodeEventLog({ abi: [REVIEW_UPVOTED_EVENT], data: log.data, topics: log.topics })
              const a = args as { upvoter: `0x${string}`; totalAmount: bigint; protocolFee: bigint; projectId: `0x${string}` }
              const authorAmount = a.totalAmount - a.protocolFee
              return {
                upvoter: a.upvoter.toLowerCase(),
                ts: boostLogTs(log),
                projectSlug: bytes32ToSlug(a.projectId),
                authorAmount,
              }
            } catch { return null }
          })
          .filter((b): b is NonNullable<typeof b> => b !== null)

        if (cancelled) return

        const result = computeProjectMomentum(projectSlug!, votes, retracts, reviews, boosts, now)
        if (!cancelled) {
          setMomentum(result)
          setIsLoading(false)
        }
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : 'Failed to compute momentum')
          setIsLoading(false)
        }
      }
    }

    void run()
    return () => { cancelled = true }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectSlug, contractAddress, refetchTick])

  return { momentum, isLoading, error, refetch }
}
