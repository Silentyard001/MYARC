/**
 * useUserActivity
 *
 * Derives the connected wallet's activity directly from the App's live state:
 * - Vote history: all projects the wallet has voted on this session
 * - Reviews posted: reviews where authorFull matches the connected address
 * - Poll vote history: polls the wallet has voted in this session
 *
 * This is a pure derivation hook — no separate state needed.
 * In production, this would be hydrated from indexed on-chain events.
 */

import { useMemo } from 'react'
import type { Project, Poll, Sentiment } from '../data/projects'

export interface VoteHistoryItem {
  projectId: string
  projectName: string
  sentiment: Sentiment
}

export interface ReviewHistoryItem {
  id: string
  projectName: string
  sentiment: Sentiment
  body: string
}

export interface PollVoteHistoryItem {
  pollId: string
  question: string
  chosenLabel: string
}

export interface UseUserActivityReturn {
  voteHistory: VoteHistoryItem[]
  reviewsPosted: ReviewHistoryItem[]
  pollVoteHistory: PollVoteHistoryItem[]
  totalVotesCast: number
  totalReviewsPosted: number
}

interface UseUserActivityParams {
  address: `0x${string}` | undefined
  projects: Project[]
  polls: Poll[]
  userVotes: Record<string, Sentiment>
  pollVotes: Record<string, string>
}

export function useUserActivity({
  address,
  projects,
  polls,
  userVotes,
  pollVotes,
}: UseUserActivityParams): UseUserActivityReturn {
  const voteHistory = useMemo<VoteHistoryItem[]>(() => {
    return Object.entries(userVotes).map(([projectId, sentiment]) => {
      const project = projects.find((p) => p.id === projectId)
      return {
        projectId,
        projectName: project?.name ?? projectId,
        sentiment,
      }
    })
  }, [userVotes, projects])

  const reviewsPosted = useMemo<ReviewHistoryItem[]>(() => {
    if (!address) return []
    const result: ReviewHistoryItem[] = []
    for (const project of projects) {
      for (const review of project.reviews) {
        if (review.authorFull.toLowerCase() === address.toLowerCase()) {
          result.push({
            id: review.id,
            projectName: project.name,
            sentiment: review.sentiment,
            body: review.body,
          })
        }
      }
    }
    return result
  }, [address, projects])

  const pollVoteHistory = useMemo<PollVoteHistoryItem[]>(() => {
    return Object.entries(pollVotes).map(([pollId, optionId]) => {
      const poll = polls.find((p) => p.id === pollId)
      const option = poll?.options.find((o) => o.id === optionId)
      return {
        pollId,
        question: poll?.question ?? pollId,
        chosenLabel: option?.label ?? optionId,
      }
    })
  }, [pollVotes, polls])

  return {
    voteHistory,
    reviewsPosted,
    pollVoteHistory,
    totalVotesCast: voteHistory.length,
    totalReviewsPosted: reviewsPosted.length,
  }
}
