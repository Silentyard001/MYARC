/**
 * useLocalStorage
 *
 * A type-safe useState wrapper that syncs a value to localStorage.
 * - Reads the stored value on mount (SSR-safe: reads lazily in initializer).
 * - Writes to localStorage on every state change.
 * - Falls back to `initialValue` silently if localStorage is unavailable
 *   (private mode, quota exceeded, etc.).
 */

import { useState, useEffect, useCallback } from 'react'

function readStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key)
    if (raw === null) return fallback
    return JSON.parse(raw) as T
  } catch {
    return fallback
  }
}

function writeStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value))
  } catch {
    // quota exceeded or private mode — fail silently
  }
}

export function useLocalStorage<T>(
  key: string,
  initialValue: T
): [T, (value: T | ((prev: T) => T)) => void] {
  // Lazy initializer so we only read localStorage once on mount
  const [state, setStateRaw] = useState<T>(() => readStorage(key, initialValue))

  // Write to localStorage whenever state changes
  useEffect(() => {
    writeStorage(key, state)
  }, [key, state])

  // Re-read from storage if the key changes (e.g. per-wallet key)
  useEffect(() => {
    setStateRaw(readStorage(key, initialValue))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key])

  const setState = useCallback(
    (value: T | ((prev: T) => T)) => {
      setStateRaw((prev) => {
        const next = typeof value === 'function' ? (value as (p: T) => T)(prev) : value
        writeStorage(key, next)
        return next
      })
    },
    [key]
  )

  return [state, setState]
}
