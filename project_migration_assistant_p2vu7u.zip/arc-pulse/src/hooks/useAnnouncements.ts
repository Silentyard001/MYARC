/**
 * useAnnouncements
 *
 * Fetches active, non-expired announcements from Supabase `announcements` table.
 * Returns them newest-first. Falls back to empty array when Supabase is absent.
 */
import { useState, useEffect, useCallback } from 'react'
import { supabase } from '../lib/supabase'

export type AnnouncementType = 'info' | 'warning' | 'success'

export interface Announcement {
  id: string
  message: string
  type: AnnouncementType
  active: boolean
  expires_at: string | null
  created_at: string
}

interface UseAnnouncementsReturn {
  announcements: Announcement[]
  allAnnouncements: Announcement[]  // all including inactive — for admin panel
  isLoading: boolean
  refetch: () => void
}

export function useAnnouncements(): UseAnnouncementsReturn {
  const [announcements, setAnnouncements] = useState<Announcement[]>([])
  const [allAnnouncements, setAllAnnouncements] = useState<Announcement[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [tick, setTick] = useState(0)

  const refetch = useCallback(() => setTick((t) => t + 1), [])

  useEffect(() => {
    if (!supabase) return
    let cancelled = false

    const load = async () => {
      setIsLoading(true)
      const { data, error } = await supabase!
        .from('announcements')
        .select('*')
        .order('created_at', { ascending: false })
      if (cancelled) return
      if (!error && data) {
        const all = data as Announcement[]
        setAllAnnouncements(all)
        const now = new Date()
        const active = all.filter((a) =>
          a.active && (a.expires_at === null || new Date(a.expires_at) > now)
        )
        setAnnouncements(active)
      }
      setIsLoading(false)
    }

    void load()
    return () => { cancelled = true }
  }, [tick])

  return { announcements, allAnnouncements, isLoading, refetch }
}
