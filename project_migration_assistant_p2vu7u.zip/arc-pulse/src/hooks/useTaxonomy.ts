/**
 * useTaxonomy
 *
 * Single source of truth for taxonomy state.
 * Merges DEFAULT_CATEGORIES / DEFAULT_USE_CASES / DEFAULT_TAGS with admin
 * overrides persisted in localStorage (same pattern as useAdminConfig).
 *
 * Admin writes mutate the overlay; defaults are never overwritten.
 */
import { useMemo } from 'react'
import {
  DEFAULT_CATEGORIES, DEFAULT_USE_CASES, DEFAULT_TAGS, normalizeTag,
  type Category, type UseCase, type CanonicalTag,
} from '../data/taxonomy'
import { useLocalStorage } from './useLocalStorage'

export type TaxonomyOverlay = {
  categories?: Partial<Category>[]
  useCases?: Partial<UseCase>[]
  tags?: Partial<CanonicalTag>[]
}

export type TaxonomyResult = {
  categories: Category[]
  activeCategories: Category[]
  useCases: UseCase[]
  activeUseCases: UseCase[]
  tags: CanonicalTag[]
  activeTags: CanonicalTag[]
  /** Resolve a raw string to a canonical tag id (checks aliases). */
  resolveTag: (raw: string) => string | undefined
  /** Look up a category by id. */
  getCategory: (id: string) => Category | undefined
  /** Look up a use case by id. */
  getUseCase: (id: string) => UseCase | undefined
  /** Look up a canonical tag by id. */
  getTag: (id: string) => CanonicalTag | undefined
  /** Persist admin edits back to localStorage. */
  saveCategories: (cats: Category[]) => void
  saveUseCases: (ucs: UseCase[]) => void
  saveTags: (tags: CanonicalTag[]) => void
}

function mergeById<T extends { id: string }>(defaults: T[], overrides: Partial<T>[]): T[] {
  const map = new Map<string, T>(defaults.map((d) => [d.id, { ...d }]))
  for (const o of overrides) {
    if (!o.id) continue
    const existing = map.get(o.id)
    if (existing) {
      map.set(o.id, { ...existing, ...o })
    } else {
      // Admin-created entity (not in defaults)
      map.set(o.id, o as T)
    }
  }
  return Array.from(map.values()).sort((a, b) => {
    const ao = (a as { order?: number }).order ?? 999
    const bo = (b as { order?: number }).order ?? 999
    return ao - bo
  })
}

export function useTaxonomy(): TaxonomyResult {
  const [catOverrides, setCatOverrides] = useLocalStorage<Partial<Category>[]>('myarc:taxonomy:categories', [])
  const [ucOverrides, setUcOverrides] = useLocalStorage<Partial<UseCase>[]>('myarc:taxonomy:use-cases', [])
  const [tagOverrides, setTagOverrides] = useLocalStorage<Partial<CanonicalTag>[]>('myarc:taxonomy:tags', [])

  const categories = useMemo(() => mergeById(DEFAULT_CATEGORIES, catOverrides), [catOverrides])
  const useCases   = useMemo(() => mergeById(DEFAULT_USE_CASES, ucOverrides),   [ucOverrides])
  const tags       = useMemo(() => mergeById(DEFAULT_TAGS, tagOverrides),        [tagOverrides])

  const activeCategories = useMemo(() => categories.filter((c) => c.active), [categories])
  const activeUseCases   = useMemo(() => useCases.filter((u) => u.active),   [useCases])
  const activeTags       = useMemo(() => tags.filter((t) => t.active),       [tags])

  const getCategory = useMemo(() => (id: string) => categories.find((c) => c.id === id), [categories])
  const getUseCase  = useMemo(() => (id: string) => useCases.find((u) => u.id === id),   [useCases])
  const getTag      = useMemo(() => (id: string) => tags.find((t) => t.id === id),       [tags])
  const resolveTag  = useMemo(() => (raw: string) => normalizeTag(raw, tags),             [tags])

  const saveCategories = (cats: Category[]) => {
    // Store only the delta from defaults
    const overlay = cats.map((c) => {
      const def = DEFAULT_CATEGORIES.find((d) => d.id === c.id)
      if (!def) return c // admin-created
      // Only store fields that differ
      const delta: Partial<Category> = { id: c.id }
      if (c.label  !== def.label)  delta.label  = c.label
      if (c.active !== def.active) delta.active = c.active
      if (c.order  !== def.order)  delta.order  = c.order
      return delta
    })
    setCatOverrides(overlay)
  }

  const saveUseCases = (ucs: UseCase[]) => {
    const overlay = ucs.map((u) => {
      const def = DEFAULT_USE_CASES.find((d) => d.id === u.id)
      if (!def) return u
      const delta: Partial<UseCase> = { id: u.id }
      if (u.label  !== def.label)  delta.label  = u.label
      if (u.active !== def.active) delta.active = u.active
      if (u.order  !== def.order)  delta.order  = u.order
      if (u.group  !== def.group)  delta.group  = u.group
      return delta
    })
    setUcOverrides(overlay)
  }

  const saveTags = (newTags: CanonicalTag[]) => {
    const overlay = newTags.map((t) => {
      const def = DEFAULT_TAGS.find((d) => d.id === t.id)
      if (!def) return t
      const delta: Partial<CanonicalTag> = { id: t.id }
      if (t.label  !== def.label)   delta.label   = t.label
      if (t.active !== def.active)  delta.active  = t.active
      if (t.order  !== def.order)   delta.order   = t.order
      if (JSON.stringify(t.aliases) !== JSON.stringify(def.aliases)) delta.aliases = t.aliases
      return delta
    })
    setTagOverrides(overlay)
  }

  return {
    categories, activeCategories,
    useCases, activeUseCases,
    tags, activeTags,
    resolveTag,
    getCategory, getUseCase, getTag,
    saveCategories, saveUseCases, saveTags,
  }
}
