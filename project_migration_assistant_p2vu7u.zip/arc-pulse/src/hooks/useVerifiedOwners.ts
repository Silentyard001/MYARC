/**
 * useVerifiedOwners
 *
 * Returns a mapping of projectId slug → verified owner address (lowercase).
 *
 * Data source (priority order):
 *   1. Goldsky subgraph (when VITE_SUBGRAPH_URL is set) — single GraphQL query.
 *   2. Direct getLogs against Arc Testnet RPC — fallback.
 *
 * First-claim semantics: if multiple ProjectVerified events exist for the same
 * projectId (shouldn't happen on-chain, but guarded against), the earliest one wins.
 *
 * Event: ProjectVerified(bytes32 indexed projectId, address indexed owner)
 */

import { useState, useEffect, useCallback } from 'react'
import { usePublicClient } from 'wagmi'
import { parseAbiItem, decodeEventLog } from 'viem'
import { ARC_TESTNET_CHAIN_ID } from '../config'
import { bytes32ToSlug } from '../utils/projectId'
import { getPaginatedLogs } from '../utils/getLogs'
import {
  querySubgraph,
  SubgraphUnavailableError,
  VERIFIED_PROJECTS_QUERY,
  type GqlVerifiedProject,
} from '../lib/graphql'

const PROJECT_VERIFIED_EVENT = parseAbiItem(
  'event ProjectVerified(bytes32 indexed projectId, address indexed owner)'
)

const SUBGRAPH_PAGE_SIZE = 1000

export interface UseVerifiedOwnersReturn {
  /** slug → verified owner address (lowercase) */
  verifiedOwners: Record<string, string>
  isLoading: boolean
  error: string | null
  refetch: () => void
}

export function useVerifiedOwners(
  contractAddress: `0x${string}` | undefined
): UseVerifiedOwnersReturn {
  const publicClient = usePublicClient({ chainId: ARC_TESTNET_CHAIN_ID })
  const [verifiedOwners, setVerifiedOwners] = useState<Record<string, string>>({})
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [tick, setTick] = useState(0)

  const refetch = useCallback(() => setTick((t) => t + 1), [])

  useEffect(() => {
    if (!contractAddress || !publicClient) return

    let cancelled = false

    async function run() {
      if (!publicClient || !contractAddress) return
      setIsLoading(true)
      setError(null)

      try {
        // ── Try subgraph first ────────────────────────────────────────────────
        let gqlEntities: GqlVerifiedProject[] | null = null

        try {
          const data = await querySubgraph<{ verifiedProjects: GqlVerifiedProject[] }>(
            VERIFIED_PROJECTS_QUERY,
            { first: SUBGRAPH_PAGE_SIZE }
          )
          gqlEntities = data.verifiedProjects
        } catch (err) {
          if (!(err instanceof SubgraphUnavailableError)) {
            console.warn('[useVerifiedOwners] subgraph query failed, falling back to RPC:', err)
          }
        }

        if (cancelled) return

        if (gqlEntities !== null) {
          // ── Subgraph path ─────────────────────────────────────────────────
          // Subgraph handler already enforces first-claim (only saves if entity absent),
          // so each projectId appears at most once. Still guard in the frontend.
          const map: Record<string, string> = {}
          for (const entity of gqlEntities) {
            const slug = bytes32ToSlug(entity.projectId as `0x${string}`)
            if (!map[slug]) map[slug] = entity.owner.toLowerCase()
          }
          setVerifiedOwners(map)
          if (!cancelled) setIsLoading(false)
          return
        }

        // ── RPC fallback path ─────────────────────────────────────────────────
        // Arc Testnet RPC enforces a 100 000-block limit — use paginated fetching
        const logs = await getPaginatedLogs(publicClient, {
          address: contractAddress,
          event: PROJECT_VERIFIED_EVENT,
        })

        if (cancelled) return

        const map: Record<string, string> = {}
        for (const log of logs) {
          try {
            const { args } = decodeEventLog({
              abi: [PROJECT_VERIFIED_EVENT],
              data: log.data,
              topics: log.topics,
            })
            const a = args as { projectId: `0x${string}`; owner: string }
            const slug = bytes32ToSlug(a.projectId)
            if (!map[slug]) map[slug] = a.owner.toLowerCase()
          } catch {
            // skip malformed log
          }
        }
        setVerifiedOwners(map)
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : 'Failed to fetch verified owners')
        }
      } finally {
        if (!cancelled) setIsLoading(false)
      }
    }

    void run()
    return () => { cancelled = true }
  }, [contractAddress, publicClient, tick])

  return { verifiedOwners, isLoading, error, refetch }
}
