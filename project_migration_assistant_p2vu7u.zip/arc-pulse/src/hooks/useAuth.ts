/**
 * useAuth — Phase 3 wallet authentication hook
 *
 * Implements Sign-In With Ethereum (SIWE / EIP-4361) authentication against
 * the MYARC Supabase backend via two Edge Functions:
 *
 *   auth-challenge  POST {walletAddress}
 *                   → {nonce, issuedAt, expiresAt, message}
 *
 *   auth-verify     POST {walletAddress, signature, nonce}
 *                   → {access_token, refresh_token, userId, expiresIn}
 *
 * Flow:
 *   1. Wallet connects → useAuth detects the new address.
 *   2. If no live session for this wallet → status is 'unauthenticated'.
 *   3. App calls signIn() → fetches challenge, asks wallet to sign, verifies.
 *   4. On success: stores tokens in sessionStorage, sets Supabase session.
 *   5. useProfile switches from x-wallet-address header to the JWT session.
 *
 * Session storage:
 *   sessionStorage key: myarc:auth:<walletAddress>
 *   Value: { accessToken, refreshToken, userId, expiresAt (ISO string) }
 *   sessionStorage is intentionally scoped to the tab/session — not persisted
 *   across restarts, which forces re-authentication on page reload. This is the
 *   correct tradeoff: a stale session in localStorage could be replayed across
 *   devices; sessionStorage limits exposure to the current browser tab.
 *
 * Wallet-change handling:
 *   - When the connected address changes, the previous session is immediately
 *     invalidated and status resets to 'unauthenticated'.
 *   - The new wallet must authenticate independently.
 *   - This prevents silent session-transfer between accounts.
 *
 * Supabase session:
 *   On successful signIn, the hook calls supabase.auth.setSession() with the
 *   tokens returned by auth-verify. Subsequent Supabase client calls use the
 *   authenticated context, and RLS policies using auth.uid() work correctly.
 *
 * x-wallet-address:
 *   getWalletClient() (the old insecure mechanism) is NO LONGER USED for
 *   profile mutations. The Supabase client picks up the JWT session from
 *   supabase.auth.setSession() automatically on all subsequent calls.
 *
 * Admin operations (Phase 3b):
 *   getAdminClient() now returns the shared supabase client (no custom header).
 *   Admin RLS policies check the `wallet_address` JWT claim instead of the old
 *   self-asserted x-owner-address header. Admin writes therefore also require
 *   the owner wallet to complete this SIWE flow first.
 *
 * Limitations (documented for Phase 4):
 *   - Refresh token rotation is not implemented; the 1-hour access token must
 *     be renewed by re-signing. Future work: a /auth-refresh Edge Function.
 *   - sessionStorage means authentication is lost on tab close / page reload.
 *     The app degrades gracefully: profile reads (public) still work; profile
 *     writes prompt re-authentication.
 *   - Smart-contract wallets (ERC-1271) that sign via a contract method are not
 *     supported; only EOA personal_sign is verified in auth-verify.
 */

import { useState, useEffect, useCallback, useRef } from 'react'
import { useAccount, useSignMessage } from 'wagmi'
import { supabase } from '../lib/supabase'

// ── Types ──────────────────────────────────────────────────────────────────────

export type AuthStatus =
  | 'idle'               // No wallet connected
  | 'unauthenticated'    // Wallet connected but no valid session
  | 'authenticating'     // signIn() in progress
  | 'authenticated'      // Valid session exists for the connected wallet
  | 'error'              // Authentication failed

export interface AuthSession {
  walletAddress: string
  userId: string
  accessToken: string
  refreshToken: string
  expiresAt: string  // ISO string
}

export interface UseAuthReturn {
  /** Current authentication status for the connected wallet. */
  status: AuthStatus
  /** Non-null when status === 'authenticated'. */
  session: AuthSession | null
  /** Non-null when status === 'error'. */
  authError: string | null
  /**
   * Trigger the authentication flow: request challenge → wallet signs →
   * verify server-side → establish session.
   * Resolves with the session on success, null on failure.
   */
  signIn: () => Promise<AuthSession | null>
  /** Invalidate the current session and clear Supabase auth state. */
  signOut: () => Promise<void>
  /** True while the hook is checking for a stored session (initial hydration). */
  isHydrating: boolean
}

// ── Constants ──────────────────────────────────────────────────────────────────

const FUNCTIONS_URL = import.meta.env.VITE_SUPABASE_FUNCTIONS_URL as string | undefined
const SUPABASE_URL  = import.meta.env.VITE_SUPABASE_URL as string | undefined

function functionsBaseUrl(): string {
  if (FUNCTIONS_URL) return FUNCTIONS_URL.replace(/\/$/, '')
  if (SUPABASE_URL)  return `${SUPABASE_URL.replace(/\/$/, '')}/functions/v1`
  return ''
}

function sessionKey(walletAddress: string): string {
  return `myarc:auth:${walletAddress.toLowerCase()}`
}

// ── Session storage helpers ────────────────────────────────────────────────────

function loadSession(walletAddress: string): AuthSession | null {
  try {
    const raw = sessionStorage.getItem(sessionKey(walletAddress))
    if (!raw) return null
    const s = JSON.parse(raw) as AuthSession
    // Check expiry
    if (new Date(s.expiresAt) < new Date()) {
      sessionStorage.removeItem(sessionKey(walletAddress))
      return null
    }
    return s
  } catch {
    return null
  }
}

function saveSession(session: AuthSession): void {
  try {
    sessionStorage.setItem(sessionKey(session.walletAddress), JSON.stringify(session))
  } catch { /* quota — ignore */ }
}

function clearSession(walletAddress: string): void {
  try {
    sessionStorage.removeItem(sessionKey(walletAddress))
  } catch { /* ignore */ }
}

// ── Hook ──────────────────────────────────────────────────────────────────────

export function useAuth(): UseAuthReturn {
  const { address, isConnected } = useAccount()
  const { signMessageAsync } = useSignMessage()

  const [status,      setStatus]      = useState<AuthStatus>('idle')
  const [session,     setSession]     = useState<AuthSession | null>(null)
  const [authError,   setAuthError]   = useState<string | null>(null)
  const [isHydrating, setIsHydrating] = useState(true)

  // Track the wallet address the current session belongs to so we can detect
  // account switches without relying on stale closure values.
  const sessionWalletRef = useRef<string | null>(null)

  // ── Restore session from sessionStorage on wallet connect ─────────────────
  useEffect(() => {
    setIsHydrating(true)

    if (!isConnected || !address) {
      setStatus('idle')
      setSession(null)
      setAuthError(null)
      sessionWalletRef.current = null
      // Sign out of Supabase too
      if (supabase) void supabase.auth.signOut()
      setIsHydrating(false)
      return
    }

    const lowerAddress = address.toLowerCase()

    // Wallet changed while a session was live for a different address?
    if (sessionWalletRef.current && sessionWalletRef.current !== lowerAddress) {
      // Invalidate the previous session immediately
      clearSession(sessionWalletRef.current)
      if (supabase) void supabase.auth.signOut()
      setSession(null)
      sessionWalletRef.current = null
    }

    // Try to restore existing session for this wallet
    const stored = loadSession(lowerAddress)
    if (stored) {
      setSession(stored)
      setStatus('authenticated')
      sessionWalletRef.current = lowerAddress
      // Re-hydrate Supabase client session
      if (supabase) {
        void supabase.auth.setSession({
          access_token:  stored.accessToken,
          refresh_token: stored.refreshToken,
        })
      }
    } else {
      setStatus('unauthenticated')
      setSession(null)
      sessionWalletRef.current = null
    }

    setIsHydrating(false)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [address, isConnected])

  // ── signIn ────────────────────────────────────────────────────────────────
  const signIn = useCallback(async (): Promise<AuthSession | null> => {
    if (!address || !isConnected) {
      setAuthError('No wallet connected.')
      return null
    }
    if (status === 'authenticating') return null

    const lowerAddress = address.toLowerCase()
    const base = functionsBaseUrl()

    if (!base) {
      setAuthError('Supabase is not configured. Authentication is unavailable.')
      setStatus('error')
      return null
    }

    setStatus('authenticating')
    setAuthError(null)

    try {
      // ── Step 1: Request challenge ──────────────────────────────────────
      const challengeRes = await fetch(`${base}/auth-challenge`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ walletAddress: lowerAddress }),
      })
      if (!challengeRes.ok) {
        const err = (await challengeRes.json().catch(() => ({}))) as { error?: string }
        throw new Error(err.error ?? `Challenge request failed (${challengeRes.status})`)
      }
      const { nonce, message } = (await challengeRes.json()) as {
        nonce: string; issuedAt: string; expiresAt: string; message: string
      }

      // ── Step 2: Sign the challenge message ────────────────────────────
      // signMessageAsync uses EIP-191 personal_sign — the same method that
      // recoverMessageAddress in auth-verify expects.
      let signature: `0x${string}`
      try {
        signature = await signMessageAsync({ message })
      } catch (e) {
        // User rejected the signature request
        const msg = (e as Error).message ?? ''
        const rejected = msg.toLowerCase().includes('reject') || msg.toLowerCase().includes('denied') || msg.toLowerCase().includes('cancel')
        throw new Error(rejected ? 'Signature rejected by wallet.' : `Signing failed: ${msg}`)
      }

      // ── Step 3: Verify server-side ─────────────────────────────────────
      const verifyRes = await fetch(`${base}/auth-verify`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ walletAddress: lowerAddress, signature, nonce }),
      })
      if (!verifyRes.ok) {
        const err = (await verifyRes.json().catch(() => ({}))) as { error?: string }
        throw new Error(err.error ?? `Verification failed (${verifyRes.status})`)
      }
      const { access_token, refresh_token, userId, expiresIn } = (await verifyRes.json()) as {
        access_token: string; refresh_token: string; userId: string; expiresIn: number
      }

      // ── Step 4: Establish session ──────────────────────────────────────
      const expiresAt = new Date(Date.now() + expiresIn * 1000).toISOString()
      const newSession: AuthSession = {
        walletAddress: lowerAddress,
        userId,
        accessToken:  access_token,
        refreshToken: refresh_token,
        expiresAt,
      }

      saveSession(newSession)
      setSession(newSession)
      setStatus('authenticated')
      setAuthError(null)
      sessionWalletRef.current = lowerAddress

      // ── Step 5: Set Supabase client session ────────────────────────────
      if (supabase) {
        await supabase.auth.setSession({
          access_token,
          refresh_token,
        })
      }

      return newSession
    } catch (e) {
      const msg = (e instanceof Error ? e.message : String(e)) || 'Authentication failed.'
      setAuthError(msg)
      setStatus('unauthenticated')
      return null
    }
  }, [address, isConnected, status, signMessageAsync])

  // ── signOut ───────────────────────────────────────────────────────────────
  const signOut = useCallback(async (): Promise<void> => {
    if (address) clearSession(address.toLowerCase())
    setSession(null)
    setStatus(isConnected && address ? 'unauthenticated' : 'idle')
    setAuthError(null)
    sessionWalletRef.current = null
    if (supabase) await supabase.auth.signOut()
  }, [address, isConnected])

  return { status, session, authError, signIn, signOut, isHydrating }
}
