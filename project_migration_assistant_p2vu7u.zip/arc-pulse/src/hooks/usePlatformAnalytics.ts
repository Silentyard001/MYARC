/**
 * usePlatformAnalytics
 *
 * Fetches platform-wide event logs for Voted, ReviewPosted, and ProjectVerified
 * events across ALL wallets (no address filter) and derives aggregate analytics.
 *
 * All getLogs calls are made against the Arc Testnet RPC directly (no subgraph
 * dependency) so this always works in the admin panel even before the subgraph
 * is deployed.
 *
 * Derived outputs:
 *   totalVotesAllTime          — all Voted events ever
 *   totalVotesLast7d           — Voted events in last 7 days
 *   totalVotesLast30d          — Voted events in last 30 days
 *   uniqueVotersAllTime        — unique voter addresses ever
 *   uniqueVotersLast7d         — unique voter addresses in last 7 days
 *   totalReviewsAllTime        — all ReviewPosted events ever
 *   totalReviewsLast7d         — ReviewPosted events in last 7 days
 *   verifiedProjectCount       — unique project ids from ProjectVerified
 *   mostActiveProject7d        — project id (bytes32 slug) with most votes this week
 *   ecosystemSentiment         — live {bullish, neutral, bearish} across ALL voters
 *   dailyVoteVolume14d         — 14-element array, index 0 = oldest day
 *   dailyNewWallets14d         — 14-element array of unique first-seen wallet counts
 *   dayLabels14d               — 14-element array of date labels (MMM D)
 *   pollVotersCount            — unique wallets that cast a PollVoteCast event
 *   platformVotersCount        — same as uniqueVotersAllTime (for participation rate)
 */

import { useState, useEffect, useCallback, useRef } from 'react'
import { usePublicClient } from 'wagmi'
import { parseAbiItem, decodeEventLog, type Log } from 'viem'
import { ARC_TESTNET_CHAIN_ID } from '../config'
import { bytes32ToSlug } from '../utils/projectId'
import { getPaginatedLogs } from '../utils/getLogs'
import type { Project } from '../data/projects'

// ── Event ABIs ────────────────────────────────────────────────────────────────

const VOTED_EVENT = parseAbiItem(
  'event Voted(bytes32 indexed projectId, address indexed voter, uint8 sentiment, bool isChange)'
)
const REVIEW_POSTED_EVENT = parseAbiItem(
  'event ReviewPosted(bytes32 indexed projectId, address indexed author, uint8 sentiment, uint256 reviewIndex)'
)
const PROJECT_VERIFIED_EVENT = parseAbiItem(
  'event ProjectVerified(bytes32 indexed projectId, address indexed owner, uint256 fee)'
)
const POLL_VOTE_CAST_EVENT = parseAbiItem(
  'event PollVoteCast(bytes32 indexed pollId, address indexed voter, uint8 optionIndex, uint256 stake)'
)
const VOTE_RETRACTED_EVENT = parseAbiItem(
  'event VoteRetracted(bytes32 indexed projectId, address indexed voter)'
)

// ── Types ─────────────────────────────────────────────────────────────────────

export interface EcosystemSentiment {
  bullish: number
  neutral: number
  bearish: number
}

export interface PlatformAnalyticsResult {
  totalVotesAllTime: number
  totalVotesLast7d: number
  totalVotesLast30d: number
  uniqueVotersAllTime: number
  uniqueVotersLast7d: number
  totalReviewsAllTime: number
  totalReviewsLast7d: number
  verifiedProjectCount: number
  mostActiveProject7d: string | null  // human-readable name or slug
  ecosystemSentiment: EcosystemSentiment
  dailyVoteVolume14d: number[]
  dailyNewWallets14d: number[]
  dayLabels14d: string[]
  pollVotersCount: number
  platformVotersCount: number
  isLoading: boolean
  error: string | null
  refetch: () => void
}

const DAY_MS = 86_400_000

// ── Helpers ───────────────────────────────────────────────────────────────────


function safeDecode<T>(
  log: Log,
  abi: ReturnType<typeof parseAbiItem>[]
): T | null {
  try {
    const { args } = decodeEventLog({ abi, data: log.data, topics: log.topics })
    return args as T
  } catch { return null }
}

// ── Hook ─────────────────────────────────────────────────────────────────────

export function usePlatformAnalytics(
  contractAddress: `0x${string}` | undefined,
  allProjects: Project[]
): PlatformAnalyticsResult {
  const publicClient = usePublicClient({ chainId: ARC_TESTNET_CHAIN_ID })
  const [refetchTick, setRefetchTick] = useState(0)
  const refetch = useCallback(() => setRefetchTick((t) => t + 1), [])

  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const [result, setResult] = useState<Omit<PlatformAnalyticsResult, 'isLoading' | 'error' | 'refetch'>>({
    totalVotesAllTime: 0,
    totalVotesLast7d: 0,
    totalVotesLast30d: 0,
    uniqueVotersAllTime: 0,
    uniqueVotersLast7d: 0,
    totalReviewsAllTime: 0,
    totalReviewsLast7d: 0,
    verifiedProjectCount: 0,
    mostActiveProject7d: null,
    ecosystemSentiment: { bullish: 0, neutral: 0, bearish: 0 },
    dailyVoteVolume14d: Array(14).fill(0) as number[],
    dailyNewWallets14d: Array(14).fill(0) as number[],
    dayLabels14d: Array.from({ length: 14 }, (_, i) => {
      const d = new Date(Date.now() - (13 - i) * DAY_MS)
      return d.toLocaleDateString('en', { month: 'short', day: 'numeric' })
    }),
    pollVotersCount: 0,
    platformVotersCount: 0,
  })

  // Stable ref for allProjects to avoid re-fetching on every render
  const projectsRef = useRef(allProjects)
  projectsRef.current = allProjects

  useEffect(() => {
    if (!contractAddress || !publicClient) return

    let cancelled = false

    async function run() {
      if (!publicClient || !contractAddress) return
      setIsLoading(true)
      setError(null)

      try {
        // Fetch all 5 event types sequentially via paginated getLogs
        // (Arc Testnet RPC enforces a 100 000-block-per-request limit)
        const votedLogs = await getPaginatedLogs(publicClient, {
          address: contractAddress,
          event: VOTED_EVENT,
        })
        const retractedLogs = await getPaginatedLogs(publicClient, {
          address: contractAddress,
          event: VOTE_RETRACTED_EVENT,
        })
        const reviewLogs = await getPaginatedLogs(publicClient, {
          address: contractAddress,
          event: REVIEW_POSTED_EVENT,
        })
        const verifiedLogs = await getPaginatedLogs(publicClient, {
          address: contractAddress,
          event: PROJECT_VERIFIED_EVENT,
        })
        const pollVoteLogs = await getPaginatedLogs(publicClient, {
          address: contractAddress,
          event: POLL_VOTE_CAST_EVENT,
        })

        if (cancelled) return

        // Batch-fetch unique block timestamps for all logs
        const blockSet = new Set<bigint>()
        for (const log of [...votedLogs, ...retractedLogs, ...reviewLogs, ...verifiedLogs, ...pollVoteLogs]) {
          if (log.blockNumber) blockSet.add(log.blockNumber)
        }

        const blockTimestamps = new Map<bigint, number>()
        if (blockSet.size > 0) {
          const results = await Promise.all(
            Array.from(blockSet).map((bn) =>
              publicClient.getBlock({ blockNumber: bn })
                .then((b) => ({ bn, ts: Number(b.timestamp) * 1000 }))
                .catch(() => ({ bn, ts: Date.now() }))
            )
          )
          for (const { bn, ts } of results) blockTimestamps.set(bn, ts)
        }

        if (cancelled) return

        const logTs = (log: Log): number =>
          log.blockNumber ? (blockTimestamps.get(log.blockNumber) ?? Date.now()) : Date.now()

        const now = Date.now()
        const t7d  = now - 7  * DAY_MS
        const t30d = now - 30 * DAY_MS
        const t14d = now - 14 * DAY_MS

        // ── Voted logs ───────────────────────────────────────────────────────
        type VotedArgs = { projectId: `0x${string}`; voter: `0x${string}`; sentiment: number }
        const votedWithTs = votedLogs.map((log) => {
          const args = safeDecode<VotedArgs>(log, [VOTED_EVENT])
          return args ? { ...args, ts: logTs(log) } : null
        }).filter((v): v is NonNullable<typeof v> => v !== null)

        type RetractedArgs = { projectId: `0x${string}`; voter: `0x${string}` }
        const retractedWithTs = retractedLogs.map((log) => {
          const args = safeDecode<RetractedArgs>(log, [VOTE_RETRACTED_EVENT])
          return args ? { ...args, ts: logTs(log) } : null
        }).filter((v): v is NonNullable<typeof v> => v !== null)

        // Build live vote map (voter -> {projectId, sentiment}) after retractions
        const allSorted = [
          ...votedWithTs.map((v) => ({ type: 'vote' as const, voter: (v.voter as string).toLowerCase(), projectId: v.projectId, sentiment: v.sentiment, ts: v.ts })),
          ...retractedWithTs.map((v) => ({ type: 'retract' as const, voter: (v.voter as string).toLowerCase(), projectId: v.projectId, sentiment: 0, ts: v.ts })),
        ].sort((a, b) => a.ts - b.ts)

        const liveVoteMap = new Map<string, { projectId: string; sentiment: number }>()
        for (const ev of allSorted) {
          if (ev.type === 'vote') {
            liveVoteMap.set(ev.voter, { projectId: ev.projectId, sentiment: ev.sentiment })
          } else {
            liveVoteMap.delete(ev.voter)
          }
        }

        const totalVotesAllTime  = votedLogs.length
        const totalVotesLast7d   = votedWithTs.filter((v) => v.ts >= t7d).length
        const totalVotesLast30d  = votedWithTs.filter((v) => v.ts >= t30d).length

        const votersAllTime = new Set(votedWithTs.map((v) => (v.voter as string).toLowerCase()))
        const votersLast7d  = new Set(votedWithTs.filter((v) => v.ts >= t7d).map((v) => (v.voter as string).toLowerCase()))

        // Ecosystem sentiment (live)
        const sentiment: EcosystemSentiment = { bullish: 0, neutral: 0, bearish: 0 }
        for (const { sentiment: s } of liveVoteMap.values()) {
          if (s === 0) sentiment.bullish++
          else if (s === 1) sentiment.neutral++
          else sentiment.bearish++
        }

        // Most active project this week (by raw vote count, not net)
        const voteCountByProject7d = new Map<string, number>()
        for (const v of votedWithTs) {
          if (v.ts < t7d) continue
          const slug = bytes32ToSlug(v.projectId)
          voteCountByProject7d.set(slug, (voteCountByProject7d.get(slug) ?? 0) + 1)
        }
        let mostActiveSlug: string | null = null
        let maxVotes = 0
        for (const [slug, count] of voteCountByProject7d) {
          if (count > maxVotes) { maxVotes = count; mostActiveSlug = slug }
        }
        const mostActiveProject7d = mostActiveSlug
          ? (projectsRef.current.find((p) => p.id === mostActiveSlug)?.name ?? mostActiveSlug)
          : null

        // ── Daily vote volume (14d) ──────────────────────────────────────────
        const dailyVoteVolume14d = Array(14).fill(0) as number[]
        for (const { ts } of votedWithTs) {
          if (ts < t14d) continue
          const daysAgo = Math.floor((now - ts) / DAY_MS)
          const idx = 13 - daysAgo
          if (idx >= 0 && idx < 14) dailyVoteVolume14d[idx]++
        }

        // ── Daily new wallets (14d) — first vote ever by that wallet ─────────
        const firstSeenTs = new Map<string, number>()
        for (const { voter, ts } of votedWithTs) {
          const addr = (voter as string).toLowerCase()
          const prev = firstSeenTs.get(addr)
          if (prev === undefined || ts < prev) firstSeenTs.set(addr, ts)
        }
        const dailyNewWallets14d = Array(14).fill(0) as number[]
        for (const ts of firstSeenTs.values()) {
          if (ts < t14d) continue
          const daysAgo = Math.floor((now - ts) / DAY_MS)
          const idx = 13 - daysAgo
          if (idx >= 0 && idx < 14) dailyNewWallets14d[idx]++
        }

        // ── 14d day labels ───────────────────────────────────────────────────
        const dayLabels14d = Array.from({ length: 14 }, (_, i) => {
          const d = new Date(now - (13 - i) * DAY_MS)
          return d.toLocaleDateString('en', { month: 'short', day: 'numeric' })
        })

        // ── Reviews ──────────────────────────────────────────────────────────
        type ReviewArgs = { projectId: `0x${string}`; author: `0x${string}`; sentiment: number }
        const reviewsWithTs = reviewLogs.map((log) => {
          const args = safeDecode<ReviewArgs>(log, [REVIEW_POSTED_EVENT])
          return args ? { ...args, ts: logTs(log) } : null
        }).filter((v): v is NonNullable<typeof v> => v !== null)

        const totalReviewsAllTime = reviewLogs.length
        const totalReviewsLast7d  = reviewsWithTs.filter((r) => r.ts >= t7d).length

        // ── Verified projects ────────────────────────────────────────────────
        type VerifiedArgs = { projectId: `0x${string}`; owner: `0x${string}` }
        const verifiedProjectIds = new Set(
          verifiedLogs
            .map((log) => safeDecode<VerifiedArgs>(log, [PROJECT_VERIFIED_EVENT])?.projectId)
            .filter((id): id is `0x${string}` => id !== undefined)
        )

        // ── Poll voters ──────────────────────────────────────────────────────
        type PollVoteArgs = { pollId: `0x${string}`; voter: `0x${string}` }
        const pollVoters = new Set(
          pollVoteLogs
            .map((log) => safeDecode<PollVoteArgs>(log, [POLL_VOTE_CAST_EVENT])?.voter?.toLowerCase())
            .filter((v): v is string => v !== undefined)
        )

        if (cancelled) return

        setResult({
          totalVotesAllTime,
          totalVotesLast7d,
          totalVotesLast30d,
          uniqueVotersAllTime: votersAllTime.size,
          uniqueVotersLast7d: votersLast7d.size,
          totalReviewsAllTime,
          totalReviewsLast7d,
          verifiedProjectCount: verifiedProjectIds.size,
          mostActiveProject7d,
          ecosystemSentiment: sentiment,
          dailyVoteVolume14d,
          dailyNewWallets14d,
          dayLabels14d,
          pollVotersCount: pollVoters.size,
          platformVotersCount: votersAllTime.size,
        })
        setIsLoading(false)
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : 'Failed to fetch platform analytics')
          setIsLoading(false)
        }
      }
    }

    void run()
    return () => { cancelled = true }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [contractAddress, refetchTick])

  return { ...result, isLoading, error, refetch }
}
