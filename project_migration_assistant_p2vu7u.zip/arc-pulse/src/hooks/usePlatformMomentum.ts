/**
 * usePlatformMomentum
 *
 * Computes Momentum Index for ALL projects in a single fetch pass.
 *
 * Architecture:
 *   - Fetches all Voted, VoteRetracted, ReviewPosted, and ReviewUpvoted events
 *     platform-wide (no address/project filter — same approach as usePlatformAnalytics).
 *   - Groups events by projectSlug.
 *   - Calls computeProjectMomentum() from src/lib/momentum.ts for each project.
 *   - Returns a ranked list (highest momentum first) plus a lookup map.
 *
 * This is the hook to use for:
 *   - "MYARC Rising" (top N projects by momentum)
 *   - Project Comparison (pass two slugs, look them up in the map)
 *   - Community Milestones (pass signals from any project in the map)
 *   - Admin platform overview (iterate ranked list)
 *
 * Performance:
 *   - One fetch pass per event type (4 calls total) — NOT one-per-project.
 *   - Block timestamps are batch-fetched via Promise.all across all unique blocks.
 *   - Results are stable until refetch() is called.
 *
 * Only projects that have at least one on-chain event appear in the results.
 * Seed projects with zero on-chain activity will be absent — that is correct.
 */

import { useState, useEffect, useCallback, useRef } from 'react'
import { usePublicClient } from 'wagmi'
import { parseAbiItem, decodeEventLog, type Log } from 'viem'
import { ARC_TESTNET_CHAIN_ID } from '../config'
import { bytes32ToSlug } from '../utils/projectId'
import { getPaginatedLogs } from '../utils/getLogs'
import {
  computeProjectMomentum,
  rankByMomentum,
  type MomentumResult,
  type VoteEvent,
  type RetractEvent,
  type ReviewEvent,
  type BoostEvent,
} from '../lib/momentum'
import type { Project } from '../data/projects'
import {
  querySubgraph,
  SubgraphUnavailableError,
  ALL_EVENTS_QUERY,
  type AllEventsQueryResult,
} from '../lib/graphql'

// ── Event ABIs ────────────────────────────────────────────────────────────────

const VOTED_EVENT = parseAbiItem(
  'event Voted(bytes32 indexed projectId, address indexed voter, uint8 sentiment, bool isChange)'
)
const VOTE_RETRACTED_EVENT = parseAbiItem(
  'event VoteRetracted(bytes32 indexed projectId, address indexed voter)'
)
const REVIEW_POSTED_EVENT = parseAbiItem(
  'event ReviewPosted(bytes32 indexed projectId, address indexed author, uint8 sentiment, uint256 reviewIndex)'
)
const REVIEW_UPVOTED_EVENT = parseAbiItem(
  'event ReviewUpvoted(bytes32 indexed projectId, uint256 indexed reviewIndex, address indexed upvoter, address author, uint256 totalAmount, uint256 protocolFee)'
)

// ── Return type ───────────────────────────────────────────────────────────────

export interface UsePlatformMomentumReturn {
  /** All computed results, sorted by momentumIndex descending. */
  ranked: MomentumResult[]
  /** Fast lookup by projectSlug. */
  bySlug: Map<string, MomentumResult>
  /** Projects with any data available (slugs). */
  activeProjectSlugs: string[]
  isLoading: boolean
  error: string | null
  refetch: () => void
}

// ── Hook ──────────────────────────────────────────────────────────────────────

export function usePlatformMomentum(
  contractAddress: `0x${string}` | undefined,
  allProjects: Project[],
): UsePlatformMomentumReturn {
  const publicClient = usePublicClient({ chainId: ARC_TESTNET_CHAIN_ID })
  const [ranked, setRanked] = useState<MomentumResult[]>([])
  const [bySlug, setBySlug] = useState<Map<string, MomentumResult>>(new Map())
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [refetchTick, setRefetchTick] = useState(0)
  const refetch = useCallback(() => setRefetchTick((t) => t + 1), [])

  // Stable ref so the effect does not re-fire when allProjects array identity changes
  const projectsRef = useRef(allProjects)
  projectsRef.current = allProjects

  useEffect(() => {
    if (!contractAddress || !publicClient) return

    let cancelled = false
    setIsLoading(true)
    setError(null)

    /** Shared computation: given decoded event arrays, derive ranked momentum results. */
    function computeFromEvents(
      now: number,
      votedRaw: { projectId: string; voter: string; sentiment: number; ts: number }[],
      retractedRaw: { projectId: string; voter: string; ts: number }[],
      reviewsRaw: { projectId: string; author: string; ts: number }[],
      boostsRaw: { projectId: string; upvoter: string; authorAmount: bigint; ts: number }[],
    ): { sorted: MomentumResult[]; map: Map<string, MomentumResult> } {
      const votesBySlug    = new Map<string, VoteEvent[]>()
      const retractsBySlug = new Map<string, RetractEvent[]>()
      const reviewsBySlug  = new Map<string, ReviewEvent[]>()
      const boostsBySlug   = new Map<string, BoostEvent[]>()

      const ensure = <T>(m: Map<string, T[]>, slug: string): T[] => {
        if (!m.has(slug)) m.set(slug, [])
        return m.get(slug)!
      }

      for (const v of votedRaw) {
        const slug = bytes32ToSlug(v.projectId as `0x${string}`)
        ensure(votesBySlug, slug).push({ voter: v.voter.toLowerCase(), sentiment: v.sentiment, ts: v.ts, projectSlug: slug })
      }
      for (const r of retractedRaw) {
        const slug = bytes32ToSlug(r.projectId as `0x${string}`)
        ensure(retractsBySlug, slug).push({ voter: r.voter.toLowerCase(), ts: r.ts, projectSlug: slug })
      }
      for (const r of reviewsRaw) {
        const slug = bytes32ToSlug(r.projectId as `0x${string}`)
        ensure(reviewsBySlug, slug).push({ author: r.author.toLowerCase(), ts: r.ts, projectSlug: slug })
      }
      for (const b of boostsRaw) {
        const slug = bytes32ToSlug(b.projectId as `0x${string}`)
        ensure(boostsBySlug, slug).push({ upvoter: b.upvoter.toLowerCase(), ts: b.ts, projectSlug: slug, authorAmount: b.authorAmount })
      }

      const allSlugs = new Set([...votesBySlug.keys(), ...reviewsBySlug.keys(), ...boostsBySlug.keys()])
      const results: MomentumResult[] = []
      for (const slug of allSlugs) {
        results.push(computeProjectMomentum(
          slug,
          votesBySlug.get(slug)    ?? [],
          retractsBySlug.get(slug) ?? [],
          reviewsBySlug.get(slug)  ?? [],
          boostsBySlug.get(slug)   ?? [],
          now,
        ))
      }
      const sorted = rankByMomentum(results)
      const map    = new Map<string, MomentumResult>(sorted.map((r) => [r.projectSlug, r]))
      return { sorted, map }
    }

    /** Subgraph path: query ALL_EVENTS_QUERY, parse Gql rows into typed arrays. */
    async function runViaSubgraph(now: number): Promise<void> {
      const data = await querySubgraph<AllEventsQueryResult>(ALL_EVENTS_QUERY, { first: 5000 })

      const DAY_MS = 86_400_000
      const votedRaw = data.votes.map((v) => ({
        projectId: v.projectId,
        voter: v.voter,
        sentiment: v.sentiment,
        ts: Number(v.timestamp) * 1000,
      }))
      const retractedRaw = data.voteRetractions.map((r) => ({
        projectId: r.projectId,
        voter: r.voter,
        ts: Number(r.timestamp) * 1000,
      }))
      const reviewsRaw = data.reviews.map((r) => ({
        projectId: r.projectId,
        author: r.author,
        ts: Number(r.timestamp) * 1000,
      }))
      const boostsRaw = data.reviewUpvotes.map((b) => ({
        projectId: b.projectId,
        upvoter: b.upvoter,
        authorAmount: BigInt(b.authorAmount),
        ts: Number(b.timestamp) * 1000,
      }))
      // Suppress unused DAY_MS — kept here for future windowed subgraph queries
      void DAY_MS

      const { sorted, map } = computeFromEvents(now, votedRaw, retractedRaw, reviewsRaw, boostsRaw)
      if (!cancelled) {
        setRanked(sorted)
        setBySlug(map)
        setIsLoading(false)
      }
    }

    async function run() {
      if (!publicClient || !contractAddress) return

      try {
        const now = Date.now()

        // ── Subgraph-first path ────────────────────────────────────────────────
        // Attempt the Goldsky subgraph query first. If VITE_SUBGRAPH_URL is not
        // configured (SubgraphUnavailableError) or the query fails for any reason,
        // fall through to the RPC getLogs path.
        try {
          await runViaSubgraph(now)
          return // success — RPC path not needed
        } catch (subgraphErr) {
          if (!(subgraphErr instanceof SubgraphUnavailableError)) {
            // Subgraph was configured but returned an error — log and fall back
            console.warn('[usePlatformMomentum] Subgraph query failed, falling back to RPC:', subgraphErr)
          }
          // SubgraphUnavailableError: URL not configured — silent fall-through
        }

        // ── RPC fallback path ─────────────────────────────────────────────────
        const [votedLogs, retractedLogs, reviewLogs, boostLogs] = await Promise.all([
          getPaginatedLogs(publicClient, { address: contractAddress, event: VOTED_EVENT }),
          getPaginatedLogs(publicClient, { address: contractAddress, event: VOTE_RETRACTED_EVENT }),
          getPaginatedLogs(publicClient, { address: contractAddress, event: REVIEW_POSTED_EVENT }),
          getPaginatedLogs(publicClient, { address: contractAddress, event: REVIEW_UPVOTED_EVENT })
            .catch(() => [] as Log[]),
        ])

        if (cancelled) return

        // ── Batch-fetch unique block timestamps ───────────────────────────────
        const blockSet = new Set<bigint>()
        for (const log of [...votedLogs, ...retractedLogs, ...reviewLogs, ...boostLogs]) {
          if (log.blockNumber) blockSet.add(log.blockNumber)
        }

        const blockTs = new Map<bigint, number>()
        if (blockSet.size > 0) {
          const tsResults = await Promise.all(
            Array.from(blockSet).map((bn) =>
              publicClient.getBlock({ blockNumber: bn })
                .then((b) => ({ bn, ts: Number(b.timestamp) * 1000 }))
                .catch(() => ({ bn, ts: 0 }))
            )
          )
          for (const { bn, ts } of tsResults) blockTs.set(bn, ts)
        }

        if (cancelled) return

        const logTs = (log: Log): number =>
          log.blockNumber ? (blockTs.get(log.blockNumber) ?? 0) : 0

        // ── Decode logs into common typed arrays, then call computeFromEvents ──

        const votedRaw: { projectId: string; voter: string; sentiment: number; ts: number }[] = []
        const retractedRaw: { projectId: string; voter: string; ts: number }[] = []
        const reviewsRaw: { projectId: string; author: string; ts: number }[] = []
        const boostsRaw: { projectId: string; upvoter: string; authorAmount: bigint; ts: number }[] = []

        for (const log of votedLogs) {
          try {
            const { args } = decodeEventLog({ abi: [VOTED_EVENT], data: log.data, topics: log.topics })
            const a = args as { projectId: `0x${string}`; voter: `0x${string}`; sentiment: number }
            votedRaw.push({ projectId: a.projectId, voter: a.voter, sentiment: a.sentiment, ts: logTs(log) })
          } catch { /* skip undecoded */ }
        }

        for (const log of retractedLogs) {
          try {
            const { args } = decodeEventLog({ abi: [VOTE_RETRACTED_EVENT], data: log.data, topics: log.topics })
            const a = args
            retractedRaw.push({ projectId: a.projectId, voter: a.voter, ts: logTs(log) })
          } catch { /* skip */ }
        }

        for (const log of reviewLogs) {
          try {
            const { args } = decodeEventLog({ abi: [REVIEW_POSTED_EVENT], data: log.data, topics: log.topics })
            const a = args as { projectId: `0x${string}`; author: `0x${string}` }
            reviewsRaw.push({ projectId: a.projectId, author: a.author, ts: logTs(log) })
          } catch { /* skip */ }
        }

        for (const log of boostLogs) {
          try {
            const { args } = decodeEventLog({ abi: [REVIEW_UPVOTED_EVENT], data: log.data, topics: log.topics })
            const a = args as { projectId: `0x${string}`; upvoter: `0x${string}`; totalAmount: bigint; protocolFee: bigint }
            boostsRaw.push({ projectId: a.projectId, upvoter: a.upvoter, authorAmount: a.totalAmount - a.protocolFee, ts: logTs(log) })
          } catch { /* skip */ }
        }

        if (cancelled) return

        const { sorted, map } = computeFromEvents(now, votedRaw, retractedRaw, reviewsRaw, boostsRaw)

        if (!cancelled) {
          setRanked(sorted)
          setBySlug(map)
          setIsLoading(false)
        }
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : 'Failed to compute platform momentum')
          setIsLoading(false)
        }
      }
    }

    void run()
    return () => { cancelled = true }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [contractAddress, refetchTick])

  const activeProjectSlugs = ranked.map((r) => r.projectSlug)

  return { ranked, bySlug, activeProjectSlugs, isLoading, error, refetch }
}
