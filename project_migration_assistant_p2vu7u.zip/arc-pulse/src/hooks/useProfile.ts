/**
 * useProfile
 *
 * Wallet → profile resolution and persistence for MYARC.
 *
 * Phase 3 update: profile WRITES now require an authenticated Supabase session
 * established by useAuth (SIWE signature verified server-side). The old
 * x-wallet-address header mechanism (getWalletClient) is removed from the
 * write path. Profile READS remain publicly accessible via the anon client.
 *
 * Identity flow:
 *   1. Wallet connects + user authenticates via useAuth (signIn).
 *   2. useAuth calls supabase.auth.setSession() with the JWT from auth-verify.
 *   3. resolveProfile reads the existing profile row (anon read — no auth needed).
 *   4. Profile creation is handled server-side in auth-verify on first sign-in.
 *   5. updateProfile writes via the anon supabase client, which now carries the
 *      JWT session set by useAuth. Supabase RLS: auth.uid() = user_id.
 *   6. On disconnect → clear local profile state (Supabase row preserved).
 *
 * Persistence:
 *   Primary:  Supabase `profiles` table (shared, durable).
 *   Fallback: localStorage keyed by wallet address (when Supabase is absent).
 *
 * RLS policy (Phase 3):
 *   create policy "profiles_authenticated_write" on profiles
 *     for all to authenticated
 *     using     (auth.uid()::text = user_id::text)
 *     with check(auth.uid()::text = user_id::text);
 *
 * The `userId` is the stable internal identifier. wallet_address is a lookup key.
 */

import { useState, useEffect, useCallback } from 'react'
import { useAccount } from 'wagmi'
import { supabase } from '../lib/supabase'
import { normaliseUsername, validateUsername } from '../utils/username'

// ── Types ──────────────────────────────────────────────────────────────────────

export type WalletVisibility = 'hidden' | 'public'

export interface UserProfile {
  /** Stable internal application identity — uuid from Supabase or a derived local id. */
  userId: string
  /** The primary connected wallet address (lowercase). */
  walletAddress: string
  /** Optional unique handle. null when not set. */
  username: string | null
  /** Display name shown in the UI. */
  displayName: string
  /** Avatar URL (external image or data URI). null when not set. */
  avatarUrl: string | null
  /** Short bio text. null when not set. */
  bio: string | null
  /** Whether the wallet is shown on public-facing surfaces. Default: 'hidden'. */
  walletVisibility: WalletVisibility
  createdAt: string
  updatedAt: string
}

export interface ProfileUpdatePayload {
  username?: string | null
  displayName?: string
  avatarUrl?: string | null
  bio?: string | null
  walletVisibility?: WalletVisibility
}

export interface UseProfileReturn {
  /** Currently resolved profile, or null when no wallet connected / still loading. */
  profile: UserProfile | null
  isLoading: boolean
  /** Non-null when the last save/load failed. */
  error: string | null
  /**
   * Persist profile field changes.
   * Returns { ok: true } on success or { ok: false, error: string } on failure.
   */
  updateProfile: (payload: ProfileUpdatePayload) => Promise<{ ok: boolean; error?: string }>
  /** Reload the profile from Supabase (or localStorage fallback). */
  refetch: () => Promise<void>
}

// ── Local storage key ─────────────────────────────────────────────────────────

function localKey(walletAddress: string) {
  return `myarc:profile:${walletAddress.toLowerCase()}`
}

/**
 * ⚠ DEVELOPMENT / OFFLINE FALLBACK ONLY — not a production data store.
 *
 * loadLocal reads the last-known profile from browser localStorage.
 * It is only called when Supabase is unavailable or not configured.
 * On reconnect, Supabase always wins — localStorage never overwrites Supabase.
 *
 * saveLocal is called after every successful Supabase read/write to keep a
 * read-through cache. This enables offline/degraded-mode reads without implying
 * that localStorage is an authoritative source of truth.
 *
 * A localStorage-only profile gets a userId prefixed with "local-" to make it
 * visually distinct from a real Supabase UUID. Never treat a "local-" userId as
 * a stable, shareable identity — it is meaningless to other clients.
 *
 * makeLocalProfile creates a minimal profile record from a wallet address with
 * all optional fields null and wallet_visibility defaulting to 'hidden'. It is
 * only used as a last-resort in-memory stand-in when both Supabase and an
 * existing localStorage entry are absent.
 */
function loadLocal(walletAddress: string): UserProfile | null {
  try {
    const raw = localStorage.getItem(localKey(walletAddress))
    if (!raw) return null
    return JSON.parse(raw) as UserProfile
  } catch {
    return null
  }
}

function saveLocal(profile: UserProfile): void {
  try {
    localStorage.setItem(localKey(profile.walletAddress), JSON.stringify(profile))
  } catch { /* quota / private mode — ignore */ }
}

function makeLocalProfile(walletAddress: string): UserProfile {
  const now = new Date().toISOString()
  return {
    userId: `local-${walletAddress.toLowerCase()}`,
    walletAddress: walletAddress.toLowerCase(),
    username: null,
    displayName: '',
    avatarUrl: null,
    bio: null,
    walletVisibility: 'hidden',
    createdAt: now,
    updatedAt: now,
  }
}

// ── Supabase client with per-wallet auth header ───────────────────────────────

/**
 * ⚠ Security note — x-wallet-address is NOT cryptographically verified.
 *
 * The RLS policy on the `profiles` table checks:
 *   lower(wallet_address) = lower(request.headers->>'x-wallet-address')
 *
 * This header is a plain HTTP header that any client can set to any value.
 * There is no signature, JWT, or other cryptographic proof that the requester
 * controls the private key for the wallet address they are asserting.
 *
 * Consequences:
 *   - Profile fields (username, displayName, bio, walletVisibility) are
 *     user-controlled cosmetic data. Treat them as self-asserted — not as
 *     trusted identity claims.
 *   - The `wallet_address unique` constraint is the only enforcement that
 *     prevents a new row being created for an already-claimed address. An
 *     attacker who knows another wallet address CAN update that profile's
 *     cosmetic fields.
 *   - wallet_address must never be used as a basis for security decisions
 *     from the profiles table alone (e.g. "this profile says wallet X is
 *     the project owner" is not safe — verify on-chain via verifiedOwners).
 *
 * Phase 3: this function has been REMOVED. Profile writes now use the
 * Supabase client's authenticated session (set by useAuth via
 * supabase.auth.setSession). The RLS policy checks auth.uid() = user_id,
 * which is cryptographically enforced by Supabase's own JWT validation.
 *
 * The old x-wallet-address header is no longer sent on the write path.
 * The anon `supabase` client is reused for writes — it picks up the JWT
 * automatically after useAuth calls supabase.auth.setSession().
 */

// ── Row → domain model ────────────────────────────────────────────────────────

interface ProfileRow {
  user_id: string
  wallet_address: string
  username: string | null
  display_name: string | null
  avatar_url: string | null
  bio: string | null
  wallet_visibility: string
  created_at: string
  updated_at: string
}

function rowToProfile(row: ProfileRow): UserProfile {
  return {
    userId: row.user_id,
    walletAddress: row.wallet_address.toLowerCase(),
    username: row.username ?? null,
    displayName: row.display_name ?? '',
    avatarUrl: row.avatar_url ?? null,
    bio: row.bio ?? null,
    walletVisibility: (row.wallet_visibility === 'public' ? 'public' : 'hidden'),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  }
}

// ── Hook ──────────────────────────────────────────────────────────────────────

export function useProfile(): UseProfileReturn {
  const { address, isConnected } = useAccount()
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // ── Resolve / create profile when wallet connects ──────────────────────────
  const resolveProfile = useCallback(async (walletAddress: string) => {
    setIsLoading(true)
    setError(null)

    // ── Supabase path (read-only — no write here) ────────────────────────────
    // Phase 3: profile creation is handled server-side in the auth-verify
    // Edge Function after signature verification. resolveProfile only reads.
    if (supabase) {
      try {
        const { data: existingRaw, error: fetchErr } = await supabase
          .from('profiles')
          .select('*')
          .eq('wallet_address', walletAddress.toLowerCase())
          .maybeSingle() as { data: ProfileRow | null; error: unknown }

        if (fetchErr) throw fetchErr instanceof Error ? fetchErr : new Error(JSON.stringify(fetchErr))

        if (existingRaw) {
          const p = rowToProfile(existingRaw)
          setProfile(p)
          saveLocal(p) // keep local in sync as read-through cache
          setIsLoading(false)
          return
        }

        // No profile yet — wallet has not authenticated yet (auth-verify creates it).
        // Use local fallback so the UI has something to show.
      } catch (e) {
        // Non-fatal — fall through to local fallback
        console.warn('[useProfile] Supabase unavailable, using localStorage fallback:', e)
      }
    }

    // ── Local fallback ───────────────────────────────────────────────────────
    const local = loadLocal(walletAddress) ?? makeLocalProfile(walletAddress)
    saveLocal(local)
    setProfile(local)
    setIsLoading(false)
  }, [])

  // Trigger resolve when wallet connects/changes
  useEffect(() => {
    if (isConnected && address) {
      void resolveProfile(address)
    } else {
      // Wallet disconnected — clear local state (Supabase row preserved)
      setProfile(null)
      setError(null)
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [address, isConnected])

  // ── Update profile fields ──────────────────────────────────────────────────
  const updateProfile = useCallback(async (payload: ProfileUpdatePayload): Promise<{ ok: boolean; error?: string }> => {
    if (!profile) return { ok: false, error: 'No profile loaded.' }

    // Validate username if provided
    if (payload.username !== undefined && payload.username !== null) {
      const result = validateUsername(payload.username)
      if (!result.valid) return { ok: false, error: result.reason }
      payload = { ...payload, username: normaliseUsername(payload.username) }
    }

    const now = new Date().toISOString()
    const updated: UserProfile = {
      ...profile,
      ...(payload.username !== undefined    ? { username: payload.username }             : {}),
      ...(payload.displayName !== undefined ? { displayName: payload.displayName }       : {}),
      ...(payload.avatarUrl !== undefined   ? { avatarUrl: payload.avatarUrl }           : {}),
      ...(payload.bio !== undefined         ? { bio: payload.bio }                       : {}),
      ...(payload.walletVisibility !== undefined ? { walletVisibility: payload.walletVisibility } : {}),
      updatedAt: now,
    }

    // Optimistic update
    setProfile(updated)
    saveLocal(updated)

    // ── Supabase path (Phase 3: uses authenticated session, not x-wallet-address) ──
    // The `supabase` client picks up the JWT session set by useAuth via
    // supabase.auth.setSession(). Supabase RLS: auth.uid() = user_id.
    // A missing/expired session means the update will be rejected by RLS (403).
    if (supabase) {
      const dbPayload: Record<string, unknown> = { updated_at: now }
      if (payload.username !== undefined)         dbPayload['username']          = payload.username
      if (payload.displayName !== undefined)      dbPayload['display_name']      = payload.displayName
      if (payload.avatarUrl !== undefined)        dbPayload['avatar_url']        = payload.avatarUrl
      if (payload.bio !== undefined)              dbPayload['bio']               = payload.bio
      if (payload.walletVisibility !== undefined) dbPayload['wallet_visibility'] = payload.walletVisibility

      const { error: updateErr } = await supabase
        .from('profiles')
        .update(dbPayload)
        .eq('wallet_address', profile.walletAddress.toLowerCase())

      if (updateErr) {
        const msg = (updateErr as { message?: string; code?: string }).message ?? ''
        const code = (updateErr as { message?: string; code?: string }).code ?? ''
        if (msg.includes('profiles_username_ci') || msg.includes('unique')) {
          // Roll back optimistic update on unique-constraint violation
          setProfile(profile)
          saveLocal(profile)
          return { ok: false, error: 'That username is already taken.' }
        }
        if (code === 'PGRST301' || msg.toLowerCase().includes('jwt') || msg.toLowerCase().includes('auth')) {
          // Session expired or missing — inform the caller so the UI can prompt re-auth
          setProfile(profile)
          saveLocal(profile)
          return { ok: false, error: 'Your session has expired. Please sign in again.' }
        }
        // Other DB errors — keep local optimistic update, warn
        console.warn('[useProfile] Supabase update error:', updateErr)
      }
    }

    return { ok: true }
  }, [profile])

  const refetch = useCallback(async () => {
    if (address && isConnected) await resolveProfile(address)
  }, [address, isConnected, resolveProfile])

  return { profile, isLoading, error, updateProfile, refetch }
}

// ── Standalone resolvers ────────────────────────────────────────────────────

/**
 * Fetch the public profile for any wallet address.
 * Used by ProfilePage to show identity info without requiring a connection.
 * Returns null when not found or Supabase is absent.
 */
export async function fetchPublicProfile(walletAddress: string): Promise<UserProfile | null> {
  if (!supabase) {
    return loadLocal(walletAddress)
  }
  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('wallet_address', walletAddress.toLowerCase())
      .maybeSingle() as { data: ProfileRow | null; error: unknown }
    if (error || !data) return null
    return rowToProfile(data)
  } catch {
    return null
  }
}

/**
 * Fetch a public profile by username (case-insensitive).
 * Used for username-based routing (/profile/@alice).
 * Returns null when not found, username is null, or Supabase is absent.
 */
export async function fetchProfileByUsername(username: string): Promise<UserProfile | null> {
  if (!supabase) return null
  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .ilike('username', username)
      .maybeSingle() as { data: ProfileRow | null; error: unknown }
    if (error || !data) return null
    return rowToProfile(data)
  } catch {
    return null
  }
}
