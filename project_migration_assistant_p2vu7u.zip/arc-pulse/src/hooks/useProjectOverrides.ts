/**
 * useProjectOverrides
 *
 * Fetches project_overrides from Supabase and exposes an applyOverrides()
 * function that merges the overrides onto a Project[] list at runtime.
 *
 * Tables:
 *   project_overrides  — slug-keyed override layer for name/tagline/description/
 *                        website/status/statusNote/verifiedBadgeHidden
 *   project_edit_log   — append-only audit trail for all edits
 */
import { useState, useEffect, useCallback } from 'react'
import { supabase, getAdminClient } from '../lib/supabase'
import type { Project } from '../data/projects'

export type ProjectStatus =
  | 'active'
  | 'inactive'
  | 'discontinued'
  | 'under_review'
  | 'delisted'

export interface ProjectOverride {
  id: string                    // project slug
  name?: string | null
  tagline?: string | null
  description?: string | null
  website?: string | null
  logo_url?: string | null
  status: ProjectStatus
  status_note?: string | null
  verified_badge_hidden: boolean
  updated_at?: string
}

export interface UseProjectOverridesResult {
  overrides: Record<string, ProjectOverride>
  applyOverrides: (projects: Project[]) => Project[]
  saveOverride: (
    projectId: string,
    patch: Partial<Omit<ProjectOverride, 'id'>>,
    ownerAddress?: string,
    previousValues?: Record<string, unknown>,
    action?: string,
  ) => Promise<void>
  isLoading: boolean
  refetch: () => void
}

export function useProjectOverrides(): UseProjectOverridesResult {
  const [overrides, setOverrides] = useState<Record<string, ProjectOverride>>({})
  const [isLoading, setIsLoading] = useState(Boolean(supabase))
  const [refetchTick, setRefetchTick] = useState(0)

  const refetch = useCallback(() => setRefetchTick((t) => t + 1), [])

  useEffect(() => {
    if (!supabase) return
    let cancelled = false

    const run = async () => {
      try {
        const { data, error } = await supabase!
          .from('project_overrides')
          .select('id, name, tagline, description, website, logo_url, status, status_note, verified_badge_hidden, updated_at')

        if (cancelled) return
        if (error || !data) { setIsLoading(false); return }

        const map: Record<string, ProjectOverride> = {}
        for (const row of data as ProjectOverride[]) {
          map[row.id] = row
        }
        if (!cancelled) {
          setOverrides(map)
          setIsLoading(false)
        }
      } catch {
        if (!cancelled) setIsLoading(false)
      }
    }

    void run()
    return () => { cancelled = true }
  }, [refetchTick])

  const applyOverrides = useCallback((projects: Project[]): Project[] => {
    return projects.map((p) => {
      const ov = overrides[p.id]
      if (!ov) return p
      return {
        ...p,
        name:               ov.name        ?? p.name,
        tagline:            ov.tagline     ?? p.tagline,
        description:        ov.description ?? p.description,
        website:            ov.website     ?? p.website,
        logoUrl:            ov.logo_url    ?? p.logoUrl,
        status:             ov.status,
        statusNote:         ov.status_note ?? undefined,
        verifiedBadgeHidden: ov.verified_badge_hidden,
      }
    })
  }, [overrides])

  const saveOverride = useCallback(async (
    projectId: string,
    patch: Partial<Omit<ProjectOverride, 'id'>>,
    ownerAddress?: string,
    previousValues?: Record<string, unknown>,
    action = 'edited',
  ) => {
    const client = ownerAddress ? getAdminClient(ownerAddress) : null
    if (!client) return

    // Optimistic update
    setOverrides((prev) => {
      const existing = prev[projectId] ?? { id: projectId, status: 'active' as const, verified_badge_hidden: false }
      return {
        ...prev,
        [projectId]: { ...existing, ...patch },
      }
    })

    await client.from('project_overrides').upsert({
      id: projectId,
      ...patch,
      updated_at: new Date().toISOString(),
    }, { onConflict: 'id' })

    // Append audit log entry
    await client.from('project_edit_log').insert({
      project_id: projectId,
      editor_address: ownerAddress,
      action,
      previous_value: previousValues ?? null,
      new_value: patch,
    })
  }, [])

  return { overrides, applyOverrides, saveOverride, isLoading, refetch }
}
