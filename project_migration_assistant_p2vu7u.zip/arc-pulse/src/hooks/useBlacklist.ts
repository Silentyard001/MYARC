/**
 * useBlacklist
 *
 * Fetches the wallet blacklist from Supabase `blacklisted_wallets` table.
 * Writes use getAdminClient() (session-bearing client; JWT wallet_address claim verified by RLS).
 *
 * Returns:
 *   blacklistedAddresses  — Set<string> of lowercase addresses
 *   blacklistRows         — full row data for the admin panel
 *   isBlacklisted         — (address: string) => boolean helper
 *   blacklistWallet       — add a wallet to the blacklist
 *   unblacklistWallet     — remove a wallet from the blacklist
 *   isLoading             — true while fetching
 *   refetch               — re-fetch manually
 */
import { useState, useEffect, useCallback } from 'react'
import { supabase, getAdminClient } from '../lib/supabase'

export interface BlacklistedWalletRow {
  id: string
  address: string
  reason: string | null
  blacklisted_at: string
  blacklisted_by: string
}

export interface UseBlacklistReturn {
  blacklistedAddresses: Set<string>
  blacklistRows: BlacklistedWalletRow[]
  isBlacklisted: (address: string) => boolean
  blacklistWallet: (address: string, reason?: string) => Promise<void>
  unblacklistWallet: (address: string) => Promise<void>
  isLoading: boolean
  refetch: () => void
}

export function useBlacklist(connectedAddress?: string): UseBlacklistReturn {
  const [rows, setRows] = useState<BlacklistedWalletRow[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [tick, setTick] = useState(0)

  const refetch = useCallback(() => setTick((t) => t + 1), [])

  useEffect(() => {
    if (!supabase) return
    let cancelled = false

    const load = async () => {
      setIsLoading(true)
      const { data, error } = await supabase!
        .from('blacklisted_wallets')
        .select('*')
        .order('blacklisted_at', { ascending: false })
      if (cancelled) return
      if (!error && data) setRows(data as BlacklistedWalletRow[])
      setIsLoading(false)
    }

    void load()
    return () => { cancelled = true }
  }, [tick])

  const blacklistedAddresses = new Set<string>(rows.map((r) => r.address.toLowerCase()))

  const isBlacklisted = useCallback(
    (address: string) => blacklistedAddresses.has(address.toLowerCase()),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [rows]
  )

  const blacklistWallet = useCallback(async (address: string, reason?: string) => {
    if (!connectedAddress) return
    const client = getAdminClient(connectedAddress)
    if (!client) return

    await client.from('blacklisted_wallets').insert({
      address:         address.toLowerCase(),
      reason:          reason ?? null,
      blacklisted_by:  connectedAddress.toLowerCase(),
    })

    refetch()
  }, [connectedAddress, refetch])

  const unblacklistWallet = useCallback(async (address: string) => {
    if (!connectedAddress) return
    const client = getAdminClient(connectedAddress)
    if (!client) return

    await client
      .from('blacklisted_wallets')
      .delete()
      .eq('address', address.toLowerCase())

    refetch()
  }, [connectedAddress, refetch])

  return {
    blacklistedAddresses,
    blacklistRows: rows,
    isBlacklisted,
    blacklistWallet,
    unblacklistWallet,
    isLoading,
    refetch,
  }
}
