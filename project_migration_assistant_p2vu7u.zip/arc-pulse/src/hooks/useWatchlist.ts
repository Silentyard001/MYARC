/**
 * useWatchlist
 *
 * Manages a localStorage-backed list of watched project slugs and computes
 * sentiment-shift alerts every 60 seconds against a snapshot.
 *
 * Storage keys:
 *   myarc:watchlist          — string[]  (slug array)
 *   myarc:watchlist-snapshot — Record<string, { bullish: number; neutral: number; bearish: number }>
 */
import { useEffect, useCallback, useRef } from 'react'
import type { Project } from '../data/projects'
import { useLocalStorage } from './useLocalStorage'

export type AlertEntry = {
  id: string
  projectId: string
  projectName: string
  direction: 'bullish' | 'bearish'
  delta: number
  timestamp: number
  read: boolean
}

type SentimentSnapshot = {
  bullishPct: number
  neutralPct: number
  bearishPct: number
}

function computePcts(votes: { bullish: number; neutral: number; bearish: number }): SentimentSnapshot {
  const total = votes.bullish + votes.neutral + votes.bearish
  if (total === 0) return { bullishPct: 33, neutralPct: 34, bearishPct: 33 }
  return {
    bullishPct: Math.round((votes.bullish / total) * 100),
    neutralPct: Math.round((votes.neutral / total) * 100),
    bearishPct: Math.round((votes.bearish / total) * 100),
  }
}

export interface UseWatchlistReturn {
  watchlist: string[]
  toggleWatchlist: (slug: string) => void
  isWatched: (slug: string) => boolean
  alerts: AlertEntry[]
  unreadCount: number
  markAlertsRead: () => void
}

export function useWatchlist(projects: Project[]): UseWatchlistReturn {
  const [watchlist, setWatchlist] = useLocalStorage<string[]>('myarc:watchlist', [])
  const [snapshot, setSnapshot] = useLocalStorage<Record<string, SentimentSnapshot>>(
    'myarc:watchlist-snapshot',
    {}
  )
  const [alerts, setAlerts] = useLocalStorage<AlertEntry[]>('myarc:alerts', [])

  const projectsRef = useRef(projects)
  projectsRef.current = projects

  const snapshotRef = useRef(snapshot)
  snapshotRef.current = snapshot

  const watchlistRef = useRef(watchlist)
  watchlistRef.current = watchlist

  const toggleWatchlist = useCallback((slug: string) => {
    setWatchlist((prev) =>
      prev.includes(slug) ? prev.filter((s) => s !== slug) : [...prev, slug]
    )
  }, [setWatchlist])

  const isWatched = useCallback((slug: string) => watchlist.includes(slug), [watchlist])

  const markAlertsRead = useCallback(() => {
    setAlerts((prev) => prev.map((a) => ({ ...a, read: true })))
  }, [setAlerts])

  // On mount and every 60 seconds: check for sentiment shifts on watched projects
  useEffect(() => {
    function checkAlerts() {
      const currentWatchlist = watchlistRef.current
      const currentSnapshot = snapshotRef.current
      const currentProjects = projectsRef.current
      const newAlerts: AlertEntry[] = []
      const newSnapshot: Record<string, SentimentSnapshot> = { ...currentSnapshot }

      for (const slug of currentWatchlist) {
        const project = currentProjects.find((p) => p.id === slug)
        if (!project) continue

        const current = computePcts(project.votes)
        const prev = currentSnapshot[slug]

        if (prev) {
          const bullishDelta = current.bullishPct - prev.bullishPct
          const bearishDelta = current.bearishPct - prev.bearishPct

          if (bullishDelta >= 15) {
            newAlerts.push({
              id: `alert-${slug}-bullish-${Date.now()}`,
              projectId: slug,
              projectName: project.name,
              direction: 'bullish',
              delta: bullishDelta,
              timestamp: Date.now(),
              read: false,
            })
          } else if (bearishDelta >= 15) {
            newAlerts.push({
              id: `alert-${slug}-bearish-${Date.now()}`,
              projectId: slug,
              projectName: project.name,
              direction: 'bearish',
              delta: bearishDelta,
              timestamp: Date.now(),
              read: false,
            })
          }
        }

        newSnapshot[slug] = current
      }

      if (newAlerts.length > 0) {
        setAlerts((prev) => [...newAlerts, ...prev].slice(0, 50))
      }
      setSnapshot(newSnapshot)
    }

    // Run immediately on mount
    checkAlerts()

    const interval = setInterval(checkAlerts, 60_000)
    return () => clearInterval(interval)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const unreadCount = alerts.filter((a) => !a.read).length

  return { watchlist, toggleWatchlist, isWatched, alerts, unreadCount, markAlertsRead }
}
