/**
 * useVoteBySig
 *
 * Collects an EIP-712 signature from the connected wallet and submits it
 * via MYARC.voteBySig — letting the signer vote without needing USDC
 * for gas (the relayer / caller pays).
 *
 * Falls back to the direct vote() call when no contract address is
 * configured (pre-deploy dev mode).
 *
 * EIP-712 domain MUST include verifyingContract so the signature binds
 * to the specific deployed contract — omitting it is a common bug.
 */

import { useCallback, useEffect, useRef } from 'react'
import { useAccount, useSignTypedData, useReadContract, usePublicClient } from 'wagmi'
import { toast } from 'sonner'
import type { Abi } from 'viem'
import { useSimulatedWrite } from './useSimulatedWrite'
import { ARC_TESTNET_CHAIN_ID } from '../config'

// Minimal ABI for the functions used here
export const MYARC_ABI = [
  {
    name: 'vote',
    type: 'function',
    stateMutability: 'nonpayable',
    inputs: [
      { name: 'projectId', type: 'bytes32' },
      { name: 'sentiment', type: 'uint8' },
    ],
    outputs: [],
  },
  {
    name: 'retractVote',
    type: 'function',
    stateMutability: 'nonpayable',
    inputs: [{ name: 'projectId', type: 'bytes32' }],
    outputs: [],
  },
  {
    name: 'postReview',
    type: 'function',
    stateMutability: 'nonpayable',
    inputs: [
      { name: 'projectId', type: 'bytes32' },
      { name: 'sentiment', type: 'uint8' },
      { name: 'body', type: 'string' },
    ],
    outputs: [],
  },
  {
    name: 'voteBySig',
    type: 'function',
    stateMutability: 'nonpayable',
    inputs: [
      { name: 'projectId', type: 'bytes32' },
      { name: 'sentiment', type: 'uint8' },
      { name: 'nonce', type: 'uint256' },
      { name: 'deadline', type: 'uint256' },
      { name: 'signature', type: 'bytes' },
    ],
    outputs: [],
  },
  {
    name: 'nonces',
    type: 'function',
    stateMutability: 'view',
    inputs: [{ name: 'signer', type: 'address' }],
    outputs: [{ name: '', type: 'uint256' }],
  },
  {
    name: 'tallies',
    type: 'function',
    stateMutability: 'view',
    inputs: [{ name: 'projectId', type: 'bytes32' }],
    outputs: [
      { name: 'bullish', type: 'uint128' },
      { name: 'neutral', type: 'uint128' },
      { name: 'bearish', type: 'uint128' },
    ],
  },
  {
    name: 'getVote',
    type: 'function',
    stateMutability: 'view',
    inputs: [
      { name: 'voter', type: 'address' },
      { name: 'projectId', type: 'bytes32' },
    ],
    outputs: [{ name: '', type: 'uint8' }],
  },
  {
    name: 'reviewCount',
    type: 'function',
    stateMutability: 'view',
    inputs: [{ name: 'projectId', type: 'bytes32' }],
    outputs: [{ name: '', type: 'uint256' }],
  },
  // ── batchVote ─────────────────────────────────────────────────────────────
  {
    name: 'batchVote',
    type: 'function',
    stateMutability: 'nonpayable',
    inputs: [
      { name: 'projectIds', type: 'bytes32[]' },
      { name: 'sentiments', type: 'uint8[]' },
    ],
    outputs: [],
  },
  {
    name: 'MAX_BATCH_SIZE',
    type: 'function',
    stateMutability: 'view',
    inputs: [],
    outputs: [{ name: '', type: 'uint256' }],
  },
  // ── Review flagging ───────────────────────────────────────────────────────
  {
    name: 'flagReview',
    type: 'function',
    stateMutability: 'nonpayable',
    inputs: [
      { name: 'projectId', type: 'bytes32' },
      { name: 'reviewIndex', type: 'uint256' },
    ],
    outputs: [],
  },
  {
    name: 'reviewFlags',
    type: 'function',
    stateMutability: 'view',
    inputs: [
      { name: 'projectId', type: 'bytes32' },
      { name: 'reviewIndex', type: 'uint256' },
    ],
    outputs: [{ name: '', type: 'uint256' }],
  },
  {
    name: 'hasFlaggerFlagged',
    type: 'function',
    stateMutability: 'view',
    inputs: [
      { name: 'projectId', type: 'bytes32' },
      { name: 'reviewIndex', type: 'uint256' },
      { name: 'flagger', type: 'address' },
    ],
    outputs: [{ name: '', type: 'bool' }],
  },
  // ── Epoch functions ───────────────────────────────────────────────────────
  {
    name: 'currentEpoch',
    type: 'function',
    stateMutability: 'view',
    inputs: [],
    outputs: [{ name: '', type: 'uint256' }],
  },
  {
    name: 'epochDuration',
    type: 'function',
    stateMutability: 'view',
    inputs: [],
    outputs: [{ name: '', type: 'uint256' }],
  },
  {
    name: 'epochStart',
    type: 'function',
    stateMutability: 'view',
    inputs: [],
    outputs: [{ name: '', type: 'uint256' }],
  },
  {
    name: 'epochTallies',
    type: 'function',
    stateMutability: 'view',
    inputs: [
      { name: 'epoch', type: 'uint256' },
      { name: 'projectId', type: 'bytes32' },
    ],
    outputs: [
      { name: 'bullish', type: 'uint128' },
      { name: 'neutral', type: 'uint128' },
      { name: 'bearish', type: 'uint128' },
    ],
  },
  // ── Events ────────────────────────────────────────────────────────────────
  {
    name: 'ReviewFlagged',
    type: 'event',
    inputs: [
      { name: 'projectId', type: 'bytes32', indexed: true },
      { name: 'reviewIndex', type: 'uint256', indexed: true },
      { name: 'flagger', type: 'address', indexed: true },
      { name: 'totalFlags', type: 'uint256', indexed: false },
    ],
  },
] as const satisfies Abi

const VOTE_TYPES = {
  Vote: [
    { name: 'projectId', type: 'bytes32' },
    { name: 'sentiment', type: 'uint8' },
    { name: 'nonce', type: 'uint256' },
    { name: 'deadline', type: 'uint256' },
  ],
} as const

interface UseVoteBySigOptions {
  contractAddress: `0x${string}` | undefined
}

export function useVoteBySig({ contractAddress }: UseVoteBySigOptions) {
  const { address } = useAccount()
  const { signTypedDataAsync } = useSignTypedData()
  const { simulateAndWrite, isPending } = useSimulatedWrite()
  const publicClient = usePublicClient({ chainId: ARC_TESTNET_CHAIN_ID })

  // Cache MAX_BATCH_SIZE from the contract; fall back to 50 (the known constant)
  // so batching works even before the read completes.
  const maxBatchSizeRef = useRef<number>(50)

  useEffect(() => {
    if (!contractAddress || !publicClient) return
    let cancelled = false
    publicClient
      .readContract({
        address: contractAddress,
        abi: MYARC_ABI,
        functionName: 'MAX_BATCH_SIZE',
      })
      .then((val) => {
        if (!cancelled) maxBatchSizeRef.current = Number(val)
      })
      .catch(() => { /* keep fallback */ })
    return () => { cancelled = true }
  }, [contractAddress, publicClient])

  // Fetch the signer's current nonce from the contract
  const { data: currentNonce } = useReadContract({
    address: contractAddress,
    abi: MYARC_ABI,
    functionName: 'nonces',
    args: address ? [address] : undefined,
    chainId: ARC_TESTNET_CHAIN_ID,
    query: { enabled: Boolean(contractAddress && address) },
  })

  /** Cast a vote using EIP-712 gasless path. */
  const voteBySig = useCallback(
    async (projectId: `0x${string}`, sentiment: 0 | 1 | 2): Promise<boolean> => {
      if (!address || !contractAddress) {
        toast.error('Connect your wallet to vote.')
        return false
      }
      if (currentNonce === undefined) {
        toast.error('Unable to fetch nonce — please try again.')
        return false
      }

      const deadline = BigInt(Math.floor(Date.now() / 1000) + 1800)

      // EIP-712 domain MUST include verifyingContract — without it the
      // contract's domain separator won't match and the sig will be rejected.
      const domain = {
        name: 'MYARC',
        version: '1',
        chainId: ARC_TESTNET_CHAIN_ID,
        verifyingContract: contractAddress,
      } as const

      let signature: `0x${string}`
      try {
        signature = await signTypedDataAsync({
          domain,
          types: VOTE_TYPES,
          primaryType: 'Vote',
          message: {
            projectId,
            sentiment,
            nonce: currentNonce,
            deadline,
          },
        })
      } catch {
        // User cancelled — stay silent
        return false
      }

      const txHash = await simulateAndWrite({
        address: contractAddress,
        abi: MYARC_ABI,
        functionName: 'voteBySig',
        args: [projectId, sentiment, currentNonce, deadline, signature],
        chainId: ARC_TESTNET_CHAIN_ID,
      })

      return txHash !== null
    },
    [address, contractAddress, currentNonce, signTypedDataAsync, simulateAndWrite]
  )

  /** Cast a vote directly (no sig, caller pays gas). */
  const voteDirectly = useCallback(
    async (projectId: `0x${string}`, sentiment: 0 | 1 | 2): Promise<boolean> => {
      if (!address || !contractAddress) {
        toast.error('Connect your wallet to vote.')
        return false
      }

      const txHash = await simulateAndWrite({
        address: contractAddress,
        abi: MYARC_ABI,
        functionName: 'vote',
        args: [projectId, sentiment],
        chainId: ARC_TESTNET_CHAIN_ID,
      })

      return txHash !== null
    },
    [address, contractAddress, simulateAndWrite]
  )

  /** Retract an existing vote. */
  const retractVote = useCallback(
    async (projectId: `0x${string}`): Promise<boolean> => {
      if (!address || !contractAddress) {
        toast.error('Connect your wallet to retract.')
        return false
      }

      const txHash = await simulateAndWrite({
        address: contractAddress,
        abi: MYARC_ABI,
        functionName: 'retractVote',
        args: [projectId],
        chainId: ARC_TESTNET_CHAIN_ID,
      })

      return txHash !== null
    },
    [address, contractAddress, simulateAndWrite]
  )

  /** Post a review onchain. */
  const postReview = useCallback(
    async (projectId: `0x${string}`, sentiment: 0 | 1 | 2, body: string): Promise<boolean> => {
      if (!address || !contractAddress) {
        toast.error('Connect your wallet to post a review.')
        return false
      }

      const txHash = await simulateAndWrite({
        address: contractAddress,
        abi: MYARC_ABI,
        functionName: 'postReview',
        args: [projectId, sentiment, body],
        chainId: ARC_TESTNET_CHAIN_ID,
      })

      return txHash !== null
    },
    [address, contractAddress, simulateAndWrite]
  )

  /**
   * Cast votes on multiple projects, splitting into MAX_BATCH_SIZE chunks if
   * needed.  When more than one chunk is required, each submission shows a
   * "Submitting batch X of Y" toast.  On a chunk failure the function reports
   * how many votes were already submitted before it stopped.
   */
  const batchVoteDirectly = useCallback(
    async (
      projectIds: `0x${string}`[],
      sentiments: (0 | 1 | 2)[]
    ): Promise<boolean> => {
      if (!address || !contractAddress) {
        toast.error('Connect your wallet to batch vote.')
        return false
      }

      const chunkSize = maxBatchSizeRef.current
      const total = projectIds.length

      // Build chunks
      const chunks: Array<{ ids: `0x${string}`[]; sents: (0 | 1 | 2)[] }> = []
      for (let i = 0; i < total; i += chunkSize) {
        chunks.push({
          ids: projectIds.slice(i, i + chunkSize),
          sents: sentiments.slice(i, i + chunkSize),
        })
      }

      const numChunks = chunks.length
      let submitted = 0

      for (let ci = 0; ci < numChunks; ci++) {
        const { ids, sents } = chunks[ci]

        if (numChunks > 1) {
          toast(`Submitting batch ${ci + 1} of ${numChunks}…`, { duration: 3000 })
        }

        const txHash = await simulateAndWrite({
          address: contractAddress,
          abi: MYARC_ABI,
          functionName: 'batchVote',
          args: [ids, sents],
          chainId: ARC_TESTNET_CHAIN_ID,
        })

        if (txHash === null) {
          if (numChunks > 1) {
            toast.error(
              submitted === 0
                ? `Batch ${ci + 1} of ${numChunks} failed — no votes were submitted.`
                : `Batch ${ci + 1} of ${numChunks} failed — ${submitted} vote${submitted !== 1 ? 's' : ''} submitted before the error.`
            )
          }
          return false
        }

        submitted += ids.length
      }

      return true
    },
    [address, contractAddress, simulateAndWrite]
  )

  /** Flag a review for spam. */
  const flagReviewOnchain = useCallback(
    async (projectId: `0x${string}`, reviewIndex: bigint): Promise<boolean> => {
      if (!address || !contractAddress) {
        toast.error('Connect your wallet to flag a review.')
        return false
      }
      const txHash = await simulateAndWrite({
        address: contractAddress,
        abi: MYARC_ABI,
        functionName: 'flagReview',
        args: [projectId, reviewIndex],
        chainId: ARC_TESTNET_CHAIN_ID,
      })
      return txHash !== null
    },
    [address, contractAddress, simulateAndWrite]
  )

  return {
    voteBySig,
    voteDirectly,
    retractVote,
    postReview,
    batchVoteDirectly,
    flagReviewOnchain,
    isPending,
  }
}
