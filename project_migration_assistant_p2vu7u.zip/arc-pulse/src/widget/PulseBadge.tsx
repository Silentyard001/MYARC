/**
 * PulseBadge — self-contained embeddable sentiment badge.
 *
 * No wagmi, no app providers, no global CSS. Creates its own viem publicClient.
 * All styles are namespaced with `myarc-badge__` and scoped to the root element.
 * CSS variables are declared inline on the root element — they do not leak to the host.
 */

import { useState, useEffect, useRef } from 'react'
import { createPublicClient, http, parseAbi } from 'viem'
import { slugToBytes32 } from '../utils/projectId'

// ── Types ─────────────────────────────────────────────────────────────────────

export interface PulseBadgeProps {
  projectId: string
  contractAddress: string
  rpcUrl?: string
  theme?: 'dark' | 'light'
  size?: 'sm' | 'md' | 'lg'
}

// ── Sizing config ─────────────────────────────────────────────────────────────

const SIZE_CONFIG = {
  sm: { width: 120, height: 48, pct: '1.1rem', label: '0.55rem', icon: 10 },
  md: { width: 200, height: 72, pct: '1.7rem', label: '0.7rem',  icon: 14 },
  lg: { width: 280, height: 96, pct: '2.2rem', label: '0.8rem',  icon: 18 },
} as const

// ── ABI ───────────────────────────────────────────────────────────────────────

const TALLIES_ABI = parseAbi([
  'function tallies(bytes32 projectId) view returns (uint128 bullish, uint128 neutral, uint128 bearish)',
  'function getVerifiedOwner(bytes32 projectId) view returns (address)',
])

// ── Pulse wave SVG ────────────────────────────────────────────────────────────

function PulseWave({ size, color }: { size: number; color: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <polyline
        points="2,12 6,12 8,6 10,18 12,4 14,20 16,8 18,14 22,12"
        stroke={color}
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
    </svg>
  )
}

// ── Verified checkmark ────────────────────────────────────────────────────────

function VerifiedIcon({ size, color }: { size: number; color: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path
        d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
        stroke={color}
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <polyline points="9,12 11,14 15,10" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

// ── Counter animation hook ────────────────────────────────────────────────────

function useCountUp(target: number, durationMs: number, enabled: boolean): number {
  // Initialize to target immediately when animation is disabled (avoids sync setState in effect)
  const [current, setCurrent] = useState(() => enabled ? 0 : target)
  const rafRef = useRef<number>(0)
  const startRef = useRef<number>(0)

  useEffect(() => {
    // When animation is disabled or target is 0, sync current to target via a microtask
    // so we never call setState synchronously inside the effect body.
    if (!enabled || target === 0) {
      const id = setTimeout(() => setCurrent(target), 0)
      return () => clearTimeout(id)
    }

    startRef.current = performance.now()
    const tick = (now: number) => {
      const elapsed = now - startRef.current
      const progress = Math.min(elapsed / durationMs, 1)
      // ease-out cubic
      const eased = 1 - Math.pow(1 - progress, 3)
      setCurrent(Math.round(eased * target))
      if (progress < 1) rafRef.current = requestAnimationFrame(tick)
    }
    rafRef.current = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(rafRef.current)
  }, [target, durationMs, enabled])

  return current
}

// ── Theme colors ──────────────────────────────────────────────────────────────

function themeVars(theme: 'dark' | 'light') {
  return theme === 'dark'
    ? {
        bg: '#0d1117',
        border: '#21262d',
        ink: '#e6edf3',
        ink2: '#8b949e',
        accent: '#1f6feb',
        bullish: '#3fb950',
        amber: '#d29922',
        bearish: '#f85149',
      }
    : {
        bg: '#ffffff',
        border: '#d0d7de',
        ink: '#1f2328',
        ink2: '#656d76',
        accent: '#0969da',
        bullish: '#1a7f37',
        amber: '#9a6700',
        bearish: '#cf222e',
      }
}

// ── PulseBadge component ──────────────────────────────────────────────────────

export function PulseBadge({
  projectId,
  contractAddress,
  rpcUrl = 'https://rpc.testnet.arc.io',
  theme = 'dark',
  size = 'md',
}: PulseBadgeProps) {
  const cfg = SIZE_CONFIG[size]
  const colors = themeVars(theme)

  const [bullishPct, setBullishPct] = useState<number | null>(null)
  const [isVerified, setIsVerified] = useState(false)
  // Initialize error to true when required props are missing — no sync setState needed in effect
  const [error, setError] = useState(() => !contractAddress || !projectId)

  // Respect prefers-reduced-motion
  const [reducedMotion] = useState(() =>
    typeof window !== 'undefined'
      ? window.matchMedia('(prefers-reduced-motion: reduce)').matches
      : false
  )

  const displayPct = useCountUp(bullishPct ?? 0, 800, !reducedMotion && bullishPct !== null)

  useEffect(() => {
    if (!contractAddress || !projectId) return

    const client = createPublicClient({
      transport: http(rpcUrl, { retryCount: 2, timeout: 8000 }),
    })

    const projectIdBytes32 = slugToBytes32(projectId)
    const addr = contractAddress as `0x${string}`

    async function load() {
      try {
        const [tally, owner] = await Promise.all([
          client.readContract({
            address: addr,
            abi: TALLIES_ABI,
            functionName: 'tallies',
            args: [projectIdBytes32],
          }),
          client.readContract({
            address: addr,
            abi: TALLIES_ABI,
            functionName: 'getVerifiedOwner',
            args: [projectIdBytes32],
          }),
        ])

        const [bullish, neutral, bearish] = tally as [bigint, bigint, bigint]
        const total = Number(bullish + neutral + bearish)
        setBullishPct(total > 0 ? Math.round((Number(bullish) / total) * 100) : 0)

        const ownerAddr = owner as string
        setIsVerified(
          ownerAddr !== '0x0000000000000000000000000000000000000000' &&
          ownerAddr !== undefined
        )
      } catch {
        setError(true)
      }
    }

    void load()
  }, [projectId, contractAddress, rpcUrl])

  const pctColor =
    bullishPct === null
      ? colors.ink2
      : bullishPct >= 60
      ? colors.bullish
      : bullishPct >= 40
      ? colors.amber
      : colors.bearish

  const appUrl = typeof window !== 'undefined'
    ? `${window.location.origin}/?project=${encodeURIComponent(projectId)}`
    : `https://myarc.io/?project=${encodeURIComponent(projectId)}`

  // Inline styles — fully isolated, no global CSS
  const rootStyle: React.CSSProperties = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: size === 'sm' ? '6px' : '10px',
    width: `${cfg.width}px`,
    height: `${cfg.height}px`,
    padding: size === 'sm' ? '0 8px' : size === 'md' ? '0 14px' : '0 18px',
    background: colors.bg,
    border: `1px solid ${colors.border}`,
    borderRadius: '10px',
    boxSizing: 'border-box',
    fontFamily: '"DM Sans", "Inter", system-ui, sans-serif',
    textDecoration: 'none',
    cursor: 'pointer',
    overflow: 'hidden',
    flexShrink: 0,
    position: 'relative',
  }

  if (error) {
    return (
      <a
        href={appUrl}
        target="_blank"
        rel="noopener noreferrer"
        style={rootStyle}
        className="myarc-badge__root myarc-badge__error"
      >
        <PulseWave size={cfg.icon} color={colors.ink2} />
        <span style={{ fontSize: cfg.label, color: colors.ink2, lineHeight: 1.3 }}>
          MYARC
          <br />
          <span style={{ opacity: 0.6 }}>unavailable</span>
        </span>
      </a>
    )
  }

  const loading = bullishPct === null

  return (
    <a
      href={appUrl}
      target="_blank"
      rel="noopener noreferrer"
      style={rootStyle}
      className="myarc-badge__root"
      title={`View ${projectId} on MYARC`}
    >
      {/* Pulse wave logo */}
      <PulseWave size={cfg.icon} color={loading ? colors.ink2 : pctColor} />

      {/* Content */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '1px', minWidth: 0 }}>
        {/* Percentage */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '4px',
          lineHeight: 1,
        }}>
          <span style={{
            fontSize: cfg.pct,
            fontWeight: 700,
            color: loading ? colors.ink2 : pctColor,
            fontVariantNumeric: 'tabular-nums',
            letterSpacing: '-0.02em',
            opacity: loading ? 0.4 : 1,
            transition: 'color 0.3s ease, opacity 0.3s ease',
          }}>
            {loading ? '--' : `${displayPct}%`}
          </span>
          {isVerified && !loading && size !== 'sm' && (
            <VerifiedIcon size={cfg.icon - 2} color={colors.accent} />
          )}
        </div>

        {/* Label row */}
        {size !== 'sm' && (
          <span style={{
            fontSize: cfg.label,
            color: colors.ink2,
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
          }}>
            Bullish · MYARC
          </span>
        )}
      </div>
    </a>
  )
}

// ── IIFE browser mount API ─────────────────────────────────────────────────────

/**
 * PulseBadge.mount(target, props)
 *
 * target: CSS selector string or DOM element
 * props:  PulseBadgeProps
 *
 * Example:
 *   PulseBadge.mount('#my-badge', { projectId: 'arcswap', contractAddress: '0x...' })
 */
export function mount(
  target: string | Element,
  props: PulseBadgeProps
): void {
  // Dynamic import of ReactDOM to keep tree-shaking possible in ES build
  void import('react-dom/client')
    .then(({ createRoot }) =>
      import('react').then(({ createElement }) => {
        const el = typeof target === 'string' ? document.querySelector(target) : target
        if (!el) { console.error('[PulseBadge] target not found:', target); return }
        createRoot(el).render(createElement(PulseBadge, props))
      })
    )
    .catch((err: unknown) => console.error('[PulseBadge] mount failed:', err))
}
