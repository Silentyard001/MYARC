/**
 * Widget entry point — exported for both IIFE and ES module builds.
 *
 * IIFE build:  exposes `window.PulseBadge` with `mount()` and `PulseBadge`
 * ES build:    named exports for bundler / npm consumption
 */
export { PulseBadge, mount } from './PulseBadge'
export type { PulseBadgeProps } from './PulseBadge'
