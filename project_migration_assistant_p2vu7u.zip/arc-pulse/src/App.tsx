import { useState, useMemo, useCallback, useEffect, useRef } from 'react'
import { BrowserRouter, Routes, Route, useParams } from 'react-router-dom'
import { motion, AnimatePresence, useReducedMotion } from 'framer-motion'
import { ConnectKitButton } from 'connectkit'
import { useAccount } from 'wagmi'
import { LayoutGrid, BarChart2, Vote, Search, TrendingUp, Zap, Info, Activity, PlusCircle, Target, Bell, Bookmark, Settings, Flame, RefreshCw } from 'lucide-react'
import { toast } from 'sonner'

import { PROJECTS, type Project, type Sentiment, type VoteCounts } from './data/projects'
import { useTaxonomy } from './hooks/useTaxonomy'
import { useOnchainPolls } from './hooks/useOnchainPolls'
import { useSubmittedProjects } from './hooks/useSubmittedProjects'
import { ProjectCard } from './components/ProjectCard'
import { ProjectDetailSheet } from './components/ProjectDetailSheet'
import { PollWidget } from './components/PollWidget'
import { LeaderboardRow } from './components/LeaderboardRow'
import { NetworkGuard } from './components/NetworkGuard'
import { ThemeToggle } from './components/ThemeToggle'
import { SkeletonCard, SkeletonLeaderboardRow, SkeletonPollWidget } from './components/Skeleton'
import { TrendingStrip, type ProjectWithTrending } from './components/TrendingStrip'
import { FeaturedBanner } from './components/FeaturedBanner'
import { ProfilePage } from './components/ProfilePage'
import { ReputationBadge } from './components/ReputationBadge'
import { AnnouncementBanner } from './components/AnnouncementBanner'
import { ARC_TESTNET_CHAIN_ID } from './config'
import { useVoteBySig } from './hooks/useVoteBySig'
import { useUserActivity } from './hooks/useUserActivity'
import { useOnchainActivity } from './hooks/useOnchainActivity'
import { useLocalStorage } from './hooks/useLocalStorage'
import { useReputation } from './hooks/useReputation'
import { useVerifiedOwners } from './hooks/useVerifiedOwners'
import { useWatchlist } from './hooks/useWatchlist'
import { SubmitProjectModal } from './components/SubmitProjectModal'
import { AdminPanel } from './components/AdminPanel'
import { slugToBytes32, sentimentToUint8 } from './utils/projectId'
import { useProfile, fetchProfileByUsername } from './hooks/useProfile'
import { useAuth } from './hooks/useAuth'
import { useAdminConfig } from './hooks/useAdminConfig'
import { useProjectOverrides } from './hooks/useProjectOverrides'
import { useAnnouncements } from './hooks/useAnnouncements'
import { useBlacklist } from './hooks/useBlacklist'
import { usePlatformMomentum } from './hooks/usePlatformMomentum'
import { RisingCard } from './components/RisingCard'
import { MilestoneShareCard } from './components/MilestoneShareCard'
import { achievedMilestones } from './lib/momentum'
import { PulseBadge } from './widget/PulseBadge'

// ---------------------------------------------------------------------------
// Contract address — set VITE_MYARC_ADDRESS in .env after deploying.
// ---------------------------------------------------------------------------
const CONTRACT_ADDRESS = (import.meta.env.VITE_MYARC_ADDRESS as `0x${string}` | undefined) ?? undefined
const ONCHAIN_MODE = Boolean(CONTRACT_ADDRESS)

// StoredReview is exported so other components (ProfilePage, ProjectDetailSheet) can import it.
export type StoredReview = {
  id: string; author: string; authorFull: string
  body: string; sentiment: Sentiment; timestamp: number; helpful: number
}

type Tab = 'discover' | 'rising' | 'leaderboard' | 'polls' | 'activity'
type SortMode = 'bullish' | 'reviewed' | 'recent' | 'trending'
type VoteDeltas = Record<string, Partial<VoteCounts>>
// 'watched' is a filter mode, not a sort mode
type DiscoverFilter = 'tag' | 'watched'

const NOW = Date.now()
const H24 = 86400000

// ── Trending score helper ─────────────────────────────────────────────────────
function computeTrendingScore(project: Project, recentVoteCount: number): number {
  const reviews24h = project.reviews.filter((r) => NOW - r.timestamp < H24).length
  const total = project.votes.bullish + project.votes.neutral + project.votes.bearish
  const bullishPct = total > 0 ? project.votes.bullish / total : 0.5
  const bullishChange = Math.abs(bullishPct - 0.5) * 100
  return recentVoteCount * 3 + reviews24h * 5 + bullishChange * 2
}

function openProject(proj: Project, setter: (p: Project | null) => void) {
  setter(proj)
  const url = new URL(window.location.href)
  url.searchParams.set('project', proj.id)
  window.history.replaceState({}, '', url.toString())
}

function closeProject(setter: (p: Project | null) => void) {
  setter(null)
  const url = new URL(window.location.href)
  url.searchParams.delete('project')
  window.history.replaceState({}, '', url.toString())
}

// ── Activity tab labels (with unread badge) ───────────────────────────────────
// TAG_FILTERS are now driven by taxonomy categories (built at runtime in AppInner).
// 'All' is always the first option; rest come from activeCategories.
type TagFilter = string  // 'All' | any active category id

const SORT_OPTIONS: { value: SortMode; label: string }[] = [
  { value: 'bullish',  label: 'Most Bullish'  },
  { value: 'reviewed', label: 'Most Reviewed' },
  { value: 'recent',   label: 'Most Recent'   },
  { value: 'trending', label: 'Trending'      },
]

// ── Main app ─────────────────────────────────────────────────────────────────
function AppInner() {
  const { address, chainId, isConnected } = useAccount()
  const isWrongChain = isConnected && chainId !== undefined && chainId !== ARC_TESTNET_CHAIN_ID

  // ── Taxonomy ─────────────────────────────────────────────────────────────────
  const taxonomy = useTaxonomy()
  // Category filter chips: 'All' + active categories that have at least one project
  const TAG_FILTERS = useMemo(() => {
    const used = new Set<string>()
    // We'll derive this after allSeedProjects is available — use all active for now
    taxonomy.activeCategories.forEach((c) => used.add(c.id))
    return ['All', ...taxonomy.activeCategories.map((c) => c.id)]
  }, [taxonomy.activeCategories])

  // ── Profile identity (wallet → upsert profile on connect) ───────────────────
  // profile and updateProfile are used in ProfilePageWrapper (same file).
  // AppInner itself only needs the hook to trigger wallet→profile resolution.
  const { profile: _profile, updateProfile: _updateProfile } = useProfile()

  // ── Phase 3: wallet authentication (SIWE) ────────────────────────────────────
  // Called here to ensure session state is initialised at app startup.
  // ProfilePageWrapper calls useAuth() independently to get authStatus/signIn.
  useAuth()

  // ── Navigation ──────────────────────────────────────────────────────────────
  const [tab, setTab] = useState<Tab>('discover')

  // ── Persisted state ─────────────────────────────────────────────────────────
  const [userVotes, setUserVotes] = useLocalStorage<Record<string, Sentiment>>('myarc:votes', {})
  const [pollVotes, setPollVotes] = useLocalStorage<Record<string, string>>('myarc:poll-votes', {})
  const [voteDeltas, setVoteDeltas] = useLocalStorage<VoteDeltas>('myarc:vote-deltas', {})
  const [pollDeltaMap, setPollDeltaMap] = useLocalStorage<Record<string, Record<string, number>>>('myarc:poll-deltas', {})
  const [reviewOverrides, setReviewOverrides] = useLocalStorage<Record<string, StoredReview[]>>('myarc:reviews', {})
  const [seedHelpfulDeltas, setSeedHelpfulDeltas] = useLocalStorage<Record<string, number>>('myarc:helpful-deltas', {})
  const [helpfulVoted, setHelpfulVoted] = useLocalStorage<Record<string, boolean>>('myarc:helpful', {})
  // Submitted projects from Supabase (approved only). Falls back to empty array
  // when Supabase is not configured — SubmitProjectModal uses onSubmit fallback in that case.
  const { submittedProjects, refetch: refetchSubmitted } = useSubmittedProjects()

  // Polls from Supabase onchain_polls table + seed POLLS as fallback
  const { polls: onchainPollList } = useOnchainPolls(CONTRACT_ADDRESS)
  /** Owner can override project description + website */
  const [projectOverrides, setProjectOverrides] = useLocalStorage<Record<string, Partial<Project>>>('myarc:project-overrides', {})

  // ── Admin config (must be before derived project/poll state) ─────────────
  const adminConfig = useAdminConfig()
  const { featuredIds, sponsoredPolls: sponsoredPollsConfig } = adminConfig

  // ── Project overrides (status, field edits, verified badge suppression) ──
  const { applyOverrides, saveOverride: saveProjectOverride, refetch: refetchOverrides } = useProjectOverrides()

  // ── Announcements ─────────────────────────────────────────────────────────
  const { announcements } = useAnnouncements()

  // ── Blacklist ─────────────────────────────────────────────────────────────
  const blacklist = useBlacklist(address)

  // ── Derived project state ────────────────────────────────────────────────────
  const allSeedProjects = useMemo(
    () => applyOverrides(
      [...submittedProjects, ...PROJECTS].map((p) => ({ ...p, featured: featuredIds.has(p.id) }))
    ),
    [submittedProjects, featuredIds, applyOverrides]
  )

  const projects = useMemo(() =>
    allSeedProjects.map((p) => {
      const d = voteDeltas[p.id]
      if (!d) return p
      return { ...p, votes: {
        bullish: p.votes.bullish + (d.bullish ?? 0),
        neutral: p.votes.neutral + (d.neutral ?? 0),
        bearish: p.votes.bearish + (d.bearish ?? 0),
      }}
    }),
  [allSeedProjects, voteDeltas])

  // ── Blacklist-adjusted projects (filter blacklisted votes from sentiment) ─
  // Reviews written by blacklisted wallets are also hidden in ProjectDetailSheet.
  const projectsWithBlacklistFilter = useMemo(() =>
    blacklist.blacklistedAddresses.size === 0
      ? projects
      : projects.map((p) => {
          // Filter out reviews from blacklisted wallets
          const filteredReviews = p.reviews.filter(
            (r) => !blacklist.isBlacklisted(r.authorFull)
          )
          return { ...p, reviews: filteredReviews }
        }),
  // eslint-disable-next-line react-hooks/exhaustive-deps
  [projects, blacklist.blacklistedAddresses])

  const projectsWithReviews = useMemo(() =>
    projectsWithBlacklistFilter.map((p) => {
      const extra = (reviewOverrides[p.id] ?? []).filter(
        (r) => !blacklist.isBlacklisted(r.authorFull)
      )
      const seedReviews = p.reviews.map((r) =>
        seedHelpfulDeltas[r.id] ? { ...r, helpful: r.helpful + seedHelpfulDeltas[r.id] } : r
      )
      // Apply project overrides (description, website)
      const override = projectOverrides[p.id] ?? {}
      return { ...p, ...override, reviews: [...extra, ...seedReviews] }
    }),
  // eslint-disable-next-line react-hooks/exhaustive-deps
  [projectsWithBlacklistFilter, reviewOverrides, seedHelpfulDeltas, projectOverrides])

  // ── Trending scores ──────────────────────────────────────────────────────────
  const projectsWithTrending = useMemo<ProjectWithTrending[]>(() =>
    projectsWithReviews.map((p) => {
      const recentVoteCount = userVotes[p.id] ? 1 : 0
      const score = computeTrendingScore(p, recentVoteCount)
      const total = p.votes.bullish + p.votes.neutral + p.votes.bearish
      const bullishPct = total > 0 ? p.votes.bullish / total : 0.5
      return { ...p, trendingScore: score, trendDirection: bullishPct >= 0.5 ? 1 : -1 }
    }),
  [projectsWithReviews, userVotes])

  // ── Platform momentum (Rising tab + Admin Analytics) ─────────────────────
  // One fetch pass shared between the Rising tab and AdminPanel.
  const platformMomentum = usePlatformMomentum(CONTRACT_ADDRESS, projectsWithReviews)

  // ── Poll state ───────────────────────────────────────────────────────────────
  const polls = useMemo(() =>
    onchainPollList.map((p) => {
      const d = pollDeltaMap[p.id]
      const sponsorName = sponsoredPollsConfig[p.id]
      const base = {
        ...p,
        sponsored: sponsorName !== undefined ? true : p.sponsored,
        sponsorName: sponsorName ?? p.sponsorName,
      }
      if (!d) return base
      return {
        ...base,
        totalVotes: p.totalVotes + Object.values(d).reduce((a, b) => a + b, 0),
        options: p.options.map((o) => ({ ...o, votes: o.votes + (d[o.id] ?? 0) })),
      }
    }),
  [onchainPollList, pollDeltaMap, sponsoredPollsConfig])

  // ── Feed generation tracking (entrance choreography guard) ───────────────────
  // Computed inline after 'filtered' is available; placed here for co-location.

  // ── UI state ─────────────────────────────────────────────────────────────────
  const prefersReduced = useReducedMotion()
  // Tracks how many times the feed query has changed (filter/sort/search).
  // Generation 0 = first load → run entrance choreography.
  // Generation > 0 = user changed a filter → suppress re-entrance, only layout/exit.
  const feedGeneration = useRef(0)
  const prevFilterKey = useRef('')
  const [selectedProject, setSelectedProject] = useState<Project | null>(null)
  const [search, setSearch]         = useState('')
  const [tagFilter, setTagFilter]   = useState<TagFilter>('All')
  const [discoverFilter, setDiscoverFilter] = useState<DiscoverFilter>('tag')
  const [sortMode, setSortMode]     = useState<SortMode>('bullish')
  const [isHydrating, setIsHydrating] = useState(true)
  const [isSubmitOpen, setIsSubmitOpen] = useState(false)
  const [isAdminOpen, setIsAdminOpen] = useState(false)
  const [alertsRead, setAlertsRead] = useState(false)
  // Incremented after every confirmed on-chain write — drives analytics refetch
  // in ProjectDetailSheet without requiring a close/reopen cycle.
  const [analyticsRefetchTick, setAnalyticsRefetchTick] = useState(0)

  // ── On-chain hooks ─────────────────────────────────────────────────────────
  const onchainActivity = useOnchainActivity({
    contractAddress: CONTRACT_ADDRESS,
    address,
    projects: projectsWithReviews,
    polls,
    pollVotes,
  })

  // ── Verified owners ────────────────────────────────────────────────────────
  const { verifiedOwners } = useVerifiedOwners(CONTRACT_ADDRESS)

  // ── Watchlist + alerts ─────────────────────────────────────────────────────
  const {
    toggleWatchlist,
    isWatched,
    alerts,
    unreadCount,
    markAlertsRead,
  } = useWatchlist(projectsWithReviews)

  // Mark alerts read when Activity tab is opened and user views alerts section
  const handleActivityTabSelect = useCallback(() => {
    setTab('activity')
    setAlertsRead(true)
    markAlertsRead()
  }, [markAlertsRead])

  useEffect(() => {
    const t = setTimeout(() => setIsHydrating(false), 300)
    return () => clearTimeout(t)
  }, [])

  useEffect(() => {
    const pid = new URLSearchParams(window.location.search).get('project')
    if (pid) {
      const found = projectsWithReviews.find((p) => p.id === pid)
      if (found) setSelectedProject(found)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    if (!selectedProject) return
    const fresh = projectsWithReviews.find((p) => p.id === selectedProject.id)
    if (fresh) setSelectedProject(fresh)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectsWithReviews])

  const { voteDirectly, retractVote, postReview, isPending: isOnchainPending } =
    useVoteBySig({ contractAddress: CONTRACT_ADDRESS })

  // Stable refetch reference — extracted so useCallback deps don't need the
  // whole onchainActivity object (which changes identity every render).
  const refetchOnchainActivity = onchainActivity.refetch

  const sessionActivity = useUserActivity({ address, projects: projectsWithReviews, polls, userVotes, pollVotes })
  const activity = ONCHAIN_MODE && !onchainActivity.isLoading && onchainActivity.voteHistory.length > 0
    ? onchainActivity
    : sessionActivity

  const reputation = useReputation({
    address,
    projects: projectsWithReviews,
    userVotes,
    reviewOverrides,
    seedHelpfulDeltas,
  })

  // ── Filtered + sorted Discover list ──────────────────────────────────────────
  const filtered = useMemo(() => {
    const HIDDEN_STATUSES = new Set(['delisted', 'discontinued'])
    const base = projectsWithTrending.filter((p) => {
      // Hide delisted/discontinued by default (still accessible via direct link)
      if (p.status && HIDDEN_STATUSES.has(p.status)) return false
      if (discoverFilter === 'watched') return isWatched(p.id)
      // Taxonomy-aware category filter
      const matchCategory = tagFilter === 'All' || (() => {
        // Match primary category
        if (p.primaryCategory === tagFilter) return true
        // Also match via use cases (a project in category 'defi' can show in 'trading-exchanges' if it has a dex use case)
        if (p.useCases?.includes(tagFilter)) return true
        // Match canonical tags
        if (p.canonicalTags?.includes(tagFilter)) return true
        // Legacy tag fallback for unmigrated submitted projects
        const catLabel = taxonomy.getCategory(tagFilter)?.label
        if (catLabel && p.tags.some((t) => t.toLowerCase() === catLabel.toLowerCase())) return true
        return false
      })()
      const q = search.toLowerCase()
      const matchSearch = !q || (
        p.name.toLowerCase().includes(q) ||
        p.tagline.toLowerCase().includes(q) ||
        p.description?.toLowerCase().includes(q) ||
        (p.primaryCategory && taxonomy.getCategory(p.primaryCategory)?.label.toLowerCase().includes(q)) ||
        p.useCases?.some((uc) => taxonomy.getUseCase(uc)?.label.toLowerCase().includes(q)) ||
        p.canonicalTags?.some((t) => taxonomy.getTag(t)?.label.toLowerCase().includes(q)) ||
        // Also check tag aliases
        p.canonicalTags?.some((t) => taxonomy.getTag(t)?.aliases.some((a) => a.toLowerCase().includes(q)))
      )
      return matchCategory && matchSearch
    })

    const sorted = [...base].sort((a, b) => {
      const tA = a.votes.bullish + a.votes.neutral + a.votes.bearish
      const tB = b.votes.bullish + b.votes.neutral + b.votes.bearish
      switch (sortMode) {
        case 'bullish':   return (b.votes.bullish / Math.max(1, tB)) - (a.votes.bullish / Math.max(1, tA))
        case 'reviewed':  return b.reviews.length - a.reviews.length
        case 'recent':    return (b.reviews[0]?.timestamp ?? 0) - (a.reviews[0]?.timestamp ?? 0)
        case 'trending':  return b.trendingScore - a.trendingScore
        default:          return 0
      }
    })

    // Featured projects float to top (except Watched filter preserves their relative featured order)
    return sorted.sort((a, b) => {
      if (discoverFilter === 'watched') return 0 // keep sort within watched
      if (a.featured && !b.featured) return -1
      if (!a.featured && b.featured) return 1
      return 0
    })
  }, [projectsWithTrending, tagFilter, search, sortMode, discoverFilter, isWatched, taxonomy])

  // Increment feedGeneration whenever the user actively changes a query parameter.
  // This is read synchronously in the render below — no state update, no extra render.
  useEffect(() => {
    const key = `${discoverFilter}:${tagFilter}:${sortMode}:${search}`
    if (prevFilterKey.current === '') {
      // First render — record the initial key without incrementing.
      prevFilterKey.current = key
    } else if (key !== prevFilterKey.current) {
      prevFilterKey.current = key
      feedGeneration.current += 1
    }
  }, [discoverFilter, tagFilter, sortMode, search])

  const leaderboard = useMemo(() =>
    [...projectsWithReviews].sort((a, b) => {
      const aP = a.votes.bullish / Math.max(1, a.votes.bullish + a.votes.neutral + a.votes.bearish)
      const bP = b.votes.bullish / Math.max(1, b.votes.bullish + b.votes.neutral + b.votes.bearish)
      return bP - aP
    }),
  [projectsWithReviews])

  // ── Delta helpers ─────────────────────────────────────────────────────────────
  const applyVoteDelta = useCallback((projectId: string, patch: Partial<VoteCounts>) => {
    setVoteDeltas((prev) => {
      const ex = prev[projectId] ?? {}
      return { ...prev, [projectId]: {
        bullish: (ex.bullish ?? 0) + (patch.bullish ?? 0),
        neutral: (ex.neutral ?? 0) + (patch.neutral ?? 0),
        bearish: (ex.bearish ?? 0) + (patch.bearish ?? 0),
      }}
    })
  }, [setVoteDeltas])

  // ── Vote handler ──────────────────────────────────────────────────────────────
  const handleVote = useCallback(async (projectId: string, sentiment: Sentiment) => {
    if (!isConnected)  { toast.error('Connect your wallet to vote.'); return }
    if (isWrongChain)  { toast.error('Switch to Arc Testnet to vote.'); return }

    const prev = userVotes[projectId]
    const isUnvote = prev === sentiment

    setUserVotes((v) => { const n = { ...v }; if (isUnvote) delete n[projectId]; else n[projectId] = sentiment; return n })
    const patch: Partial<VoteCounts> = isUnvote
      ? { [sentiment]: -1 }
      : { [sentiment]: 1, ...(prev ? { [prev]: -1 } : {}) }
    applyVoteDelta(projectId, patch)

    if (ONCHAIN_MODE) {
      const id32 = slugToBytes32(projectId)
      const ok = isUnvote
        ? await retractVote(id32)
        : await voteDirectly(id32, sentimentToUint8(sentiment))
      if (!ok) {
        setUserVotes((v) => { const n = { ...v }; if (prev) n[projectId] = prev; else delete n[projectId]; return n })
        const rollback: Partial<VoteCounts> = isUnvote ? { [sentiment]: 1 } : { [sentiment]: -1, ...(prev ? { [prev]: 1 } : {}) }
        applyVoteDelta(projectId, rollback)
        return
      }
      // Tx submitted — schedule a refetch 1s later to give the RPC node time to
      // index the new block before getLogs is called.
      setTimeout(() => {
        refetchOnchainActivity()
        setAnalyticsRefetchTick((t) => t + 1)
      }, 1000)
      if (!isUnvote) toast.success(`${sentiment.charAt(0).toUpperCase() + sentiment.slice(1)} vote recorded onchain.`)
      else toast('Vote retracted.')
    } else {
      if (!isUnvote) toast(`${sentiment.charAt(0).toUpperCase() + sentiment.slice(1)} vote recorded.`, { duration: 1800 })
      else toast('Vote retracted.', { duration: 1800 })
    }
  }, [isConnected, isWrongChain, userVotes, applyVoteDelta, setUserVotes, retractVote, voteDirectly, refetchOnchainActivity])

  const handlePollVote = useCallback((pollId: string, optionId: string) => {
    if (!isConnected) { toast.error('Connect your wallet to vote in polls.'); return }
    if (pollVotes[pollId]) return
    setPollVotes((v) => ({ ...v, [pollId]: optionId }))
    setPollDeltaMap((prev) => ({
      ...prev,
      [pollId]: { ...(prev[pollId] ?? {}), [optionId]: ((prev[pollId] ?? {})[optionId] ?? 0) + 1 },
    }))
    toast('Vote cast.', { duration: 1800 })
  }, [isConnected, pollVotes, setPollVotes, setPollDeltaMap])

  const handleReview = useCallback(async (projectId: string, body: string, sentiment: Sentiment) => {
    if (!isConnected) { toast.error('Connect your wallet to post a review.'); return }
    if (isWrongChain) { toast.error('Switch to Arc Testnet to post a review.'); return }

    const author     = address ? `${address.slice(0, 6)}...${address.slice(-4)}` : '0xAnon...0000'
    const authorFull = address ?? '0xAnonymous'
    const reviewId   = `r${Date.now()}`
    const newReview: StoredReview = { id: reviewId, author, authorFull, body, sentiment, timestamp: Date.now(), helpful: 0 }

    setReviewOverrides((prev) => ({ ...prev, [projectId]: [newReview, ...(prev[projectId] ?? [])] }))

    if (ONCHAIN_MODE) {
      const ok = await postReview(slugToBytes32(projectId), sentimentToUint8(sentiment), body)
      if (!ok) {
        setReviewOverrides((prev) => ({ ...prev, [projectId]: (prev[projectId] ?? []).filter((r) => r.id !== reviewId) }))
        return
      }
      // Tx submitted — schedule a refetch after 1s to allow block indexing.
      setTimeout(() => {
        refetchOnchainActivity()
        setAnalyticsRefetchTick((t) => t + 1)
      }, 1000)
      toast.success('Review posted onchain.')
    } else {
      toast('Review posted.', { duration: 2000 })
    }
  }, [isConnected, isWrongChain, address, setReviewOverrides, postReview, refetchOnchainActivity])

  const handleHelpful = useCallback((projectId: string, reviewId: string) => {
    if (helpfulVoted[reviewId]) return
    setHelpfulVoted((prev) => ({ ...prev, [reviewId]: true }))
    setReviewOverrides((prev) => {
      const existing = prev[projectId]
      if (existing?.some((r) => r.id === reviewId)) {
        return { ...prev, [projectId]: existing.map((r) => r.id === reviewId ? { ...r, helpful: r.helpful + 1 } : r) }
      }
      return prev
    })
    setSeedHelpfulDeltas((prev) => ({ ...prev, [reviewId]: (prev[reviewId] ?? 0) + 1 }))
  }, [helpfulVoted, setHelpfulVoted, setReviewOverrides, setSeedHelpfulDeltas])

  const handleSaveProjectOverride = useCallback((projectId: string, patch: Partial<Project>) => {
    setProjectOverrides((prev) => ({ ...prev, [projectId]: { ...(prev[projectId] ?? {}), ...patch } }))
  }, [setProjectOverrides])

  // ── Community stats ───────────────────────────────────────────────────────────
  const totalVotes = projectsWithReviews.reduce((a, p) => a + p.votes.bullish + p.votes.neutral + p.votes.bearish, 0)
  const totalReviews = projectsWithReviews.reduce((a, p) => a + p.reviews.length, 0)
  const overallBullish = Math.round((projectsWithReviews.reduce((a, p) => a + p.votes.bullish, 0) / Math.max(1, totalVotes)) * 100)

  // Tab definitions — activity tab shows unread badge
  const TABS: { id: Tab; label: string; icon: typeof LayoutGrid; badge?: number }[] = [
    { id: 'discover',    label: 'Discover',    icon: LayoutGrid },
    { id: 'rising',      label: 'Rising',      icon: Flame      },
    { id: 'leaderboard', label: 'Leaderboard', icon: TrendingUp },
    { id: 'polls',       label: 'Polls',       icon: Vote       },
    { id: 'activity',    label: 'Activity',    icon: Activity, badge: alertsRead ? 0 : unreadCount },
  ]

  // ── Render ────────────────────────────────────────────────────────────────────
  return (
    <div className="min-h-dvh" style={{ background: 'var(--bg-gradient)', backgroundAttachment: 'fixed' }}>
      {/* Announcements */}
      {announcements.length > 0 && (
        <AnnouncementBanner announcements={announcements} />
      )}
      {/* Top nav */}
      <header
        className="sticky top-0 z-30 px-4 py-3.5"
        style={{ background: 'var(--nav-bg)', backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)', borderBottom: '1px solid var(--border)' }}
      >
        <div className="max-w-2xl mx-auto flex items-center justify-between gap-2 min-w-0">
          <div className="flex items-center gap-2.5 flex-shrink-0">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: 'var(--accent)' }}>
              <BarChart2 size={14} color="var(--bg)" strokeWidth={2.5} />
            </div>
            <span className="display font-bold text-lg hidden sm:block" style={{ color: 'var(--ink)', letterSpacing: '-0.03em' }}>
              MYARC
            </span>
          </div>
          <div className="flex items-center gap-2 min-w-0">
            {!ONCHAIN_MODE && (
              <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium flex-shrink-0"
                style={{ background: 'rgba(107,101,128,0.12)', color: 'var(--muted)', border: '1px solid var(--border)' }}>
                <Info size={11} /> Preview mode
              </div>
            )}
            {ONCHAIN_MODE && isOnchainPending && (
              <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium flex-shrink-0"
                style={{ background: 'rgba(26,128,71,0.10)', color: 'var(--success)', border: '1px solid rgba(26,128,71,0.20)' }}>
                <Zap size={11} /> Confirming…
              </div>
            )}
            <ThemeToggle />
            {ONCHAIN_MODE && (
              <button
                onClick={() => setIsAdminOpen(true)}
                className="flex items-center justify-center w-9 h-9 rounded-xl min-h-[44px] min-w-[44px] transition-all hover:opacity-85 flex-shrink-0"
                style={{ background: 'var(--surface-muted)', color: 'var(--muted)', border: '1px solid var(--border)' }}
                title="Admin panel"
              >
                <Settings size={16} />
              </button>
            )}
            <ConnectKitButton />
          </div>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 pb-28">
        {/* Community stats — contextual, not dominant */}
        <div className="pt-5 pb-3">
          <div className="grid grid-cols-3" style={{ borderTop: '1px solid var(--border)', borderBottom: '1px solid var(--border)' }}>
            {[
              { label: 'Votes',    value: totalVotes.toLocaleString()   },
              { label: 'Bullish',  value: `${overallBullish}%`           },
              { label: 'Reviews',  value: totalReviews.toLocaleString() },
            ].map(({ label, value }, i) => (
              <div key={label} className="text-center px-2 py-2.5"
                style={i < 2 ? { borderRight: '1px solid var(--border)' } : undefined}>
                <p className="display font-bold text-xl tabular-nums leading-none" style={{ color: 'var(--ink)' }}>{value}</p>
                <p className="text-[11px] mt-1 leading-none" style={{ color: 'var(--subtle)' }}>{label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Tab bar */}
        {(() => {
          const activeIndex = TABS.findIndex(t => t.id === tab)
          const indicatorColor = tab === 'rising' ? 'var(--momentum)' : 'var(--accent)'
          return (
            <div className="relative flex border-b mb-6" style={{ borderColor: 'var(--border)' }}>
              {TABS.map(({ id, label, icon: Icon, badge }) => (
                <button key={id}
                  onClick={() => id === 'activity' ? handleActivityTabSelect() : setTab(id)}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2.5 text-sm font-medium relative transition-colors duration-150"
                  style={{ color: tab === id ? 'var(--ink)' : 'var(--subtle)', marginBottom: '-1px' }}>
                  <Icon
                    size={14}
                    strokeWidth={tab === id ? 2.5 : 1.75}
                    style={id === 'rising' ? {
                      color: 'var(--momentum)',
                      opacity: tab === id ? 1 : 0.7,
                      filter: tab === id
                        ? 'drop-shadow(0 0 3px rgba(217,119,6,0.5))'
                        : undefined,
                    } : undefined}
                  />
                  <span className="hidden sm:inline">{label}</span>
                  {badge !== undefined && badge > 0 && (
                    <span className="absolute top-1 right-0.5 min-w-[15px] h-[15px] px-1 rounded-full text-[9px] font-bold flex items-center justify-center"
                      style={{ background: 'var(--bearish)', color: '#fff' }}>
                      {badge > 9 ? '9+' : badge}
                    </span>
                  )}
                </button>
              ))}
              {/* Single shared underline — travels between tabs via animate */}
              <motion.div
                aria-hidden="true"
                className="absolute bottom-0 pointer-events-none"
                style={{ height: 2, borderRadius: '1px 1px 0 0', background: indicatorColor }}
                animate={{
                  left: `${activeIndex * (100 / TABS.length)}%`,
                  width: `${100 / TABS.length}%`,
                  background: indicatorColor,
                }}
                transition={prefersReduced
                  ? { duration: 0 }
                  : { type: 'tween', ease: [0.25, 0.1, 0.25, 1], duration: 0.22 }}
              />
            </div>
          )
        })()}

        <AnimatePresence mode="sync">

          {/* ── Discover ───────────────────────────────────────────────────── */}
          {tab === 'discover' && (
            <motion.div key="discover" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.18 }}>

              {/* ── Discovery header + search + filters ──────────────────── */}
              <div className="space-y-4">

              {/* Discovery header */}
              <div>
                <h2 className="display font-semibold text-lg leading-tight" style={{ color: 'var(--ink)' }}>
                  Discover Arc projects
                </h2>
                <p className="text-sm mt-0.5" style={{ color: 'var(--muted)' }}>
                  Community reputation, sentiment, and momentum — all onchain.
                </p>
              </div>

              {/* Search bar + Submit button */}
              <div className="flex items-center gap-2">
                <div className="flex-1 flex items-center gap-2.5 px-3.5 rounded-xl border"
                  style={{ background: 'var(--surface)', borderColor: 'var(--border)', height: '44px' }}>
                  <Search size={15} style={{ color: 'var(--subtle)', flexShrink: 0 }} />
                  <input value={search} onChange={(e) => setSearch(e.target.value)}
                    placeholder="Search projects..." className="flex-1 bg-transparent outline-none text-sm"
                    style={{ color: 'var(--ink)', fontFamily: "'DM Sans', sans-serif" }} />
                </div>
                <button
                  onClick={() => setIsSubmitOpen(true)}
                  className="flex-shrink-0 flex items-center gap-1.5 px-4 rounded-xl text-sm font-semibold min-h-[44px] transition-all hover:opacity-85 whitespace-nowrap"
                  style={{ background: 'var(--accent)', color: 'var(--bg)' }}
                  title="Submit a project"
                >
                  <PlusCircle size={15} />
                  <span className="hidden sm:inline">Submit</span>
                </button>
              </div>

              {/* Filter row: Watched + tags + divider + sort chips */}
              <div
                className="flex items-center gap-1.5 overflow-x-auto hide-scrollbar"
                style={{ scrollbarWidth: 'none', WebkitOverflowScrolling: 'touch', paddingBottom: '2px' }}
              >
                {/* Watched chip */}
                <motion.button
                  layout
                  onClick={() => setDiscoverFilter(discoverFilter === 'watched' ? 'tag' : 'watched')}
                  className="flex-shrink-0 flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-medium min-h-[32px] relative overflow-hidden"
                  style={{
                    color: discoverFilter === 'watched' ? 'var(--bg)' : 'var(--subtle)',
                    border: discoverFilter === 'watched' ? 'none' : '1px solid var(--border)',
                    WebkitTapHighlightColor: 'transparent',
                  }}
                >
                  {discoverFilter === 'watched' && (
                    <motion.span
                      layoutId="filter-pill-bg"
                      className="absolute inset-0 rounded-full"
                      style={{ background: 'var(--accent)' }}
                      transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                    />
                  )}
                  <span className="relative z-10 flex items-center gap-1">
                    <Bookmark size={10} />
                    Watched
                  </span>
                </motion.button>

                {/* Category filters — driven by taxonomy */}
                {discoverFilter !== 'watched' && TAG_FILTERS.map((catId) => {
                  const label = catId === 'All' ? 'All' : (taxonomy.getCategory(catId)?.label ?? catId)
                  return (
                    <motion.button
                      layout
                      key={catId}
                      onClick={() => setTagFilter(catId)}
                      className="flex-shrink-0 flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-medium min-h-[32px] relative overflow-hidden"
                      style={{
                        color: tagFilter === catId ? 'var(--bg)' : 'var(--subtle)',
                        border: tagFilter === catId ? 'none' : '1px solid var(--border)',
                        WebkitTapHighlightColor: 'transparent',
                      }}
                    >
                      {tagFilter === catId && (
                        <motion.span
                          layoutId="filter-pill-bg"
                          className="absolute inset-0 rounded-full"
                          style={{ background: 'var(--ink)' }}
                          transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                        />
                      )}
                      <span className="relative z-10">{label}</span>
                    </motion.button>
                  )
                })}

                {/* Divider */}
                <div className="flex-shrink-0 self-center mx-1" style={{ width: 1, height: 14, background: 'var(--border)' }} />

                {/* Sort chips */}
                {SORT_OPTIONS.map((opt) => {
                  const isActive = sortMode === opt.value
                  return (
                    <motion.button
                      layout
                      key={opt.value}
                      onClick={() => setSortMode(opt.value)}
                      className="flex-shrink-0 flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-medium min-h-[32px] relative overflow-hidden"
                      style={{
                        color: isActive ? 'var(--bg)' : 'var(--subtle)',
                        border: isActive ? 'none' : '1px solid var(--border)',
                        WebkitTapHighlightColor: 'transparent',
                      }}
                    >
                      {isActive && (
                        <motion.span
                          layoutId="sort-pill-bg"
                          className="absolute inset-0 rounded-full"
                          style={{ background: 'var(--ink)' }}
                          transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                        />
                      )}
                      <span className="relative z-10">{opt.label}</span>
                    </motion.button>
                  )
                })}
              </div>{/* end filter row */}

              </div>{/* end header+search+filters group */}

              {/* ── Featured — presentation stage ──────────────────────────── */}
              {!isHydrating && discoverFilter !== 'watched' && (
                <div className="mt-7">
                  <FeaturedBanner
                    projects={projectsWithTrending}
                    onSelect={(proj) => openProject(proj, setSelectedProject)}
                  />
                </div>
              )}

              {/* ── Trending strip ─────────────────────────────────────────── */}
              {!isHydrating && discoverFilter !== 'watched' && (
                <div className="mt-5">
                  <TrendingStrip
                    projects={projectsWithTrending}
                    onSelect={(proj) => openProject(proj, setSelectedProject)}
                    count={3}
                  />
                </div>
              )}

              {/* ── Project feed — AnimatePresence handles enter/exit/reorder ── */}
              <div className="mt-6 space-y-3">
              {isHydrating ? (
                [0, 1, 2].map((i) => <SkeletonCard key={i} />)
              ) : (
                <AnimatePresence mode="popLayout">
                  {filtered.length === 0 ? (
                    // Empty state — fades in/out smoothly
                    <motion.div
                      key="empty-state"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: prefersReduced ? 0 : 0.2 }}
                      className="py-16 text-center space-y-2"
                    >
                      <p className="font-medium" style={{ color: 'var(--ink-2)' }}>
                        {discoverFilter === 'watched' ? 'No watched projects yet' : 'No projects found'}
                      </p>
                      <p className="text-sm" style={{ color: 'var(--subtle)' }}>
                        {discoverFilter === 'watched'
                          ? 'Tap the bookmark icon on any project card to watch it'
                          : 'Try a different search or filter'}
                      </p>
                    </motion.div>
                  ) : (
                    <>
                      {filtered.map((p, i) => {
                        // Generation 0 = first-load entrance: staggered fade-up.
                        // Generation > 0 = filter/sort change: items that are *new*
                        // to the list still enter, but no stagger delay so the
                        // reorder feels instant rather than replaying the sequence.
                        const isFirstLoad = feedGeneration.current === 0
                        const isMobile = typeof window !== 'undefined' && window.matchMedia('(max-width: 640px)').matches
                        const staggerInterval = isMobile ? 0.03 : 0.045
                        const staggerDelay = isFirstLoad
                          ? (prefersReduced ? 0 : Math.min(i, 7) * staggerInterval)
                          : 0
                        const enterDuration = prefersReduced ? 0 : (isFirstLoad ? (isMobile ? 0.25 : 0.32) : 0.18)
                        const enterY = prefersReduced ? 0 : (isFirstLoad ? (isMobile ? 6 : 10) : 4)
                        return (
                        <motion.div
                          key={p.id}
                          layout
                          initial={{ opacity: 0, y: enterY }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, scale: prefersReduced ? 1 : 0.98 }}
                          transition={{
                            delay: staggerDelay,
                            duration: enterDuration,
                            ease: [0.25, 0.1, 0.25, 1],
                            layout: { duration: prefersReduced ? 0 : 0.28, ease: [0.25, 0.1, 0.25, 1] },
                          }}
                        >
                          <ProjectCard
                            project={p}
                            userVote={userVotes[p.id] ?? null}
                            onVote={(id, s) => { void handleVote(id, s) }}
                            onSelect={(proj) => openProject(proj, setSelectedProject)}
                            isConnected={isConnected}
                            isVerified={Boolean(verifiedOwners[p.id])}
                            isWatched={isWatched(p.id)}
                            onToggleWatchlist={toggleWatchlist}
                          />
                        </motion.div>
                        )
                      })}

                      {/* Submit CTA */}
                      {discoverFilter !== 'watched' && (
                        <motion.button
                          key="submit-cta"
                          layout
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          transition={{ duration: prefersReduced ? 0 : 0.2 }}
                          onClick={() => setIsSubmitOpen(true)}
                          className="w-full flex items-center justify-between px-5 py-4 rounded-2xl min-h-[64px] transition-all hover:opacity-85 group"
                          style={{ background: 'var(--surface)', border: '1.5px dashed var(--border-strong)' }}
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 transition-colors group-hover:opacity-90"
                              style={{ background: 'rgba(26,92,255,0.10)' }}>
                              <PlusCircle size={18} style={{ color: 'var(--accent)' }} />
                            </div>
                            <div className="text-left">
                              <p className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>Submit a project</p>
                              <p className="text-xs" style={{ color: 'var(--subtle)' }}>Know an Arc-native project? Add it here.</p>
                            </div>
                          </div>
                          <span className="text-xs font-semibold px-3 py-1.5 rounded-full flex-shrink-0"
                            style={{ background: 'var(--accent)', color: 'var(--bg)' }}>
                            Submit
                          </span>
                        </motion.button>
                      )}
                    </>
                  )}
                </AnimatePresence>
              )}
              </div>{/* end project feed */}
            </motion.div>
          )}

          {/* ── Rising ─────────────────────────────────────────────────────── */}
          {tab === 'rising' && (
            <motion.div key="rising" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.18 }} className="space-y-5">

              {/* Header */}
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <h2 className="display font-semibold text-lg" style={{ color: 'var(--ink)' }}>Rising</h2>
                  <p className="text-sm" style={{ color: 'var(--muted)' }}>
                    Projects gaining community attention across Arc right now
                  </p>
                </div>
                {ONCHAIN_MODE && (
                  <button
                    onClick={() => platformMomentum.refetch()}
                    className="flex-shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium min-h-[44px] transition-all hover:opacity-80"
                    style={{ background: 'var(--surface-muted)', color: 'var(--muted)', border: '1px solid var(--border)' }}
                    title="Refresh momentum data"
                  >
                    <RefreshCw size={13} />
                    <span className="hidden sm:inline">Refresh</span>
                  </button>
                )}
              </div>

              {/* Disclaimer */}
              <div className="px-3.5 py-2.5 rounded-xl text-xs leading-relaxed"
                style={{ background: 'rgba(26,92,255,0.05)', border: '1px solid rgba(26,92,255,0.12)', color: 'var(--muted)' }}>
                Community momentum reflects recent votes, reviews, boosts, and new wallet participation — not financial performance or price prediction.
              </div>

              {/* No contract = preview mode notice */}
              {!ONCHAIN_MODE && (
                <div className="py-16 flex flex-col items-center gap-4 text-center rounded-2xl"
                  style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
                  <div className="w-14 h-14 rounded-2xl flex items-center justify-center"
                    style={{ background: 'var(--surface-muted)' }}>
                    <Flame size={24} style={{ color: 'var(--muted)' }} />
                  </div>
                  <div className="space-y-1.5">
                    <p className="font-semibold" style={{ color: 'var(--ink)' }}>On-chain mode required</p>
                    <p className="text-sm max-w-full" style={{ color: 'var(--subtle)' }}>
                      Rising uses live on-chain activity. Set <code className="text-xs">VITE_MYARC_ADDRESS</code> to enable it.
                    </p>
                  </div>
                </div>
              )}

              {/* Loading */}
              {ONCHAIN_MODE && platformMomentum.isLoading && (
                <div className="space-y-3">
                  {[0,1,2,3].map((i) => (
                    <div key={i} className="h-28 rounded-2xl animate-pulse" style={{ background: 'var(--surface-muted)' }} />
                  ))}
                </div>
              )}

              {/* Error */}
              {ONCHAIN_MODE && !platformMomentum.isLoading && platformMomentum.error && (
                <div className="px-4 py-3 rounded-xl text-sm"
                  style={{ background: 'rgba(186,43,76,0.06)', border: '1px solid rgba(186,43,76,0.15)', color: 'var(--bearish)' }}>
                  Could not load momentum data. {platformMomentum.error}
                </div>
              )}

              {/* Content */}
              {ONCHAIN_MODE && !platformMomentum.isLoading && !platformMomentum.error && (() => {
                const ranked = platformMomentum.ranked
                if (ranked.length === 0) {
                  return (
                    <div className="py-16 flex flex-col items-center gap-4 text-center rounded-2xl"
                      style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
                      <div className="w-14 h-14 rounded-2xl flex items-center justify-center"
                        style={{ background: 'var(--surface-muted)' }}>
                        <Flame size={24} style={{ color: 'var(--muted)' }} />
                      </div>
                      <div className="space-y-1.5">
                        <p className="font-semibold" style={{ color: 'var(--ink)' }}>No activity yet</p>
                        <p className="text-sm max-w-full" style={{ color: 'var(--subtle)' }}>
                          Community momentum will appear here once projects start receiving votes and reviews.
                        </p>
                      </div>
                      <button onClick={() => setTab('discover')}
                        className="px-5 py-2.5 rounded-xl text-sm font-semibold transition-opacity hover:opacity-90"
                        style={{ background: 'var(--accent)', color: 'var(--bg)' }}>
                        Discover projects
                      </button>
                    </div>
                  )
                }

                // Rising Now: top 5 by momentum (must have momentumIndex > 0)
                const risingNow = ranked.filter((r) => r.momentumIndex > 0).slice(0, 5)
                // New & Rising: have insufficientHistory but some activity, not in top5
                const newAndRising = ranked
                  .filter((r) => r.signals.insufficientHistory && r.signals.totalVotesAllTime > 0)
                  .filter((r) => !risingNow.some((x) => x.projectSlug === r.projectSlug))
                  .slice(0, 3)
                // Sentiment Shifts: sentimentDelta >= 5 or <= -5
                const sentimentShifts = ranked
                  .filter((r) => r.signals.sentiment.sentimentDelta !== null && Math.abs(r.signals.sentiment.sentimentDelta) >= 5)
                  .sort((a, b) => Math.abs(b.signals.sentiment.sentimentDelta!) - Math.abs(a.signals.sentiment.sentimentDelta!))
                  .slice(0, 3)
                // Most Active: highest activityScore
                const mostActive = [...ranked]
                  .sort((a, b) => b.signals.activityScore - a.signals.activityScore)
                  .slice(0, 3)
                // Most Boosted: have any boost activity in 7d
                const mostBoosted = [...ranked]
                  .filter((r) => r.signals.boosts.d7 > 0)
                  .sort((a, b) => Number(b.signals.boostVolume7d - a.signals.boostVolume7d))
                  .slice(0, 3)

                return (
                  <div className="space-y-6">

                    {/* Rising Now */}
                    {risingNow.length > 0 && (
                      <section className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Flame size={14} style={{ color: 'var(--momentum)' }} />
                          <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--momentum)', letterSpacing: '0.08em' }}>
                            Rising Now
                          </p>
                          <p className="text-xs" style={{ color: 'var(--subtle)' }}>strongest community momentum</p>
                        </div>
                        {risingNow.map((result, i) => {
                          const project = projectsWithReviews.find((p) => p.id === result.projectSlug)
                          return (
                            <motion.div key={result.projectSlug}
                              initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: i * 0.06 }}>
                              <RisingCard
                                result={result}
                                project={project}
                                rank={i + 1}
                                isVerified={Boolean(verifiedOwners[result.projectSlug])}
                                onSelect={(proj) => { openProject(proj, setSelectedProject); setTab('discover') }}
                              />
                            </motion.div>
                          )
                        })}
                      </section>
                    )}

                    {/* New & Rising */}
                    {newAndRising.length > 0 && (
                      <section className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Zap size={14} style={{ color: 'var(--bullish)' }} />
                          <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--bullish)', letterSpacing: '0.08em' }}>
                            New &amp; Rising
                          </p>
                          <p className="text-xs" style={{ color: 'var(--subtle)' }}>early community activity</p>
                        </div>
                        {newAndRising.map((result, i) => {
                          const project = projectsWithReviews.find((p) => p.id === result.projectSlug)
                          return (
                            <motion.div key={result.projectSlug}
                              initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: i * 0.06 }}>
                              <RisingCard
                                result={result}
                                project={project}
                                isVerified={Boolean(verifiedOwners[result.projectSlug])}
                                onSelect={(proj) => { openProject(proj, setSelectedProject); setTab('discover') }}
                              />
                            </motion.div>
                          )
                        })}
                      </section>
                    )}

                    {/* Most Active */}
                    {mostActive.length > 0 && (
                      <section className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Activity size={14} style={{ color: 'var(--neutral)' }} />
                          <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                            Most Active
                          </p>
                          <p className="text-xs" style={{ color: 'var(--subtle)' }}>highest community engagement</p>
                        </div>
                        {mostActive.map((result, i) => {
                          const project = projectsWithReviews.find((p) => p.id === result.projectSlug)
                          return (
                            <motion.div key={result.projectSlug}
                              initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: i * 0.06 }}>
                              <RisingCard
                                result={result}
                                project={project}
                                isVerified={Boolean(verifiedOwners[result.projectSlug])}
                                onSelect={(proj) => { openProject(proj, setSelectedProject); setTab('discover') }}
                              />
                            </motion.div>
                          )
                        })}
                      </section>
                    )}

                    {/* Sentiment Shifts */}
                    {sentimentShifts.length > 0 && (
                      <section className="space-y-3">
                        <div className="flex items-center gap-2">
                          <TrendingUp size={14} style={{ color: 'var(--accent)' }} />
                          <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                            Sentiment Shifts
                          </p>
                          <p className="text-xs" style={{ color: 'var(--subtle)' }}>notable community opinion changes</p>
                        </div>
                        {sentimentShifts.map((result, i) => {
                          const project = projectsWithReviews.find((p) => p.id === result.projectSlug)
                          return (
                            <motion.div key={result.projectSlug}
                              initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: i * 0.06 }}>
                              <RisingCard
                                result={result}
                                project={project}
                                isVerified={Boolean(verifiedOwners[result.projectSlug])}
                                onSelect={(proj) => { openProject(proj, setSelectedProject); setTab('discover') }}
                              />
                            </motion.div>
                          )
                        })}
                      </section>
                    )}

                    {/* Most Boosted */}
                    {mostBoosted.length > 0 && (
                      <section className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Zap size={14} style={{ color: 'var(--accent)' }} />
                          <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                            Most Boosted
                          </p>
                          <p className="text-xs" style={{ color: 'var(--subtle)' }}>highest review boost activity this week</p>
                        </div>
                        {mostBoosted.map((result, i) => {
                          const project = projectsWithReviews.find((p) => p.id === result.projectSlug)
                          return (
                            <motion.div key={result.projectSlug}
                              initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: i * 0.06 }}>
                              <RisingCard
                                result={result}
                                project={project}
                                isVerified={Boolean(verifiedOwners[result.projectSlug])}
                                onSelect={(proj) => { openProject(proj, setSelectedProject); setTab('discover') }}
                              />
                            </motion.div>
                          )
                        })}
                      </section>
                    )}

                  </div>
                )
              })()}
            </motion.div>
          )}

          {/* ── Leaderboard ────────────────────────────────────────────────── */}
          {tab === 'leaderboard' && (
            <motion.div key="leaderboard" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.18 }} className="space-y-3">
              <div className="mb-1">
                <h2 className="display font-semibold text-lg" style={{ color: 'var(--ink)' }}>Most Bullish Projects</h2>
                <p className="text-sm" style={{ color: 'var(--muted)' }}>Ranked by community bullish sentiment</p>
              </div>
              {isHydrating
                ? [0, 1, 2, 3, 4].map((i) => <SkeletonLeaderboardRow key={i} />)
                : leaderboard.map((p, i) => (
                    <motion.div key={p.id} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}>
                      <LeaderboardRow project={p} rank={i + 1} onSelect={(proj) => openProject(proj, setSelectedProject)} />
                    </motion.div>
                  ))}
            </motion.div>
          )}

          {/* ── Polls ──────────────────────────────────────────────────────── */}
          {tab === 'polls' && (
            <motion.div key="polls" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.18 }} className="space-y-4">
              <div className="mb-1">
                <h2 className="display font-semibold text-lg" style={{ color: 'var(--ink)' }}>Community Polls</h2>
                <p className="text-sm" style={{ color: 'var(--muted)' }}>What does the Arc community think?</p>
              </div>
              {isHydrating
                ? [0, 1].map((i) => <SkeletonPollWidget key={i} />)
                : polls.map((poll, i) => (
                    <motion.div key={poll.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}>
                      <PollWidget
                        poll={poll}
                        votedOption={pollVotes[poll.id] ?? null}
                        onVote={handlePollVote}
                        isConnected={isConnected}
                      />
                    </motion.div>
                  ))}
            </motion.div>
          )}

          {/* ── Activity ───────────────────────────────────────────────────── */}
          {tab === 'activity' && (
            <motion.div key="activity" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.18 }} className="space-y-5">

              {/* Header */}
              <div className="mb-1 space-y-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="display font-semibold text-lg" style={{ color: 'var(--ink)' }}>
                    {isConnected ? 'Your Activity' : 'Activity'}
                  </h2>
                  {isConnected && (
                    <ReputationBadge tier={reputation.tier} score={reputation.score} size="md" />
                  )}
                </div>
                {isConnected && (
                  <p className="text-sm" style={{ color: 'var(--muted)' }}>
                    {activity.totalVotesCast} vote{activity.totalVotesCast !== 1 ? 's' : ''} · {activity.reviewsPosted.length} review{activity.reviewsPosted.length !== 1 ? 's' : ''} · {activity.pollVoteHistory.length} poll vote{activity.pollVoteHistory.length !== 1 ? 's' : ''}
                  </p>
                )}
                {isConnected && reputation.predictionAccuracy.total > 0 && (
                  <div className="flex items-center gap-1.5 text-sm" style={{ color: 'var(--muted)' }}>
                    <Target size={14} style={{ color: 'var(--accent)' }} />
                    <span className="tabular-nums font-semibold" style={{ color: 'var(--ink-2)' }}>
                      {reputation.predictionAccuracy.pct}%
                    </span>
                    <span>accuracy ({reputation.predictionAccuracy.correct}/{reputation.predictionAccuracy.total} predictions)</span>
                  </div>
                )}
                {!isConnected && (
                  <p className="text-sm" style={{ color: 'var(--muted)' }}>
                    Connect your wallet to track your votes and reviews
                  </p>
                )}
              </div>

              {/* Alerts section */}
              {alerts.length > 0 && (
                <section className="space-y-2">
                  <div className="flex items-center gap-2">
                    <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                      Alerts ({alerts.length})
                    </p>
                    {unreadCount > 0 && !alertsRead && (
                      <span className="text-xs font-bold px-1.5 py-0.5 rounded-full"
                        style={{ background: 'var(--bearish)', color: '#fff' }}>
                        {unreadCount} new
                      </span>
                    )}
                  </div>
                  {alerts.slice(0, 10).map((alert) => (
                    <div key={alert.id}
                      className="flex items-center gap-3 px-4 py-3 rounded-xl"
                      style={{
                        background: alert.read ? 'var(--surface)' : 'rgba(26,92,255,0.05)',
                        border: `1px solid ${alert.read ? 'var(--border)' : 'rgba(26,92,255,0.15)'}`,
                      }}>
                      <Bell size={14} style={{ color: 'var(--accent)', flexShrink: 0 }} />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium" style={{ color: 'var(--ink)' }}>
                          {alert.projectName}
                        </p>
                        <p className="text-xs" style={{ color: 'var(--muted)' }}>
                          {alert.direction === 'bullish' ? 'Bullish' : 'Bearish'} sentiment shifted +{alert.delta}pp
                        </p>
                      </div>
                      <span className="text-xs flex-shrink-0" style={{ color: 'var(--subtle)' }}>
                        {new Date(alert.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  ))}
                </section>
              )}

              {!isConnected ? (
                <div className="py-14 flex flex-col items-center gap-4 rounded-2xl text-center"
                  style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
                  <div className="w-14 h-14 rounded-2xl flex items-center justify-center"
                    style={{ background: 'var(--surface-muted)' }}>
                    <Activity size={24} style={{ color: 'var(--muted)' }} />
                  </div>
                  <div className="space-y-1">
                    <p className="font-semibold" style={{ color: 'var(--ink)' }}>No wallet connected</p>
                    <p className="text-sm max-w-full" style={{ color: 'var(--subtle)' }}>
                      Connect a wallet to see your votes, reviews, and poll activity here.
                    </p>
                  </div>
                  <ConnectKitButton />
                </div>
              ) : activity.totalVotesCast === 0 && activity.reviewsPosted.length === 0 && activity.pollVoteHistory.length === 0 ? (
                <div className="py-14 flex flex-col items-center gap-4 rounded-2xl text-center"
                  style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
                  <div className="w-14 h-14 rounded-2xl flex items-center justify-center"
                    style={{ background: 'rgba(26,92,255,0.08)' }}>
                    <TrendingUp size={24} style={{ color: 'var(--accent)' }} />
                  </div>
                  <div className="space-y-1.5">
                    <p className="font-semibold" style={{ color: 'var(--ink)' }}>Nothing here yet</p>
                    <p className="text-sm max-w-full" style={{ color: 'var(--subtle)' }}>
                      Cast your first vote on the Discover tab to start building your on-chain reputation.
                    </p>
                  </div>
                  <button onClick={() => setTab('discover')}
                    className="px-5 py-2.5 rounded-xl text-sm font-semibold transition-opacity hover:opacity-90"
                    style={{ background: 'var(--accent)', color: 'var(--bg)' }}>
                    Go to Discover
                  </button>
                </div>
              ) : (
                <>
                  {activity.voteHistory.length > 0 && (
                    <section className="space-y-2">
                      <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                        Votes ({activity.voteHistory.length})
                      </p>
                      {activity.voteHistory.map((item) => (
                        <div key={item.projectId}
                          className="flex items-center justify-between px-4 py-3 rounded-xl min-h-[44px]"
                          style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
                          <button onClick={() => {
                            const proj = projectsWithReviews.find((p) => p.id === item.projectId)
                            if (proj) { openProject(proj, setSelectedProject); setTab('discover') }
                          }} className="text-sm font-medium text-left hover:opacity-70 transition-opacity" style={{ color: 'var(--ink)' }}>
                            {item.projectName}
                          </button>
                          <span className="text-xs font-semibold capitalize px-2 py-1 rounded-full flex-shrink-0"
                            style={{
                              background: item.sentiment === 'bullish' ? 'rgba(26,128,71,0.10)' : item.sentiment === 'bearish' ? 'rgba(186,43,76,0.10)' : 'rgba(107,101,128,0.10)',
                              color: item.sentiment === 'bullish' ? 'var(--bullish)' : item.sentiment === 'bearish' ? 'var(--bearish)' : 'var(--neutral)',
                            }}>
                            {item.sentiment}
                          </span>
                        </div>
                      ))}
                    </section>
                  )}

                  {activity.reviewsPosted.length > 0 && (
                    <section className="space-y-2">
                      <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                        Reviews ({activity.reviewsPosted.length})
                      </p>
                      {activity.reviewsPosted.map((r) => (
                        <div key={r.id} className="p-4 rounded-2xl space-y-1.5"
                          style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-semibold" style={{ color: 'var(--ink-2)' }}>{r.projectName}</span>
                            <span className="text-xs capitalize px-2 py-0.5 rounded-full"
                              style={{
                                background: r.sentiment === 'bullish' ? 'rgba(26,128,71,0.10)' : r.sentiment === 'bearish' ? 'rgba(186,43,76,0.10)' : 'rgba(107,101,128,0.10)',
                                color: r.sentiment === 'bullish' ? 'var(--bullish)' : r.sentiment === 'bearish' ? 'var(--bearish)' : 'var(--neutral)',
                              }}>
                              {r.sentiment}
                            </span>
                          </div>
                          <p className="text-sm leading-relaxed" style={{ color: 'var(--ink-2)' }}>{r.body}</p>
                        </div>
                      ))}
                    </section>
                  )}

                  {activity.pollVoteHistory.length > 0 && (
                    <section className="space-y-2">
                      <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                        Poll Votes ({activity.pollVoteHistory.length})
                      </p>
                      {activity.pollVoteHistory.map((pv) => (
                        <div key={pv.pollId}
                          className="flex items-start justify-between gap-3 px-4 py-3 rounded-xl min-h-[44px]"
                          style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
                          <span className="text-sm flex-1" style={{ color: 'var(--ink-2)' }}>{pv.question}</span>
                          <span className="text-xs font-semibold flex-shrink-0 px-2 py-1 rounded-full"
                            style={{ background: 'rgba(26,92,255,0.08)', color: 'var(--accent)' }}>
                            {pv.chosenLabel}
                          </span>
                        </div>
                      ))}
                    </section>
                  )}

                  {/* ── Platform milestone events ───────────────────────────── */}
                  {platformMomentum.ranked.length > 0 && (() => {
                    const recentMilestones = platformMomentum.ranked.flatMap((r) =>
                      achievedMilestones(r.signals, r.momentumIndex).map((m) => ({
                        ...m,
                        projectSlug: r.projectSlug,
                      }))
                    ).slice(0, 6)
                    if (recentMilestones.length === 0) return null
                    return (
                      <section className="space-y-2">
                        <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>
                          Community Milestones
                        </p>
                        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                          {recentMilestones.map((m) => {
                            const proj = projectsWithReviews.find((p) => p.id === m.projectSlug)
                            if (!proj) return null
                            return (
                              <MilestoneShareCard
                                key={`${m.projectSlug}-${m.id}`}
                                milestone={m}
                                project={proj}
                                compact
                              />
                            )
                          })}
                        </div>
                      </section>
                    )
                  })()}
                </>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Project detail sheet */}
      <ProjectDetailSheet
        project={selectedProject}
        userVote={selectedProject ? (userVotes[selectedProject.id] ?? null) : null}
        onVote={(id, s) => { void handleVote(id, s) }}
        onClose={() => closeProject(setSelectedProject)}
        onReview={(id, body, s) => { void handleReview(id, body, s) }}
        onHelpful={handleHelpful}
        helpfulVoted={helpfulVoted}
        isConnected={isConnected}
        connectedAddress={address}
        allProjects={projectsWithReviews}
        reviewOverrides={reviewOverrides}
        seedHelpfulDeltas={seedHelpfulDeltas}
        verifiedOwners={verifiedOwners}
        projectOverrides={projectOverrides}
        onSaveProjectOverride={handleSaveProjectOverride}
        isWatched={selectedProject ? isWatched(selectedProject.id) : false}
        onToggleWatchlist={toggleWatchlist}
        contractAddress={CONTRACT_ADDRESS}
        analyticsRefetchKey={analyticsRefetchTick}
        lastReportGenerated={adminConfig.lastReportGenerated}
        markReportGenerated={adminConfig.markReportGenerated}
        saveProjectOverrideSupabase={saveProjectOverride}
        refetchOverrides={refetchOverrides}
        isBlacklisted={blacklist.isBlacklisted}
        platformMomentum={platformMomentum.ranked}
      />

      <NetworkGuard isWrongChain={isWrongChain} />

      <SubmitProjectModal
        isOpen={isSubmitOpen}
        isConnected={isConnected}
        address={address}
        taxonomy={taxonomy}
        onClose={() => setIsSubmitOpen(false)}
        onSubmit={(_newProject) => {
          // Called only when Supabase is not configured (local fallback)
          refetchSubmitted()
          setIsSubmitOpen(false)
        }}
      />

      <AdminPanel
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        contractAddress={CONTRACT_ADDRESS}
        adminConfig={adminConfig}
        allProjects={projectsWithReviews}
        saveProjectOverride={saveProjectOverride}
        refetchOverrides={refetchOverrides}
        blacklist={blacklist}
        platformMomentum={platformMomentum}
      />
    </div>
  )
}

// ── Root ──────────────────────────────────────────────────────────────────────
export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Wallet-address route (existing — preserved) */}
        <Route path="/profile/:address" element={<ProfilePageWrapper />} />
        {/* Username route — /profile/@alice resolves username to wallet address */}
        <Route path="/profile/%40:username" element={<ProfilePageWrapper byUsername />} />
        <Route path="/widget/:projectId" element={<WidgetPageWrapper />} />
        <Route path="*" element={<AppInner />} />
      </Routes>
    </BrowserRouter>
  )
}

function ProfilePageWrapper({ byUsername = false }: { byUsername?: boolean }) {
  const { address: routeAddress, username: routeUsername } = useParams<{ address?: string; username?: string }>()
  const [reviewOverrides] = useLocalStorage<Record<string, StoredReview[]>>('myarc:reviews', {})
  const [seedHelpfulDeltas] = useLocalStorage<Record<string, number>>('myarc:helpful-deltas', {})
  const [userVotes] = useLocalStorage<Record<string, Sentiment>>('myarc:votes', {})
  const { address } = useAccount()
  const { profile, updateProfile } = useProfile()
  // Phase 3: auth state for the profile owner's edit flow
  const { status: authStatus, signIn } = useAuth()
  // When reached via /profile/@username, resolve username → wallet address
  const [resolvedAddress, setResolvedAddress] = useState<string | undefined>(
    byUsername ? undefined : routeAddress
  )
  const [usernameNotFound, setUsernameNotFound] = useState(false)

  useEffect(() => {
    if (!byUsername || !routeUsername) return
    // Fetch by username via Supabase public read
    void fetchProfileByUsername(routeUsername).then((p) => {
      if (p) {
        setResolvedAddress(p.walletAddress)
      } else {
        setUsernameNotFound(true)
      }
    })
  }, [byUsername, routeUsername])

  const userVotesByAddress = useMemo(() => {
    if (!address) return {}
    return { [address.toLowerCase()]: userVotes }
  }, [address, userVotes])

  if (byUsername && usernameNotFound) {
    return (
      <div className="min-h-dvh flex items-center justify-center" style={{ background: 'var(--bg-gradient)' }}>
        <div className="text-center space-y-2 px-6">
          <p className="font-semibold text-lg" style={{ color: 'var(--ink)' }}>Profile not found</p>
          <p className="text-sm" style={{ color: 'var(--muted)' }}>
            @{routeUsername} has not created a MYARC profile.
          </p>
        </div>
      </div>
    )
  }

  if (byUsername && !resolvedAddress) {
    return (
      <div className="min-h-dvh flex items-center justify-center" style={{ background: 'var(--bg-gradient)' }}>
        <div className="w-8 h-8 rounded-full border-2 border-t-transparent animate-spin"
          style={{ borderColor: 'var(--accent) transparent transparent transparent' }} />
      </div>
    )
  }

  return (
    <ProfilePage
      projects={PROJECTS}
      userVotesByAddress={userVotesByAddress}
      reviewOverrides={reviewOverrides}
      seedHelpfulDeltas={seedHelpfulDeltas}
      connectedAddress={address}
      ownProfile={profile}
      onUpdateProfile={updateProfile}
      overrideAddress={resolvedAddress}
      authStatus={authStatus}
      onSignIn={signIn}
    />
  )
}

/**
 * Widget route — /widget/:projectId
 * Renders PulseBadge full-page with transparent background and no app shell.
 * Serves the iFrame embed use case.
 */
function WidgetPageWrapper() {
  const { projectId } = useParams<{ projectId: string }>()

  if (!projectId) {
    return (
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        minHeight: '100vh', background: 'transparent',
        fontFamily: '"DM Sans", system-ui, sans-serif', color: '#8b949e',
        fontSize: '0.85rem',
      }}>
        No project specified.
      </div>
    )
  }

  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      minHeight: '100vh',
      background: 'transparent',
      padding: '16px',
    }}>
      <PulseBadge
        projectId={projectId}
        contractAddress={CONTRACT_ADDRESS ?? ''}
        size="md"
        theme="dark"
      />
    </div>
  )
}
