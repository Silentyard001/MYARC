# MYARC — Ecosystem Grant Application

**Applicant:** MYARC (solo project, independent builder)
**Category:** Infrastructure / Developer Tooling
**Requested Funding:** $45,000 USDC
**Stage:** Deployed on Arc Testnet, feature-complete v2

---

## Overview

MYARC is a community sentiment and reputation platform built natively on Arc. It is the first on-chain signal layer for the Arc ecosystem — a place where developers, users, and token holders can discover Arc-native projects, vote on their sentiment, leave verified reviews, and participate in staked community polls. Every meaningful action is anchored to Arc Testnet today, with mainnet deployment planned upon audit completion.

The deployed contract — `MYARC.sol` at `0xb703ce22c104d326c2abd40da4ba0a0b631b34e9` on Arc Testnet — handles votes, reviews, flags, project verification, and staked polls with proportional reward distribution. The frontend at this repo is production-quality React + TypeScript, tested with 110+ Foundry unit and fuzz tests.

---

## The Problem

Arc is a fast, USDC-native chain with genuine technical advantages: sub-second finality, predictable gas costs, and native stablecoin settlement. But the ecosystem lacks shared signal infrastructure. Right now:

- There is no trusted, community-sourced way to evaluate Arc-native projects.
- There is no reputation layer that lets builders and users distinguish long-term community contributors from drive-by participants.
- There is no shared polling mechanism for the ecosystem to coordinate views on direction, priorities, and protocol parameters.
- There is no analytics surface that gives project teams insight into how their community feels about them over time.

This is not a soft problem. Ecosystems that lack credible signal infrastructure attract low-quality projects and struggle to retain the users and capital needed for compound growth. Trust needs a substrate.

---

## The Solution

MYARC is that substrate. Concretely:

**Sentiment Voting** — Any wallet can vote bullish, neutral, or bearish on any listed Arc project. Votes are on-chain (`vote()`, `retractVote()`, `batchVote()`), epoch-aware, and EIP-712 gasless-compatible. Votes are not permanent — users can change or retract them as their view evolves.

**Verified Reviews** — Text reviews up to 400 bytes are stored on-chain, author-indexed, and linked to on-chain sentiment. Reviews can be flagged by the community; three distinct flags collapse a review with a "show anyway" disclosure. Helpful votes accumulate on-chain and feed into reputation scoring.

**Reputation System** — A tier-based reputation model (Newcomer → Analyst → Pioneer → Whale) accumulates score from votes, reviews, helpful votes received, early-adopter bonuses, and prediction accuracy. Reputation is cross-session and wallet-bound, making MYARC meaningful as long-term social capital.

**Project Verification** — Project teams can claim ownership of their listing by paying a 5 USDC verification fee on-chain. The fee goes directly to the contract owner. Verified projects receive a `BadgeCheck` badge on all discovery surfaces. The first-claim-wins mechanic is enforced at the contract level.

**Staked Community Polls** — The contract owner can create polls with on-chain stake mechanics. Voters stake Arc-native USDC; after a poll ends, the total pool is distributed proportionally to voters who picked the winning option by their individual stake share. This is not a prediction market — it is a community coordination mechanism with real economic stakes.

**Analytics for Project Owners** — Verified project owners see a private analytics tab with a 7-day sentiment timeline (pure-SVG line chart), review volume bar chart, sentiment health score, top reviewers, and a downloadable JSON report. All data is derived from live on-chain event logs — no indexer dependency.

**Admin Interface** — A contract-owner-only admin panel lets the MYARC operator mark projects as featured (surfaced at the top of Discover and in a dedicated horizontal strip) and mark polls as sponsored (with a named sponsor label). Featured and sponsored status is persisted to Supabase and merged into the frontend dynamically.

**Watchlist and Alerts** — Users can bookmark projects. A polling loop checks sentiment every 60 seconds against a snapshot and fires alerts when bullish or bearish sentiment shifts by 15+ percentage points, surfaced in the Activity tab with an unread badge.

---

## Technical Architecture

**Smart Contract (`contracts/MYARC.sol`)**
- Solidity 0.8.28, OpenZeppelin v5 (EIP712, ECDSA, Ownable)
- Epoch-aware vote tallies (configurable window, default 7 days)
- EIP-712 `voteBySig` for gasless meta-transactions
- `postReview` with 400-byte cap and indexed pagination
- `verifyProject` (payable, first-claim, fee-forwarded)
- `createPoll` / `voteOnPoll` / `claimPollReward` with proportional stake distribution
- `getWinnerStakeTotal`, `getPollResult`, `getPollStake` view functions
- 110+ unit and fuzz tests, all passing

**Frontend**
- React 18 + TypeScript + Vite + Tailwind CSS
- wagmi v2 + ConnectKit for wallet connectivity (Arc Testnet default)
- Framer Motion animations throughout
- localStorage + Supabase hybrid state (votes and reviews optimistic; flags and admin config Supabase-backed)
- Pure-SVG charts (no chart library dependency)
- React Router v6 for wallet profile pages (`/profile/:address`)

**On-Chain Event Indexing**
- `useOnchainActivity` — fetches `Voted`, `VoteRetracted`, `ReviewPosted` events per connected wallet
- `useVerifiedOwners` — fetches all `ProjectVerified` events and returns a slug→address map
- `useProjectAnalytics` — fetches all three event types for a specific project, batch-fetches block timestamps in a single `Promise.all`, and derives 7-day sentiment timeline, review volume, live breakdown, and top reviewers
- All event queries use `publicClient.getLogs` with `fromBlock: 0n` — no subgraph required today, though a subgraph is in the roadmap for scalability

**Infrastructure**
- Supabase: `review_flags` (shared community flags), `featured_projects`, `sponsored_polls`, `revenue_entries` (off-chain placement tracking)
- Deployed via Circle Smart Contract Platform to Arc Testnet; no private key exposure in CI

---

## Current State

- Contract deployed at `0xb703ce22c104d326c2abd40da4ba0a0b631b34e9` on Arc Testnet (v2, deployed September 2026)
- 6 seed projects listed across DeFi, Bridge, NFT, Gaming, DAO, and Infrastructure categories
- 4 community polls live (one sponsored)
- 2 featured projects (ArcSwap, BridgeArc) with dynamic featured strip
- Full sentiment voting, review, and poll-vote flows working end-to-end on testnet
- Reputation system with prediction accuracy tracking fully functional
- Admin panel live (contract owner only): featured, sponsored, revenue tracking
- 110+ Foundry tests passing (unit + fuzz), zero lint/typecheck errors

---

## Traction and Community Value

MYARC is infrastructure, not an application. Its value compounds with the number of projects and users in the ecosystem:

- Every new Arc project needs somewhere for the community to form a public view on it.
- Every new user needs a way to distinguish signal from noise when evaluating where to deploy capital.
- Every builder needs feedback loops that are verifiable and not manipulable by a single actor.
- The verification fee mechanic creates a small but real barrier against spam listings while generating on-chain revenue for the protocol operator.
- Staked polls create economic commitment around ecosystem direction decisions.

As Arc's project count grows, MYARC becomes more valuable — not less. This is the network-effect property that makes it worth funding as ecosystem infrastructure rather than as a standalone application.

---

## Roadmap

**Q4 2026 — Production hardening**
- Security audit of `MYARC.sol` by a reputable firm (see funding request)
- Subgraph deployment on Arc Testnet for scalable event indexing (replace current `getLogs` polling)
- Mobile-first responsive redesign (current layout is desktop-first)
- Mainnet deployment on Arc after audit completion

**Q1 2027 — Growth**
- Community-driven project submission moderation (verified owners can endorse new submissions)
- Cross-project reputation leaderboard (public, filterable by tier)
- Notification webhooks for watched projects (push-style alerts, not poll-based)
- USDC-denominated poll staking surfaced through ConnectKit (full wallet flow, not just contract interaction)

**Q2 2027 — Monetization layer**
- Featured placement sales (currently manual admin; automated purchase flow via contract)
- Sponsored poll marketplace — any project can pay to create a sponsored poll
- Project analytics API (read-only, rate-limited, for dashboards and third-party integrations)
- MYARC SDK (npm package) for embedding sentiment bars and vote counts in third-party frontends

---

## Team

Solo project — one builder. Background: full-stack and smart contract development, previously shipped two production DeFi protocols on EVM chains. MYARC was designed, built, and deployed end-to-end as a single-person project, which is also a constraint — the primary risk is bandwidth, not technical competence. The grant funding is specifically intended to bring in a security auditor and a frontend contractor for mobile optimization and design polish.

---

## Funding Request: $45,000 USDC

| Item | Amount |
|---|---|
| Smart contract security audit (1 contract, ~700 lines) | $18,000 |
| Frontend mobile optimization + design polish (contractor, 6 weeks) | $14,000 |
| Subgraph development and hosting (6 months) | $6,000 |
| Marketing, community growth, and ecosystem outreach | $5,000 |
| Operational reserve (infra, Supabase, 6 months) | $2,000 |
| **Total** | **$45,000** |

The audit is the largest and most important line item. `MYARC.sol` holds user stakes (poll votes) and forwards verification fees — it must be audited before mainnet. Without a grant, mainnet deployment is delayed indefinitely.

---

## Why MYARC is Foundational

Every healthy ecosystem has a reputation and signal layer. Ethereum has Token Terminal, DeFiLlama, and Messari. Solana has Step Finance dashboards and community wikis. These tools don't just display data — they shape capital allocation, project priorities, and ecosystem narrative.

Arc does not have this yet. MYARC is the most direct path to filling that gap: it is already deployed, already tested, and already demonstrates the core value proposition. Funding it now — before Arc's project count scales — means the signal infrastructure is in place before it is needed, rather than after.

The alternative is that Arc's growth happens without a shared signal layer. Projects compete on marketing spend rather than verified community reputation. Users have no credible way to distinguish quality from noise. Capital flows to whoever has the loudest voice, not the strongest fundamentals.

MYARC is the fix for that before it becomes a problem.

---

*Contract address: `0xb703ce22c104d326c2abd40da4ba0a0b631b34e9` (Arc Testnet)*
*Explorer: https://explorer.testnet.arc.io/address/0xb703ce22c104d326c2abd40da4ba0a0b631b34e9*
*Deploy tx: `0x03d4a593dcfff7b84daf59fde7ab192fc1bfdad302f99175d999bcf390b4303b`*
