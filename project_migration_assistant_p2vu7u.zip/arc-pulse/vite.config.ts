import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'
import { nodePolyfills } from 'vite-plugin-node-polyfills'

export default defineConfig({
  plugins: [react(), nodePolyfills()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
    dedupe: ['react', 'react-dom'],
  },
  optimizeDeps: {
    include: [
      'react',
      'react-dom',
      'react-dom/client',
      'react/jsx-runtime',
      '@tanstack/react-query',
      'wagmi',
      'wagmi/chains',
      'wagmi/connectors',
      'viem',
      'viem/chains',
      'connectkit',
      'framer-motion',
      'lucide-react',
      'sonner',
      'clsx',
      'tailwind-merge',
      'vite-plugin-node-polyfills/shims/buffer',
      'vite-plugin-node-polyfills/shims/global',
      'vite-plugin-node-polyfills/shims/process',
    ],
  },
  build: {
    // ConnectKit bundles its own UI + wallet icons and cannot be split further.
    // Raise the warning threshold to suppress the false positive for that vendor chunk.
    chunkSizeWarningLimit: 1000,
    rollupOptions: {
      output: {
        manualChunks: {
          // Heavy wallet/blockchain libs — loaded once, rarely change
          'vendor-wagmi': ['wagmi', 'wagmi/chains', 'wagmi/connectors', 'viem', 'viem/chains'],
          // ConnectKit UI — sizeable, independently cacheable
          'vendor-connectkit': ['connectkit'],
          // Framer Motion — animation runtime
          'vendor-motion': ['framer-motion'],
          // React core
          'vendor-react': ['react', 'react-dom', 'react-dom/client', 'react/jsx-runtime'],
          // Remaining third-party utilities
          'vendor-misc': ['@tanstack/react-query', 'lucide-react', 'sonner', 'clsx', 'tailwind-merge'],
        },
      },
    },
  },
  server: {
    allowedHosts: true,
    cors: true,
  },
})
