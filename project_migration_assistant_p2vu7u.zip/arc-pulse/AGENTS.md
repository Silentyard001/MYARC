# MYARC

> Built with Arc Studio - money-powered apps in minutes

This is the **project memory** - what Arc Studio remembers about building this app. It helps future agents (or humans) understand and extend the project.

---

## What This App Does

MYARC is a social sentiment platform for the Arc blockchain ecosystem. Users can:

- **Discover projects** — browse Arc-native protocols (DEXs, yield vaults, bridges, NFT marketplaces, DAOs, and more) with search and tag-based filtering.
- **Vote on sentiment** — cast a Bullish, Neutral, or Bearish vote on any project; votes are toggle-able (tap again to unvote). Animated sentiment bars show the live community split.
- **Write reviews** — leave a typed review with a sentiment label on any project; reviews display the reviewer's wallet address, timestamp, and helpful count.
- **Community leaderboard** — projects ranked by their bullish sentiment percentage with live mini vote bars.
- **Community polls** — multi-option polls on ecosystem topics (sector growth, UX improvements, gas model opinions); users vote once and results animate in with percentage breakdowns and a countdown to the poll deadline.
- **Wallet connection** — ConnectKit wallet integration on Arc Testnet (Chain ID 5042002) with USDC as the native gas token.

The on-chain component (`MYARC.sol`) stores votes and reviews permanently on Arc Testnet, enforces one-vote-per-address-per-project, and emits events for indexing. The frontend uses local React state for immediate optimistic updates and can be wired to read live contract state.

## Deployed Contracts

### Current (v5 — flexible verification fee: whitelist, custom fee per wallet, pause, getEffectiveFee, VerificationFeeCharged event)

| Contract | Network | Address | Explorer |
|---|---|---|---|
| `MYARC` | Arc Testnet | `0x101d8fb447acafac5a1269a46c6c62af796beb5e` | [View](https://explorer.testnet.arc.io/address/0x101d8fb447acafac5a1269a46c6c62af796beb5e) |

Constructor args: `epochDuration = 0` (defaults to 7 days = 604800 s), `initialOwner = 0x551f1372eBf01fB6650863909f9dAe6EE88d04bA`
Deploy tx: `0x65822d802864dc8b13b52d370d97c086490814f7590452c4f126460803fe1a01`
Deployed: 2026-09-19
Owner: `0x551f1372eBf01fB6650863909f9dAe6EE88d04bA` (verified via `cast call owner()`)
Default verificationFee: `5e18` (5 USDC); whitelisted wallets pay 0; custom fee overrides per wallet supported.

### Superseded (v4 — missing flexible fee system)

| Contract | Network | Address | Explorer |
|---|---|---|---|
| `MYARC` | Arc Testnet | `0xb703ce22c104d326c2abd40da4ba0a0b631b34e9` | [View](https://explorer.testnet.arc.io/address/0xb703ce22c104d326c2abd40da4ba0a0b631b34e9) |

Deploy tx: `0x03d4a593dcfff7b84daf59fde7ab192fc1bfdad302f99175d999bcf390b4303b`
Deployed: 2026-09-18

### Superseded (v1 — missing poll and verifyProject functions)

| Contract | Network | Address | Explorer |
|---|---|---|---|
| `MYARC` | Arc Testnet | `0x411c8e3ba131e92faddf0e0a5d6ebd565b22894b` | [View](https://explorer.testnet.arc.io/address/0x411c8e3ba131e92faddf0e0a5d6ebd565b22894b) |

Deploy tx: `0x6cdf45b3f286d283c39cc437a0ee8f717c25ad0f1c142b7066f26cf62ef53430`
Deployed: 2026-09-17

## Tech Stack

- Frontend: React 18, Vite, TypeScript, Tailwind CSS
- Web3: wagmi v2, viem v2, ConnectKit
- Contracts: Solidity 0.8.28 + Foundry. Sources in `contracts/`, unit tests in `contracts/test/*.t.sol`. Build with `bun run contracts:build` (`forge build`), test with `bun run contracts:test` (`forge test`).
- Wallet: injected (MetaMask, etc.)
- Chain: Arc Testnet (Chain ID: 5042002, imported from `viem/chains`)
- Token: USDC (6 decimals) (Address: 0x3600000000000000000000000000000000000000, Chain: Arc Testnet)
- Toasts: Sonner

## Key Files

- `src/App.tsx` - Main application logic
- `src/components/` - UI components
- `src/config.ts` - wagmi config (chains, connectors, transports)

## Subgraph (Goldsky)

The `subgraph/` directory at the project root contains a Goldsky-compatible subgraph
definition for `MYARC`. It indexes `Voted`, `VoteRetracted`, `ReviewPosted`,
`ProjectVerified`, `PollVoteCast`, and `PollRewardClaimed` events from the v5
contract (`0x101d8fb447acafac5a1269a46c6c62af796beb5e`).

**Address last updated:** 2026-09-19 (updated from v3 `0x9bf7bc1b866d4b8a24c024d1de623dbd392df03e` to v5 `0x101d8fb447acafac5a1269a46c6c62af796beb5e`)

**Deployment steps:**

```bash
# 1. Install the Goldsky CLI (one-time)
curl -fsSL https://cli.goldsky.com/install | bash

# 2. Authenticate (one-time — opens browser)
goldsky login

# 3. Deploy the subgraph
bun run subgraph:deploy
# equivalent to: goldsky subgraph deploy myarc/1.0.0 --path subgraph/
```

After deployment Goldsky will print a GraphQL endpoint URL in the form:
`https://api.goldsky.com/api/public/<project-id>/subgraphs/myarc/1.0.0/gn`

Set it as an environment variable so the frontend uses the subgraph instead of
direct RPC log queries:

```
VITE_SUBGRAPH_URL=<your-goldsky-endpoint>
```

When `VITE_SUBGRAPH_URL` is absent the frontend falls back automatically to direct
`getLogs` calls against the Arc Testnet RPC — no functionality is lost.

**Updating after a redeployment:**
- Edit `subgraph/subgraph.yaml` with the new contract address and bump the version.
- Run `goldsky subgraph deploy myarc/<new-version> --path subgraph/`.

## Supabase Security

### Admin Authorization (Phase 3b)

Admin write access requires the owner wallet to complete SIWE authentication (`useAuth.signIn()`). The `auth-verify` Edge Function sets a `wallet_address` custom claim in the JWT after verifying the EIP-191 signature. RLS policies check this claim — it is cryptographically signed and cannot be forged by a browser.

`getAdminClient()` in `src/lib/supabase.ts` returns the shared Supabase client (which carries the JWT session). No custom HTTP header is set or trusted for admin authorization.

**Tables with owner-gated writes:** `featured_projects`, `sponsored_polls`, `revenue_entries`, `onchain_polls`, `announcements`, `blacklisted_wallets`, `project_edit_log`, `review_moderation`, `pinned_reviews`, `review_responses`, `project_overrides`
**Tables with anon insert + owner update/delete:** `submitted_projects` (anyone can submit; only owner can approve/reject), `review_flags` (anyone can flag)

**RLS policy pattern for admin tables (Phase 3b):**
```sql
-- SELECT open to all
create policy "anon read" on <table> for select using (true);
-- INSERT/UPDATE/DELETE only for authenticated owner wallet (JWT claim)
create policy "admin_jwt_write" on <table> for all
  to authenticated
  using (lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA'))
  with check (lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA'));
```

Where `myarc_jwt_wallet()` is a security-definer function that reads `wallet_address` from the current request's JWT claims (see migration `20260929_phase3b_admin_auth.sql`).

**⚠ Previous mechanism (replaced):** The old `x-owner-address` HTTP header was self-asserted and could be forged by any browser. It has been removed from all tables.

## To Run

```bash
bun install
bun run dev
```
