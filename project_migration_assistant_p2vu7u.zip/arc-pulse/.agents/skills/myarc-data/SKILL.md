---
name: myarc-data
description: >
  Manages project and poll seed data for MYARC. Use when adding, editing,
  or removing projects or polls in src/data/projects.ts — covers the Project
  and Poll type shapes, required fields, logo-color conventions, and tag taxonomy.
---

# MYARC Data Skill

## File

`src/data/projects.ts` — single source of truth for all seed projects and polls.

## Project fields

| Field | Type | Notes |
|---|---|---|
| `id` | `string` | kebab-case, unique |
| `name` | `string` | Display name |
| `tagline` | `string` | One short phrase |
| `description` | `string` | 1-3 sentences |
| `tags` | `Tag[]` | Pick from the Tag union; at least one |
| `logoInitials` | `string` | 2 uppercase letters |
| `logoColor` | `string` | Tailwind `bg-[#hex]` class — use a saturated, dark color |
| `votes` | `VoteCounts` | Seed with plausible non-zero values |
| `reviews` | `Review[]` | At least 1 seed review per project |
| `tvl` | `string?` | Optional, e.g. `"$4.2M"` — only for DeFi protocols |
| `launchDate` | `string` | `"Mon YYYY"` format |

## Tag taxonomy

`'DeFi' | 'NFT' | 'Gaming' | 'Infrastructure' | 'Bridge' | 'Payments' | 'DAO' | 'Launchpad'`

Do NOT add new Tag values without also adding them to `TAG_FILTERS` in `src/App.tsx`.

## Poll fields

| Field | Type | Notes |
|---|---|---|
| `id` | `string` | `p` + number, e.g. `p4` |
| `question` | `string` | Full question sentence |
| `options` | `{ id, label, votes }[]` | 3-5 options; seed with realistic vote counts |
| `endsAt` | `number` | `Date.now() + ms` — use days: `86400000 * N` |
| `totalVotes` | `number` | Must equal `sum(options[*].votes)` |
| `category` | `string` | Short label shown above the question |

## Review shape

```ts
{
  id: string          // "r" + number, unique across all projects
  author: string      // truncated: "0xABCD...1234"
  authorFull: string  // full address or identifier
  body: string        // honest, specific, no emojis
  sentiment: Sentiment
  timestamp: number   // Date.now() - 86400000 * N  (past date)
  helpful: number     // seed 0-50
}
```

## Rules

- `totalVotes` on a poll must always equal the sum of all option `votes`.
- Review `id` values must be globally unique across all projects.
- Do not use emojis anywhere in body text or labels.
- Logo colors must contrast white text (avoid light yellows or pastels).
