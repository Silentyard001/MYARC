---
name: myarc-contract
description: >
  Smart contract knowledge for MYARC. Use when reading from or writing to
  MYARC.sol — covers the contract ABI, projectId encoding, vote/review
  flows, error handling, and how to wire wagmi hooks to each function.
---

# MYARC Contract Skill

## Contract

`contracts/MYARC.sol` — deployed on Arc Testnet (Chain ID 5042002).

Store the deployed address in `AGENTS.md` under `## Deployed Contracts` and in
`.env` as `VITE_MYARC_ADDRESS=0x...` after each deploy.

## ABI summary

### State-changing

| Function | Args | Notes |
|---|---|---|
| `vote(bytes32 projectId, uint8 sentiment)` | projectId, 0/1/2 | Overwrites previous vote automatically |
| `retractVote(bytes32 projectId)` | projectId | Reverts with `NoActiveVote` if no vote exists |
| `postReview(bytes32 projectId, uint8 sentiment, string body)` | projectId, sentiment, body | body 1-400 bytes |

### View

| Function | Returns |
|---|---|
| `tallies(bytes32)` | `(uint128 bullish, uint128 neutral, uint128 bearish)` |
| `getVote(address voter, bytes32 projectId)` | `uint8` — 0=none, 1=Bullish, 2=Neutral, 3=Bearish |
| `getReview(bytes32 projectId, uint256 index)` | `Review` struct |
| `getReviews(bytes32 projectId, uint256 offset, uint256 limit)` | `Review[]` |
| `reviewCount(bytes32)` | `uint256` |

### Events

- `Voted(bytes32 indexed projectId, address indexed voter, uint8 sentiment, bool isChange)`
- `VoteRetracted(bytes32 indexed projectId, address indexed voter)`
- `ReviewPosted(bytes32 indexed projectId, address indexed author, uint8 sentiment, uint256 reviewIndex)`

### Custom errors

- `EmptyProjectId()` — projectId is bytes32(0)
- `EmptyReviewBody()` — body is empty string
- `ReviewTooLong()` — body exceeds 400 bytes
- `NoActiveVote()` — retractVote called with no existing vote
- `ReviewIndexOutOfBounds(uint256 index, uint256 length)`

## projectId encoding

Project IDs in the frontend (`src/data/projects.ts`) are short strings like
`"arcswap"`. Encode them to bytes32 for contract calls:

```ts
import { encodeAbiParameters, parseAbiParameters, keccak256, toHex } from 'viem'

// Option A — keccak256 hash (collision-resistant, used in tests)
const projectId = keccak256(toHex('arcswap'))

// Option B — right-padded UTF-8 (human-readable in storage, max 31 bytes)
const projectId = encodeAbiParameters(parseAbiParameters('bytes32'), [
  toHex('arcswap', { size: 32 })
])[0]
```

Use Option A (keccak256) for production — it handles any-length IDs uniformly.

## wagmi hook patterns

```ts
import { useWriteContract, useWaitForTransactionReceipt, useReadContract } from 'wagmi'
import { keccak256, toHex } from 'viem'

const MYARC_ABI = [...] // import from contracts/out/MYARC.sol/MYARC.json
const MYARC_ADDRESS = import.meta.env.VITE_MYARC_ADDRESS as `0x${string}`
const CHAIN_ID = 5042002 // Arc Testnet

// Cast a vote
const { writeContract } = useWriteContract()
writeContract({
  address: MYARC_ADDRESS,
  abi: MYARC_ABI,
  functionName: 'vote',
  args: [keccak256(toHex(projectId)), sentiment], // sentiment: 0 | 1 | 2
  chainId: CHAIN_ID,
})

// Read tally
const { data: tally } = useReadContract({
  address: MYARC_ADDRESS,
  abi: MYARC_ABI,
  functionName: 'tallies',
  args: [keccak256(toHex(projectId))],
  chainId: CHAIN_ID,
})
```

## Chain validation

Always check `useAccount().chainId === 5042002` before writing. If wrong, call
`switchChain({ chainId: 5042002 })` first and show an inline "Switch to Arc
Testnet" button — never block the whole UI.

## Gas note

Arc Testnet uses USDC as native gas (same pool as the ERC-20 USDC balance).
Gas costs for `vote` are negligible (<0.001 USDC). Do NOT display an estimated
gas cost — show the action button directly.
