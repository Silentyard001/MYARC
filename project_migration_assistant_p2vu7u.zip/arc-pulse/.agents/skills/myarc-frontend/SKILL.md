---
name: myarc-frontend
description: >
  Frontend architecture guide for MYARC. Use when adding or modifying UI
  components, pages, tabs, or interaction flows — covers component map, state
  shape, design tokens, and the rules that keep the app consistent.
---

# MYARC Frontend Skill

## Stack

React 18 + Vite + TypeScript + Tailwind CSS + wagmi v2 + ConnectKit + Framer Motion

## Component map

```
src/
  App.tsx                      — root: nav, hero stats, tab routing, all state
  data/
    projects.ts                — seed data + all TypeScript types
  components/
    ProjectCard.tsx            — card shown in Discover tab; vote buttons
    ProjectDetailSheet.tsx     — bottom sheet: full description, votes, reviews, review form
    PollWidget.tsx             — single poll card; vote once, results animate in
    LeaderboardRow.tsx         — compact ranked row for Leaderboard tab
    VoteBar.tsx                — animated three-segment bar (bullish/neutral/bearish)
    SentimentBadge.tsx         — small colored chip with icon (bullish/neutral/bearish)
```

## State (all in App.tsx)

| State var | Type | Purpose |
|---|---|---|
| `projects` | `Project[]` | Live project list (votes + reviews mutated locally) |
| `polls` | `Poll[]` | Live poll list (votes mutated locally) |
| `userVotes` | `Record<string, Sentiment>` | One vote per projectId for this session |
| `pollVotes` | `Record<string, string>` | One vote per pollId (value = optionId) |
| `selectedProject` | `Project \| null` | Opens detail sheet when set |
| `tab` | `'discover' \| 'leaderboard' \| 'polls'` | Active tab |
| `search` | `string` | Discover search input |
| `tagFilter` | `TagFilter` | Active tag filter chip |

## Design tokens (CSS variables — defined in src/index.css)

| Token | Usage |
|---|---|
| `--ink` | Primary text |
| `--ink-2` | Secondary text |
| `--muted` | De-emphasised text, icons |
| `--subtle` | Timestamps, counts |
| `--surface` | Card backgrounds (glass) |
| `--surface-muted` | Input backgrounds, inner rows |
| `--surface-strong` | Sheet backgrounds |
| `--border` | Card/input borders |
| `--accent` | Primary CTA, active states (dark navy) |
| `--bullish` | Green (`#1a8047`) |
| `--bearish` | Red (`#ba2b4c`) |
| `--neutral` | Muted purple-grey (`#6b6580`) |

## Typography

- Display text: `className="display"` — Space Grotesk, letter-spacing -0.03em
- Body: DM Sans (default body font, no class needed)
- Numbers/addresses: `className="mono"` — JetBrains Mono
- Amounts/counts: always add `tabular-nums`

## Rules

- No emojis anywhere — use `lucide-react` icons only.
- Never fabricate wallet addresses, balances, or transaction hashes.
- One primary CTA per card. Secondary actions are ghost buttons or text links.
- Tap targets must be at least 44px tall.
- Show real wallet address from `useAccount().address` in reviews — never invent one.
- Animated elements use `framer-motion`; never CSS `transition` on layout props.
- After a vote or review action, fire a `toast()` from `sonner` as secondary feedback only.

## Adding a new tab

1. Add the tab ID to `type Tab` and the `TABS` array in `App.tsx`.
2. Add the `AnimatePresence` child with `key`, `initial`, `animate`, `exit`, and `transition`.
3. Create a component file in `src/components/` if the tab has more than ~30 lines of JSX.

## Adding a new component

Follow the pattern of `ProjectCard.tsx`:
- Accept typed props only — no untyped objects.
- All colors via CSS variables, not Tailwind color classes.
- Wrap the root element in `<motion.div initial animate>` for entrance animation.
- Export as a named export, not default.
