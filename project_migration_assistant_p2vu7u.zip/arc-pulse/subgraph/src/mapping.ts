import { Bytes, BigInt } from '@graphprotocol/graph-ts'
import {
  Voted,
  VoteRetracted,
  ReviewPosted,
  ProjectVerified,
  PollVoteCast,
  PollRewardClaimed,
  ReviewUpvoted,
} from '../generated/MYARC/MYARC'
import {
  Vote,
  VoteRetraction,
  Review,
  VerifiedProject,
  PollVote,
  PollRewardClaim,
  ReviewUpvote,
} from '../generated/schema'

/** Stable entity ID: tx hash + log index prevents collisions across blocks */
function eventId(txHash: Bytes, logIndex: BigInt): string {
  return txHash.toHex() + '-' + logIndex.toString()
}

export function handleVoted(event: Voted): void {
  const id = eventId(event.transaction.hash, event.logIndex)
  const entity = new Vote(id)
  entity.projectId = event.params.projectId.toHex()
  entity.voter = event.params.voter.toHex()
  entity.sentiment = event.params.sentiment
  entity.isChange = event.params.isChange
  entity.blockNumber = event.block.number
  entity.timestamp = event.block.timestamp
  entity.save()
}

export function handleVoteRetracted(event: VoteRetracted): void {
  const id = eventId(event.transaction.hash, event.logIndex)
  const entity = new VoteRetraction(id)
  entity.projectId = event.params.projectId.toHex()
  entity.voter = event.params.voter.toHex()
  entity.blockNumber = event.block.number
  entity.timestamp = event.block.timestamp
  entity.save()
}

export function handleReviewPosted(event: ReviewPosted): void {
  const id = eventId(event.transaction.hash, event.logIndex)
  const entity = new Review(id)
  entity.projectId = event.params.projectId.toHex()
  entity.author = event.params.author.toHex()
  entity.sentiment = event.params.sentiment
  entity.reviewIndex = event.params.reviewIndex
  entity.blockNumber = event.block.number
  entity.timestamp = event.block.timestamp
  entity.save()
}

export function handleProjectVerified(event: ProjectVerified): void {
  // Immutable entity — use tx hash + log index as ID so each event is stored
  // exactly once. The contract enforces first-claim-wins at the Solidity level,
  // so only one ProjectVerified event will ever be emitted per projectId.
  const id = eventId(event.transaction.hash, event.logIndex)
  const entity = new VerifiedProject(id)
  entity.projectId = event.params.projectId.toHex()
  entity.owner = event.params.owner.toHex()
  entity.blockNumber = event.block.number
  entity.timestamp = event.block.timestamp
  entity.save()
}

export function handlePollVoteCast(event: PollVoteCast): void {
  const id = eventId(event.transaction.hash, event.logIndex)
  const entity = new PollVote(id)
  entity.pollId = event.params.pollId.toHex()
  entity.voter = event.params.voter.toHex()
  entity.optionIndex = event.params.optionIndex
  entity.stake = event.params.stake
  entity.blockNumber = event.block.number
  entity.timestamp = event.block.timestamp
  entity.save()
}

export function handlePollRewardClaimed(event: PollRewardClaimed): void {
  const id = eventId(event.transaction.hash, event.logIndex)
  const entity = new PollRewardClaim(id)
  entity.pollId = event.params.pollId.toHex()
  entity.claimant = event.params.claimant.toHex()
  entity.amount = event.params.amount
  entity.blockNumber = event.block.number
  entity.timestamp = event.block.timestamp
  entity.save()
}

export function handleReviewUpvoted(event: ReviewUpvoted): void {
  const id = eventId(event.transaction.hash, event.logIndex)
  const entity = new ReviewUpvote(id)
  entity.projectId = event.params.projectId.toHex()
  entity.reviewIndex = event.params.reviewIndex
  entity.upvoter = event.params.upvoter.toHex()
  entity.author = event.params.author.toHex()
  entity.totalAmount = event.params.totalAmount
  entity.protocolFee = event.params.protocolFee
  entity.authorAmount = event.params.totalAmount.minus(event.params.protocolFee)
  entity.blockNumber = event.block.number
  entity.timestamp = event.block.timestamp
  entity.save()
}
