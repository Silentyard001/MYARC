-- =============================================================================
-- MYARC — Phase 3b: Secure Admin Authorization
-- Migration: 20260929_phase3b_admin_auth.sql
--
-- Replaces the self-asserted x-owner-address HTTP header mechanism with a
-- cryptographically verified JWT wallet_address claim.
--
-- WHY THE OLD MECHANISM WAS INSECURE
-- ────────────────────────────────────
-- The previous RLS policies compared:
--   lower(current_setting('request.headers')::json->>'x-owner-address')
--   = lower('<OWNER_ADDRESS>')
--
-- The x-owner-address header was set by the frontend (getAdminClient) and
-- sent with the public anon key. Because the anon key is public and the
-- owner address is visible on-chain, any browser could craft a request with
-- the correct header and bypass the RLS gate entirely.
--
-- THE NEW MECHANISM
-- ──────────────────
-- The new policies check the 'wallet_address' claim inside the authenticated
-- JWT, which is set server-side by the auth-verify Edge Function after
-- cryptographic signature verification (EIP-191 personal_sign). This claim
-- cannot be forged by a browser: it would require knowledge of
-- SUPABASE_JWT_SECRET, which is only available inside Edge Functions.
--
-- The policy expression:
--   (current_setting('request.jwt.claims', true)::json->>'wallet_address')
--
-- reads from the signed JWT, not from any client-supplied header.
--
-- SAFE TO RUN ON AN EXISTING DATABASE
-- ─────────────────────────────────────
-- This migration:
--   1. Drops the old header-based owner policies (if they exist).
--   2. Creates new JWT-claim-based owner policies on all affected tables.
--   3. Preserves all table structures, data, and non-admin policies.
--   4. Does not touch arc_rep or any other schema.
--
-- Run once in the Supabase SQL editor.
-- =============================================================================

-- ---------------------------------------------------------------------------
-- Helper: extract the wallet_address claim from the current authenticated JWT.
-- Returns null when called without an authenticated session (anon role).
-- ---------------------------------------------------------------------------
create or replace function myarc_jwt_wallet()
returns text
language sql
stable
security definer
set search_path = public
as $$
  select nullif(
    current_setting('request.jwt.claims', true)::json->>'wallet_address',
    ''
  )
$$;

-- ---------------------------------------------------------------------------
-- 1. featured_projects
-- ---------------------------------------------------------------------------
drop policy if exists "owner write"   on featured_projects;
drop policy if exists "admin write"   on featured_projects;

create policy "admin_jwt_write" on featured_projects
  for all
  to authenticated
  using (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  )
  with check (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  );

-- ---------------------------------------------------------------------------
-- 2. sponsored_polls
-- ---------------------------------------------------------------------------
drop policy if exists "owner write"   on sponsored_polls;
drop policy if exists "admin write"   on sponsored_polls;

create policy "admin_jwt_write" on sponsored_polls
  for all
  to authenticated
  using (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  )
  with check (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  );

-- ---------------------------------------------------------------------------
-- 3. revenue_entries
-- ---------------------------------------------------------------------------
drop policy if exists "owner write"   on revenue_entries;
drop policy if exists "admin write"   on revenue_entries;

create policy "admin_jwt_write" on revenue_entries
  for all
  to authenticated
  using (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  )
  with check (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  );

-- ---------------------------------------------------------------------------
-- 4. onchain_polls
-- ---------------------------------------------------------------------------
drop policy if exists "owner write"   on onchain_polls;
drop policy if exists "admin write"   on onchain_polls;

create policy "admin_jwt_write" on onchain_polls
  for all
  to authenticated
  using (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  )
  with check (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  );

-- ---------------------------------------------------------------------------
-- 5. submitted_projects
-- Owner can approve/reject; anon insert remains open.
-- ---------------------------------------------------------------------------
drop policy if exists "owner manage"  on submitted_projects;
drop policy if exists "admin manage"  on submitted_projects;

create policy "admin_jwt_manage" on submitted_projects
  for all
  to authenticated
  using (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  )
  with check (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  );

-- ---------------------------------------------------------------------------
-- 6. announcements
-- ---------------------------------------------------------------------------
drop policy if exists "owner write"   on announcements;
drop policy if exists "admin write"   on announcements;

create policy "admin_jwt_write" on announcements
  for all
  to authenticated
  using (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  )
  with check (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  );

-- ---------------------------------------------------------------------------
-- 7. blacklisted_wallets
-- ---------------------------------------------------------------------------
drop policy if exists "owner write"   on blacklisted_wallets;
drop policy if exists "admin write"   on blacklisted_wallets;

create policy "admin_jwt_write" on blacklisted_wallets
  for all
  to authenticated
  using (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  )
  with check (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  );

-- ---------------------------------------------------------------------------
-- 8. project_edit_log
-- ---------------------------------------------------------------------------
drop policy if exists "owner write"   on project_edit_log;
drop policy if exists "admin write"   on project_edit_log;

create policy "admin_jwt_write" on project_edit_log
  for all
  to authenticated
  using (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  )
  with check (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  );

-- ---------------------------------------------------------------------------
-- 9. review_moderation
-- ---------------------------------------------------------------------------
drop policy if exists "owner write"   on review_moderation;
drop policy if exists "admin write"   on review_moderation;

create policy "admin_jwt_write" on review_moderation
  for all
  to authenticated
  using (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  )
  with check (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  );

-- ---------------------------------------------------------------------------
-- 10. pinned_reviews
-- ---------------------------------------------------------------------------
drop policy if exists "owner write"   on pinned_reviews;
drop policy if exists "admin write"   on pinned_reviews;

create policy "admin_jwt_write" on pinned_reviews
  for all
  to authenticated
  using (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  )
  with check (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  );

-- ---------------------------------------------------------------------------
-- 11. review_responses
-- ---------------------------------------------------------------------------
drop policy if exists "owner write"   on review_responses;
drop policy if exists "admin write"   on review_responses;

create policy "admin_jwt_write" on review_responses
  for all
  to authenticated
  using (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  )
  with check (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  );

-- ---------------------------------------------------------------------------
-- 12. project_overrides
-- ---------------------------------------------------------------------------
drop policy if exists "owner write"   on project_overrides;
drop policy if exists "admin write"   on project_overrides;

create policy "admin_jwt_write" on project_overrides
  for all
  to authenticated
  using (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  )
  with check (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  );

-- ---------------------------------------------------------------------------
-- 13. profiles — admin management (separate from the user's own profile write)
-- Allows the admin to clear usernames, modify visibility, etc.
-- The profiles_authenticated_write policy (from phase3_auth.sql) already
-- allows authenticated users to write their own row. This additive policy
-- allows the admin to write ANY row.
-- ---------------------------------------------------------------------------
drop policy if exists "admin_profile_manage" on profiles;

create policy "admin_profile_manage" on profiles
  for all
  to authenticated
  using (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  )
  with check (
    lower(myarc_jwt_wallet()) = lower('0x551f1372eBf01fB6650863909f9dAe6EE88d04bA')
  );

-- =============================================================================
-- DEPLOYMENT NOTES
-- ─────────────────
-- 1. Run this migration AFTER the Phase 3 auth flow is deployed and the admin
--    wallet has signed in at least once (so auth-verify has stored the
--    wallet_address claim in the JWT).
-- 2. The owner address 0x551f1372eBf01fB6650863909f9dAe6EE88d04bA is the
--    MYARC contract owner verified on-chain via owner(). Update it here if
--    the owner is ever transferred.
-- 3. The myarc_jwt_wallet() function is security-definer so it reads from the
--    JWT claims of the session making the request — it cannot be spoofed by
--    setting a custom header.
-- =============================================================================
