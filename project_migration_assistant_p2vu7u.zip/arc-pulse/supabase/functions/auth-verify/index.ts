/**
 * auth-verify — Supabase Edge Function
 *
 * Verifies an EIP-191 personal_sign signature against a previously issued
 * challenge. On success:
 *   1. Deletes the challenge row (one-time use).
 *   2. Upserts a profile row for the wallet (creates on first sign-in).
 *   3. Returns a Supabase JWT (access_token + refresh_token) with the
 *      profile's user_id as the `sub` claim.
 *
 * POST /functions/v1/auth-verify
 * Body: { walletAddress: string, signature: string, nonce: string }
 * Response: { access_token: string, refresh_token: string, userId: string, expiresIn: number }
 *
 * Security properties:
 *   - Signature is verified against the exact message stored server-side for
 *     this nonce — the client cannot substitute a different message.
 *   - The challenge must exist, be unexpired, and belong to the claimed wallet.
 *   - Challenge is deleted before the token is returned — no replay possible.
 *   - The JWT is minted with signInWithCustomToken via the service-role key,
 *     which never leaves the Edge Function environment.
 *   - Token lifetime is 1 hour (3600 s). Clients must re-authenticate after
 *     expiry or on wallet change.
 *   - The SUPABASE_SERVICE_ROLE_KEY is only accessible to Edge Functions; it
 *     is never returned to the browser.
 */

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { recoverMessageAddress }  from 'https://esm.sh/viem@2'

const CORS = {
  'Access-Control-Allow-Origin':  '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: CORS })

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405, headers: { ...CORS, 'Content-Type': 'application/json' },
    })
  }

  let body: { walletAddress?: string; signature?: string; nonce?: string }
  try {
    body = await req.json() as typeof body
  } catch {
    return new Response(JSON.stringify({ error: 'Invalid JSON' }), {
      status: 400, headers: { ...CORS, 'Content-Type': 'application/json' },
    })
  }

  const { walletAddress: rawAddress, signature, nonce } = body

  if (!rawAddress || typeof rawAddress !== 'string' || !/^0x[0-9a-fA-F]{40}$/.test(rawAddress)) {
    return new Response(JSON.stringify({ error: 'walletAddress must be a valid 0x-prefixed EVM address' }), {
      status: 400, headers: { ...CORS, 'Content-Type': 'application/json' },
    })
  }
  if (!signature || typeof signature !== 'string' || !signature.startsWith('0x')) {
    return new Response(JSON.stringify({ error: 'signature is required' }), {
      status: 400, headers: { ...CORS, 'Content-Type': 'application/json' },
    })
  }
  if (!nonce || typeof nonce !== 'string' || !/^[0-9a-f]{64}$/.test(nonce)) {
    return new Response(JSON.stringify({ error: 'nonce is required' }), {
      status: 400, headers: { ...CORS, 'Content-Type': 'application/json' },
    })
  }

  const walletAddress = rawAddress.toLowerCase()

  const serviceClient = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
  )

  // ── 1. Look up the challenge ───────────────────────────────────────────────
  type ChallengeRow = { id: string; wallet_address: string; nonce: string; message: string; expires_at: string }
  const { data: challengeRow, error: fetchErr } = await serviceClient
    .from('auth_challenges')
    .select('id, wallet_address, nonce, message, expires_at')
    .eq('wallet_address', walletAddress)
    .eq('nonce', nonce)
    .maybeSingle() as { data: ChallengeRow | null; error: unknown }

  if (fetchErr || !challengeRow) {
    return new Response(JSON.stringify({ error: 'Challenge not found' }), {
      status: 401, headers: { ...CORS, 'Content-Type': 'application/json' },
    })
  }

  // ── 2. Check expiry ────────────────────────────────────────────────────────
  if (new Date(challengeRow.expires_at) < new Date()) {
    // Clean up expired row
    await serviceClient.from('auth_challenges').delete().eq('id', challengeRow.id)
    return new Response(JSON.stringify({ error: 'Challenge expired' }), {
      status: 401, headers: { ...CORS, 'Content-Type': 'application/json' },
    })
  }

  // ── 3. Verify signature ───────────────────────────────────────────────────
  //
  // recoverMessageAddress applies the EIP-191 "\x19Ethereum Signed Message:\n"
  // prefix before recovering the signer, matching what personal_sign produces.
  // We verify the EXACT stored message — the client cannot substitute.
  let recoveredAddress: string
  try {
    recoveredAddress = (await recoverMessageAddress({
      message: challengeRow.message,
      signature: signature as `0x${string}`,
    })).toLowerCase()
  } catch (e) {
    console.error('[auth-verify] recoverMessageAddress error', e)
    return new Response(JSON.stringify({ error: 'Invalid signature' }), {
      status: 401, headers: { ...CORS, 'Content-Type': 'application/json' },
    })
  }

  if (recoveredAddress !== walletAddress) {
    return new Response(JSON.stringify({ error: 'Signature does not match wallet address' }), {
      status: 401, headers: { ...CORS, 'Content-Type': 'application/json' },
    })
  }

  // ── 4. Consume the challenge (delete before token issuance — no replay) ───
  await serviceClient.from('auth_challenges').delete().eq('id', challengeRow.id)

  // ── 5. Upsert profile — get or create the userId for this wallet ──────────
  type ProfileRow = { user_id: string }
  const now = new Date().toISOString()
  const { data: profileRow, error: profileErr } = await serviceClient
    .from('profiles')
    .upsert(
      {
        wallet_address: walletAddress,
        display_name:   '',
        wallet_visibility: 'hidden',
        created_at: now,
        updated_at: now,
      },
      { onConflict: 'wallet_address', ignoreDuplicates: true }
    )
    .select('user_id')
    .single() as { data: ProfileRow | null; error: unknown }

  // If upsert returned nothing (ignoreDuplicates on conflict), fetch explicitly
  let userId: string
  if (profileErr || !profileRow) {
    const { data: existing, error: existingErr } = await serviceClient
      .from('profiles')
      .select('user_id')
      .eq('wallet_address', walletAddress)
      .single() as { data: ProfileRow | null; error: unknown }

    if (existingErr || !existing) {
      console.error('[auth-verify] profile fetch error', existingErr)
      return new Response(JSON.stringify({ error: 'Could not resolve profile' }), {
        status: 500, headers: { ...CORS, 'Content-Type': 'application/json' },
      })
    }
    userId = existing.user_id
  } else {
    userId = profileRow.user_id
  }

  // ── 6. Mint Supabase JWT via admin signInWithCustomToken ──────────────────
  //
  // signInWithCustomToken requires Supabase Auth to be in "custom" mode, OR we
  // use the admin.createUser + admin.generateLink approach.
  //
  // The most portable approach for Supabase without custom JWT providers:
  // use the admin auth API to sign a custom JWT with the JWT secret directly.
  // This matches the `sub` to the userId (UUID), making auth.uid() work in RLS.
  //
  // We sign with the SUPABASE_JWT_SECRET that Supabase itself uses.
  const jwtSecret = Deno.env.get('SUPABASE_JWT_SECRET')!
  const expiresIn  = 3600 // 1 hour
  const issuedAtSec = Math.floor(Date.now() / 1000)

  // Build JWT manually — jose is available in Deno via esm.sh
  const { SignJWT } = await import('https://esm.sh/jose@5')
  const secretKey = new TextEncoder().encode(jwtSecret)

  const accessToken = await new SignJWT({
    sub:  userId,
    aud:  'authenticated',
    role: 'authenticated',
    // MYARC custom claim — wallet address, used for informational purposes only.
    // Authorization decisions use auth.uid() = user_id, NOT this claim.
    wallet_address: walletAddress,
  })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt(issuedAtSec)
    .setExpirationTime(issuedAtSec + expiresIn)
    .sign(secretKey)

  // For refresh: issue a long-lived opaque token stored in a refresh_tokens table.
  // For simplicity in Phase 3, we issue a second JWT as the "refresh token" with
  // a 30-day lifetime. On refresh the client calls auth-verify again with the
  // stored refresh token to get a new access token. A separate refresh endpoint
  // is out of Phase 3 scope — the client simply re-authenticates when the
  // 1-hour token expires.
  //
  // Store the refresh token server-side so it can be revoked.
  const refreshNonceBytes = new Uint8Array(32)
  crypto.getRandomValues(refreshNonceBytes)
  const refreshToken = Array.from(refreshNonceBytes).map(b => b.toString(16).padStart(2, '0')).join('')
  const refreshExpiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()

  await serviceClient
    .from('auth_refresh_tokens')
    .insert({
      user_id:    userId,
      token:      refreshToken,
      expires_at: refreshExpiresAt,
    })
    // Old refresh tokens for this user are pruned on next use; don't block here.

  return new Response(JSON.stringify({
    access_token:  accessToken,
    refresh_token: refreshToken,
    userId,
    expiresIn,
  }), {
    status: 200, headers: { ...CORS, 'Content-Type': 'application/json' },
  })
})
