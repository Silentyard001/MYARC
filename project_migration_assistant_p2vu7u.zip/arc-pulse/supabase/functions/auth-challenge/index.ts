/**
 * auth-challenge — Supabase Edge Function
 *
 * Issues a one-time, short-lived authentication challenge for a given wallet
 * address. The nonce is generated server-side and stored in the
 * `auth_challenges` table so the authoritative state never lives in the
 * browser.
 *
 * POST /functions/v1/auth-challenge
 * Body: { walletAddress: string }
 * Response: { nonce: string, issuedAt: string, expiresAt: string, message: string }
 *
 * The returned `message` is the exact text the client must pass to
 * `personal_sign` (EIP-191). It follows the EIP-4361 (SIWE) format so it is
 * human-readable in wallet confirmation dialogs.
 *
 * Security properties:
 *   - nonce is 32 random bytes (hex) generated with crypto.getRandomValues.
 *   - challenge expires in 5 minutes.
 *   - one challenge per wallet per request (old unused challenges for the same
 *     wallet are invalidated on each call so there is at most one live
 *     challenge per wallet at any time).
 *   - the challenge row is deleted by auth-verify on successful use.
 *   - the challenges table has a cron/cleanup job to purge expired rows
 *     (see migration).
 */

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const CORS = {
  'Access-Control-Allow-Origin':  '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: CORS })

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405, headers: { ...CORS, 'Content-Type': 'application/json' },
    })
  }

  let body: { walletAddress?: string }
  try {
    body = await req.json() as { walletAddress?: string }
  } catch {
    return new Response(JSON.stringify({ error: 'Invalid JSON' }), {
      status: 400, headers: { ...CORS, 'Content-Type': 'application/json' },
    })
  }

  const rawAddress = body.walletAddress
  if (!rawAddress || typeof rawAddress !== 'string' || !/^0x[0-9a-fA-F]{40}$/.test(rawAddress)) {
    return new Response(JSON.stringify({ error: 'walletAddress must be a valid 0x-prefixed EVM address' }), {
      status: 400, headers: { ...CORS, 'Content-Type': 'application/json' },
    })
  }
  const walletAddress = rawAddress.toLowerCase()

  // ── Generate nonce ─────────────────────────────────────────────────────────
  const nonceBytes = new Uint8Array(32)
  crypto.getRandomValues(nonceBytes)
  const nonce = Array.from(nonceBytes).map(b => b.toString(16).padStart(2, '0')).join('')

  const now       = new Date()
  const expiresAt = new Date(now.getTime() + 5 * 60 * 1000) // 5 minutes

  // ── Build SIWE-style message ───────────────────────────────────────────────
  const domain    = Deno.env.get('SITE_DOMAIN') ?? 'myarc.app'
  const chainId   = Deno.env.get('CHAIN_ID')    ?? '5042002'       // Arc Testnet (chain ID from viem/chains arcTestnet)
  const issuedAt  = now.toISOString()
  const message   = [
    `${domain} wants you to sign in with your Ethereum account:`,
    walletAddress,
    '',
    'Sign in to MYARC. This request will not trigger a blockchain transaction or cost any gas.',
    '',
    `URI: https://${domain}`,
    'Version: 1',
    `Chain ID: ${chainId}`,
    `Nonce: ${nonce}`,
    `Issued At: ${issuedAt}`,
    `Expiration Time: ${expiresAt.toISOString()}`,
  ].join('\n')

  // ── Persist to Supabase (service-role, bypasses RLS) ─────────────────────
  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
  )

  // Invalidate any existing unused challenge for this wallet (one live at a time)
  await supabase
    .from('auth_challenges')
    .delete()
    .eq('wallet_address', walletAddress)

  const { error: insertErr } = await supabase
    .from('auth_challenges')
    .insert({
      wallet_address: walletAddress,
      nonce,
      message,
      expires_at: expiresAt.toISOString(),
    })

  if (insertErr) {
    console.error('[auth-challenge] insert error', insertErr)
    return new Response(JSON.stringify({ error: 'Failed to issue challenge' }), {
      status: 500, headers: { ...CORS, 'Content-Type': 'application/json' },
    })
  }

  return new Response(JSON.stringify({ nonce, issuedAt, expiresAt: expiresAt.toISOString(), message }), {
    status: 200, headers: { ...CORS, 'Content-Type': 'application/json' },
  })
})
